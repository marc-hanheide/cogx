#ifndef _CANOPEN_NODE_CONFIG_H_
#define _CANOPEN_NODE_CONFIG_H_

#define NEURONICS_CANOPEN_APP NEURONICS_CANOPEN_APP_AXIS

//#include "axis_config.h"

#include <Golem/Device/Katana450/config_pdo.h>
#include <Golem/Device/Katana450/config_emcy.h>

#endif // _CANOPEN_NODE_CONFIG_H_
