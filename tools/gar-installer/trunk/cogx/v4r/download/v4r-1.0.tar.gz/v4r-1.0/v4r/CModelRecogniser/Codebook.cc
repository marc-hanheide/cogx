/**
 * $Id$
 * Johann Prankl, 2011-11-04
 * prankl@acin.tuwien.ac.at
 */


#include "Codebook.hh"

#define DEBUG


namespace P 
{

/**
 * Save the codebook
 */
bool Codebook::Save(const string &filename)
{
  cout<<"Save codebook to file: "<<filename<<"...";

  if (cbEntries.size()==0)
  {
    cout<<"No codebook available!"<<endl;
    return false;
  }

  ofstream out(filename.c_str());

  out<<cbEntries.size()<<' '<<cbEntries[0]->data.size()<<'\n';

  for (unsigned i=0; i<cbEntries.size(); i++)
  {
    CBEntry &ent = *cbEntries[i];
    for (unsigned j=0; j<ent.data.size(); j++)
    {
      out<<ent.data[j]<<' ';
    }
    out<<'\n';
  }
  
  out.close();

  cout<<"ok"<<endl;
  return true;
}




}







