/**
 * @file Annotation.cpp
 * @author Richtsfeld Andreas
 * @date November 2011
 * @version 0.1
 * @brief Annotation from file.
 */

#include<stdio.h>
#include "Annotation.h"

#include "opencv2/highgui/highgui.hpp"
#include "PCLUtils.h"

namespace pa
{
 
/**
 * @brief Constructor of class LoadAnnotation
 */
Annotation::Annotation()
{
  initialized = false;
  have_indices = false;
  have_pairs = false;
}

/**
 * @brief Destructor of class LoadAnnotation
 */
Annotation::~Annotation()
{}


void Annotation::init(std::string _ann_filename, 
                          int _cnt_min, int _cnt_max)
{
  cnt = 0;
  cnt_max = _cnt_max - _cnt_min;
  f_min = _cnt_min;
  f_max = _cnt_max;
  ann_filenames.clear();
  for(unsigned i= _cnt_min; i<_cnt_max+1; i++)
  {
    char ann_tmp_filename[1024];
    snprintf(ann_tmp_filename, 1024, _ann_filename.c_str(), i);
    ann_filenames.push_back(ann_tmp_filename);
  }
  initialized = true;
}

void Annotation::load(int width, std::vector<int> &annotation, bool show)
{
  if(!initialized) {
    printf("Annotation::load: Error: Annotation not initialized.\n");
    return;
  }
  if(cnt > cnt_max) {
    printf("Annotation::load: Warning: End of files reached: Abort.\n");
    return;
  }
  printf("Annotation::load image: %s\n", ann_filenames[cnt].c_str());
  
  have_indices = false;
  have_pairs = false;
  indices.resize(0);
  pairs.resize(0);
  max_annotation = 0;
  anno.resize(0);
  
  double scale = 640./width;
  int height = (int) 480/scale;
  IplImage *anno_image = cvLoadImage(ann_filenames[cnt].c_str(), CV_LOAD_IMAGE_GRAYSCALE);
  for(unsigned i=0; i<anno_image->height; i+=scale)
    for(unsigned j=0; j<anno_image->width; j+=scale)
    {
      int id = anno_image->imageData[i*anno_image->width + j];
      annotation.push_back(id);
      anno.push_back(id);
      if(id > max_annotation)
        max_annotation = id;
    }
  cnt++;
  
  if(show) {
    cv::Mat_<cv::Vec3b> anno_show_image;
    pclA::Anno2Image(annotation, max_annotation, width, height, anno_show_image);
    cv::imshow("Annotation", anno_show_image);
  }
}

void Annotation::setIndices(std::vector<pcl::PointIndices::Ptr> &_indices)
{
  if(_indices.size() < 2) {
    printf("Annotation::setIndices: Warning: Not enough patches to calculate pairs.\n");
  }
  indices = _indices; 
  have_indices = true;
}

void Annotation::calculate()
{
  if(!initialized || !have_indices) {
    printf("Annotation::calculate: Error: Annotation not initialized or no patch indices given.\n");
    return;
  }
    
  // Calculate for each patch the object number!
  int annoMaxLabel = 0;
  for(unsigned i=0; i<anno.size(); i++)
    if(anno[i] != -1)
      if(anno[i] > annoMaxLabel)
        annoMaxLabel = anno[i];
    
  std::vector<int> object_number;           // annotation number for each patch
  for(unsigned i=0; i<indices.size(); i++)  // for each patch
  {
    int nr_points[annoMaxLabel+1];
    for(unsigned j=0; j<=annoMaxLabel; j++)
      nr_points[j] = 0;
    for(unsigned j=0; j<indices[i]->indices.size(); j++)
    {
      if(anno[indices[i]->indices[j]] != -1)
        nr_points[anno[indices[i]->indices[j]]]++;
      else nr_points[0]++;
    }
  
    int max_nr_points = 0;
    int max_object = 0;
    for(unsigned j=0; j<=annoMaxLabel; j++)
    {
      if(nr_points[j] > max_nr_points)
      {
        max_nr_points = nr_points[j];
        max_object = j;
      }
    }
    object_number.push_back(max_object);
  } 
  
  // find all patches which belong together (without background)
  for(unsigned i=0; i<object_number.size(); i++) 
  {
    std::vector<int> patch;
    for(unsigned j=0; j<object_number.size(); j++)
      if(i != j && object_number[i] == object_number[j] && object_number[i] != 0)
        patch.push_back(j);
    pairs.push_back(patch);
  }
  have_pairs = true;
}

void Annotation::getResults(std::vector< std::vector<int> > &_results)
{
  if(!have_pairs) {
    printf("Annotation::load: Error: Annotation not initialized or no patch indices given.\n");
    return;
  }
  _results = pairs;
}


} // end pa



