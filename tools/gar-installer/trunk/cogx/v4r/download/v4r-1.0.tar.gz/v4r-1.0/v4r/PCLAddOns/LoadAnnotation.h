/**
 * @file Annotation.h
 * @author Richtsfeld Andreas
 * @date November 2011
 * @version 0.1
 * @brief Load annotation from file.
 */

#ifndef PA_ANNOTATION_H
#define PA_ANNOTATION_H

#include <string>
#include <vector>

namespace pa
{

/**
 * @brief Class Annotation
 */
class Annotation
{
private:
  int f_min, f_max;                                     ///< filename counter, maximum value
  std::vector<std::string> ann_filenames;               ///< filenames of annotation images

public:
  Annotation();
  ~Annotation();

  /** Initialize loading of annotation **/
  void init(std::string _ann_filename, 
            int _cnt_min, int _cnt_max);
  
  /** Load next annotation file **/
  void load(std::vector<unsigned> &annotation);
  
};

}

#endif

