/**
 * $Id$
 * Johann Prankl, 2011-11-04
 * prankl@acin.tuwien.ac.at
 */


#include "RNNCodebook.hh"

#define DEBUG


namespace P 
{

static const bool CmpMatchesDec(const cv::Ptr<ObjectMatches>& a, const cv::Ptr<ObjectMatches>& b)
{
  return (a->conf > b->conf);
}



RNNCodebook::RNNCodebook(cv::Ptr<cv::DescriptorMatcher> &descMatcher, Parameter _param)
 : optimized(false), N(0), param(_param)
{
  matcher = descMatcher;
}

RNNCodebook::~RNNCodebook()
{
}




/************************************** PRIVATE ************************************/





/************************************** PUBLIC ************************************/
/**
 * Clear the tree and delete all view links
 */
void RNNCodebook::clear()
{ 
  cbEntries.clear();
  descriptors = cv::Mat();
}

/**
 * Optimize
 * for now just copy descriptors to a dense matrix
 */
void RNNCodebook::Optimize()
{
  if (!descriptors.isContinuous())
  {
    cv::Mat_<float> tmp(descriptors.rows,descriptors.cols);
    descriptors.copyTo(tmp);
    descriptors = tmp;
  }

  if (param.useFlann)
  {
    if (flannMatcher.empty())
      flannMatcher = new cv::FlannBasedMatcher(
                     new cv::flann::KDTreeIndexParams(param.numTrees), 
                     new cv::flann::SearchParams(param.searchDepth) );
    
    vector<cv::Mat> descs;
    descs.push_back(descriptors);

    flannMatcher->clear();
    flannMatcher->add(descs);
    flannMatcher->train();

    optimized = true;
  }
}

/**
 * Insert a view to the codebook
 */
void RNNCodebook::InsertView(unsigned idxObject,unsigned idxView, std::vector<cv::Ptr<CModel> > &objs, bool incExtend)
{
  View &view = *objs[idxObject]->views[idxView];

  if (incExtend || cbEntries.size()==0)
  {
    float sqrThrDesc = PMath::Sqr(param.thrDesc);
    std::vector<cv::Ptr<CBEntry> > cb(cbEntries);
    cbEntries.clear();

    for (unsigned k=0; k<view.keys.size(); k++)
      cb.push_back(new CBEntry(N, &view.descriptors(k,0), view.descriptors.cols, 
                               idxObject, idxView, k, sqrThrDesc));    

    ClusterEntries(cb);
  }
  else
  {
    int idx;
    float dist;

    for (unsigned k=0; k<view.keys.size(); k++)
    {
      idx=GetNearestNeighbour(&view.descriptors(k,0), view.descriptors.cols, cbEntries,dist);
      cbEntries[idx]->InsertOccurrence(idxObject,idxView,k);
    }
  }
  
  optimized = true;
}

/**
 * init for each occurrence one codebook entry
 */
void RNNCodebook::InitCodebook(std::vector<cv::Ptr<CModel> > &objs,
                               std::vector< cv::Ptr<CBEntry> > &cb)
{
  float sqrThrDesc = PMath::Sqr(param.thrDesc);
  for (unsigned i=0; i<objs.size(); i++)
  {
    for (unsigned j=0; j<objs[i]->views.size(); j++)
    {
      View &view = *objs[i]->views[j]; 
      for (unsigned k=0; k<view.keys.size(); k++)
      {
        cb.push_back(new CBEntry(N, &view.descriptors(k,0), view.descriptors.cols, i, j, k, sqrThrDesc));
      }

    }
  }
}

/**
 * find nearest neighbour of CodebookEntries
 */
int RNNCodebook::GetNearestNeighbour(float *d, int size, std::vector< cv::Ptr<CBEntry> > &cb, float &dist)
{
  int idx = INT_MAX;
  float dist2;
  dist=FLT_MAX;

  for (unsigned i=0; i<cb.size(); i++)
  {
    dist2 = CBEntry::DistSqr(&cb[i]->data[0], d, size);
    if (dist2 < dist)
    {
      dist = dist2;
      idx = i;
    }
  }

  return idx;
}

/**
 * find nearest neighbour of CodebookEntries
 */
int RNNCodebook::GetNearestNeighbour(CBEntry &cbe, std::vector<cv::Ptr<CBEntry> > &cb, float &sim)
{
  int idx = INT_MAX;
  float sim2;
  sim = -FLT_MAX;

  for (unsigned i=0; i<cb.size(); i++)
  {
    sim2 = -(cbe.sqrSigma + cb[i]->sqrSigma + cbe.DistSqr(*cb[i]));
    if (sim2 > sim)
    {
      sim = sim2;
      idx = i;
    }
  }

  return idx;
}

/**
 * Agglomerate
 */
void RNNCodebook::Agglomerate(CBEntry &src, CBEntry &dst)
{
  float sum = src.occurrences.size()+dst.occurrences.size();
  dst.sqrSigma = 1./(sum) * (
              src.occurrences.size()*src.sqrSigma +
              dst.occurrences.size()*dst.sqrSigma +
              src.occurrences.size()*dst.occurrences.size() / sum  *
              src.DistSqr(dst) );

  //compute new mean model of two clusters
  dst.Mul(dst.occurrences.size());
  src.Mul(src.occurrences.size());

  dst.Add(src);
  dst.Mul( 1./sum );

  //add occurrences from c
  for (unsigned i=0; i<src.occurrences.size(); i++)
  {
    Occurrence &occ = src.occurrences[i];
    dst.InsertOccurrence(occ.object, occ.view, occ.key);
  }
}

/**
 * TryMergeSmallEntries
 */
void RNNCodebook::TryMergeSmallEntries(std::vector<cv::Ptr<CBEntry> > &cb)
{
  float dist;
  float sqrThr2 = PMath::Sqr(1./param.nnRatio * param.thrCluster);

  for (unsigned i=0; i<cbEntries.size(); i++)
  {
    if (cbEntries[i]->occurrences.size()==1)
    {
      for (unsigned j=0; j<cbEntries.size(); j++)
      {
        if (i!=j)
        {
          if (cbEntries[j]->occurrences.size() > 1)
          {
            if(cbEntries[i]->DistSqr(*cbEntries[j]) < sqrThr2)
            {
              Agglomerate(*cbEntries[i], *cbEntries[j]);
              cbEntries.erase(cbEntries.begin()+i);
              i--;
              break;
            }
          }
        }
      }
    }
  }
}


/**
 * CreateCodebook
 */
void RNNCodebook::ClusterEntries(std::vector<cv::Ptr<CBEntry> > &cb)
{
  int nn, last;
  float sim;
  std::vector<float> lastsim;
  std::vector<cv::Ptr<CBEntry> > chain;
  std::vector<cv::Ptr<CBEntry> > remaining;

  clear();
  remaining = cb;

  if (remaining.size()==0)
    return;

  last=0;
  lastsim.push_back(-FLT_MAX);

  chain.push_back(remaining.back());
  remaining.pop_back();
  float sqrThr = -param.thrCluster*param.thrCluster;


  while (remaining.size()!=0){
    nn = GetNearestNeighbour(*chain[last], remaining, sim);

    if(sim > lastsim[last]){
      //no RNN -> add to chain
      last++;
      chain.push_back(remaining[nn]);
      remaining.erase(remaining.begin()+nn);
      lastsim.push_back(sim);
    }else{
      //RNN found
      if (lastsim[last] > sqrThr){
        Agglomerate(*chain[last-1], *chain[last]);
        remaining.push_back(chain[last]);
        chain.pop_back();
        chain.pop_back();
        lastsim.pop_back();
        lastsim.pop_back();
        last-=2;
      }else{
        //cluster found set codebook
        for (unsigned i=0; i<chain.size(); i++){
          cbEntries.push_back(chain[i]);
        }
        chain.clear();
        lastsim.clear();
        last=-1;
      }
    }

    if (last<0){
      //init new chain
      last++;
      lastsim.push_back(-FLT_MAX);

      chain.push_back(remaining.back());
      remaining.pop_back();
    }
  }

  #ifdef DEBUG
  cout<<"cbEntries.size()="<<cbEntries.size()<<endl;
  #endif

  // try merge small clusters
  if (param.tryMergeSmallClusters)
    TryMergeSmallEntries(cbEntries);

  descriptors = cv::Mat_<float>(cbEntries.size(),cbEntries[0]->data.size());

  for (unsigned i=0; i<cbEntries.size(); i++)
  {
    cbEntries[i]->copyTo(&descriptors(i,0));
  }

  optimized = true;

  #ifdef DEBUG
  cout<<"After post processing cbEntries.size()="<<cbEntries.size()<<endl;
  #endif
}


/**
 * CreateCodebook
 */
void RNNCodebook::CreateCodebook(std::vector<cv::Ptr<CModel> > &objs)
{
  std::vector<cv::Ptr<CBEntry> > occs;

  clear();
  InitCodebook(objs, occs);

  ClusterEntries(occs);
}

/**
 * Query an object view
 * @param matches <object_idx, matches>
 */
void RNNCodebook::QueryObjects(cv::Mat_<float> &queryDescriptors, map<unsigned, vector<cv::DMatch> > &matches)
{
  matches.clear();
  if (descriptors.empty())
    return;

  // match
  vector<vector<cv::DMatch> > tmpMatches;

  if (param.useFlann && optimized)
  {
    cout<<"Use FLANN for matching!"<<endl;
    flannMatcher->knnMatch(queryDescriptors, tmpMatches, 2);
  }
  else
    matcher->knnMatch(queryDescriptors, descriptors, tmpMatches, 2);

  // get object matches
  for (unsigned i=0; i<tmpMatches.size();i++)
  {
    if (tmpMatches[i].size()==1 ||
        (tmpMatches[i].size()==2 && tmpMatches[i][0].distance/tmpMatches[i][1].distance<param.nnRatio) )
    {
      CBEntry &entry = *cbEntries[tmpMatches[i][0].trainIdx];
      for (unsigned j=0; j<entry.occurrences.size(); j++)
      {
        Occurrence &occ = entry.occurrences[j];
        matches[occ.object].push_back(cv::DMatch(tmpMatches[i][0].queryIdx, occ.key, occ.view, entry.wi));
      }
    }
  }

}

/**
 * Load codebook
 */
bool RNNCodebook::Load(const string &filename)
{
  cout<<"Load codebook from file: "<<filename<<"...";

  ifstream in(filename.c_str());

  if (in.is_open())
  {
    int numEntries, size;
    float sqrThrDesc = PMath::Sqr(param.thrDesc);
    
    in>>numEntries>>size;

    cbEntries.resize(numEntries);
    descriptors = cv::Mat_<float>(numEntries,size);
    for (unsigned i=0; i<numEntries; i++)
    {
      cbEntries[i] = new CBEntry(N, sqrThrDesc);
      CBEntry &ent = *cbEntries[i];
      ent.data.resize(size);
      for (unsigned j=0; j<size; j++)
        in>>ent.data[j];
      ent.copyTo(&descriptors(i,0));
    }

    cout<<"codebook size="<<cbEntries.size()<<", ok"<<endl;
    return true;
  }

  cout << "failed"<<endl;
  return false;

} 


}







