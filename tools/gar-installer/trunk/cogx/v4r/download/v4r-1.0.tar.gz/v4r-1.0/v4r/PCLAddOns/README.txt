PCL Add Ons
===========

Requirements:
-------------
- OpenCV
- PCL
- Kinect


Implementations:
----------------
- PlanePopout (with dominant plane, ROI and SOI calculation)
- ModelFitter: Fitting different shape models (plane, cylinder, sphere) in point cloud.
- LoadAnnotion: For loading annotations, made by the plane-annotation app.
- PCLFunctions: Several functions used with PCL library
- PCLUtils: Mainly convert functions or "little helpers"


------------------
Andreas Richtsfeld
Automation and Control Institute
Vienna University of Technology
ari@acin.tuwien.ac.at
skype: andreas.richtsfeld

