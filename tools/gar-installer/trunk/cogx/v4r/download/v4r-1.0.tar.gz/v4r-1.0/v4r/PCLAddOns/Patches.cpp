/**
 * @file Patches.cpp
 * @author Richtsfeld
 * @date November 2011
 * @version 0.1
 * @brief Calculate patch relations
 */

#include "Patches.h"
#include "v4r/PCLAddOns/PCLUtils.h"
#include "v4r/PCLAddOns/PCLFunctions.h"
#include <opencv/highgui.h>

namespace pclA
{


/************************************************************************************
 * Constructor/Destructor
 */

Patches::Patches()
{
  have_input_cloud = false;
  have_patches = false;
  have_neighbors = false;
  z_max = 0.01; // 1cm
  nr_hist_bins = 10;
}

Patches::~Patches()
{}

// ================================= Private functions ================================= //

void Patches::preprocess()
{
  // prepare color histograms
  for(unsigned i=0; i<pcl_model_types.size(); i++)
    hist.push_back(new ColorHistogram(nr_hist_bins));
  
  for(unsigned i=0; i<pcl_model_types.size(); i++) {
    hist[i]->setColorModelYUV();
    hist[i]->setInputCloud(pcl_cloud);
    hist[i]->setIndices(pcl_model_cloud_indices[i]);
    hist[i]->compute();
  }
  
  // prepare normals for planes (all normals of plane set to plane normal)
  cv::Vec3f plane_normal;
  for(unsigned i=0; i<pcl_model_types.size(); i++) 
  {
    if(pcl_model_types[i] == pcl::SACMODEL_NORMAL_PLANE || 
      (pcl_model_types[i] == pcl::SACMODEL_PLANE)) 
    {
      if(model_coefficients[i]->values[3] < 0.) {
        plane_normal[0] = -model_coefficients[i]->values[0];
        plane_normal[1] = -model_coefficients[i]->values[1];
        plane_normal[2] = -model_coefficients[i]->values[2];
      }
      else {
        plane_normal[0] = model_coefficients[i]->values[0];
        plane_normal[1] = model_coefficients[i]->values[1];
        plane_normal[2] = model_coefficients[i]->values[2];
      }
      for(unsigned idx=0; idx<pcl_model_cloud_indices[i]->indices.size(); idx++)
      {
        int pos = pcl_model_cloud_indices[i]->indices[idx];
        pcl_normals->points[pos].normal_x = plane_normal[0];
        pcl_normals->points[pos].normal_y = plane_normal[1];
        pcl_normals->points[pos].normal_z = plane_normal[2];
      }
    }
  }
}

/** Calculate relations on the border of the patches **/
/** color, depth, mask, curvature **/
bool Patches::CalculateBorderRelation(int p0, int p1, 
                                      std::vector<double> &rel_value)
{
  rel_value.resize(0);
  p0++; p1++;  // indices on patches starting with 1!
  
  int first = 0;
  int second = 0;
  std::vector<int> first_ngbr;
  std::vector<int> second_ngbr;
 
  for(int row=1; row<patches.rows; row++) {
    for(int col=1; col<patches.cols; col++) {
      bool found = false;
      if((patches.at<cv::Vec3b>(row, col)[0] == p0 && patches.at<cv::Vec3b>(row-1, col-1)[0] == p1) ||
         (patches.at<cv::Vec3b>(row, col)[0] == p1 && patches.at<cv::Vec3b>(row-1, col-1)[0] == p0)) {
        first = row*patches.cols + col;
        second = (row-1)*patches.cols + col-1;
        found = true;
      }
      if((patches.at<cv::Vec3b>(row, col)[0] == p0 && patches.at<cv::Vec3b>(row-1, col+1)[0] == p1) ||
         (patches.at<cv::Vec3b>(row, col)[0] == p1 && patches.at<cv::Vec3b>(row-1, col+1)[0] == p0)) {
        first = row*patches.cols + col;
        second = (row-1)*patches.cols + col-1;
        found = true;
      }
      if((patches.at<cv::Vec3b>(row, col)[0] == p0 && patches.at<cv::Vec3b>(row-1, col)[0] == p1) ||
         (patches.at<cv::Vec3b>(row, col)[0] == p1 && patches.at<cv::Vec3b>(row-1, col)[0] == p0)) {
        first = row*patches.cols + col;
        second = (row-1)*patches.cols + col;
        found = true;
      }
      if((patches.at<cv::Vec3b>(row, col)[0] == p0 && patches.at<cv::Vec3b>(row, col-1)[0] == p1) ||
         (patches.at<cv::Vec3b>(row, col)[0] == p1 && patches.at<cv::Vec3b>(row, col-1)[0] == p0)) {
        first = row*patches.cols + col;
        second = row*patches.cols + col-1;
        found = true;
      }
      if(found) {
        first_ngbr.push_back(first);
        second_ngbr.push_back(second);
      }
    }
  }
  
  int nr_valid_points_color = 0;
  int nr_valid_points_depth = 0;
  int nr_valid_points_curvature = 0;
  double sum_uv_color_distance = 0.;
  double sum_curvature = 0.;
  double sum_depth = 0.;
  for(unsigned i=0; i<first_ngbr.size(); i++)
  {
    /// calculate color similarity
    nr_valid_points_color++;
    RGBValue p0_color, p1_color;
    p0_color.float_value = pcl_cloud->points[first_ngbr[i]].rgb;
    p1_color.float_value = pcl_cloud->points[second_ngbr[i]].rgb;

//     double p0_Y =  (0.257 * p0_color.r) + (0.504 * p0_color.g) + (0.098 * p0_color.b) + 16;
    double p0_U = -(0.148 * p0_color.r) - (0.291 * p0_color.g) + (0.439 * p0_color.b) + 128;
    double p0_V =  (0.439 * p0_color.r) - (0.368 * p0_color.g) - (0.071 * p0_color.b) + 128;
//     double p1_Y =  (0.257 * p1_color.r) + (0.504 * p1_color.g) + (0.098 * p1_color.b) + 16;
    double p1_U = -(0.148 * p1_color.r) - (0.291 * p1_color.g) + (0.439 * p1_color.b) + 128;
    double p1_V =  (0.439 * p1_color.r) - (0.368 * p1_color.g) - (0.071 * p1_color.b) + 128;
    
//     double y_1 = p0_Y/255 - p1_Y/255;
//     double y_2 = y_1 * y_1 * 100;
    double u_1 = p0_U/255 - p1_U/255;
    double u_2 = u_1 * u_1 * 100;
    double v_1 = p0_V/255 - p1_V/255;
    double v_2 = v_1 * v_1 * 100;
    double cDist = sqrt(u_2 + v_2);
    sum_uv_color_distance += cDist;
    
    /// calculate depth
    double p0_z = pcl_cloud->points[first_ngbr[i]].z;
    double p1_z = pcl_cloud->points[second_ngbr[i]].z;
    double depth = fabs(p0_z - p1_z);
    if(depth == depth) { // no nan
      nr_valid_points_depth++;
      sum_depth += depth;
    }
    
    /// calculate curvature
    cv::Vec3f pt0, pt1;
    pt0[0]= pcl_cloud->points[first_ngbr[i]].x;
    pt0[1]= pcl_cloud->points[first_ngbr[i]].y;
    pt0[2]= pcl_cloud->points[first_ngbr[i]].z;
    pt1[0]= pcl_cloud->points[second_ngbr[i]].x;
    pt1[1]= pcl_cloud->points[second_ngbr[i]].y;
    pt1[2]= pcl_cloud->points[second_ngbr[i]].z;
    
    if(pt0 == pt0 || pt1 == pt1)
    {
      cv::Vec3f p0_normal;
      p0_normal[0] = pcl_normals->points[first_ngbr[i]].normal_x;
      p0_normal[1] = pcl_normals->points[first_ngbr[i]].normal_y;
      p0_normal[2] = pcl_normals->points[first_ngbr[i]].normal_z;
      cv::Vec3f p1_normal;
      p1_normal[0] = pcl_normals->points[second_ngbr[i]].normal_x;
      p1_normal[1] = pcl_normals->points[second_ngbr[i]].normal_y;
      p1_normal[2] = pcl_normals->points[second_ngbr[i]].normal_z;
      cv::Vec3f pp = pt1 - pt0;

      double norm_pp = cv::norm(pp);
      cv::Vec3f pp_dir;
      pp_dir[0] = pp[0]/norm_pp;
      pp_dir[1] = pp[1]/norm_pp;
      pp_dir[2] = pp[2]/norm_pp;  

      double a_p0_pp = acos(p0_normal.ddot(pp_dir));
      pp_dir = -pp_dir; // invert direction between points
      double a_p1_pp = acos(p1_normal.ddot(pp_dir));
      if(a_p0_pp == a_p0_pp && a_p1_pp == a_p1_pp) {
        nr_valid_points_curvature++;
        sum_curvature += a_p0_pp+a_p1_pp - M_PI;
      }
      else printf("Patches::CalculateBorderRelation: Warning: Invalid curvature points: Should not happen!\n");
    }
  } 
  
  if(nr_valid_points_color != 0.)
    sum_uv_color_distance /= nr_valid_points_color;
  else printf("sum_color: %4.3f\n", sum_uv_color_distance);
  if(nr_valid_points_depth != 0.)
    sum_depth /= nr_valid_points_depth;
  else printf("sum_depth: %4.3f\n", sum_depth);
  if(nr_valid_points_curvature != 0.)
    sum_curvature /= nr_valid_points_curvature;
  else printf("sum_curvature: %4.3f\n", sum_curvature);

  rel_value.push_back(sum_uv_color_distance);
  rel_value.push_back(sum_depth);
  rel_value.push_back(0.0);                         /// TODO Mask is missing
  rel_value.push_back(sum_curvature);
  return true;
}

// ================================= Public functions ================================= //

void Patches::setZLimit(double _z_max)
{
  z_max = _z_max;
}  

void Patches::setInputCloud(pcl::PointCloud<pcl::PointXYZRGB>::Ptr &_pcl_cloud,
                            pcl::PointCloud<pcl::Normal>::Ptr &_pcl_normals)
{
  relations.resize(0);
  hist.resize(0);
  neighbors3D.resize(0);
  
  if(_pcl_cloud.get() == 0 || _pcl_cloud->points.size() == 0) {
    printf("Patches::setInputCloud: Error: Empty or invalid pcl-point-cloud.\n");
    return;
  } 
  pcl_cloud = _pcl_cloud;
  if(pcl_cloud->width <= 1 || pcl_cloud->height <=1)
    printf("Patches::setInputCloud: Warning: Point cloud is not ordered.\n");

  if(_pcl_normals.get() == 0 || _pcl_normals->points.size())
    pclA::NormalsFromSortedPCLCloud(pcl_cloud, pcl_normals, 0.02, 5.0);
  else
    pcl_normals = _pcl_normals;
  
  have_input_cloud = true;
  have_patches = false;
  have_neighbors = false;
}

void Patches::setPatches(const std::vector<int> &_pcl_model_types,
                         const std::vector<pcl::ModelCoefficients::Ptr> &_model_coefficients,
                         const std::vector<pcl::PointIndices::Ptr> &_pcl_model_cloud_indices)
{
  if(!have_input_cloud) {
  printf("Planes::setPlanes: Error: First set dense input cloud with correct resolution.\n");
  return;
  }
  if(pcl_cloud->width <= 1 || pcl_cloud->height <= 1) {
    printf("Planes::setPlanes: Error: Input cloud is not a correct matrix.\n");
    return;
  }
  patches = cv::Mat_<cv::Vec3b>(pcl_cloud->height, pcl_cloud->width);
  patches.setTo(0);
  for(unsigned i=0; i<_pcl_model_cloud_indices.size(); i++) {
    for(unsigned j=0; j<_pcl_model_cloud_indices[i]->indices.size(); j++) {
      int row = _pcl_model_cloud_indices[i]->indices[j] / pcl_cloud->width;
      int col = _pcl_model_cloud_indices[i]->indices[j] % pcl_cloud->width;
      patches.at<cv::Vec3b>(row, col)[0] = i+1;  /// plane 1,2,...,n
    }
  }
  nr_patches = _pcl_model_cloud_indices.size();
 
  pcl_model_types = _pcl_model_types;
  model_coefficients = _model_coefficients;
  pcl_model_cloud_indices = _pcl_model_cloud_indices;

  have_patches = true;
}


void Patches::computeNeighbors()
{
  if(!have_input_cloud || !have_patches) {
    printf("Planes::computeNeighbors: Error: No input cloud and patches available.\n");
    return;
  }

  neighbors2D.resize(0);
  neighbors3D.resize(0);

  bool nbgh_matrix3D[nr_patches+1][nr_patches+1];
  bool nbgh_matrix2D[nr_patches+1][nr_patches+1];
  for(int i=0; i<nr_patches+1; i++)
    for(int j=0; j<nr_patches+1; j++) {
      nbgh_matrix3D[i][j] = false;
      nbgh_matrix2D[i][j] = false;
    }
  
  for(int row=1; row<patches.rows; row++) {
    for(int col=1; col<patches.cols; col++) {
      if(patches.at<cv::Vec3b>(row, col)[0] != 0) {
        if(patches.at<cv::Vec3b>(row, col)[0] != patches.at<cv::Vec3b>(row-1, col)[0]) {
          if(patches.at<cv::Vec3b>(row-1, col)[0] != 0) {
            int pos_0 = row*pcl_cloud->width+col;
            int pos_1 = (row-1)*pcl_cloud->width+col;
            double dis = fabs(pcl_cloud->points[pos_0].z - pcl_cloud->points[pos_1].z);
            if( dis < z_max) {
              nbgh_matrix3D[patches.at<cv::Vec3b>(row-1, col)[0]][patches.at<cv::Vec3b>(row, col)[0]] = true;
              nbgh_matrix3D[patches.at<cv::Vec3b>(row, col)[0]][patches.at<cv::Vec3b>(row-1, col)[0]] = true;
            }
            nbgh_matrix2D[patches.at<cv::Vec3b>(row-1, col)[0]][patches.at<cv::Vec3b>(row, col)[0]] = true;
            nbgh_matrix2D[patches.at<cv::Vec3b>(row, col)[0]][patches.at<cv::Vec3b>(row-1, col)[0]] = true;
          }
        }
        if(patches.at<cv::Vec3b>(row, col)[0] != patches.at<cv::Vec3b>(row, col-1)[0]) {
          if(patches.at<cv::Vec3b>(row, col-1)[0] != 0) {
            int pos_0 = row*pcl_cloud->width+col;
            int pos_1 = row*pcl_cloud->width+col-1;
            double dis = fabs(pcl_cloud->points[pos_0].z - pcl_cloud->points[pos_1].z);
            if( dis < z_max) {
              nbgh_matrix3D[patches.at<cv::Vec3b>(row, col-1)[0]][patches.at<cv::Vec3b>(row, col)[0]] = true;
              nbgh_matrix3D[patches.at<cv::Vec3b>(row, col)[0]][patches.at<cv::Vec3b>(row, col-1)[0]] = true;
            }
            nbgh_matrix2D[patches.at<cv::Vec3b>(row, col-1)[0]][patches.at<cv::Vec3b>(row, col)[0]] = true;
            nbgh_matrix2D[patches.at<cv::Vec3b>(row, col)[0]][patches.at<cv::Vec3b>(row, col-1)[0]] = true;
          }
        }
        if(patches.at<cv::Vec3b>(row, col)[0] != patches.at<cv::Vec3b>(row-1, col-1)[0]) {
          if(patches.at<cv::Vec3b>(row-1, col-1)[0] != 0) {
            int pos_0 = row*pcl_cloud->width+col;
            int pos_1 = (row-1)*pcl_cloud->width+col-1;
            double dis = fabs(pcl_cloud->points[pos_0].z - pcl_cloud->points[pos_1].z);
            if( dis < z_max) {
              nbgh_matrix3D[patches.at<cv::Vec3b>(row-1, col-1)[0]][patches.at<cv::Vec3b>(row, col)[0]] = true;
              nbgh_matrix3D[patches.at<cv::Vec3b>(row, col)[0]][patches.at<cv::Vec3b>(row-1, col-1)[0]] = true;
            }
            nbgh_matrix2D[patches.at<cv::Vec3b>(row-1, col-1)[0]][patches.at<cv::Vec3b>(row, col)[0]] = true;
            nbgh_matrix2D[patches.at<cv::Vec3b>(row, col)[0]][patches.at<cv::Vec3b>(row-1, col-1)[0]] = true;
          }
        }
      }
    }
  }
  
  for(int i=1; i<nr_patches+1; i++) {
    std::vector<unsigned> neighbor;
    for(int j=1; j<nr_patches+1; j++) {
      if(nbgh_matrix3D[i][j])
        neighbor.push_back(j-1);
    }
    neighbors3D.push_back(neighbor);
  }
  for(int i=1; i<nr_patches+1; i++) {
    std::vector<unsigned> neighbor;
    for(int j=1; j<nr_patches+1; j++) {
      if(nbgh_matrix2D[i][j])
        neighbor.push_back(j-1);
    }
    neighbors2D.push_back(neighbor);
  }
  have_neighbors = true;
}


void Patches::computeTestRelations()
{
printf("Patches::computeTestRelations: start!\n"); 

  if(!have_input_cloud || !have_patches) {
    printf("Planes::computeNeighbors: Error: No input cloud and patches available.\n");
    return;
  }

  if(!have_neighbors)
    computeNeighbors();

  preprocess();
  
  for(unsigned i=0; i<neighbors2D.size(); i++) 
  {
    for(unsigned j=0; j<neighbors2D[i].size(); j++) 
    {
      int p0 = i;
      int p1 = neighbors2D[i][j];
      if(p0 > p1) continue;
      
      bool valid_relation = true;
      double colorSimilarity = hist[p0]->compare(hist[p1]);
// printf("ColorSimilarity [%u]-[%u]: %4.3f\n", p0, p1, colorSimilarity);

      std::vector<double> ppRelations;
      if(!CalculateBorderRelation(p0, p1, ppRelations))
        valid_relation = false;



//       if(p0->GetObjectLabel() != 0 && p0->GetObjectLabel() == px->GetObjectLabel())
//       {
// //         // calculate relation values
// //        double proximity = p0->CalculateProximity(px);              /// wie kann man proximity am besten berechnen?
// //         double n0n1, ppn0, ppn1;
// //         p0->CalculateCoplanarity2(px, n0n1, ppn0, ppn1);
// //         
// //         std::vector<double> segRelations;                       /// TODO Nur mehr für mask
// //         if(!CalculateSegmentRelations(p0, px, segRelations))
// //           valid_relation = false;
// // //         std::vector<double> colRelations;
// // //         if(!CalculatePPColorRelation(p0, px, colRelations))
// // //           valid_relation = false;
// //         std::vector<double> ppRelations;
// //         if(!CalculatePPRelation(p0, px, ppRelations))
// //           valid_relation = false;
// 
      if(valid_relation)
      {
        Relation r;
        r.groundTruth = 1;
        r.prediction = -1;
        r.type = 1;                                 /// TODO type is patch-patch ???
        r.id_0 = p0;
        r.id_1 = p1;
// //           r.rel_value.push_back(proximity);           // proximity of planes (minimum hull distance)
        r.rel_value.push_back(colorSimilarity);     // color similarity (histogram) of the patch 
// //           r.rel_value.push_back(n0n1);                // coplanarity: angle between patch-normals
// // //           r.rel_value.push_back(ppn0);                // angle between center point line and first patch normal
// // //           r.rel_value.push_back(ppn1);                // angle between center point line and second patch normal
// // //           r.rel_value.push_back(segRelations[0]);     // distance to first plane
// // //           r.rel_value.push_back(segRelations[1]);     // distance to second plane
// // //           r.rel_value.push_back(segRelations[2]);     // depth value
// //           r.rel_value.push_back(segRelations[3]);     // mask value /// TODO vorerst weglassen?
// // //           r.rel_value.push_back(segRelations[4]);     // curvature value
        r.rel_value.push_back(ppRelations[0]);     // color similarity between the plane patches (pixel-wise) 
        r.rel_value.push_back(ppRelations[1]);     // depth value between neighboring plane pixels
        r.rel_value.push_back(ppRelations[3]);     // curvature value between neighboring plane pixels
        relations.push_back(r);
printf("relation[%u][%u]: ", r.id_0, r.id_1);
for(unsigned ridx=0; ridx<r.rel_value.size(); ridx++)
  printf("%4.3f - ", r.rel_value[ridx]);
printf("\n");
      }
    }
  }


//   unsigned nrPatches = kcore->NumGestalts3D(Gestalt3D::PATCH);
//   for(unsigned i=0; i<nrPatches-1; i++)
//   {
//     Patch3D *p0 = (Patch3D*) kcore->Gestalts3D(Gestalt3D::PATCH, i);
//     for(unsigned j=i+1; j<nrPatches; j++)
//     {
//       Patch3D *px = (Patch3D*) kcore->Gestalts3D(Gestalt3D::PATCH, j);
//       
// // printf("  Calculate PP-Relation: %u-%u (%u-%u)\n", p0->GetNodeID(), px->GetNodeID(), p0->GetObjectLabel(), px->GetObjectLabel());
//       
//       // check if it belongs to the same object (ground truth) => True ground truth
//       bool valid_relation = true;
//       if(p0->GetObjectLabel() != 0 && p0->GetObjectLabel() == px->GetObjectLabel())
//       {
//         // calculate relation values
//         double proximity = p0->CalculateProximity(px);
//         double colorSimilarity = p0->CompareColor(px);
//         double n0n1, ppn0, ppn1;
//         p0->CalculateCoplanarity2(px, n0n1, ppn0, ppn1);
//         
//         std::vector<double> segRelations;                       /// TODO Nur mehr für mask
//         if(!CalculateSegmentRelations(p0, px, segRelations))
//           valid_relation = false;
// //         std::vector<double> colRelations;
// //         if(!CalculatePPColorRelation(p0, px, colRelations))
// //           valid_relation = false;
//         std::vector<double> ppRelations;
//         if(!CalculatePPRelation(p0, px, ppRelations))
//           valid_relation = false;
//        
// // printf(" PP True : %u-%u: %4.3f - %4.3f - %4.3f - %4.3f - %4.3f\n", p0->GetNodeID(), px->GetNodeID(), proximity, colorSimilarity, n0n1, ppn0, ppn1);
// // printf("  PP TRUE:\n");
//         if(valid_relation)
//         {
// // printf(" ==> valid\n");
//           Relation r;
//           r.groundTruth = 1;
//           r.prediction = -1;
//           r.type = 1;
//           r.id_0 = p0->GetNodeID();
//           r.id_1 = px->GetNodeID();
//           r.rel_value.push_back(proximity);           // proximity of planes (minimum hull distance)
//           r.rel_value.push_back(colorSimilarity);     // color similarity (histogram) of the patch 
//           r.rel_value.push_back(n0n1);                // coplanarity: angle between patch-normals
// //           r.rel_value.push_back(ppn0);                // angle between center point line and first patch normal
// //           r.rel_value.push_back(ppn1);                // angle between center point line and second patch normal
// //           r.rel_value.push_back(segRelations[0]);     // distance to first plane
// //           r.rel_value.push_back(segRelations[1]);     // distance to second plane
// //           r.rel_value.push_back(segRelations[2]);     // depth value
//           r.rel_value.push_back(segRelations[3]);     // mask value
// //           r.rel_value.push_back(segRelations[4]);     // curvature value
//           r.rel_value.push_back(ppRelations[0]);     // color similarity between the plane patches (pixel-wise) 
//           r.rel_value.push_back(ppRelations[1]);     // depth value between neighboring plane pixels
//           r.rel_value.push_back(ppRelations[3]);     // curvature value between neighboring plane pixels
//           relations.push_back(r);
//         }
//       }
//       else if((p0->GetObjectLabel() != 0 || px->GetObjectLabel() != 0) &&   // => False ground truth
//                p0->GetObjectLabel() != px->GetObjectLabel())
//       {
//         // calculate relation values
//         double proximity = p0->CalculateProximity(px);
//         double colorSimilarity = p0->CompareColor(px);
//         double n0n1, ppn0, ppn1;
//         p0->CalculateCoplanarity2(px, n0n1, ppn0, ppn1);
//         
//         std::vector<double> segRelations;                       /// TODO Nur mehr für mask
//         if(!CalculateSegmentRelations(p0, px, segRelations))
//           valid_relation = false;
// //         std::vector<double> colRelations;
// //         if(!CalculatePPColorRelation(p0, px, colRelations))
// //           valid_relation = false;
//         std::vector<double> ppRelations;
//         if(!CalculatePPRelation(p0, px, ppRelations))
//           valid_relation = false;
// 
// // printf("  PP FALSE:\n");
// 
// // printf(" PP False: %u-%u: %4.3f - %4.3f - %4.3f - %4.3f - %4.3f\n", p0->GetNodeID(), px->GetNodeID(), proximity, colorSimilarity, n0n1, ppn0, ppn1);
//         if(valid_relation)
//         {
// // printf("  ==> valid\n");
//           Relation r;
//           r.groundTruth = 0;
//           r.prediction = -1;
//           r.type = 1;
//           r.id_0 = p0->GetNodeID();
//           r.id_1 = px->GetNodeID();
//           r.rel_value.push_back(proximity);           // proximity of planes (minimum hull distance)
//           r.rel_value.push_back(colorSimilarity);     // color similarity (histogram) of the patch 
//           r.rel_value.push_back(n0n1);                // coplanarity: angle between patch-normals
// //           r.rel_value.push_back(ppn0);                // angle between center point line and first patch normal
// //           r.rel_value.push_back(ppn1);                // angle between center point line and second patch normal
// //           r.rel_value.push_back(segRelations[0]);     // distance to first plane
// //           r.rel_value.push_back(segRelations[1]);     // distance to second plane
// //           r.rel_value.push_back(segRelations[2]);     // depth value
//           r.rel_value.push_back(segRelations[3]);     // mask value
// //           r.rel_value.push_back(segRelations[4]);     // curvature value
//           r.rel_value.push_back(ppRelations[0]);     // color similarity between the plane patches (pixel-wise) 
//           r.rel_value.push_back(ppRelations[1]);     // depth value between neighboring plane pixels
//           r.rel_value.push_back(ppRelations[3]);     // curvature value between neighboring plane pixels
//           relations.push_back(r);
//         }
//       }
//     }
//   }
}


}












