/**
 * @file Annotation.h
 * @author Richtsfeld Andreas
 * @date November 2011
 * @version 0.1
 * @brief Annotation from file.
 */

#ifndef PA_ANNOTATION_H
#define PA_ANNOTATION_H

#include <string>
#include <vector>
#include "PCLCommonHeaders.h"

namespace pa
{

/**
 * @brief Class Annotation
 */
class Annotation
{
private:

  bool initialized;
  int cnt, cnt_max;                                     ///< counter for ann_filenames
  int f_min, f_max;                                     ///< filename minimum, maximum value
  std::vector<std::string> ann_filenames;               ///< filenames of annotation images
  int max_annotation;                                   ///< Number of annotations
  std::vector<int> anno;                                ///< Annotation from file (in image space) (objects 1,2,3...)

  bool have_indices;
  std::vector<pcl::PointIndices::Ptr> indices;          ///< Patch indices
  bool have_pairs;
  std::vector< std::vector<int> > pairs;                ///< Pairs of connected patches (according to indices-vector)

public:
  Annotation();
  ~Annotation();

  /** Initialize loading of annotation **/
  void init(std::string _ann_filename, 
            int _cnt_min, int _cnt_max);
  
  /** Load next annotation file (object = 1-n / unknown = 0 !!!) **/
  void load(int width, std::vector<int> &annotation, bool show = true);
  
  /** Set indices of patches **/
  void setIndices(std::vector<pcl::PointIndices::Ptr> &_indices);
  
  /** Calculate for all patches the ground truth and how they belong together **/
  void calculate();
  
  /** get vector, describing, which patches belong together **/
  void getResults(std::vector< std::vector<int> > &_results);
  
};

}

#endif

