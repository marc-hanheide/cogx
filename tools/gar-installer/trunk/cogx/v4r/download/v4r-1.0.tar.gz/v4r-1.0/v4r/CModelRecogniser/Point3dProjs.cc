/**
 * $Id$
 */


#include "Point3dProjs.hh"




namespace P 
{

unsigned Point3dProjs::nbcnt=0;


}












