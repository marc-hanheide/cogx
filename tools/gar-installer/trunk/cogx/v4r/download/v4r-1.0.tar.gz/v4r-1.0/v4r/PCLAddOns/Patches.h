/**
 * @file Patches.h
 * @author Richtsfeld
 * @date November 2011
 * @version 0.1
 * @brief Calculate patch relations.
 */

#ifndef PCLA_PATCHES_HH
#define PCLA_PATCHES_HH

#include <vector>
#include <utility>
#include "PCLCommonHeaders.h"
#include "ColorHistogram.h"
#include "Relation.h"

namespace pclA
{
  
class Patches
{
public:
EIGEN_MAKE_ALIGNED_OPERATOR_NEW     /// for 32-bit systems for pcl mandatory
  
protected:

private:
        
  int nr_hist_bins;                                             ///< Number of color histogram bins
  double z_max;                                                 ///< Maximum z-value between neighboring pixels
  
  bool have_input_cloud;
  pcl::PointCloud<pcl::PointXYZRGB>::Ptr pcl_cloud;           ///< Input cloud
  pcl::PointCloud<pcl::Normal>::Ptr pcl_normals;                ///< Normals of the point cloud

  bool have_patches;
  int nr_patches;                                               ///< Number of patches
  cv::Mat_<cv::Vec3b> patches;                                  ///< Patch indices (+1 !) on image grid

  std::vector<int> pcl_model_types;                             ///< Type of model
  std::vector<pcl::ModelCoefficients::Ptr> model_coefficients;  ///< model coeffficients
  std::vector<pcl::PointIndices::Ptr> pcl_model_cloud_indices;  ///< pcl_model_cloud_indices

  bool have_neighbors;
  std::vector< std::vector<unsigned> > neighbors3D;             ///< Neighboring patches (with z_max value)
  std::vector< std::vector<unsigned> > neighbors2D;             ///< Neighboring patches in image space
  std::vector<ColorHistogram*> hist;                            ///< Color histogram of each patch
  std::vector<Relation> relations;                              ///< Relations between patches

  void preprocess();
  bool CalculateBorderRelation(int p0, int p1, 
                               std::vector<double> &rel_value);

public:
  Patches();
  ~Patches();

   /** Set maximum z-value between neighboring pixels **/
  void setZLimit(double _z_max);

  /** Set input point cloud **/
  void setInputCloud(pcl::PointCloud<pcl::PointXYZRGB>::Ptr &_pcl_cloud, 
                     pcl::PointCloud<pcl::Normal>::Ptr &_pcl_normals);
  
  /** Set input planes **/
  void setPatches(const std::vector<int> &_pcl_model_types,
                  const std::vector<pcl::ModelCoefficients::Ptr> &_model_coefficients,
                  const std::vector<pcl::PointIndices::Ptr> &_pcl_model_cloud_indices);

  /** Compute neigbors between planes **/
  void setNeighbors(std::vector< std::vector<unsigned> > &n) {neighbors3D = n; have_neighbors = true;}

  /** Compute neigboring patches **/
  void computeNeighbors();
  
  /** Get the results from the neighborhood processing **/
  void getNeighbors(std::vector< std::vector<unsigned> > &n) {n = neighbors3D;}

  /** Set annotation **/
//   void setAnnotion(std::vector< std::vector<int> > &_anno);

  /** Compute **/
  void computeTestRelations();

  /** getRelations **/
  void getRelations(std::vector<Relation> &r) {r = relations;}
       

};

/*************************** INLINE METHODES **************************/

} //--END--

#endif

