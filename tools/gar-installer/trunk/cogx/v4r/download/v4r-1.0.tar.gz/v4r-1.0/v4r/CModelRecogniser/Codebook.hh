/**
 * $Id$
 * Johann Prankl, 2011-03-31 
 * prankl@acin.tuwien.ac.at
 */

#ifndef P_CODEBOOK_HH
#define P_CODEBOOK_HH

#include <vector>
#include <string>
#include <opencv2/core/core.hpp>
#include "PKeypoint.hh"
#include "View.hh"
#include "CModel.hh"
#include "CBEntry.hh"




namespace P
{

class ObjectMatches;

/**
 * Codebook
 */
class Codebook
{
protected:
  vector< cv::Ptr<CBEntry> > cbEntries;      // the codebook
 
public:
  Codebook() {}
  ~Codebook() {}

  virtual void clear() {}
  virtual unsigned size() {return cbEntries.size();}
  virtual void Optimize() {}
  virtual void InsertView(unsigned idxObject,unsigned idxView,std::vector<cv::Ptr<CModel> > &objs, bool incExtend=true) = 0;
  virtual void CreateCodebook(std::vector<cv::Ptr<CModel> > &objs) {};
  virtual void QueryObjects(cv::Mat_<float> &queryDescriptors, map<unsigned, vector<cv::DMatch> > &matches) = 0;

  virtual bool Load(const string &filename){ cout<<"Not implemented!"<<endl; return false;}
  virtual bool Save(const string &filename);
};


/**
 * matches with object
 */
class ObjectMatches
{     
public: 
  unsigned idxObject;
  double conf;

  vector<cv::DMatch> matches;    
  
  ObjectMatches(unsigned &oidx, double c) : idxObject(oidx), conf(c) {}
};    



/************************** INLINE METHODES ******************************/



}

#endif

