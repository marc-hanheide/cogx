/**
 * @file Planes.h
 * @author Richtsfeld
 * @date November 2011
 * @version 0.1
 * @brief Calculate plane neighborhood and ...
 */

#ifndef PCLA_PLANES_HH
#define PCLA_PLANES_HH

#include <vector>
#include <utility>
#include "v4r/PCLAddOns/PCLCommonHeaders.h"

namespace pclA
{

class Planes
{
public:
EIGEN_MAKE_ALIGNED_OPERATOR_NEW     /// for 32-bit systems for pcl mandatory
  
protected:

private:
  double z_max;                                             ///< Maximum z-value between neighboring pixels
  
  bool have_input_cloud;
  pcl::PointCloud<pcl::PointXYZRGB>::Ptr input_cloud;       ///< Input cloud

  bool have_planes;
  int nr_planes;                                            ///< Number of planes
  cv::Mat_<cv::Vec3b> planes;                               ///< Plane indices on image grid
  
  std::vector< std::vector<unsigned> > neighbors;

public:
  Planes();
  ~Planes();
  
  /** Set maximum z-value between neighboring pixels **/
  void setZLimit(double _z_max);
  
  /** Set input point cloud **/
  void setInputCloud(pcl::PointCloud<pcl::PointXYZRGB>::Ptr &pcl_cloud);

  /** Set input point cloud **/
  void setPlanes(const std::vector<int> &_pcl_model_types,
                 const std::vector<pcl::ModelCoefficients::Ptr> &_model_coefficients,
                 const std::vector<pcl::PointIndices::Ptr> &_pcl_model_cloud_indices);

  
  /** Compute all **/
  void computeAll();

  /** Compute neigbors between planes **/
  void computeNeighbors();

  /** Get the results from the neighborhood processing **/
  void getNeighbors(std::vector< std::vector<unsigned> > &_neighbors);
       

};

/*************************** INLINE METHODES **************************/

} //--END--

#endif

