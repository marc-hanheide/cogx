/**
 * @file LoadAnnotation.cpp
 * @author Richtsfeld Andreas
 * @date November 2011
 * @version 0.1
 * @brief Load annotation from file.
 */

#include<stdio.h>
#include "LoadAnnotation.h"

#include "opencv2/highgui/highgui.hpp"

namespace pa
{
 
/**
 * @brief Constructor of class LoadAnnotation
 */
LoadAnnotation::LoadAnnotation()
{}

/**
 * @brief Destructor of class LoadAnnotation
 */
LoadAnnotation::~LoadAnnotation()
{}


void LoadAnnotation::init(std::string _ann_filename, 
                          int _cnt_min, int _cnt_max)
{
  cnt = _cnt_min;
  cnt_max = _cnt_max;
  ann_filenames.clear();
  for(unsigned i= _cnt_min; i<_cnt_max; i++)
  {
    char ann_tmp_filename[1024];
    snprintf(ann_tmp_filename, 1024, _ann_filename.c_str(), i);
    ann_filenames.push_back(ann_tmp_filename);
  }
}

void LoadAnnotation::load(std::vector<unsigned> &annotation)
{
  IplImage *anno_image = cvLoadImage(ann_filenames[cnt].c_str(), CV_LOAD_IMAGE_GRAYSCALE);
  for(unsigned i=0; i<(anno_image->width*anno_image->height); i++)
    annotation.push_back(anno_image->imageData[i]);
  cnt++;
}

} // end pa



