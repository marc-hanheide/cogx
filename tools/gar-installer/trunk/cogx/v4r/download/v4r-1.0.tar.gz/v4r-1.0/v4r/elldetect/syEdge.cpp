/**
 * $Id$
 * 
 * Johann Prankl, 20091111
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install,
 *  copy or use the software.
 *
 *
 *                        Intel License Agreement
 *                For Open Source Computer Vision Library
 *
 * Copyright (C) 2000, Intel Corporation, all rights reserved.
 * Third party copyrights are property of their respective owners.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *   * Redistribution's of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *   * Redistribution's in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *   * The name of Intel Corporation may not be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 * This software is provided by the copyright holders and contributors "as is" and
 * any express or implied warranties, including, but not limited to, the implied
 * warranties of merchantability and fitness for a particular purpose are disclaimed.
 * In no event shall the Intel Corporation or contributors be liable for any direct,
 * indirect, incidental, special, exemplary, or consequential damages
 * (including, but not limited to, procurement of substitute goods or services;
 * loss of use, data, or profits; or business interruption) however caused
 * and on any theory of liability, whether in contract, strict liability,
 * or tort (including negligence or otherwise) arising in any way out of
 * the use of this software, even if advised of the possibility of such damage.
 **/
//
// (C) 2010, Aitor Aldoma Buchaca,
//           Johann Prankl,
//           Gerhard Obernberger <gerhard@obernberger.at>
//
//


#include "syDebug.hpp"

#include "syEdge.hpp"
#include "syFormClosedSegmentGroups.hpp"
#include <map>
#include <omp.h>

// include Steinbichler libraries
#include "ipAOI.hpp"

// include OpenCV libraries
#include OCV_CV_H
#include OCV_CXCORE_H
#include OCV_HIGHGUI_H

NAMESPACE_CLASS_BEGIN( RTE )


////////////////////////////////////////////////////////////////////////////////
CzEdge::CzEdge()
 : apertureSize(3)
{
}

////////////////////////////////////////////////////////////////////////////////
CzEdge::~CzEdge()
{
}


////////////////////////////////////////////////////////////////////////////////
// Trace edge gradient
void CzEdge::TraceEdge(IplImage *edgels, IplImage *tmp, short u, short v,
CzArray<CzEdgel> &arr)
{
  short x=u, y=v;

  do
  {
    SetPx8UC1(tmp,x, y,255);
    arr.PushBack(CzEdgel(CzVector2(x,y)));
  }while(TestEdgel(edgels, tmp, x,y) && y>0 && y<edgels->height-1);
}

/*********************** PUBLIC ******************************************/

////////////////////////////////////////////////////////////////////////////////
// Applies a sobel filter on img to both directions and returns the both gradient images in dx and dy
void CzEdge::Sobel(IplImage *img, IplImage *dx, IplImage *dy)
{
  if(!IsImage8UC1(img))
    throw CzExcept(__HERE__,"Input image should be IPL_DEPTH_8U, 1 channels!");
  if(!IsImage16SC1(dx) || !IsImage16SC1(dy))
    throw CzExcept(__HERE__,"Output images should be IPL_DEPTH_16S, 1 channel!");
  if(!IsImageSizeEqual(img,dx) || !IsImageSizeEqual(img,dy))
    throw CzExcept(__HERE__,"Size of images must be equal");

int kernel=apertureSize;
//#pragma omp parallel shared(img, dx, dy, kernel) 
{
//#pragma omp sections nowait
    {

//    #pragma omp section
  cvSobel( img, dx, 1, 0, kernel );
//    #pragma omp section
  cvSobel( img, dy, 0, 1, kernel );
}
}
}

////////////////////////////////////////////////////////////////////////////////
// Get the norm of edgels according to dx and dy
void CzEdge::Norm(IplImage *dx, IplImage *dy, IplImage *edge)
{
  if(!IsImage16SC1(dx) || !IsImage16SC1(dy))
    throw CzExcept(__HERE__,"Input images should be IPL_DEPTH_16S, 1 channel!");
  if (!IsImageSizeEqual(dx,dy) || !IsImageSizeEqual(dx,edge))
    throw CzExcept(__HERE__,"Size of image must be equal!");
  if (edge->nChannels != 1)
    throw CzExcept(__HERE__,"Output image must be a 1 channel image!");

  short *d1, *d2;

  if (edge->depth == (int)IPL_DEPTH_16S)
  {
    short *e, *e_end; 

    for (int v=0; v<edge->height; v++)
    {
      d1 = (short*)(dx->imageData + dx->widthStep*v);
      d2 = (short*)(dy->imageData + dy->widthStep*v);
      e = (short*)(edge->imageData + edge->widthStep*v);
      e_end = e + edge->width;
      
      for (;e!=e_end; d1++,d2++,e++)
        *e = (short)(sqrt(Sqr((float)*d1) + Sqr((float)*d2)));
    }
  }
  else if (edge->depth == (int)IPL_DEPTH_32F)
  {
    float *e, *e_end;

    for (int v=0; v<edge->height; v++)
    {
      d1 = (short*)(dx->imageData + dx->widthStep*v);
      d2 = (short*)(dy->imageData + dy->widthStep*v);
      e = (float*)(edge->imageData + edge->widthStep*v);
      e_end = e + edge->width;
     
      for (;e!=e_end; d1++,d2++,e++)
        *e = (float)(sqrt(Sqr((float)*d1) + Sqr((float)*d2)));
    }
  }
  else throw CzExcept(__HERE__,"Unsupported image format (supported: IPL_DEPTH_16S and IPL_DEPTH_32F");
}

////////////////////////////////////////////////////////////////////////////////
// Canny edge detection
void CzEdge::Canny(IplImage *indx, IplImage *indy, IplImage *idst, double lowThr, double highThr)
{
  if(!IsImage16SC1(indx) || !IsImage16SC1(indy))
    throw CzExcept(__HERE__,"Input images should be IPL_DEPTH_16S, 1 channel!");
  if(!IsImage8UC1(idst))
    throw CzExcept(__HERE__,"Output image should be IPL_DEPTH_8U, 1 channel!");
  if (!IsImageSizeEqual(indx,indy) || !IsImageSizeEqual(indx,idst))
    throw CzExcept(__HERE__,"Size of images must be equal!");

  CvMat dxstub, *dx = (CvMat*)indx;
  CvMat dystub, *dy = (CvMat*)indy;
  CvMat dststub, *dst = (CvMat*)idst;

  int low, high;
  void *buffer = 0;
  int* mag_buf[3];
  uchar **stack_top, **stack_bottom = 0;
  CvSize size = cvGetSize(dx);
  int flags = apertureSize;
  uchar* map;
  int mapstep, maxsize;
  int i, j;
  CvMat mag_row;

  dx = cvGetMat( dx, &dxstub );
  dy = cvGetMat( dy, &dystub );
  dst = cvGetMat( dst, &dststub );

  if( flags & CV_CANNY_L2_GRADIENT )
  {
      Cv32suf ul, uh;
      ul.f = (float)lowThr;
      uh.f = (float)highThr;
      low = ul.i;
      high = uh.i;
  }
  else
  {
      low = cvFloor( lowThr );
      high = cvFloor( highThr );
  }
  

  buffer = cvAlloc( (size.width+2)*(size.height+2) + (size.width+2)*3*sizeof(int));
 
  mag_buf[0] = (int*)buffer;
  mag_buf[1] = mag_buf[0] + size.width + 2;
  mag_buf[2] = mag_buf[1] + size.width + 2; 

  map = (uchar*)(mag_buf[2] + size.width + 2);
  mapstep = size.width + 2;

  maxsize = MAX( 1 << 10, size.width*size.height/10 );
  stack_top = stack_bottom = (uchar**)cvAlloc( maxsize*sizeof(stack_top[0]) );

  memset( mag_buf[0], 0, (size.width+2)*sizeof(int) );
  memset( map, 1, mapstep );
  memset( map + mapstep*(size.height + 1), 1, mapstep );

  /* sector numbers 
     (Top-Left Origin)
4278190080
      1   2   3
       *  *  * 
        * * *  
      0*******0
        * * *  
       *  *  * 
      3   2   1
  */

  #define CE_CANNY_PUSH(d)    *(d) = (uchar)2, *stack_top++ = (d)
  #define CE_CANNY_POP(d)     (d) = *--stack_top

  mag_row = cvMat( 1, size.width, CV_32F );

  // calculate magnitude and angle of gradient, perform non-maxima supression.
  // fill the map with one of the following values:
  //   0 - the pixel might belong to an edge
  //   1 - the pixel can not belong to an edge
  //   2 - the pixel does belong to an edge
  for( i = 0; i <= size.height; i++ )
  {
      int* _mag = mag_buf[(i > 0) + 1] + 1;
      float* _magf = (float*)_mag;
      const short* _dx = (short*)(dx->data.ptr + dx->step*i);
      const short* _dy = (short*)(dy->data.ptr + dy->step*i);
      uchar* _map;
      int x, y;
      int magstep1, magstep2;
      int prev_flag = 0;

      if( i < size.height )
      {
          _mag[-1] = _mag[size.width] = 0;

          if( !(flags & CV_CANNY_L2_GRADIENT) )
              for( j = 0; j < size.width; j++ )
                  _mag[j] = abs(_dx[j]) + abs(_dy[j]);
          else
          {
              for( j = 0; j < size.width; j++ )
              {
                  x = _dx[j]; y = _dy[j];
                  _magf[j] = (float)sqrt((double)x*x + (double)y*y);
              }
          }
      }
      else
          memset( _mag-1, 0, (size.width + 2)*sizeof(int) );

      // at the very beginning we do not have a complete ring
      // buffer of 3 magnitude rows for non-maxima suppression
      if( i == 0 )
          continue;

      _map = map + mapstep*i + 1;
      _map[-1] = _map[size.width] = 1;

      _mag = mag_buf[1] + 1; // take the central row
      _dx = (short*)(dx->data.ptr + dx->step*(i-1));
      _dy = (short*)(dy->data.ptr + dy->step*(i-1));

      magstep1 = (int)(mag_buf[2] - mag_buf[1]);
      magstep2 = (int)(mag_buf[0] - mag_buf[1]);

      if( (stack_top - stack_bottom) + size.width > maxsize )
      {
          uchar** new_stack_bottom;
          maxsize = MAX( maxsize * 3/2, maxsize + size.width );
          new_stack_bottom = (uchar**)cvAlloc( maxsize * sizeof(stack_top[0])) ;
          memcpy( new_stack_bottom, stack_bottom, (stack_top - stack_bottom)*sizeof(stack_top[0]) );
          stack_top = new_stack_bottom + (stack_top - stack_bottom);
          cvFree( &stack_bottom );
          stack_bottom = new_stack_bottom;
      }

      for( j = 0; j < size.width; j++ )
      {
          #define CE_CANNY_SHIFT 15
          #define CE_TG22  (int)(0.4142135623730950488016887242097*(1<<CE_CANNY_SHIFT) + 0.5)

          x = _dx[j];
          y = _dy[j];
          int s = x ^ y;
          int m = _mag[j];

          x = abs(x);
          y = abs(y);
          if( m > low )
          {
              int tg22x = x * CE_TG22;
              int tg67x = tg22x + ((x + x) << CE_CANNY_SHIFT);

              y <<= CE_CANNY_SHIFT;

              if( y < tg22x )
              {
                  if( m > _mag[j-1] && m >= _mag[j+1] )
                  {
                      if( m > high && !prev_flag && _map[j-mapstep] != 2 )
                      {
                          CE_CANNY_PUSH( _map + j );
                          prev_flag = 1;
                      }
                      else
                          _map[j] = (uchar)0;
                      continue;
                  }
              }
              else if( y > tg67x )
              {
                  if( m > _mag[j+magstep2] && m >= _mag[j+magstep1] )
                  {
                      if( m > high && !prev_flag && _map[j-mapstep] != 2 )
                      {
                          CE_CANNY_PUSH( _map + j );
                          prev_flag = 1;
                      }
                      else
                          _map[j] = (uchar)0;
                      continue;
                  }
              }
             else
              {
                  s = s < 0 ? -1 : 1;
                  if(m > _mag[j+magstep2-s] && m > _mag[j+magstep1+s] )
                  {
                      if( m > high && !prev_flag && _map[j-mapstep] != 2 )
                      {
                          CE_CANNY_PUSH( _map + j );
                          prev_flag = 1;
                      }
                      else
                          _map[j] = (uchar)0;
                      continue;
                  }
              }
          }
          prev_flag = 0;
          _map[j] = (uchar)1;
      }

      // scroll the ring buffer
      _mag = mag_buf[0];
      mag_buf[0] = mag_buf[1];
      mag_buf[1] = mag_buf[2];
      mag_buf[2] = _mag;
  }

 // now track the edges (hysteresis thresholding)
  while( stack_top > stack_bottom )
  {
      uchar* m;
      if( (stack_top - stack_bottom) + 8 > maxsize )
      {
          uchar** new_stack_bottom;
          maxsize = MAX( maxsize * 3/2, maxsize + 8 );
          new_stack_bottom = (uchar**)cvAlloc( maxsize * sizeof(stack_top[0])) ;
          memcpy( new_stack_bottom, stack_bottom, (stack_top - stack_bottom)*sizeof(stack_top[0]) );
          stack_top = new_stack_bottom + (stack_top - stack_bottom);
          cvFree( &stack_bottom );
          stack_bottom = new_stack_bottom;
      }

      CE_CANNY_POP(m);

      if( !m[-1] )
          CE_CANNY_PUSH( m - 1 );
      if( !m[1] )
          CE_CANNY_PUSH( m + 1 );
      if( !m[-mapstep-1] )
          CE_CANNY_PUSH( m - mapstep - 1 );
      if( !m[-mapstep] )
          CE_CANNY_PUSH( m - mapstep );
      if( !m[-mapstep+1] )
          CE_CANNY_PUSH( m - mapstep + 1 );
      if( !m[mapstep-1] )
          CE_CANNY_PUSH( m + mapstep - 1 );
      if( !m[mapstep] )
          CE_CANNY_PUSH( m + mapstep );
      if( !m[mapstep+1] )
          CE_CANNY_PUSH( m + mapstep + 1 );
  }

  // the final pass, form the final image
  for( i = 0; i < size.height; i++ )
  {
      const uchar* _map = map + mapstep*(i+1) + 1;
      uchar* _dst = dst->data.ptr + dst->step*i;

      for( j = 0; j < size.width; j++ )
          _dst[j] = (uchar)-(_map[j] >> 1);
  }

  cvFree( &buffer );
  cvFree( &stack_bottom );
}

////////////////////////////////////////////////////////////////////////////////
inline void SetPixel3C(IplImage *img, int x, int y, uchar r, uchar g, uchar b)
{
  ((uchar*)(img->imageData + img->widthStep*y))[x*3] = r;
  ((uchar*)(img->imageData + img->widthStep*y))[x*3+1] = g;
  ((uchar*)(img->imageData + img->widthStep*y))[x*3+2] = b;
}

////////////////////////////////////////////////////////////////////////////////
// Link canny edgels to segments
void CzEdge::LinkEdge(IplImage *src, 
                      CzArray<CzSegment *> &segments, 
                      CzArray<CzSegment *> &segments_mem, 
                      IplImage *dx, IplImage *dy, 
                      int iLinkingGrowCount)
{
   if (!IsImage8UC1(src))
      throw CzExcept(__HERE__,"Canny image should be IPL_DEPTH_8U, 1 channel!");
  
   unsigned char r,g,b;
   IplImage *tmp = cvCreateImage(cvGetSize(dx), IPL_DEPTH_8U, 1 );
   if (tmp == 0)
      throw CzExcept(__HERE__, "Could not create instance of IplImage! Out of memory?");
/*   IplImage *tmpColor = cvCreateImage(cvGetSize(dx), IPL_DEPTH_8U, 3 );
   if (tmpColor == 0)
      throw CzExcept(__HERE__, "Could not create instance of IplImage! Out of memory?");*/
   CzArray<CzEdgel> arr1;
   CzArray<CzEdgel> arr2;
   cvZero(tmp);
   CzSegment * segm;
   int segmentId=0;
   unsigned i;
   //linking
   for (short v=3; v<src->height-3; v++) {
      for (short u=3; u<src->width-3; u++) {
         if (GetPx8UC1(src,u,v)==255 && GetPx8UC1(tmp,u,v)==0) {
            arr1.Clear(); 
            arr2.Clear();
            TraceEdge(src, tmp, u, v, arr1);

            for (i = arr1.Size()-1; i>1; i--)
               arr2.PushBack(arr1[i]);
  
            TraceEdge(src, tmp, u, v, arr2);
            segm = new CzSegment(arr2); segments_mem.PushBack(segm);
            if (segm == 0)
               throw CzExcept(__HERE__, "Could not create instance of CzSegment! Out of memory?");
            segm->id = segmentId;
            segments.PushBack(segm);
            segmentId++;
         }
      }
   }

   CzFormClosedSegmentGroups *fcsg = new CzFormClosedSegmentGroups();
   if (fcsg == 0)
      throw CzExcept(__HERE__, "Could not create instance of CzFormClosedSegmentGroups! Out of memory?");
	IplImage *voteImg = cvCreateImage(cvGetSize(dx), IPL_DEPTH_16U, 1);
   if (voteImg == 0)
      throw CzExcept(__HERE__, "Could not create instance of IplImage! Out of memory?");
   fcsg->Reset(voteImg);	
   fcsg->Operate(segments, iLinkingGrowCount);
	
	/*IplImage * drawVote = cvCreateImage(cvGetSize(dx), IPL_DEPTH_8U, 3);
	fcsg->DrawVoteImg(drawVote,true);
	
	IplImage *drwVoteRes = cvCreateImage(cvSize(1400,1024), IPL_DEPTH_8U, 3);
	cvResize(drawVote, drwVoteRes);

	cvNamedWindow("tmp");
	cvShowImage("tmp", drwVoteRes);
	cvWaitKey(0);*/

  //edgels have also an orientation....
   if (dx!=0 && dy!=0) {
      if (!IsImage16SC1(dx) && !IsImage16SC1(dy))
         throw CzExcept(__HERE__,"Gradient images should be IPL_DEPTH_16S, 1 channel!");
      if (!IsImageSizeEqual(dx,dy) || !IsImageSizeEqual(dx,src))
         throw CzExcept(__HERE__,"Input image must have same size!");

      CzSegment *seg;
      CzArray<int> idsUsed;
    
      for (unsigned i=0; i<segments.Size(); i++) {
      
         seg = segments[i];
         if (!idsUsed.Contains(seg->id)) {

            //the whole segment may be itself and some more, check it!
            r=rand()%255,g=rand()%255,b=rand()%255;
            
            if ((seg->start != NULL) && (seg->end != NULL) && (seg->closable)) {
            
               //closed contour composed of two or more segments 
               CzSegment *joined = new CzSegment(); segments_mem.PushBack(joined);
               if (joined == 0)
                  throw CzExcept(__HERE__, "Could not create instance of CzSegment! Out of memory?");
               fcsg->CloseContour(seg, idsUsed, joined);
//cout << "idsUsed.size()" << idsUsed.Size() << endl;
               seg = joined;
               segments[i] = joined;
            }

            for (unsigned j=0; j<seg->edgels.Size(); j++) {
               seg->edgels[j].dir = atan2((double)GetPx16SC1(dy,(short)cvRound(seg->edgels[j].p.x), (short)cvRound(seg->edgels[j].p.y)),
                                          (double)GetPx16SC1(dx,(short)cvRound(seg->edgels[j].p.x), (short)cvRound(seg->edgels[j].p.y)));
//               SetPixel3C(tmpColor, cvRound(seg->edgels[j].p.x), cvRound(seg->edgels[j].p.y),r,g,b);
            }
         } else {
            segments.Erase(i);
         }
      }
   }

/*	cvNamedWindow("tmp2");
	IplImage *drwImg = cvCreateImage(cvSize(src->width,src->width), IPL_DEPTH_8U, 3);
	cvResize(tmpColor, drwImg);
	cvShowImage("tmp2", drwImg);
	//cvSaveImage("edgeLinking.jpg",drwImg);
	cvWaitKey(0);*/
	//cvDestroyWindow("tmp");
	//cvDestroyWindow("tmp2");
//	cvReleaseImage(&tmpColor);
	//cvReleaseImage(&drwImg);
	cvReleaseImage(&tmp);

	cvReleaseImage(&voteImg);
	//cvReleaseImage(&drawVote);
	//cvReleaseImage(&drwVoteRes);
	delete fcsg;
}




NAMESPACE_CLASS_END()

