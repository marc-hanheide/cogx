/**
 * $Id$
 * Johann Prankl, 2011-03-31 
 * prankl@acin.tuwien.ac.at
 */

#ifndef P_RNN_CODEBOOK_HH
#define P_RNN_CODEBOOK_HH

#include <vector>
#include <vector>
#include <string>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/features2d/features2d.hpp>
#include "PKeypoint.hh"
#include "CModel.hh"
#include "View.hh"
#include "CBEntry.hh"
#include "Codebook.hh"




namespace P
{

/**
 * RNNCodebook
 */
class RNNCodebook : public Codebook
{
public:
  class Parameter
  {
  public:
    float thrDesc;                    // 0.3
    float sigmaDesc;                  // sigma for mean shift update (0.2)
    float nnRatio;
    bool useFlann;
    int numTrees;
    int searchDepth; 
    float thrCluster;
    bool tryMergeSmallClusters;

    Parameter(float _thrDesc=0.3, float _sigmaDesc=0.2, float nnr=0.8, bool flann=false, int _numTrees=4, int depth=128, float thrCl=0.35, bool tryMerge=false)
     : thrDesc(_thrDesc), sigmaDesc(_sigmaDesc), nnRatio(nnr), useFlann(flann), numTrees(_numTrees), searchDepth(depth), thrCluster(thrCl), tryMergeSmallClusters(tryMerge) {};
  };

private:
  cv::Ptr<cv::DescriptorMatcher> matcher;
  cv::Ptr<cv::DescriptorMatcher> flannMatcher;

  cv::Mat_<float> descriptors;               // a copy of the descriptors of the codebook

  bool optimized;

  unsigned N;

  void InitCodebook(std::vector<cv::Ptr<CModel> > &objs, std::vector< cv::Ptr<CBEntry> > &cb);
  int GetNearestNeighbour(CBEntry &cbe, std::vector<cv::Ptr<CBEntry> > &cb, float &sim);
  int GetNearestNeighbour(float *d,int size,std::vector<cv::Ptr<CBEntry> > &cb, float &dist);

  void Agglomerate(CBEntry &src, CBEntry &dst);
  void TryMergeSmallEntries(std::vector<cv::Ptr<CBEntry> > &cb);

  void ClusterEntries(std::vector<cv::Ptr<CBEntry> > &cb);


 
public:
  Parameter param;

  RNNCodebook(cv::Ptr<cv::DescriptorMatcher> &descMatcher, Parameter _param = Parameter());
  ~RNNCodebook();

  virtual void clear();
  virtual void Optimize();
  virtual void InsertView(unsigned idxObject,unsigned idxView, std::vector<cv::Ptr<CModel> > &objs, bool incExtend=true);
  virtual void CreateCodebook(std::vector<cv::Ptr<CModel> > &objs);

  virtual void QueryObjects(cv::Mat_<float> &queryDescriptors, map<unsigned, vector<cv::DMatch> > &matches);
  virtual bool Load(const string &filename);

};





/************************** INLINE METHODES ******************************/



}

#endif

