/**
 * @file Planes.cpp
 * @author Richtsfeld
 * @date November 2011
 * @version 0.1
 * @brief Calculate plane neighborhood and ...
 */

#include "Planes.h"
#include "v4r/PCLAddOns/PCLUtils.h"
#include "v4r/PCLAddOns/PCLFunctions.h"

namespace pclA
{


/************************************************************************************
 * Constructor/Destructor
 */

Planes::Planes()
{
  have_input_cloud = false;
  nr_planes = 0;
  z_max = 0.01;   // 1cm
}

Planes::~Planes()
{
}

// ================================= Private functions ================================= //


// ================================= Public functions ================================= //

void Planes::setZLimit(double _z_max)
{
  z_max = _z_max;
}

void Planes::setInputCloud(pcl::PointCloud<pcl::PointXYZRGB>::Ptr &pcl_cloud)
{
  if(pcl_cloud.get() == 0 || pcl_cloud->points.size() == 0) {
    printf("Planes::setInputCloud: Warning: Empty or invalid pcl-point-cloud.\n");
    return;
  } 
  input_cloud = pcl_cloud;
  have_input_cloud = true;
  neighbors.resize(0);
}

void Planes::setPlanes(const std::vector<int> &_pcl_model_types,
                       const std::vector<pcl::ModelCoefficients::Ptr> &_model_coefficients,
                       const std::vector<pcl::PointIndices::Ptr> &_pcl_model_cloud_indices)
{
  if(!have_input_cloud) {
    printf("Planes::setPlanes: Error: First set dense input cloud with correct resolution.\n");
    return;
  }
  if(input_cloud->width <= 1 || input_cloud->height <= 1) {
    printf("Planes::setPlanes: Error: Input cloud is not a correct matrix.\n");
    return;
  }

  planes = cv::Mat_<cv::Vec3b>(input_cloud->height, input_cloud->width);
  planes.setTo(0);
  for(unsigned i=0; i<_pcl_model_cloud_indices.size(); i++) {
    for(unsigned j=0; j<_pcl_model_cloud_indices[i]->indices.size(); j++) {
      int row = _pcl_model_cloud_indices[i]->indices[j] / input_cloud->width;
      int col = _pcl_model_cloud_indices[i]->indices[j] % input_cloud->width;
      planes.at<cv::Vec3b>(row, col)[0] = i+1;  /// plane 1,2,...,n
    }
  }
  nr_planes = _pcl_model_cloud_indices.size();
  have_planes = true;
}

void Planes::computeAll()
{
  if(!have_input_cloud || !have_planes) {
    printf("Planes::computeAll: Error: No input cloud and planes available.\n");
    return;
  }    
  computeNeighbors();
}

void Planes::computeNeighbors()
{
  if(!have_input_cloud || !have_planes) {
    printf("Planes::computeNeighbors: Error: No input cloud and planes available.\n");
    return;
  }

  bool nbgh_matrix[nr_planes+1][nr_planes+1];
  for(unsigned i=0; i<nr_planes+1; i++)
    for(unsigned j=0; j<nr_planes+1; j++)
      nbgh_matrix[i][j] = false;
  
  for(int row=1; row<planes.rows; row++) {
    for(int col=1; col<planes.cols; col++) {
      if(planes.at<cv::Vec3b>(row, col)[0] != 0) {
        if(planes.at<cv::Vec3b>(row, col)[0] != planes.at<cv::Vec3b>(row-1, col)[0]) {
          if(planes.at<cv::Vec3b>(row-1, col)[0] != 0) {
            int pos_0 = row*input_cloud->width+col;
            int pos_1 = (row-1)*input_cloud->width+col;
            double dis = fabs(input_cloud->points[pos_0].z - input_cloud->points[pos_1].z);
            if( dis < z_max) {
              nbgh_matrix[planes.at<cv::Vec3b>(row-1, col)[0]][planes.at<cv::Vec3b>(row, col)[0]] = true;
              nbgh_matrix[planes.at<cv::Vec3b>(row, col)[0]][planes.at<cv::Vec3b>(row-1, col)[0]] = true;
            }
          }
        }
        if(planes.at<cv::Vec3b>(row, col)[0] != planes.at<cv::Vec3b>(row, col-1)[0]) {
          if(planes.at<cv::Vec3b>(row, col-1)[0] != 0) {
            int pos_0 = row*input_cloud->width+col;
            int pos_1 = row*input_cloud->width+col-1;
            double dis = fabs(input_cloud->points[pos_0].z - input_cloud->points[pos_1].z);
            if( dis < z_max) {
              nbgh_matrix[planes.at<cv::Vec3b>(row, col-1)[0]][planes.at<cv::Vec3b>(row, col)[0]] = true;
              nbgh_matrix[planes.at<cv::Vec3b>(row, col)[0]][planes.at<cv::Vec3b>(row, col-1)[0]] = true;
            }
          }
        }
        if(planes.at<cv::Vec3b>(row, col)[0] != planes.at<cv::Vec3b>(row-1, col-1)[0]) {
          if(planes.at<cv::Vec3b>(row-1, col-1)[0] != 0) {
            int pos_0 = row*input_cloud->width+col;
            int pos_1 = (row-1)*input_cloud->width+col-1;
            double dis = fabs(input_cloud->points[pos_0].z - input_cloud->points[pos_1].z);
            if( dis < z_max) {
              nbgh_matrix[planes.at<cv::Vec3b>(row-1, col-1)[0]][planes.at<cv::Vec3b>(row, col)[0]] = true;
              nbgh_matrix[planes.at<cv::Vec3b>(row, col)[0]][planes.at<cv::Vec3b>(row-1, col-1)[0]] = true;
            }
          }
        }
      }
    }
  }
  
//   printf("Neighboring matrix:\n");
//   for(unsigned i=1; i<nr_planes+1; i++) {
//     printf("nb %2u: ", i);
//     for(unsigned j=1; j<nr_planes+1; j++) {
//       printf("%u ", nbgh_matrix[i][j]);
//     }
//     printf("\n");
//   }
  
  // store neighbors
  for(unsigned i=1; i<nr_planes+1; i++) {
    std::vector<unsigned> neighbor;
    for(unsigned j=1; j<nr_planes+1; j++) {
      if(nbgh_matrix[i][j])
        neighbor.push_back(j-1);
    }
    neighbors.push_back(neighbor);
  }
}

void Planes::getNeighbors(std::vector< std::vector<unsigned> > &_neighbors)
{
  _neighbors = neighbors;
}

}












