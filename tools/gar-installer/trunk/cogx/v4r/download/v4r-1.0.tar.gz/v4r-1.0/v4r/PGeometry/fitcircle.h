
#ifndef FITCIRCLE_H
#define FITCIRCLE_H

extern void fit_circle(double x[], double y[], int n, double *cx, double *cy,
    double *r);

#endif

