
#include <map>
#include <iostream>
#include <stdexcept>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/features2d/features2d.hpp>
#include "v4r/PMath/PMath.hh"
#include "v4r/CModelRecogniser/KeypointDetectorSURF.hh"
#include "v4r/CModelRecogniser/KeypointDetector.hh"
#include "v4r/CModelRecogniser/PSiftGPU.hh"
#include "v4r/CModelRecogniser/PKeypoint.hh"
#include "v4r/CModelRecogniser/CBEntry.hh"
#include "v4r/CModelRecogniser/Codebook.hh"
#include "v4r/CModelRecogniser/MeanShiftCodebook.hh"
#include "v4r/CModelRecogniser/MeanCodebook.hh"
#include "v4r/CModelRecogniser/RNNCodebook.hh"
#include "v4r/CModelRecogniser/CModel.hh"
#include "v4r/CModelRecogniser/View.hh"


#define USE_MEAN
//#define USE_MEAN_SHIFT
//#define USE_RNN

//#define CODEBOOK_NAME "test.cb"


using namespace std;
using namespace P;


int main(int argc, char *argv[] )
{
  cv::namedWindow("Image", 1);
  struct timespec start1, end1;
  int key;
  cv::Mat imgLoad, imgCol, imgGray, imgDraw;
  char filename[PATH_MAX];
  vector<cv::KeyPoint> cvKeys;
  vector<cv::Ptr<PKeypoint> > keys;
  cv::Mat_<float> descriptors;

  vector<cv::DMatch> matches;
  vector<vector<cv::DMatch> > knnMatches;
  map<unsigned, vector<cv::DMatch> > cbMatches;
  cv::Ptr<Codebook> cb;
  cv::Ptr<View> view;
  cv::Ptr<CModel> model = new CModel();

  cv::Ptr<P::PSiftGPU> sift = new P::PSiftGPU(P::PSiftGPU::Parameter(0.6,0.8,0));
  cv::Ptr<P::KeypointDetector> detector = &(*sift);  detector.addref();
  cv::Ptr<cv::DescriptorExtractor> extractor = &(*sift); extractor.addref();
  cv::Ptr<cv::DescriptorMatcher> matcher = &(*sift);   matcher.addref();
  //cv::Ptr<cv::DescriptorMatcher> matcher  = new cv::BruteForceMatcher<cv::L2<float> >();

  #ifdef USE_MEAN
  cb = new MeanCodebook(matcher, MeanCodebook::Parameter(.35, .15));
  #else
  #ifdef USE_MEAN_SHIFT
  cb = new MeanShiftCodebook(matcher, MeanShiftCodebook::Parameter(.35, .15));
  #else
  cb = new RNNCodebook(matcher, RNNCodebook::Parameter(.35, .15));
  #endif
  #endif
  #ifdef CODEBOOK_NAME
  cb->Load(CODEBOOK_NAME);
  #endif


  vector<string> filenames;
  filenames.push_back("/home/hannes/images/DunglZucker/ZuckerDungl_0100.png");
  filenames.push_back("/home/hannes/images/DunglZucker/ZuckerDungl_0110.png");
  filenames.push_back("/home/hannes/images/DunglZucker/ZuckerDungl_0120.png");
  filenames.push_back("/home/hannes/images/DunglZucker/ZuckerDungl_0130.png");
  filenames.push_back("/home/hannes/images/DunglZucker/ZuckerDungl_0140.png");


  //create model
  for (unsigned i=0; i<filenames.size(); i++)
  {
    imgLoad = cv::imread(filenames[i], 1);
    imgGray = imgLoad;
    if( imgLoad.type() != CV_8U ) cv::cvtColor( imgLoad, imgGray, CV_BGR2GRAY );

    view = new View();
    view->id = view->idx = i;
    detector->Detect(imgGray, view->keys);
    PKeypoint::ConvertToCv(view->keys,cvKeys);
    extractor->compute(imgGray, cvKeys, view->descriptors);

    model->views.push_back(view);
  }
 

  // load test image
  imgLoad = cv::imread("/home/hannes/images/DunglZucker/ZuckerDungl_0160.png", 1);
  imgGray = imgLoad;
  if( imgLoad.type() != CV_8U ) cv::cvtColor( imgLoad, imgGray, CV_BGR2GRAY );
  imgLoad.copyTo(imgDraw); 

  clock_gettime(CLOCK_REALTIME, &start1);
  detector->Detect(imgGray, keys);
  PKeypoint::ConvertToCv(keys,cvKeys);
  extractor->compute(imgGray, cvKeys, descriptors);
  clock_gettime(CLOCK_REALTIME, &end1);
  cout<<"Time to compute keypoints [s]: "<<PMath::timespec_diff(&end1, &start1)<<endl;


  // ------------- create codebook from models ----------------
  clock_gettime(CLOCK_REALTIME, &start1);
  std::vector<cv::Ptr<CModel> > models(1,model);
  #ifndef USE_RNN
  for (unsigned i=0; i<model->views.size(); i++)
    cb->InsertView(0,model->views[i]->id, models);
  #else
  if (cb->size()!=0)
    for (unsigned i=0; i<model->views.size(); i++)
      cb->InsertView(0,model->views[i]->id, models, false);
  else cb->CreateCodebook(models);
  #endif
  clock_gettime(CLOCK_REALTIME, &end1);
  cout<<"Time create codebook [s]: "<<PMath::timespec_diff(&end1, &start1)<<endl;

  // match sifts one view/ query image
  clock_gettime(CLOCK_REALTIME, &start1);
  matcher->match(descriptors, model->views.back()->descriptors, matches);//query,train
  clock_gettime(CLOCK_REALTIME, &end1);
  cout<<"Time matching sift[s]: "<<PMath::timespec_diff(&end1, &start1)<<endl;

  // query frame
  clock_gettime(CLOCK_REALTIME, &start1); 
  cb->QueryObjects(descriptors, cbMatches);
  clock_gettime(CLOCK_REALTIME, &end1);
  cout<<"Time query a frame [s]: "<<PMath::timespec_diff(&end1, &start1)<<endl;

  // -------------------------------------------------------------

  KeypointDetector::Draw(imgDraw, keys, CV_RGB(255,255,255));

  PKeypoint::nbcnt++;
  map<unsigned, vector<cv::DMatch> >::iterator it;
  for (it=cbMatches.begin(); it!=cbMatches.end(); it++)
  {
    unsigned cnt=0;
    for (unsigned i=0; i<it->second.size(); i++)
    {
      if (it->second[i].imgIdx==model->views.size()-1)
      {
        PKeypoint &k2 = *keys[it->second[i].queryIdx];
        PKeypoint &k1 = *model->views[it->second[i].imgIdx]->keys[it->second[i].trainIdx];
        if (PVec::DistanceSqr2(&k2.pt.x, &k1.pt.x) < 50*50)
        {
          cv::line(imgDraw, k1.pt, k2.pt, CV_RGB(0,0,255),2);
          if (k2.nb != PKeypoint::nbcnt)
            cnt++;
          k2.nb = PKeypoint::nbcnt;
        }
      }
    }
    cout<<"number of cb matches: "<<cnt<<endl;
  }

  for(unsigned i=0; i<matches.size(); i++)
  {
    PKeypoint &k1 = *model->views.back()->keys[matches[i].trainIdx];
    PKeypoint &k2 = *keys[matches[i].queryIdx];
    cv::line(imgDraw, k1.pt, k2.pt, CV_RGB(0,255,0), 1);
  }

  cout<<"number of gt matches: "<<matches.size()<<endl;

  #ifdef CODEBOOK_NAME
  cb->Save(CODEBOOK_NAME);
  #endif


  cv::imshow("Image",imgDraw);

  key = cv::waitKey(0);

  cv::destroyWindow("Image");	
	
	return 0;
}




