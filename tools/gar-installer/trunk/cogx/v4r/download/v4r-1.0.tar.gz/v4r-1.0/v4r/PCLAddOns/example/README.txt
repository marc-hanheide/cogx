Plane pop out
=============

Requirements:
-------------
- OpenCV, PCL
- Needs connected Kinect sensor!


Plane Popout Example:
---------------------
Extract the dominant plane of kinect data and estimates pop-outs on the plane. Shows
the mask of the extracted objects on the plane.



------------------
Andreas Richtsfeld
Automation and Control Institute
Vienna University of Technology
ari@acin.tuwien.ac.at
skype: andreas.richtsfeld

