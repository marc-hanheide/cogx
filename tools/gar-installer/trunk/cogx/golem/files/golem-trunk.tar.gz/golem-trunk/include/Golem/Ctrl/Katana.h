/** @file Katana.h
 * 
 * Katana 6M 180 controller implementation.
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#pragma once
#ifndef _GOLEM_CTRL_KATANA_H_
#define _GOLEM_CTRL_KATANA_H_

//------------------------------------------------------------------------------

#include <Golem/Tools/Stream.h>
#include <Golem/Ctrl/Arm.h>
#include <Golem/Ctrl/Simulator.h>
#include <KNI/cdlCOM.h>
#include <KNI/cplSerial.h>
#include <KNI/kmlBase.h>
#include <KNI/kmlExt.h>

//------------------------------------------------------------------------------

namespace golem {

//------------------------------------------------------------------------------

class KatArm;

class KatJoint: public Joint {
	friend class KatArm;

public:
	/** MCU internal time unit [sec] */
	static const Real MCU_TM_PERIOD;
	/** Katana trajectory time quant [sec] */
	static const SecTmReal TM_QUANT;
	/** Katana internal constants */
	static const Real VEL_ENC_UNIT;
	/** FIR-Filter coefficients */
	static const U32 NUM_FILTER_COEFFS = 5; // number of FIR-Filter coefficients
	/** Synchronisation flag */
	static const U32 IO_SYNC_FLAG = 152;	// see wait() function
	/** Synchronisation flag */
	static const U32 IO_CRASH_FLAG = 40;	// 
	/** IO communication buffer */
	static const U32 IO_BUF_SIZE = 256;

	/** Katana Joint description */
	class Desc : public Joint::Desc {
	public:
		/** Joint position offset */
		Real offset;
		/** Joint position gain */
		Real gain;
		
		/** Activate FIR-Filter */
		bool activateFIRFilter;
		/** FIR-Filter coefficients */
		U8 coeffs[NUM_FILTER_COEFFS];
		/** Activate slope saturation */
		bool activateSlopeSaturation;
		/** Slope saturation limit */
		U8 limit;
		
		Desc() {
			Desc::setToDefault();
		}

		virtual void setToDefault() {
			Joint::Desc::setToDefault();

			offset = (Real)0.0;
			gain = (Real)1.0;

			activateFIRFilter = true;
			coeffs[0] = 5;
			coeffs[1] = 3;
			coeffs[2] = 2;
			coeffs[3] = 1;
			coeffs[4] = 1;
			activateSlopeSaturation = true;
			limit = 255;
		}

		virtual bool isValid() const {
			if (!Joint::Desc::isValid())
				return false;

			return true;
		}
	};

protected:
	/** Joint position offset */
	Real offset;
	/** Joint position gain */
	Real gain;
	
	/** FIR-Filter coefficients */
	U8 coeffs[NUM_FILTER_COEFFS];
	/** Slope saturation limit */
	U8 limit;
	
	// Katana specific pointers initialised during construction
	KatArm *pKatArm;
	CKatana* pKatana;
	CCplBase* pProtocol;
	CMotBase* pMotBase;
	
	// Scaling description (internal->SI, SI->internal):
	TMotInit motInit;
	
	// IO buffers
	U8 sendBuf[IO_BUF_SIZE];
	U8 recvBuf[IO_BUF_SIZE];

	virtual bool sysSync();
	virtual bool sysSend(const GenCoord& prev, const GenCoord& next, SecTmReal dt) = 0;
	
	// IJointBase, partial implementation
	virtual bool sysRecv(GenCoord& curr);

	inline Real posEncToSI(Real pos) const {
		const Real s = Real(motInit.angleOffset) - REAL_2_PI*(pos - Real(motInit.encoderOffset))/
			(Real(motInit.encodersPerCycle)*motInit.rotationDirection);
		return offset + gain*s;
	}
	inline Real posSIToEnc(Real pos) const {
		pos = (pos - offset)/gain;
		const Real s = Real(motInit.encoderOffset) + (Real(motInit.angleOffset) - pos)*
			Real(motInit.encodersPerCycle)*motInit.rotationDirection/REAL_2_PI;
		return s;
	}
	inline Real velEncToSI(Real vel) const {
		const Real s = -REAL_2_PI*vel/(Real(motInit.encodersPerCycle)*motInit.rotationDirection);
		return gain*s;
	}
	inline Real velSIToEnc(Real vel) const {
		vel = vel/gain;
		const Real s = -vel*Real(motInit.encodersPerCycle)*motInit.rotationDirection/REAL_2_PI;
		return s;
	}
	inline Real accEncToSI(Real acc) const {
		// TODO
		return acc;
	}
	inline Real accSIToEnc(Real acc) const {
		// TODO
		return acc;
	}

	/** Creates Katana Joint from the description. */
	bool create(const Desc& desc);
	
	KatJoint(Arm& arm);

public:
	/** Joint position offset */
	inline const Real& getOffset() const {
		return offset;
	}
	
	/** Joint position gain */
	inline const Real& getGain() const {
		return gain;
	}

	/** Sets FIR-Filter coefficients */
	bool setFIRFilter(const U8 *coeffs);
	/** Returns FIR-Filter coefficients */
	const U8 *getFIRFilter() const;
	
	/** Slope saturation limit */
	bool setSlopeSaturation(U8 limit);
	/** Returns FIR-Filter coefficients */
	U8 getSlopeSaturation() const;
};

//------------------------------------------------------------------------------

class KatStdJoint: public KatJoint {
	friend class KatArm;

public:
	/** KatStdJoint description */
	class Desc : public KatJoint::Desc {
	protected:
		/** Creates the object from the description. */
		CREATE_FROM_OBJECT_DESC(KatStdJoint, Joint::Ptr, Arm)
	};

protected:
	virtual bool sysSend(const GenCoord& prev, const GenCoord& next, SecTmReal dt);

	KatStdJoint(Arm& arm);
};

//------------------------------------------------------------------------------

class KatTrjJoint: public KatJoint {
	friend class KatArm;

public:
	/** KatTrjJoint description */
	class Desc : public KatJoint::Desc {
	protected:
		/** Creates the object from the description. */
		CREATE_FROM_OBJECT_DESC(KatTrjJoint, Joint::Ptr, Arm)
	};

private:
	// Scaling description
	static const Real trj4ScaleFac[4];

protected:
	virtual bool sysSend(const GenCoord& prev, const GenCoord& next, SecTmReal dt);

	KatTrjJoint(Arm& arm);
};

//------------------------------------------------------------------------------

//
//            t1    t2                t3               t4       
//            ^    ^                 ^           ^ Z  ^         
//            |   /                 /            |   /          
//            |  /                 /             |  /           
//            | /                 /              | /            
//            |/       l1        /       l2      |/       Y     
//            O*****************O****************O---------> t5 
//           /*                /                /               
//          / *               /                /   T            
//         /  *              /                /                  
//        /   * l0          /                V X                  
//            *                                                 
//            *^ Z                                              
//            *|                                                
//            *|                                                
//            *| S     Y                                        
//             O-------->                                       
//            /                                                 
//           /                                                  
//          / X                                                 
//         v                                                    
//

class KatJoint;

class KatArm: public Arm {
	friend class KatJoint;

public:
	typedef obj_ptr<KatArm> Ptr;
#ifdef WIN32	// FIX
	friend class Ptr;
#endif

	/** 5 DOF Katana 6M 180 */
	static const U32 NUM_JOINTS = 5; // Number of joints without a gripper
	/** Links lengths */
	static const Real L0; // [m]
	static const Real L1; // [m]
	static const Real L2; // [m]
	static const Real L3; // [m]
	/** Gripper position encoder tolerance */
	static const U32 GRIP_ENC_TOLERANCE = 100;
	/** IO communication buffer */
	static const U32 IO_BUF_SIZE = 256;

	/** Katana sensor data */
	class SensorData {
	public:
		/** Sensor index */
		int index;
		/** Sensor value */
		int value;

		SensorData(int index = 0, int value = 0) : index(index), value(value) {}
		SensorData(const SensorData& sensorData) : index(sensorData.index), value(sensorData.value) {}
	};

	/** Katana gripper encoder data */
	class GripperEncoderData {
	public:
		/** Open gripper encoder value */
		int open;
		/** Closed gripper encoder value */
		int closed;
		/** Current gripper encoder value */
		int current;
	};

	typedef std::vector<SensorData> SensorDataSet;
	typedef std::vector<int> SensorIndexSet;

	/** Katana body */
	class Body {
	public:
		/** link #0 */
		Real l0;
		/** link #1 */
		Real l1;
		/** link #2 */
		Real l2;
		/** link #3 */
		Real l3;

		/** Bounds model */
		bool simpleBoundsModel;
		
		Body() {
			setToDefault();
		}
		
		void setToDefault() {
			l0 = (Real)L0;	// [m]
			l1 = (Real)L1;	// [m]
			l2 = (Real)L2;	// [m]
			l3 = (Real)L3;	// [m]
			simpleBoundsModel = true;
		}
		
		bool isValid() const {
			if (l0 <= (Real)0.0 || l1 <= (Real)0.0 || l2 <= (Real)0.0 || l3 <= (Real)0.0)
				return false;

			return true;
		}
	};
	
	/** KatArm description */
	class Desc : public Arm::Desc {
	protected:
		MemoryWriteStream buffer;

	public:
		/** Katana measurements */
		bool bMeasurements;
		/** Katana gripper */
		bool bGripper;
		/** Katana sensors */
		SensorIndexSet sensorIndexSet;
		/** Katana body  */
		Body body;
		/** Joint index set for synchronization function  */
		std::set<U32> syncJointIndex;

		/** Katana communication time offset */
		SecTmReal katDeltaOffs;
		
		Desc() {
			setToDefault();
		}

		/** Creates KatArm given the description object and pointers to KNI objects. 
		* @param context	golem::Context object
		* @return			pointer to the KatArm, if no errors have occured;
		*					<code>NULL</code> otherwise 
		*/
		KatArm::Ptr create(golem::Context& context, CKatana* pKatana, CCplBase* pProtocol) const {
			KatArm::Ptr pKatArm(new KatArm(context));

			if (!pKatArm->create(pKatana, pProtocol, *this))
				pKatArm.release();

			return pKatArm;
		}
		
		virtual void setupJoints() {
			joints.clear(); // and joints
			KatArm::setupJoints(joints, body);
		}
		
		virtual void setToDefault() {
			Arm::Desc::setToDefault();

			name = "Katana 6M180";
			
//			restPosition[0] = REAL_PI;

			bMeasurements = false;
			bGripper = false;

			sensorIndexSet.clear();
			// Katana Finger Type S03.02, force sensors
			sensorIndexSet.push_back(7);	// Right finger, Front
			sensorIndexSet.push_back(15);	// Left finger, Front
			sensorIndexSet.push_back(6);	// Right finger, Rear
			sensorIndexSet.push_back(14);	// Left finger, Rear

			body.setToDefault();
			referencePose.p.v2 += body.l3;
		
			setupJoints();

			katDeltaOffs = (SecTmReal)0.02; // [sec]
			deltaOffs = (SecTmReal)0.07;//0.02; // [sec]
			skewOffs = (SecTmReal)0.02;//0.01; // [sec]

			syncJointIndex.insert(1);
		}

		virtual bool isValid() const {
			if (!Arm::Desc::isValid())
				return false;
			if (bGripper && sensorIndexSet.empty())
				return false;
			if (!body.isValid())
				return false;
			if (katDeltaOffs <= (SecTmReal)0.0)
				return false;
			if (syncJointIndex.empty() || *syncJointIndex.rbegin() >= joints.size())
				return false;

			return true;
		}
	};
	
	/** Katana Joints setup */
	static void setupJoints(Joint::Desc::Seq& joints, const Body &body);
	// Inverse and forward transforms
	static void forwardTransform(Mat34& trn, const ConfigspaceCoord& cc, const Body &body);
	static void inverseTransform(ConfigspaceCoord::Seq& j, const Mat34& trn, const Body &body);
	static void velocitySpatial(Twist& v, const ConfigspaceCoord& cc, const ConfigspaceCoord& dcc, const Body &body);
	static void jacobianSpatial(Jacobian& jac, const ConfigspaceCoord& cc, const Body &body);
	
protected:
	enum GripperStatus {
		NOOP = 0x0,
		OPEN = 0x1,
		CLOSE = 0x2,
		FREEZE = 0x4,
		RECV = 0x8,
		READ = 0x10,
	};

	/** Katana measurements */
	bool bMeasurements;
	/** Katana gripper */
	bool bGripper;
	/** Katana sensors */
	SensorIndexSet sensorIndexSet;
	/** Katana body  */
	Body body;
	/** Joint index set for synchronization function  */
	std::set<U32> syncJointIndex;
	
	// Simulator specific pointers initialised during construction
	CKatana* pKatana;
	CCplBase* pProtocol;

	bool bCalibrationInit;
	GenConfigspaceCoord current;

	bool gripperIsPresent;
	CriticalSection csGripper;
	volatile int gripperStatus;
	Event evGripper, evGripperRecv;
	volatile bool bGripperResult, bGripperRecvResult;
	SensorDataSet sensorData, sensorThreshold;
	GripperEncoderData gripperEncoderData;
	SecTmReal gripperDur;

	// IO buffers
	U8 sendBuf[IO_BUF_SIZE];
	U8 recvBuf[IO_BUF_SIZE];
	
	/** I/O timings. */
	Arm::Measurement msrDeltaSendSync, msrDeltaJointSend;
	/** Katana communication time offset */
	SecTmReal katDeltaOffs;
	
	// Arm
	virtual void userCalibrate();
	virtual void userComm();
	
	void gripperCalibrate();
	void gripperComm();

	virtual bool sysRecv(GenConfigspaceCoord& curr);
	virtual bool sysSend(const GenConfigspaceCoord& prev, const GenConfigspaceCoord& next, SecTmReal dt);
	virtual bool sysSync();
	
	bool create(CKatana* pKatana, CCplBase* pProtocol, const Desc& desc);
	
	KatArm(golem::Context& context);

#ifndef WIN32	// FIX
public:
#endif
	/** Each derived class should have virtual destructor releasing resources
	*	to avoid calling virtual functions of non-existing objects
	*/
	virtual ~KatArm() {
		release();
	}
	
public:
	// Arm
	virtual void forwardTransform(Mat34& trn, const ConfigspaceCoord& cc) const;
	virtual void inverseTransform(ConfigspaceCoord::Seq& j, const Mat34& trn) const;
	virtual void velocitySpatial(Twist& v, const ConfigspaceCoord& cc, const ConfigspaceCoord& dcc) const;
	virtual void jacobianSpatial(Jacobian& jac, const ConfigspaceCoord& cc) const;

	/** Receives gripper sensor values */
	bool gripperRecvSensorData(SensorDataSet& sensorData, MSecTmU32 timeWait = MSEC_TM_U32_INF);
	
	/** Receives gripper encoder values */
	bool gripperRecvEncoderData(GripperEncoderData& encoderData, MSecTmU32 timeWait = MSEC_TM_U32_INF);
	
	/** Opens the gripper */
	bool gripperOpen(MSecTmU32 timeWait = MSEC_TM_U32_INF);

	/** Closes the gripper, stops if only a signal from any sensor is above the given threshold */
	bool gripperClose(const SensorDataSet& sensorThreshold, MSecTmU32 timeWait = MSEC_TM_U32_INF);
	
	/** Freezes the gripper */
	bool gripperFreeze(MSecTmU32 timeWait = MSEC_TM_U32_INF);

	/** Katana measurements */
	bool hasMeasurements() const {
		return bMeasurements;
	}

	/** Katana gripper */
	bool hasGripper() const {
		return bGripper;
	}

	/** Returns Katana sensor indexes */
	const SensorIndexSet& getSensorIndexSet() const {
		return sensorIndexSet;
	}

	/** Returns body configuration */
	const Body& getBody() const {
		return body;
	}
};

//------------------------------------------------------------------------------

class KatSerialArm: public KatArm {
public:
	/** RS232 serial protocol settings */
	class SerialDesc {
	public:
		/** communication port */
		U32 commPort;
		/** baud rate */
		U32 baudRate;
		/** data bit */
		U32 dataBit;
		/** parity bit */
		U32 parityBit;
		/** stop bit */
		U32 stopBit;
		/** read total timeout */
		U32 readTimeout;
		/** write total timeout */
		U32 writeTimeout;
		
		SerialDesc() {
			setToDefault();
		}
		
		void setToDefault() {
			commPort = 0;
			baudRate = 57600;
			dataBit = 8;
			parityBit = 'N';
			stopBit = 1;
			readTimeout = 500;
			writeTimeout = 0;
		}
		
		bool isValid() const {
			if (readTimeout <= 0 && writeTimeout <= 0)
				return false;

			return true;
		}
	};
	
	/** Katana Serial Arm description
	 */
	class Desc : public KatArm::Desc {
	public:
		/** configuration file */
		std::string cfgPath;
		/** RS232 serial protocol settings */
		SerialDesc serialDesc;

		Desc() {
			setToDefault();
		}
		
		/** Creates the object from the description. */
		CREATE_FROM_OBJECT_DESC(KatSerialArm, Arm::Ptr, Context)
		
		virtual void setToDefault() {
			KatArm::Desc::setToDefault();

			cfgPath = "";
			serialDesc.setToDefault();
		}
		
		virtual bool isValid() const {
			if (!KatArm::Desc::isValid())
				return false;
			if (cfgPath.empty())
				return false;
			if (!serialDesc.isValid())
				return false;

			return true;
		}
	};

protected:
	obj_ptr<CKatana> katana;
	obj_ptr<CCplBase> protocol;
	obj_ptr<CCdlBase> device;

	/** configuration file */
	std::string cfgPath;
	/** RS232 serial protocol settings */
	SerialDesc serialDesc;

	// Initialisation
	bool create(const Desc& desc);

	KatSerialArm(golem::Context& context);

	/** Each derived class should have virtual destructor releasing resources
	*	to avoid calling virtual functions of non-existing objects
	*/
	virtual ~KatSerialArm() {
		release();
	}
	
public:
	/** Returns configuration file */
	const std::string& getCfgPath() const {
		return cfgPath;
	}

	/** Returns RS232 serial protocol settings */
	const SerialDesc& getSerialDesc() const {
		return serialDesc;
	}
};

//------------------------------------------------------------------------------

class KatSimArm: public SimArm {
public:
	/** KatSimArm description
	 */
	class Desc : public SimArm::Desc {
	protected:
		MemoryWriteStream buffer;

	public:
		/** Creates the object from the description. */
		CREATE_FROM_OBJECT_DESC(KatSimArm, Arm::Ptr, Context)

		/** Katana body  */
		KatArm::Body body;
		
		Desc() {
			setToDefault();
		}

		virtual void setupJoints() {
			joints.clear(); // and joints
			KatSimArm::setupJoints(joints, body);
		}
		
		virtual void setToDefault() {
			SimArm::Desc::setToDefault();

			name = "Simulator of Katana 6M180";
			
			//restPosition[0] = REAL_PI;
			
			timeQuant = (SecTmReal)0.01;
			deltaSync = (SecTmReal)0.005;
			deltaRecv = (SecTmReal)0.0;
			deltaSend = (SecTmReal)0.075;

			body.setToDefault();
			referencePose.p.v2 += body.l3;
		
			setupJoints();
		}

		virtual bool isValid() const {
			if (!SimArm::Desc::isValid())
				return false;
			if (!body.isValid())
				return false;
			
			return true;
		}
	};

	/** Katana Joints setup */
	static void setupJoints(Joint::Desc::Seq& joints, const KatArm::Body &body);

protected:
	/** Katana body  */
	KatArm::Body body;

	/** Arm initialisation */
	bool create(const Desc& desc);

	KatSimArm(golem::Context& context);

	/** Each derived class should have virtual destructor releasing resources
	*	to avoid calling virtual functions of non-existing objects
	*/
	virtual ~KatSimArm() {
		release();
	}
	
public:
	// Arm
	virtual void forwardTransform(Mat34& trn, const ConfigspaceCoord& cc) const;
	virtual void inverseTransform(ConfigspaceCoord::Seq& j, const Mat34& trn) const;
	virtual void velocitySpatial(Twist& v, const ConfigspaceCoord& cc, const ConfigspaceCoord& dcc) const;
	virtual void jacobianSpatial(Jacobian& jac, const ConfigspaceCoord& cc) const;

	/** Katana body  */
	const KatArm::Body& getBody() const {
		return body;
	}
};

//------------------------------------------------------------------------------

};	// namespace

#endif /*_GOLEM_CTRL_KATANA_H_*/
