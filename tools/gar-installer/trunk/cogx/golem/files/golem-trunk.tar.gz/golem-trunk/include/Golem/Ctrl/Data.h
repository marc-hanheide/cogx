/** @file Data.h
 * 
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#pragma once
#ifndef _GOLEM_CTRL_DATA_H_
#define _GOLEM_CTRL_DATA_H_

//------------------------------------------------------------------------------

#include <Golem/Tools/Data.h>
#include <Golem/Ctrl/Arm.h>

//------------------------------------------------------------------------------

namespace golem {

//------------------------------------------------------------------------------

/** Reads/writes Arm::Ptr from/to a given context */
void XMLData(Arm::Desc::Ptr &val, XMLContext* context, bool create = false);

//------------------------------------------------------------------------------

};	// namespace

#endif /*_GOLEM_CTRL_DATA_H_*/
