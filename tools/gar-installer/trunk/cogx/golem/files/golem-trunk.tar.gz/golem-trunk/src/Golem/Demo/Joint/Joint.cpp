/** @file Joint.cpp
 * 
 * Demonstration program which moves the arm to the zero pose.
 * 
 * Program can be run in two modes:
 * - the first uses real Katana arm
 * - the second runs the Katana arm simulator
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#include <Golem/Ctrl/Katana.h>
#include <Golem/Ctrl/Simulator.h>
#include <Golem/Demo/Common/Tools.h>
#include <iostream>

using namespace golem;

//------------------------------------------------------------------------------

int main(int argc, char *argv[]) {
	if (argc != 1 && argc != 3 || argc == 2 && strcmp(argv[1], "-h") == 0) {
		printf("To run Katana: %s <config_file> <com_port_number>\n", argv[0]);
		printf("To run Simulation: %s\n", argv[0]);
		return 1;
	}
	
	try {
		// Create program context
		golem::Context::Desc contextDesc;
		golem::Context::Ptr context = contextDesc.create();

		// Do not display LEVEL_DEBUG messages (only with level at least LEVEL_ERR)
		//context->getLogger()->setMsgFilter(MessageFilter::Ptr(new LevelFilter<Message>(Message::LEVEL_ERR)));

		//-----------------------------------------------------------------------------

		// Simulations or real devices
		const bool simulations = argc == 1;
	
		// Create arm controller description
		Arm::Desc::Ptr pArmDesc;
		if (simulations) {
			pArmDesc.reset(new KatSimArm::Desc);
		}
		else {
			KatSerialArm::Desc *pDesc = new KatSerialArm::Desc;
			pArmDesc.reset(pDesc);
			pDesc->cfgPath = argv[1]; // configuration file
			pDesc->serialDesc.commPort = ::atoi(argv[2]); // Communication port (RS232)
			pDesc->deltaOffs = SecTmReal(0.1);
			pDesc->skewOffs = SecTmReal(0.02);
		}

		// Create arm controller
		context->getLogger()->post(Message::LEVEL_INFO, "Initialising arm controller...");
		Arm::Ptr pArm = pArmDesc->create(*context);

		// Display arm information
		armInfo(*pArm);
		
		// Move the arm to the zero pose
		armZeroMove(*pArm, SecTmReal(0.5), SecTmReal(0.5), SecTmReal(5.0));

		// Wait for some time
		context->getTimer()->sleep(SecTmReal(5.0));

		context->getLogger()->post(Message::LEVEL_INFO, "Good bye!");
	}
	catch (const Message& msg) {
		std::cerr << msg << std::endl;
	}
	catch (const std::exception &ex) {
		std::cerr << Message(Message::LEVEL_CRIT, "C++ exception: %s", ex.what()) << std::endl;
	}

	return 0;
}
