/** @file Controller.h
 * 
 * Universal interface for controlling abstract devices or systems using 
 * trajectories.
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#pragma once
#ifndef _GOLEM_CTRL_CONTROLLER_H_
#define _GOLEM_CTRL_CONTROLLER_H_

//------------------------------------------------------------------------------

#include <Golem/Defs/Pointers.h>
#include <Golem/Math/Math.h>
#include <Golem/Math/Function.h>
#include <Golem/Tools/Logger.h>
#include <Golem/Tools/Context.h>
//#include <Golem/Tools/Debug.h>
#include <Golem/Ctrl/Msg.h>
#include <vector>

//------------------------------------------------------------------------------

/** Controller debug */
//#define GOLEM_CTRL_CONTROLLER_DBG_

//------------------------------------------------------------------------------

namespace golem {

//------------------------------------------------------------------------------

/** Bidirectional queue with random access to elements.
 * 
 * Interface defining bidirectional queue (sequence) that supports random 
 * access to elements, as well as insertion/removal of elements at the beginning
 * and at the end of a queue.
 * Interface DO NOT explicitly relate the beggining (front) and the end (back)
 * of a queue (FIFO), and can be seen as two independent stacks of limited
 * capacity (LIFO).
 * If interface is realised as one data sequence than it can hold:
 * <code>size_front() == size_back()</code>,
 * <code>free_front() == free_back()</code>.
 * 
@verbatim
 
 front                                                                 back 
              {0} {1} {2} {3} ...   ... {3} {2} {1} {0}
 <----------> <------------------ / ------------------> <----------------->
 free_front() size_front()                  size_back()  free_back()
 
           ^                                             ^
           push_front(...)                               push_back(...)
 
               ^   ^                                 ^
               pop_front(2)                          pop_back(1)
 
                   ^                     ^
                   front(1)              back(3)
 
@endverbatim
 *
 */
template <class TYPE>
class TIQueue {
protected:
	virtual ~TIQueue() {}
	
public:
	virtual TYPE& front(int index = 0) const = 0;
	virtual void push_front(const TYPE& element) = 0;
	virtual void pop_front(int len = 1) = 0;
	virtual int size_front() const = 0;
	virtual int free_front() const = 0;

	virtual TYPE& back(int index = 0) const = 0;
	virtual void push_back(const TYPE& element) = 0;
	virtual void pop_back(int len = 1) = 0;
	virtual int size_back() const = 0;
	virtual int free_back() const = 0;
};

//------------------------------------------------------------------------------

/** Interface defining bidirectional access to a "virtual" sequence of elements.
 */
template <class TYPE>
class TISeq {
protected:
	virtual ~TISeq() {}
	
public:
	virtual int read(TYPE* elements, int len = 1) = 0;
	virtual int write(const TYPE* elements, int len = 1) = 0;
};

//------------------------------------------------------------------------------

/** Fast bidirectional queue implementing <code>TIQueue</code> and 
 * <code>TISeq</code>.
 * 
 * The queue is realised as an array, safe for both writing and/or reading 
 * from different threads. Queue allocates elements only once during 
 * construction (fast insertion/removal of elements).
 * Queue also supports TISeq interface allowing for insertion/removal of
 * multiple elements.
 */
template <class TYPE>
class TQueue: public TIQueue<TYPE>, TISeq<TYPE> {
protected:
	arr_ptr<TYPE> buf;
	int queueSize;
	bool autoRelease;
	int frontPtr, backPtr;
	int freeSpace;

	int _size() const {
		return queueSize - freeSpace;
	}
	int _free() const {
		return freeSpace;
	}

public:
	// Construction & destruction
	TQueue() : buf(NULL) {
	}
	TQueue(int queueSize, bool autoRelease = false) : buf(NULL) {
		resize(queueSize, autoRelease);
	}
	virtual ~TQueue() {
	}
	void resize(int queueSize, bool autoRelease = false) {
		if (buf == NULL || this->queueSize != queueSize)
			buf.reset(new TYPE [queueSize]);
		
		this->queueSize = queueSize;
		this->autoRelease = autoRelease;
		flush();
	}

	// TISeq<> interface:
	virtual inline int read(TYPE* elements, int len = 1) {
		if (len <= 0)
			len = _size();
			
		int frontLen1 = 0, frontLen2 = 0;

		if (freeSpace < queueSize) {
			// copy first memory region (>= backPtr)
			if (frontPtr >= backPtr) {
				frontLen1 = queueSize - frontPtr;
				if (frontLen1 > len)
					frontLen1 = len;
				memcpy(elements, buf.get() + frontPtr, frontLen1*sizeof(TYPE));
				frontPtr = Math::cycle_add(queueSize, frontPtr, frontLen1);
			}

			// copy second memory region (<  backPtr)
			if (frontPtr <  backPtr) {
				frontLen2 = backPtr - frontPtr;
				if (frontLen2 > len - frontLen1)
					frontLen2 = len - frontLen1;
				memcpy(elements + frontLen1, buf.get() + frontPtr, frontLen2*sizeof(TYPE));
				frontPtr = frontPtr + frontLen2;
			}

			freeSpace += frontLen1 + frontLen2;
		}

		return frontLen1 + frontLen2;
	}
	virtual inline int write(const TYPE* elements, int len = 1) {
		if (len <= 0)
			len = _free();
			
		int backLen1 = 0, backLen2 = 0;
		if (freeSpace > 0) {
			// copy first memory region (>= frontPtr)
			if (backPtr >= frontPtr) {
				backLen1 = queueSize - backPtr;
				if (backLen1 > len)
					backLen1 = len;
				memcpy(buf.get() + backPtr, elements, backLen1*sizeof(TYPE));
				backPtr = Math::cycle_add(queueSize, backPtr, backLen1);
			}

			// copy second memory region (<  frontPtr)
			if (backPtr <  frontPtr) {
				backLen2 = frontPtr - backPtr;
				if (backLen2 > len - backLen1)
					backLen2 = len - backLen1;
				memcpy(buf.get() + backPtr, elements + backLen1, backLen2*sizeof(TYPE));
				backPtr = backPtr + backLen2;
			}

			freeSpace -= backLen1 + backLen2;	
		}

		return backLen1 + backLen2;
	}
	virtual inline int read(TISeq<TYPE> &io, int len = 1) {
		if (len <= 0)
			len = _size();
			
		int frontLen = 0;
		if (freeSpace < queueSize) {
			frontLen = frontPtr >= backPtr ? queueSize - frontPtr : backPtr - frontPtr;
			if (frontLen > len)
				frontLen = len;
			frontLen = io.write(buf.get() + frontPtr, frontLen);
			frontPtr = Math::cycle_add(queueSize, frontPtr, frontLen);

			freeSpace += frontLen;
		}

		return frontLen;
	}
	virtual inline int write(TISeq<TYPE> &io, int len = 1) {
		if (len <= 0)
			len = _free();
			
		int backLen = 0;
		if (freeSpace > 0) {
			backLen = backPtr >= frontPtr ? queueSize - backPtr : frontPtr - backPtr;
			if (backLen > len)
				backLen = len;
			backLen = io.read(buf.get() + backPtr, backLen);
			backPtr = Math::cycle_add(queueSize, backPtr, backLen);

			freeSpace -= backLen;
		}

		return backLen;
	}

	// TIQueue<> interface:
	virtual inline TYPE& front(int index = 0) const {
		return buf[Math::cycle_add(queueSize, frontPtr, index)];	// index >= 0
	}
	virtual inline void push_front(const TYPE& element) {
		if (full()) {
			if (autoRelease) {
				backPtr = Math::cycle_sub(queueSize, backPtr, 1);
				freeSpace++;
			}
			else
				return;
		}

		frontPtr = Math::cycle_sub(queueSize, frontPtr, 1);
		buf[frontPtr] = element;
		freeSpace--;
	}
	virtual inline void pop_front(int len = 1) {
		if (len <= 0)
			return;
		if (len > _size())
			len = _size();
		frontPtr = Math::cycle_add(queueSize, frontPtr, len);
		freeSpace += len;
	}
	virtual inline int size_front() const {
		return _size();
	}
	virtual inline int free_front() const {
		return _free();
	}

	virtual inline TYPE& back(int index = 0) const {
		return buf[Math::cycle_sub(queueSize, backPtr, index + 1)];// index >= 0
	}
	virtual inline void push_back(const TYPE& element) {
		if (full()) {
			if (autoRelease) {
				frontPtr = Math::cycle_add(queueSize, frontPtr, 1);
				freeSpace++;
			}
			else
				return;
		}

		buf[backPtr] = element;
		backPtr = Math::cycle_add(queueSize, backPtr, 1);
		freeSpace--;
	}
	virtual inline void pop_back(int len = 1) {
		if (len <= 0)
			return;
		if (len > _size())
			len = _size();
		backPtr = Math::cycle_sub(queueSize, backPtr, len);
		freeSpace += len;
	}
	virtual inline int size_back() const {
		return _size();
	}
	virtual inline int free_back() const {
		return _free();
	}

	// Helper functions
	inline bool empty() const {
		return freeSpace == queueSize;
	}
	inline bool full() const {
		return freeSpace == 0;
	}
	inline void flush() {
		frontPtr = backPtr = 0;
		freeSpace = queueSize;
	}
	template <class TYPE2> int lookup_front(const TYPE2& item) const {
		const int size = size_front();
		if (size <= 0)
			return -1;
		
		int idx, lo = 0, hi = size;
		for (;;) {
			idx = (lo + hi)/2;
			if (lo + 1 >= hi)
				break;
			(front(size - idx - 1) < item ? lo : hi) = idx;
		}
		
		return size - idx - 1;
	}
	template <class TYPE2> int lookup_back(const TYPE2& item) const {
		const int size = size_back();
		if (size <= 0)
			return -1;
		
		int idx, lo = 0, hi = size;
		for (;;) {
			idx = (lo + hi)/2;
			if (lo + 1 >= hi)
				break;
			(back(size - idx - 1) < item ? lo : hi) = idx;
		}
		
		return size - idx - 1;
	}
};

//------------------------------------------------------------------------------

/** Generic state of the system with time stamp.
 * 
 * <code>State</code> generates the input and output states of the 
 * system basing on the template description <code>State</code>.
 */
class TimeStamp {
public:
	/** time stamp */
	SecTmReal t;
	
	TimeStamp(SecTmReal t = SEC_TM_REAL_ZERO) : t(t) {
	}
};

template <typename Type>
class State : public Type, public TimeStamp {
public:
	typedef std::vector<State> Seq;

	State(SecTmReal t = SEC_TM_REAL_ZERO) : TimeStamp(t) {
	}	

	inline bool operator < (const TimeStamp& s) const {
		return this->t < s.t;
	}
	inline bool operator < (SecTmReal t) const {
		return this->t < t;
	}
};

//------------------------------------------------------------------------------

/** Controller of a system which can be modeled as a 2-message-length control buffer.
 * 
 * Controller interface consists of the Controller wrapper (the protected part 
 * of <code>Controller</code>) which models a system,
 * and the Controller user interface (the public part 
 * of <code>Controller</code>) used for controlling a system.
 * <code>Send</code> and <code>Recv</code> template description are suitable input 
 * and output of a system.
 * 
 */
template <typename _Send, typename _Recv>
class Controller: protected Runnable {
public:
	/** System internal buffer length */
	static const U32 SYS_BUF_LEN = 2;
	/** Measurement */
	typedef golem::Measurement<SecTmReal> Measurement;

	/** Controller description
	 */
	class Desc {
	public:
		/** Working thread priority */
		Thread::Priority threadPriority;
		/** Inter-thread signalling time out */
		MSecTmU32 threadTimeOut;
		
		/** IO buffer length */
		size_t ioQueueLen;
		/** control buffer length */
		size_t ctrlQueueLen;
		/** number of calibration cycles */
		U32 cycleNum;
		/** Models the resolution of internal timers of a system - the smallest allowable time increment. */
		SecTmReal timeQuant;
		/** calibration cycle duration */
		SecTmReal cycleDur;
		/** cycle offset */
		SecTmReal deltaOffs;
		/** skew correction offset */
		SecTmReal skewOffs;

		Desc() {
			Desc::setToDefault();
		}

		virtual ~Desc() {}
		
		virtual void setToDefault() {
			threadPriority = Thread::HIGHEST;
			threadTimeOut = 5000; //[msec]

			ioQueueLen = 1000;
			ctrlQueueLen = 1000;
			cycleNum = 20;
			timeQuant = (SecTmReal)0.01; // [sec]
			cycleDur = (SecTmReal)0.300; // [sec]
			deltaOffs = (SecTmReal)0.02; // [sec]
			skewOffs = (SecTmReal)0.01; // [sec]
		}

		virtual bool isValid() const {
			if (threadTimeOut <= 0)
				return false;
			
			if (ioQueueLen <= 0 || ctrlQueueLen <= 0)
				return false;
			if (timeQuant <= (SecTmReal)0.0)
				return false;
			if (cycleNum <= 0 || cycleDur <= (SecTmReal)0.0 || deltaOffs <= (SecTmReal)0.0 || skewOffs <= (SecTmReal)0.0)
				return false;

			return true;
		}
	};

private:
	/** Input is time indexed (trajectory) */
	typedef State<_Send> Send;
	/** Output is time indexed (trajectory) */
	typedef State<_Recv> Recv;
	
	typedef TQueue<Send> SendQueue;
	typedef TQueue<Recv> RecvQueue;
	
	volatile bool bTerminate;
	Thread thread;
	
	// Input and output queues/buffers
	SendQueue qSend;
	RecvQueue qRecv;
	
	/** Inter-thread signalling time out */
	MSecTmU32 threadTimeOut;
	
	// Calibration variables
	/** Controller initialisation state. */
	bool bStart;
	/** Calibration state. */
	bool bCalibrating;
	/** Calibration state. */
	bool bCalibrated;
	/** I/O timings. */
	Measurement msrDeltaSync, msrDeltaRecv, msrDeltaProc, msrDeltaSend;
	/** Time delta - I/O cycle duration. */
	SecTmReal tmDelta;
	/** Time quant - I/O cycle duration "granularity". */
	SecTmReal timeQuant;
	/** cycle offset */
	SecTmReal deltaOffs;
	/** skew correction offset */
	SecTmReal skewOffs;

	// Working thread variables
	Event evSyncLock, evSyncUnlock;
	Event evReady, evCycle;
	SecTmReal tmCycle;
	SendQueue qCtrl;
	mutable CriticalSection csCtrl;

	volatile bool bSyncRequest, bCycleRequest;
	
	/** Initilises buffer queues */
	void initBuffers(const _Recv& curr, SecTmReal t, SecTmReal dt);

	/** Calibration stuff */
	bool calibrate(const Desc& desc);
	
	bool cycleWait(SecTmReal t, MSecTmU32 timeWait = MSEC_TM_U32_INF);
	
	/** Runnable/implementation of working thread */
	void run();
	
protected:
	/** golem::Context object. */
	golem::Context &context;

	/** Indicates if the controller undergoes calibration process.
	*
	*	Typically this function is used by overrides Controller#sysRecv(),
	*	Controller#sysSend(), Controller#sysSync() or Controller#userComm(), to check
	*	whether the control loop is in calibration mode.
	*
	*	@return				<code>true</code> the controller is just being calibrated;
	* 						<code>false</code> otherwise
	*/
	inline bool isCalibrating() const {
		return bCalibrating;
	}
	
	/** Indicates if the controller is calibratied.
	*
	*	@return				<code>true</code> the controller is calibrated;
	* 						<code>false</code> otherwise
	*/
	inline bool isCalibrated() const {
		return bCalibrated;
	}
	
	/** Models the output of a system.
	 * 
	 * This is the IO function which receives a single data packet, 
	 * describing the current state of a system.
	 * Controller assumes that <code>curr</code> is the state a system 
	 * has reached just before calling this function.
	 * 
	 * @param curr			current state of a system	
	 * @return				<code>true</code> no IO errors;
	 * 						<code>false</code> otherwise
	 * @see	Implementation for a generic robotic arm 
	 * 		<code>Arm#recv(GenConfigspaceCoord& curr)</code>
	 */
	virtual bool sysRecv(_Recv& curr) = 0;

	/** Models the input of a system.
	 * 
	 * This is the IO function which sends two data packets, which specify the 
	 * previous target state and the next target state of a system, 
	 * together with the desired time distance between them.
	 * Although Controller does not assumes how any potential system-specific 
	 * implementation of this function will interpret the function description,
	 * optimally a system will try to achieve <code>next</code> in 
	 * <code>dt + offset</code> seconds just after leaving this function.
	 * If the system internal buffer is empty <code>offset</code> equals zero,
	 * otherwise <code>offset</code> is equal to the previously sent distance
	 * <code>dt</code>.
	 * 
	 * @param prev			pointer to the previous state
	 * @param next			pointer to the next state
	 * @param dt			time distance between the previous and the next state	
	 * @return				<code>true</code> no IO errors;
	 * 						<code>false</code> otherwise
	 * @see	Implementation for a generic robotic arm 
	 * 		<code>Arm#send(const GenConfigspaceCoord& prev, const GenConfigspaceCoord& next, SecTmReal dt)</code>
	 * @see	System internal buffer <code>Controller#sync()</code>
	 */
	virtual bool sysSend(const _Send& prev, const _Send& next, SecTmReal dt) = 0;
	
	/** Models the internal buffer of a system.
	 * 
	 * The method signalises if a system is ready to accept new target state.
	 * It is assumed that a system has an internal buffer of length 2.
	 * This is an optimal length for all physical systems with limited 
	 * but reliable bandwidth of a communication channel between Controller and 
	 * a modelled system.
	 * 
	 * @return				<code>true</code> if the buffer is ready to send
	 * 						a new target state; <code>false</code> otherwise
	 * @see	Implementation for Katana arm 
	 * 		<code>KatArm#sync()</code>
	 * @see	Implementation for Katana simulator 
	 * 		<code>SimArm#sync()</code>
	 */
	virtual bool sysSync() = 0;

	/** User calibration function. */
	virtual void userCalibrate() {} // default implementation does not do anything
	
	/** User communication function. */
	virtual void userComm() {} // default implementation does not do anything
	
	/** This non-virtual function should be called before object descrution */
	void release();
	
	/** Each derived class should have virtual destructor releasing resources
	*	to avoid calling virtual functions of non-existing objects
	*/
	virtual ~Controller() {
		release();
	}

public:
	/** Constructs Controller */
	Controller(golem::Context &context);
	
	/** Creates/initialises Controller form the description
	 * @param desc			Controller description
	 * @return				<code>true</code> no errors;
	 * 						<code>false</code> otherwise
	*/
	bool create(const Desc& desc);
	
	/** Receives the actual state of a system.
	 * 
	 * @param curr			actual state
	 * @param t				requested time
	 * @param timeWait		waiting time in milliseconds
	 * @return				<code>true</code> no errors;
	 * 						<code>false</code> otherwise
	 */
	virtual bool recv(Recv& curr, SecTmReal t, MSecTmU32 timeWait = MSEC_TM_U32_INF);
	
	/** Sends the target state of a system.
	 * 
	 * Controller tries to achieve the target state at the time 
	 * <code>next.t</code> (see <code>State</code>). 
	 * By multiple calling of this function, by internal queuing up the target 
	 * state sequence, one can create or plan a target trajectory for a system. 
	 * The minimal time distance between two consecutive target 
	 * states is specified by <code>Desc::timeDelta</code>.
	 * 
	 * <p>
	 * 
	 * Because of the internal buffering of a system itself,
	 * in case of asynchronous calls of this function (e.g. as a reaction to 
	 * some external stimuli) it may take up to three times more time the 
	 * <code>Desc::timeDelta</code> for a system to achieve the 
	 * target state comparing to the current system time. 
	 * Internally, to avoid a potential damage of a system, Controller (should) 
	 * never allows for sending to a system, two consecutive target states 
	 * with time distance between them shorter than the minimal one.
	 * Therefore, for asynchronous calls, to avoid time mismatch between 
	 * the target state and the real state of a physical system, 
	 * as well as to keep the reaction time fixed,
	 * it is advised to send target states with the time stamp <code>next.t</code>
	 * set to at least <code>Controller#getTimeDeltaAsync()</code> 
	 * later than the current system time.
	 * 
	 * <p>
	 * 
	 * By default, the function clears up the internal state queue up to the new 
	 * target state basing on the time stamp <code>next.t</code>. 
	 * If the internal state queue is full, the function waits until no longer 
	 * than <code>timeWait</code> milliseconds.
	 * 
	 * 
	 * @param next			target state
	 * @param timeWait		waiting time in milliseconds
	 * @return				<code>true</code> if the new target state has been
	 * 						successfully updated; <code>false</code> otherwise
	 *
	 * @see	Time delta for asynchronous calls
	 * 		<code>Controller#getTimeDeltaAsync()</code>
	 * @see	System time
	 * 		<code>Controller#context.getTimer()->elapsed()</code>
	 */
	virtual bool send(const Send& next, MSecTmU32 timeWait = MSEC_TM_U32_INF);

	// IO helper functions
	
	/* Access to the history of states of the system at given time (system output). */
	bool lookupOut(Recv* prev, Recv* next, SecTmReal t) const;
	
	/* Access to the history of states of the system at given time interval (system output). */
	bool lookupOut(std::vector<Recv>& out, SecTmReal t0, SecTmReal t1) const;
	
	/* Access to the control queue of the system at given time (system input). */
	bool lookupInp(Send* prev, Send* next, SecTmReal t) const;
	
	/* Access to the control queue of the system at given time interval (system input). */
	bool lookupInp(std::vector<Send>& inp, SecTmReal t0, SecTmReal t1) const;
	
	/** Time quant. */
	inline SecTmReal getTimeQuant() const {
		return timeQuant;
	}

	/** Returns the minimal time distance between two consecutive target states.
	 * 
	 * The minimal time distance is calculated dynamically during calibration,
	 * and is limited by communication bandwidth with a system.
	 * 
	 * @return				time distance in seconds
	 */
	inline SecTmReal getTimeDelta() const {
		return tmDelta + skewOffs;
	}

	/** Returns the minimal time distance between the current system time
	 * and the target one for asynchronous calls.
	 * 
	 * The minimal time distance is calculated dynamically during calibration,
	 * and is limited by communication bandwidth with a system.
	 * 
	 * @return				time distance in seconds
	 * @see	Sending target states 
	 * 		<code>Controller#send(const Send& next, MSecTmU32 timeWait)</code>
	 */
	inline SecTmReal getTimeDeltaAsync() const {
		return (SYS_BUF_LEN + 1)*getTimeDelta();
	}

	/** golem::Context object */
	inline const golem::Context& getContext() const {
		return context;
	}
	inline golem::Context& getContext() {
		return context;
	}
};

//------------------------------------------------------------------------------

template <typename _Send, typename _Recv>
Controller<_Send, _Recv>::Controller(golem::Context& context) :
	context(context)
{
	bTerminate = true;
	bStart = false;
	bCalibrating = false;
	bCalibrated = false;
	bSyncRequest = bCycleRequest = false;
}

//------------------------------------------------------------------------------

template <typename _Send, typename _Recv>
void Controller<_Send, _Recv>::initBuffers(const _Recv& curr, 
	SecTmReal t, SecTmReal dt)
{
	Send inp;
	(_Send&)inp = curr;	// requires a suitable copying operator
	Recv out;
	(_Recv&)out = curr;	// default copying operator
	out.t = inp.t = t;
	
	// Init input queue, 2 elements
	qSend.flush();	// flush
	qSend.push_front(inp);	// previous
	inp.t += dt;
	qSend.push_front(inp);	// next
	
	// Init control queue, 1 element
	qCtrl.flush();	// flush
	qCtrl.push_front(inp);
	
	// Init output queue, 2 elements
	qRecv.flush();	// flush
	qRecv.push_front(out);	// previous
	out.t += dt;
	qRecv.push_front(out);	// next
}

template <typename _Send, typename _Recv>
bool Controller<_Send, _Recv>::create(const Desc& desc) {
	if (!desc.isValid()) {
		context.getLogger()->post(new MsgControllerInvalidDesc(), Message::LEVEL_CRIT,
			"Controller::create(): Invalid description"
		);
		return false;
	}

	if (bStart) {
		context.getLogger()->post(new MsgController(), Message::LEVEL_WARNING,
			"Controller::create(): Controller has already been created"
		);
		return true;
	}

	threadTimeOut = desc.threadTimeOut;

	evReady.set(true);

	qSend.resize((int)desc.ioQueueLen, true);
	qRecv.resize((int)desc.ioQueueLen, true);
	qCtrl.resize((int)desc.ctrlQueueLen);
	
	bTerminate = false;
	if (!thread.start(this)) {
		context.getLogger()->post(new MsgControllerThreadLaunch(), Message::LEVEL_CRIT,
			"Controller::create(): Unable to launch Controller thread"
		);
		return false;
	}
	if (!thread.setPriority(desc.threadPriority)) {
		context.getLogger()->post(new MsgController(), Message::LEVEL_ERR,
			"Controller::create(): Unable to change Controller thread priority"
		);
	}
	
	bStart = true;

	if (!calibrate(desc)) {
		context.getLogger()->post(new MsgControllerCalibration(), Message::LEVEL_CRIT,
			"Controller::create(): Calibration failure"
		);
		return false;
	}
	
	return true;
}

template <typename _Send, typename _Recv>
void Controller<_Send, _Recv>::release() {
	bTerminate = true;
	if (!thread.join(threadTimeOut)) {
		context.getLogger()->post(new MsgController(), Message::LEVEL_ERR,
			"Controller::release(): Unable to stop working thread"
		);
	}
}

template <typename _Send, typename _Recv>
bool Controller<_Send, _Recv>::calibrate(const Desc& desc) {
	// Enter calibration mode
	bCalibrating = true;
	bCalibrated = false;
	
	// user calibration
	userCalibrate();
	
	// Request synchronisation and wait for confirmation
	// The main control loop in the working thread become blocked
	bSyncRequest = true;
	if (!evSyncLock.wait(threadTimeOut)) {
		context.getLogger()->post(new MsgController(), Message::LEVEL_ERR,
			"Controller::calibrate(): evSyncLock timeout (1)"
		);
		return false;
	}
	
	// Receive the current output state
	_Recv curr;
	if (!sysRecv(curr)) {
		context.getLogger()->post(new MsgController(), Message::LEVEL_ERR,
			"Controller::calibrate(): receive error"
		);
		return false;
	}
	
	// Reset all measurements
	msrDeltaSync.reset();
	msrDeltaRecv.reset();
	msrDeltaProc.reset();
	msrDeltaSend.reset();

	timeQuant = desc.timeQuant;
	deltaOffs = desc.deltaOffs;
	skewOffs = desc.skewOffs;
	tmDelta = desc.cycleDur;
	initBuffers(curr, context.getTimer()->elapsed() - tmDelta, tmDelta);

	Send next;
	(_Send&)next = curr;	// requires a suitable copying operator
	next.t = context.getTimer()->elapsed() + (SYS_BUF_LEN + 1)*desc.cycleDur;
	// Send series of data without changing the system state:
	for (U32 i = 0; i <= desc.cycleNum; i++, next.t += desc.cycleDur)
		qCtrl.push_front(next);
	
	// Unlock the control loop
	evSyncUnlock.set(true);
	
	// Wait until the system has reached the target state
	if (!cycleWait(next.t, (MSecTmU32)(1000.0*desc.cycleDur*(desc.cycleNum+2)) + threadTimeOut)) {
		context.getLogger()->post(new MsgController(), Message::LEVEL_ERR,
			"Controller::calibrate(): cycleWait timeout"
		);
		return false;
	}
	
	// Lock the control loop
	bSyncRequest = true;
	if (!evSyncLock.wait(threadTimeOut)) {
		context.getLogger()->post(new MsgController(), Message::LEVEL_ERR,
			"Controller::calibrate(): evSyncLock timeout (2)"
		);
		return false;
	}
	
	// The minimal trajectory duration time is a multiple of timeQuant
	tmDelta = Math::ceil(msrDeltaSync.getAvr() + msrDeltaRecv.getAvr() + msrDeltaProc.getAvr() + 
		msrDeltaSend.getAvr() + deltaOffs, timeQuant);
	
	// Init all buffers
	initBuffers(curr, context.getTimer()->elapsed() - tmDelta, tmDelta);
	
//#ifdef GOLEM_CTRL_CONTROLLER_DBG_
	context.getLogger()->post(new MsgController(), Message::LEVEL_INFO,
		"Controller::calibrate(): delta_offs=%f, skew_offs=%f, cycle=%f, sync=%f, recv=%f, proc=%f, send=%f",
		deltaOffs, skewOffs, tmDelta, msrDeltaSync.getAvr(), msrDeltaRecv.getAvr(), msrDeltaProc.getAvr(), msrDeltaSend.getAvr()
	);
//#endif

	// Leave calibration mode
	bCalibrating = false;
	bCalibrated = true;
	
	// Unlock the control loop
	evSyncUnlock.set(true);

	return true;
}

template <typename _Send, typename _Recv>
bool Controller<_Send, _Recv>::cycleWait(SecTmReal t, MSecTmU32 timeWait) {
	evCycle.set(false);
	tmCycle = t;
	bCycleRequest = true;
	
	if (!evCycle.wait(timeWait)) {
		//context.getLogger()->post(new MsgController(), Message::LEVEL_NOTICE,
		//	"Controller::cycleWait(): evCycle timeout"
		//);
		return false;
	}
	
	bCycleRequest = false;
	return true;
}

//------------------------------------------------------------------------------
// Runnable

/** Communication function working in a separate thread. 
 * 
 * The function dispatches messages (states) from/to queues to/from 
 * system.
 */
template <typename _Send, typename _Recv>
void Controller<_Send, _Recv>::run() {
	bool bSendCurr = false;
	SecTmReal tCurr = SEC_TM_REAL_ZERO, dtCurr = SEC_TM_REAL_ZERO, tPred = SEC_TM_REAL_ZERO;
	
	while (!bTerminate) {
		const SecTmReal t0 = context.getTimer()->elapsed();

		// Wait for buffer ready to accept new data
		if (!sysSync())
			continue;
		
		const SecTmReal t1 = context.getTimer()->elapsed();
		
		// Receive data
		Recv curr;
		(void)sysRecv((_Recv&)curr);
		// User IO function
		userComm();

		const SecTmReal t2 = context.getTimer()->elapsed();
		
		Send prev, next;
		{
			CriticalSectionWrapper csw(csCtrl);	// enter critical section
			
			// Process received data
			qRecv.push_front(curr);
			qRecv.front().t = t1;	// approx
			
			// Variables controlling send queue
			const SecTmReal tPrev = tCurr;
			tCurr = t0;
			const bool bSendPrev = bSendCurr;
			bSendCurr = qCtrl.size_back() > 1; // check if there is data to send
			
			// correction <- prediction (prev cycle)
			if (bSendPrev)
				qSend.front().t = tCurr + dtCurr;
			
			// Process send data
			if (bSendCurr) {
				prev = qCtrl.back(0);
				next = qCtrl.back(1);
				
				const SecTmReal dtPrev = dtCurr;
				SecTmReal dtSkew;

				if (bSendPrev) {
					dtSkew = prev.t - (tCurr + dtCurr);
					tPred = tCurr + dtPrev;
				}
				else {
					dtSkew = std::min(SEC_TM_REAL_ZERO, (next.t - tmDelta) - std::max(tPred + dtPrev, tCurr + tmDelta));
					tPred = std::max(SEC_TM_REAL_ZERO, tPred + dtPrev - (tCurr + tmDelta)) + t2 + msrDeltaRecv.getAvr() + msrDeltaSend.getAvr();
					// Report a possible timer skew (Controller does not allow for sending so short trajectories)
					if (isCalibrated() && dtSkew + tmDelta/SecTmReal(2.0) < SEC_TM_REAL_ZERO) {
						context.getLogger()->post(new MsgController(), Message::LEVEL_WARNING,
							"Controller::run(): timer skew detected = %f", dtSkew
						);
					}
				}
				
				dtCurr = Math::round(std::max(next.t - tPred, tmDelta), timeQuant);
				
#ifdef GOLEM_CTRL_CONTROLLER_DBG_
				context.getLogger()->post(new MsgController(), Message::LEVEL_DEBUG,
					"SENDING t=%f, dt=%f, tPred=%f, tCurr=%f, dtCurr=%f, dtSkew=%f", next.t, next.t - prev.t, tPred, tCurr, dtCurr, dtSkew);
#endif

				qSend.push_front(next);
				// prediction -> correction (next cycle)
				qSend.front().t = tPred + dtCurr;
				
				qCtrl.pop_back();
				evReady.set(true);	// queue is ready for new commands
			}
		
		}// leave critical section
		
		evCycle.set(bCycleRequest && tmCycle < t0);
		
		const SecTmReal t3 = context.getTimer()->elapsed();
		
		// Send data
		if (bSendCurr)
			(void)sysSend(prev, next, dtCurr);
		
		const SecTmReal t4 = context.getTimer()->elapsed();
		
		if (isCalibrating() && bSendCurr) {
			msrDeltaSync.update(t1 - t0);
			msrDeltaRecv.update(t2 - t1);
			msrDeltaProc.update(t3 - t2);
			msrDeltaSend.update(t4 - t3);
		}

		if (isCalibrated()) {
			//if ((t1 - t0) > msrDeltaSync.getAvr() + deltaOffs) {
			//	context.getLogger()->post(new MsgController(), Message::LEVEL_WARNING,
			//		"Controller::run(): sysSync() timeout = %f", (t1 - t0)
			//	);
			//}
			if ((t2 - t1) > msrDeltaRecv.getAvr() + deltaOffs) {
				context.getLogger()->post(new MsgController(), Message::LEVEL_WARNING,
					"Controller::run(): sysRecv()/userComm() timeout = %f", (t2 - t1)
				);
			}
			if ((t3 - t2) > msrDeltaProc.getAvr() + deltaOffs) {
				context.getLogger()->post(new MsgController(), Message::LEVEL_WARNING,
					"Controller::run(): critical section timeout = %f", (t3 - t2)
				);
			}
			if ((t4 - t3) > msrDeltaSend.getAvr() + deltaOffs) {
				context.getLogger()->post(new MsgController(), Message::LEVEL_WARNING,
					"Controller::run(): sysSend() timeout = %f", (t4 - t3)
				);
			}
		}
		
		if (bSyncRequest) {
			bSyncRequest = false;
			evSyncLock.set(true);
			if (!evSyncUnlock.wait(threadTimeOut)) {
				context.getLogger()->post(new MsgController(), Message::LEVEL_ERR,
					"Controller::run(): evSyncUnlock timeout"
				);
				bTerminate = true;
			}
			evSyncUnlock.set(false);
		}
	}
	
	// Wake up waiting threads
	evReady.set(true);
	evCycle.set(true);
}

//------------------------------------------------------------------------------
// Main control interface

// Default implementation of the function returns measured states
template <typename _Send, typename _Recv>
bool Controller<_Send, _Recv>::recv(Recv& curr, SecTmReal t, MSecTmU32 timeWait) {
	if (bTerminate)
		// do not post any error message, since the system is just being stopped
		return false;
	
	if (timeWait > 0 && !cycleWait(t, timeWait)) {
		context.getLogger()->post(new MsgController(), Message::LEVEL_NOTICE,
			"Controller::recv(): timeout"
		);
		return false;
	}
	
	return lookupOut(&curr, NULL, t);
}

/* The function communicates with run() (running in a separate thread) 
 * through qCtrl. Communication is synchronised thanks to events and 
 * the critical section csCtrl.
 */
template <typename _Send, typename _Recv>
bool Controller<_Send, _Recv>::send(const Send& next, MSecTmU32 timeWait) {
	if (bTerminate)
		// do not post any error message, since the system is just being stopped
		return false;
	
	CriticalSectionWrapper csw(csCtrl);	// enter critical section

	int qIdx = qCtrl.lookup_front(next);
	if (qIdx < 0) {
		context.getLogger()->post(new MsgController(), Message::LEVEL_ERR,
			"Controller::send(): qCtrl is empty"
		);
		return false;
	}
	
	if (qIdx == 0) {
		csw.unlock();// critical section: END
		
		if (!evReady.wait(timeWait)) {
			context.getLogger()->post(new MsgController(), Message::LEVEL_NOTICE,
				"Controller::send(): timeout"
			);
			return false;
		}
		
		csw.lock();	// critical section: BEGIN
	}

	if (isCalibrating()) {
		context.getLogger()->post(new MsgController(), Message::LEVEL_WARNING,
			"Controller::send(): no access to control loop"
		);
		return false;
	}

	if (qCtrl.front(qIdx).t + tmDelta - timeQuant/SecTmReal(2.0) > next.t) {
		// If the consecutive target states are too close, drop the one before 
		// qIdx as well
		qIdx++;
	}
	
	if (qIdx > 0) {
		// If 'next' refers to a moment in time before the last queued element,
		// re-plan the sequence of states (reactive behaviour) - clear up the queue
		// but always leave the last element
		qCtrl.pop_front(std::min(qIdx, qCtrl.size_back() - 1));
	}
	
	qCtrl.push_front(next);

	if (qCtrl.full())
		evReady.set(false);
	
	return true;
}

//------------------------------------------------------------------------------

// History helper functions
template <typename _Send, typename _Recv>
bool Controller<_Send, _Recv>::lookupOut(Recv* prev, Recv* next, SecTmReal t) const {
	CriticalSectionWrapper csw(csCtrl);	// enter critical section
	
	if (bTerminate)
		// do not post any error message, since the system is just being stopped
		return false;
	
	if (isCalibrating()) {
		context.getLogger()->post(new MsgController(), Message::LEVEL_WARNING,
			"Controller::lookupOut(): no access to control loop"
		);
		return false;
	}
	
	int idx = std::max(qRecv.lookup_front(t), 1);
	if (prev != NULL)
		*prev = qRecv.front(idx);
	if (next != NULL)
		*next = qRecv.front(idx - 1);
	
	return true;
}

template <typename _Send, typename _Recv>
bool Controller<_Send, _Recv>::lookupOut(std::vector<Recv>& out, SecTmReal t0, SecTmReal t1) const {
	CriticalSectionWrapper csw(csCtrl);	// enter critical section
	
	if (bTerminate)
		// do not post any error message, since the system is just being stopped
		return false;
	
	if (isCalibrating()) {
		context.getLogger()->post(new MsgController(), Message::LEVEL_WARNING,
			"Controller::lookupOut(): no access to control loop"
		);
		return false;
	}
	
	Recv *pState;
	int idx = std::max(qRecv.lookup_front(t0), 1);
	pState = &qRecv.front(idx);
	out.push_back(*pState);
	do {
		pState = &qRecv.front(--idx);
		out.push_back(*pState);
	} while (idx > 0 && *pState < t1);
	
	return true;
}
	
template <typename _Send, typename _Recv>
bool Controller<_Send, _Recv>::lookupInp(Send* prev, Send* next, SecTmReal t) const {
	CriticalSectionWrapper csw(csCtrl);	// enter critical section

	if (bTerminate)
		// do not post any error message, since the system is just being stopped
		return false;
	
	if (isCalibrating()) {
		context.getLogger()->post(new MsgController(), Message::LEVEL_WARNING,
			"Controller::lookupInp(): no access to control loop"
		);
		return false;
	}
	
	const SendQueue *q = qSend.front() < t && qCtrl.size_front() > 1 ? &qCtrl : &qSend;	
	int idx = std::max(q->lookup_front(t), 1);
	if (prev != NULL)
		*prev = q->front(idx);
	if (next != NULL)
		*next = q->front(idx - 1);
	
	return true;
}

template <typename _Send, typename _Recv>
bool Controller<_Send, _Recv>::lookupInp(std::vector<Send> &inp, SecTmReal t0, SecTmReal t1) const {
	CriticalSectionWrapper csw(csCtrl);	// enter critical section

	if (bTerminate)
		// do not post any error message, since the system is just being stopped
		return false;
	
	if (isCalibrating()) {
		context.getLogger()->post(new MsgController(), Message::LEVEL_WARNING,
			"Controller::lookupInp(): no access to control loop"
		);
		return false;
	}
	
	Send *pState;
	bool bCtrl = qCtrl.size_front() > 1;

	if (!(qSend.front() < t0 && bCtrl)) {
		int idx = std::max(qSend.lookup_front(t0), 1);
		pState = &qSend.front(idx);
		inp.push_back(*pState);
		do {
			pState = &qSend.front(--idx);
			inp.push_back(*pState);
		} while (idx > 0 && *pState < t1);
	}

	if (qSend.front() < t1 && bCtrl) {
		int idx = std::max(qCtrl.lookup_front(t0), 1);
		if (qSend.front() < t0) {
			pState = &qCtrl.front(idx);
			inp.push_back(*pState);
		}
		do {
			pState = &qCtrl.front(--idx);
			inp.push_back(*pState);
		} while (idx > 0 && *pState < t1);
	}

	return true;
}

//------------------------------------------------------------------------------

};	// namespace

#endif /*_GOLEM_CTRL_CONTROLLER_H_*/
