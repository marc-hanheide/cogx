/** @file Planner.h
 * 
 * Arm movement control library.
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#pragma once
#ifndef _GOLEM_CTRL_PLANNER_H_
#define _GOLEM_CTRL_PLANNER_H_

#include <Golem/Ctrl/Arm.h>
#include <Golem/Ctrl/Heuristic.h>

//------------------------------------------------------------------------------

namespace golem {

//------------------------------------------------------------------------------

/** Base class for Arm movement control. */
class Planner {
public:
	typedef obj_ptr<Planner> Ptr;
#ifdef WIN32	// FIX
	friend class Ptr;
#endif

	/** Planning mode */
	enum Mode {
		/** auto */
		MODE_AUTO,
		/** local planning */
		MODE_LOCAL,
		/** global planning */
		MODE_GLOBAL,
	};

	/** Path of generalised joint states constitutes trajectory in the joint space */
	typedef std::list<GenConfigspaceState> Trajectory;
	
	/** Callback interface for data synchronization */
	class Callback {
	public:
		virtual ~Callback() {}
		/** synchronization of collision bounds */
		virtual void syncCollisionBounds() {}//= 0;
		/** synchronization of find data */
		virtual void syncFindData(Trajectory::const_iterator begin, Trajectory::const_iterator end, const WorkspaceCoord *pTarget = NULL) {}//= 0;
		/** synchronization of send data */
		virtual void syncSendData(Trajectory::const_iterator begin, Trajectory::const_iterator end) {}//= 0;
	};

	/** Planner description */
	class Desc {
	public:
		typedef obj_ptr<Desc> Ptr;
		
		/** Maximal joint velocity (absolute value) normlised to joint velocity limits */
		Real velocity;
		/** Maximal joint acceleration (absolute value) normlised to joint acceleration limits */
		Real acceleration;
		/** Arm trajectory profile description */
		Profile::Desc::Ptr pProfileDesc;
		/** Heuristic description */
		Heuristic::Desc::Ptr pHeuristicDesc;
		
		/** Constructs the description object. */
		Desc() {
			Desc::setToDefault();
		}

		virtual ~Desc() {}
		
		/** Creates Planner given the description object. 
		* @return		pointer to the Planner, if no errors have occured;
		*				<code>NULL</code> otherwise 
		*/
		virtual Planner::Ptr create(golem::Arm &arm) const = 0;
		
		/** Sets the planner parameters to the default values */
		virtual void setToDefault() {
			velocity = Real(1.0);
			acceleration = Real(1.0);
			pProfileDesc.reset(new Polynomial4::Desc);
			pHeuristicDesc.reset(new Heuristic::Desc);
		}

		/** Checks if the planner description is valid. */
		virtual bool isValid() const {
			if (velocity <= REAL_ZERO || acceleration <= REAL_ZERO)
				return false;
			if (pProfileDesc == NULL || !pProfileDesc->isValid())
				return false;
			if (pHeuristicDesc == NULL || !pHeuristicDesc->isValid())
				return false;
			
			return true;
		}
	};

protected:
	/** Arm controller interface */
	golem::Arm &arm;
	/** Context object */
	golem::Context &context;

	/** Maximal joint velocity (absolute value) normlised to joint velocity limits */
	Real velocity;
	/** Maximal joint acceleration (absolute value) normlised to joint acceleration limits */
	Real acceleration;
	/** Arm trajectory profile */
	Profile::Ptr pProfile;
	/** Heuristic object */
	Heuristic::Ptr pHeuristic;
	
	/** Generator of pseudo random numbers */
	Rand rand;
	
	/** Callback interface for auto synchronization of collision bounds */
	Callback* pCallback;

	/** Creates Planner from the description. 
	* @param desc		Planner description
	* @return			<code>TRUE</code> no errors; <code>FALSE</code> otherwise 
	*/
	bool create(const Desc& desc);

	/** Planner constructor */
	Planner(golem::Arm &arm);

#ifndef WIN32	// FIX
public:
#endif
	/** Descructor */
	virtual ~Planner() {}

public:
	/** Finds trajectory of the arm joints.
	* @param path		trajectory
	* @param iter		instertion point
	* @param begin		trajectory initial state in jointspace coordinates
	* @param end		trajectory final state in jointspace coordinates
	* @return			<code>TRUE</code> no errors; <code>FALSE</code> otherwise 
	*/
	virtual bool find(Trajectory &trajectory, Trajectory::iterator iter, const GenConfigspaceState &begin, const GenConfigspaceState &end, Mode mode = MODE_AUTO) = 0;

	/** Finds trajectory of the arm joints.
	* @param path		trajectory
	* @param iter		instertion point
	* @param begin		trajectory initial state in jointspace coordinates
	* @param end		trajectory final state in workspace coordinates
	* @return			<code>TRUE</code> no errors; <code>FALSE</code> otherwise 
	*/
	virtual bool find(Trajectory &trajectory, Trajectory::iterator iter, const GenConfigspaceState &begin, const GenWorkspaceState &end, Mode mode = MODE_AUTO) = 0;

	/** Sends a trajectory to the arm controller.
	* @param begin		beginning of trajectory
	* @param end		end of trajectory
	* @param timeWait	waiting time in milliseconds
	* @return			<code>TRUE</code> no errors; <code>FALSE</code> otherwise 
	*/
	virtual bool send(Trajectory::iterator begin, Trajectory::iterator end, MSecTmU32 timeWait = MSEC_TM_U32_INF);
	
	/** Maximal joint velocity (absolute value) normlised to joint velocity limits
	 * @return				maximal joint velocity
	 */
	virtual inline Real getVelocity() const {
		return velocity;
	}

	/** Sets maximal joint velocity (absolute value) normlised to joint velocity limits
	 * @param velocity		maximal joint velocity, range: (0..inf], default: 1.0
	 */
	virtual inline void setVelocity(Real velocity) {
		this->velocity = velocity;
	}
	
	/** Maximal joint acceleration (absolute value) normlised to joint acceleration limits
	 * @return				maximal joint acceleration
	 */
	virtual inline Real getAcceleration() const {
		return acceleration;
	}

	/** Sets maximal joint acceleration (absolute value) normlised to joint acceleration limits
	 * @param acceleration		maximal joint acceleration, range: (0..inf], default: 1.0
	 */
	virtual inline void setAcceleration(Real acceleration) {
		this->acceleration = acceleration;
	}

	/** Returns Trajectory profile
	 * @return				Trajectory profile
	 */
	virtual inline Profile::Ptr getTrajectory() const {
		return pProfile;
	}

	/** Sets Trajectory profile
	 * @param pProfile	Trajectory profile
	 */
	virtual inline void setTrajectory(const Profile::Ptr &pProfile) {
		this->pProfile = pProfile;
	}

	/** Returns heuristic object
	 * @return				heuristic
	 */
	virtual inline Heuristic::Ptr getHeuristic() const {
		return pHeuristic;
	}

	/** Sets heuristic object
	 * @param pHeuristic	heuristic
	 */
	virtual inline void setHeuristic(const Heuristic::Ptr &pHeuristic) {
		this->pHeuristic = pHeuristic;
	}
	
	/** Callback interface for data synchronization
	 * @param pCallback	pointer to the interface
	*/
	inline void setCallback(Callback* pCallback) {
		this->pCallback = pCallback;
	}
	
	/** Callback interface for data synchronization
	 * @return				pointer to the interface
	*/
	inline Callback* getCallback() {
		return pCallback;
	}
	
	/** Access to Arm controller
	 * @return				reference to the Arm controller
	 */
	inline const Arm &getArm() const {
		return arm;
	}
	inline Arm &getArm() {
		return arm;
	}
};

//------------------------------------------------------------------------------

};	// namespace

#endif /*_GOLEM_CTRL_PLANNER_H_*/
