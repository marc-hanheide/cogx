/** @file Data.cpp
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#include <Golem/Ctrl/Data.h>
#include <Golem/Ctrl/Simulator.h>
#include <Golem/Ctrl/Katana.h>

//------------------------------------------------------------------------------

using namespace golem;

//------------------------------------------------------------------------------

void golem::XMLData(golem::Arm::Desc::Ptr &val, XMLContext* context, bool create) {
	ASSERT(context)
	
	// Determine type
	std::string armType = "gen_sim_arm";
	XMLData("type", armType, context, create);
	
	// Setup controller description
	if (!armType.compare("kat_serial_arm")) {
		golem::KatSerialArm::Desc *pDesc = new golem::KatSerialArm::Desc();
		val.reset(pDesc);
		XMLData("path", pDesc->cfgPath, context->getContextFirst("kat_serial_arm config"), create);
		XMLData("port", pDesc->serialDesc.commPort, context->getContextFirst("kat_serial_arm comm"), create);
	}
	else if (!armType.compare("kat_sim_arm")) {
		golem::KatSimArm::Desc *pDesc = new golem::KatSimArm::Desc();
		val.reset(pDesc);
	}
	else if (!armType.compare("gen_sim_arm")) {
		golem::GenSimArm::Desc *pDesc = new golem::GenSimArm::Desc();
		val.reset(pDesc);
	}

	XMLData("delta_offs", val->deltaOffs, context->getContextFirst("calibration"), create);
	XMLData("skew_offs", val->skewOffs, context->getContextFirst("calibration"), create);
	XMLData(val->globalPose, context->getContextFirst("pose"), create);
}

//------------------------------------------------------------------------------
