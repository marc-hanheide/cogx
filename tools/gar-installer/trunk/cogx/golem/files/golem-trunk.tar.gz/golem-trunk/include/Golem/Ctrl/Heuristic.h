/** @file Heuristic.h
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#pragma once
#ifndef _GOLEM_CTRL_HEURISTIC_H_
#define _GOLEM_CTRL_HEURISTIC_H_

//------------------------------------------------------------------------------

#include <Golem/Ctrl/Waypoint.h>

//------------------------------------------------------------------------------

namespace golem {

//------------------------------------------------------------------------------

/** Performance monitor */
//#define _HEURISTIC_PERFMON

//------------------------------------------------------------------------------

/** Waypoint path optimisation atomic routines */
class Heuristic {
public:
	typedef obj_ptr<Heuristic> Ptr;
#ifdef WIN32	// FIX
	friend class Ptr;
#endif
	friend class Desc;
	
	/** Heuristic description */
	class Desc {
	public:
		typedef obj_ptr<Desc> Ptr;

		/** jointspace distance factor */
		Real distJointspaceFac;
		/** workspace distance factor */
		Real distWorkspaceFac;

		/** Linear distance maximum */
		Real distLinearMax;
		/** angular distance maximum */
		Real distAngularMax;
		/** maximum distance between two configuration space coordinates */
		ConfigspaceCoord distJointcoordMax;
		/** Rest position distance factor */
		ConfigspaceCoord distRestJointcoordFac;
		
		/** Colision detection */
		bool collisionDetection;		
		/** collision distance delta */
		Real colissionDistDelta;
		/** Objects skin thickness */
		Real skinThickness;
		
		/** Constructs the description object. */
		Desc() {
			Desc::setToDefault();
		}

		/** virtual destructor */
		virtual ~Desc() {}
		
		/** Creates the object from the description. */
		CREATE_FROM_OBJECT_DESC(Heuristic, Heuristic::Ptr, Arm)
		
		/** Sets the parameters to the default values */
		virtual void setToDefault() {
			distJointspaceFac = Real(0.8); // [0, 1]
			distWorkspaceFac = Real(0.18);//Real(0.7); // [0, 1]
			
			distLinearMax = Real(0.25);//OLD: 0.35
			distAngularMax = Real(0.25);//OLD: 0.35
			distJointcoordMax.set(Real(0.75)*REAL_PI);
			distRestJointcoordFac.set(Real(0.01)); //0.01

			collisionDetection = true;
			colissionDistDelta = Real(0.025);
			skinThickness = Real(0.01);
		}

		/** Checks if the description is valid. */
		virtual bool isValid() const {
			if (distJointspaceFac < REAL_ZERO || distJointspaceFac > REAL_ONE)
				return false;
			if (distWorkspaceFac < REAL_ZERO || distWorkspaceFac > REAL_ONE)
				return false;

			if (distLinearMax <= REAL_ZERO)
				return false;
			if (distAngularMax <= REAL_ZERO)
				return false;
			if (!distJointcoordMax.isPositive())
				return false;			
			if (!distRestJointcoordFac.isPositive())
				return false;

			if (colissionDistDelta <= REAL_ZERO)
				return false;
			if (skinThickness < REAL_ZERO)
				return false;

			return true;
		}
	};

protected:
	typedef std::vector<golem::Mat34> Mat34Seq;
	/** Arm controller */
	golem::Arm &arm;
	/** Context object */
	golem::Context &context;
	
	/** characteristic workspace distance scale */
	Real distWorkspaceScale;
	/** jointspace distance factor */
	Real distJointspaceFac;
	/** workspace distance factor */
	Real distWorkspaceFac;
	
	/** Linear distance maximum */
	Real distLinearMax;
	/** angular distance maximum */
	Real distAngularMax;
	/** maximum distance between two configuration space coordinates */
	ConfigspaceCoord distJointcoordMax;
	/** Rest position cost factor */
	ConfigspaceCoord distRestJointcoordFac;
	
	/** Colision detection */
	bool collisionDetection;
	/** collision distance delta */
	Real colissionDistDelta;
	/** Objects skin thickness */
	Real skinThickness;
	
	/** number of joints */
	const U32 numOfJoints;
	/** Bounds of arm joints */
	mutable std::vector<golem::Bounds::Seq> armBounds;	
	/** Poses of bounds of arm joints */
	std::vector<Mat34Seq> armBoundsPoses;
	/** The collection of bounds of objects */
	golem::Bounds::Seq collisionBounds;	
	
	/** Joint position limits */
	ConfigspaceCoord min, max, delta;
	
	mutable CriticalSection cs;

	void setPose(golem::Bounds::Seq& boundsSeq, const Mat34Seq& boundsPoses, const Mat34& pose) const;

	bool intersect(const golem::Bounds::Seq& boundsSeq0, const golem::Bounds::Seq& boundsSeq1) const;

	/** Creates Heuristic from the description. 
	* @param desc		Heuristic description
	* @return			<code>TRUE</code> no errors; <code>FALSE</code> otherwise 
	*/
	bool create(const Desc& desc);

	/** Heuristic constructor */
	Heuristic(golem::Arm &arm);

#ifndef WIN32	// FIX
public:
#endif
	/** virtual destructor */
	virtual ~Heuristic();
	
public:
#ifdef _HEURISTIC_PERFMON
	static U32 waypointCollisionCounter, pathCollisionCounter;

	static void resetLog();
	static void postLog(Context &context, const char *str);
#endif
	
	/** Collision detection test function for the single waypoint.
	 * @param w			waypoint
	 * @return			<code>true</code> if a collision has been detected;
	 *					<code>false</code> otherwise
	 */
	virtual bool collides(const Waypoint &w) const;

	/** Collision detection test function between specified waypoints.
	 * @param w0		waypoint
	 * @param w1		waypoint
	 * @param seq		waypoint graph
	 * @return			<code>true</code> if a collision has been detected;
	 *					<code>false</code> otherwise
	 */
	virtual bool collides(const Waypoint &w0, const Waypoint &w1) const;

	/** Distance to the rest position in jointspace */
	virtual inline Real getRestJointspaceDist(const ConfigspaceCoord& cc) const {
		const ConfigspaceCoord restPosition = arm.getRestPosition();
		Real dist = REAL_ZERO;
		for (U32 i = 0; i < numOfJoints; i++)
			dist += distRestJointcoordFac[i]*Math::sqr(cc[i] - restPosition[i]);

		return Math::sqrt(dist);
	}

	/** Distance between two waypoints in jointspace */
	virtual inline Real getJointspaceDist(const ConfigspaceCoord& j0, const ConfigspaceCoord& j1) const {
		Real dist = REAL_ZERO;
		for (U32 i = 0; i < numOfJoints; i++) {
			Real d = j1[i] - j0[i];
			dist += d*d;
		}

		return Math::sqrt(dist)/numOfJoints;
	}

	/** Distance between two waypoints in jointspace */
	virtual inline Real getJointspaceMagnitude(const ConfigspaceCoord& cc) const {
		Real dist = REAL_ZERO;
		for (U32 i = 0; i < numOfJoints; i++) {
			Real d = cc[i];
			dist += d*d;
		}

		return Math::sqrt(dist)/numOfJoints;
	}

	/** Distance between two waypoints in jointspace */
	virtual inline Real getJointspaceBoundedDist(const ConfigspaceCoord& j0, const ConfigspaceCoord& j1) const {
		Real dist = REAL_ZERO;
		for (U32 i = 0; i < numOfJoints; i++) {
			Real d = j1[i] - j0[i];

			if (Math::abs(d) > distJointcoordMax[i])
				return Node::COST_INF;
			
			dist += d*d;
		}

		return Math::sqrt(dist)/numOfJoints;
	}

	/** Distance between two waypoints in workspace */
	inline Real getLinearDist(const Vec3& l0, const Vec3& l1) const {
		return context.getSimulationScale()*l0.distance(l1);
	}

	/** Distance between two waypoints in workspace */
	inline Real getAngularDist(const Quat& o0, const Quat& o1) const {
		// quat0 * quat1: range: <0, 1>, 1 - identity, 0 - the largest distance
//		const Real d = Math::abs(o0.dot(o1));
//		return std::max(REAL_ONE - d, REAL_ZERO);
		// acos(quat0 * quat1): range: <0, Pi>, -Pi - identity, Pi - the largest distance
		Quat o1neg = o1;
		o1neg.negate();
		return (REAL_ONE/REAL_PI)*std::min(Math::acos(o0.dot(o1)), Math::acos(o0.dot(o1neg)));
	}

	/** Distance between two waypoints in workspace */
	virtual Real getWorkspaceDist(const Waypoint& w0, const Waypoint& w1) const {
		// linear distance
		const Real p = getLinearDist(w0.wpos.p, w1.wpos.p);
		// angular distance
		const Real q = getAngularDist(w0.wposq, w1.wposq);
		
		return distWorkspaceFac*p + (REAL_ONE - distWorkspaceFac)*q;
	}

	/** Distance between two waypoints in workspace */
	virtual Real getWorkspaceBoundedDist(const Waypoint& w0, const Waypoint& w1) const {
		// linear distance
		const Real p = getLinearDist(w0.wpos.p, w1.wpos.p);
		if (p > context.getSimulationScale()*distLinearMax)
			return Node::COST_INF;
		
		// angular distance
		const Real q = getAngularDist(w0.wposq, w1.wposq);
		if (q > distAngularMax)
			return Node::COST_INF;
		
		return distWorkspaceFac*p + (REAL_ONE - distWorkspaceFac)*q;
	}

	/** Weighted distance between two waypoints */
	virtual Real getDist(const Waypoint& w0, const Waypoint& w1) const {
		const Real wDist = getWorkspaceDist(w0, w1);
		const Real jDist = getJointspaceDist(w0.cpos, w1.cpos);
		
		return distJointspaceFac*jDist + (REAL_ONE - distJointspaceFac)*wDist;
	}
	
	/** Weighted distance between two waypoints */
	virtual Real getBoundedDist(const Waypoint& w0, const Waypoint& w1) const {
		const Real wDist = getWorkspaceBoundedDist(w0, w1);
		if (wDist >= Node::COST_INF)
			return Node::COST_INF;

		const Real jDist = getJointspaceBoundedDist(w0.cpos, w1.cpos);
		if (jDist >= Node::COST_INF)
			return Node::COST_INF;

		return distJointspaceFac*jDist + (REAL_ONE - distJointspaceFac)*wDist;
	}

	/** Synchronise bounds of all joints with the bounds descriptions
	*/
	virtual void syncArmBoundsDesc();
	
	/** Sets the collection of collision bounds
	 * @param collisionBoundsSeq	collection of collision bounds
	*/
	virtual void setCollisionBounds(const Bounds::SeqPtr &pCollisionBounds);


	/** Returns characteristic workspace distance scale */
	virtual Real getDistWorkspaceScale() const {
		return distWorkspaceScale;
	}
	/** Sets characteristic workspace distance scale */
	virtual void setDistWorkspaceScale(Real distWorkspaceScale) {
		this->distWorkspaceScale = distWorkspaceScale;
	}
	
	/** Returns jointspace distance factor */
	virtual Real getDistJointspaceFac() const {
		return distJointspaceFac;
	}
	/** Sets jointspace distance factor */
	virtual void setDistJointspaceFac(Real distJointspaceFac) {
		this->distJointspaceFac = distJointspaceFac;
	}

	/** Returns workspace distance factor */
	virtual Real getDistWorkspaceFac() const {
		return distWorkspaceFac;
	}
	/** Sets workspace distance factor */
	virtual void setDistWorkspaceFac(Real distWorkspaceFac) {
		this->distWorkspaceFac = distWorkspaceFac;
	}
	
	/** Returns Linear distance maximum */
	virtual Real getDistLinearMax() const {
		return distLinearMax;
	}
	/** Sets Linear distance maximum */
	virtual void setDistLinearMax(Real distLinearMax) {
		this->distLinearMax = distLinearMax;
	}

	/** Returns angular distance maximum */
	virtual Real getDistAngularMax() const {
		return distAngularMax;
	}
	/** Sets angular distance maximum */
	virtual void setDistAngularMax(Real distAngularMax) {
		this->distAngularMax = distAngularMax;
	}

	/** Returns maximum distance between two configuration space coordinates */
	virtual const ConfigspaceCoord &getDistJointcoordMax() const {
		return distJointcoordMax;
	}
	/** Sets maximum distance between two configuration space coordinates */
	virtual void setDistJointcoordMax(const ConfigspaceCoord &distJointcoordMax) {
		this->distJointcoordMax = distJointcoordMax;
	}
	
	/** Returns rest position cost factor */
	virtual const ConfigspaceCoord &getDistRestJointcoordFac() const {
		return distRestJointcoordFac;
	}
	/** Sets rest position cost factor */
	virtual void setDistRestJointcoordFac(const ConfigspaceCoord &distRestJointcoordFac) {
		this->distRestJointcoordFac = distRestJointcoordFac;
	}

	/** Collision detection */
	virtual bool hasCollisionDetection() const {
		return collisionDetection;
	}
	/** Sets/clears collision detection */
	virtual void setCollisionDetection(bool collisionDetection) {
		this->collisionDetection = collisionDetection;
	}

	/** Returns collision distance delta */
	virtual Real getColissionDistDelta() const {
		return colissionDistDelta;
	}
	/** Sets collision distance delta */
	virtual void setColissionDistDelta(Real colissionDistDelta) {
		this->colissionDistDelta = colissionDistDelta;
	}
	
	/** Returns objects skin thickness */
	virtual Real getSkinThickness() const {
		return skinThickness;
	}
	/** Sets objects skin thickness */
	virtual void setSkinThickness(Real skinThickness) {
		this->skinThickness = skinThickness;
	}

	/** Access to Arm controller
	 * @return				reference to the Arm controller
	 */
	inline const Arm &getArm() const {
		return arm;
	}
	inline Arm &getArm() {
		return arm;
	}
};

//------------------------------------------------------------------------------

};	// namespace

#endif /*_GOLEM_CTRL_HEURISTIC_H_*/
