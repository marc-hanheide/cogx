/** @file Simulator.h
 * 
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#pragma once
#ifndef _GOLEM_CTRL_SIMULATOR_H_
#define _GOLEM_CTRL_SIMULATOR_H_

//------------------------------------------------------------------------------

#include <Golem/Tools/Stream.h>
#include <Golem/Ctrl/Arm.h>
#include <string>

//------------------------------------------------------------------------------

namespace golem {

//------------------------------------------------------------------------------

class SimJoint: public Joint {
	friend class SimArm;

public:
	typedef obj_ptr<SimJoint> Ptr;

	/** SimJoint description */
	class Desc : public Joint::Desc {
	protected:
		/** Creates the object from the description. */
		CREATE_FROM_OBJECT_DESC(SimJoint, Joint::Ptr, Arm)
	public:
	};

protected:
	PerfTimer timer;
	GenCoordTrj trj[Arm::SYS_BUF_LEN];
	int readPtr, writePtr;
	volatile bool bStart;
	GenCoord current;
	
	bool sysSync();

	// IJointBase
	virtual bool sysRecv(GenCoord& curr);
	virtual bool sysSend(const GenCoord& prev, const GenCoord& next, SecTmReal dt);
	
	/** Creates SimJoint from the description. */
	bool create(const Desc& desc);
	
	SimJoint(Arm& arm);
};

//------------------------------------------------------------------------------

class SimArm: public Arm {
public:
	/** SimArm description
	 */
	class Desc : public Arm::Desc {
	public:
		/** Creates the object from the description. */
		CREATE_FROM_OBJECT_DESC(SimArm, Arm::Ptr, Context)

		/** sync() time duration */
		SecTmReal deltaSync;
		/** recv() time duration */
		SecTmReal deltaRecv;
		/** send() time duration */
		SecTmReal deltaSend;

		Desc() {
			setToDefault();
		}
		
		virtual void setToDefault() {
			Arm::Desc::setToDefault();

			deltaSync = (SecTmReal)0.005;
			deltaRecv = (SecTmReal)0.005;
			deltaSend = (SecTmReal)0.040;
		}
		
		virtual bool isValid() const {
			if (!Arm::Desc::isValid())
				return false;

			if (deltaSync < (SecTmReal)0.0 || deltaRecv < (SecTmReal)0.0 || deltaSend < (SecTmReal)0.0)
				return false;

			return true;
		}
	};

protected:
	/** sync() time duration */
	SecTmReal deltaSync;
	/** recv() time duration */
	SecTmReal deltaRecv;
	/** send() time duration */
	SecTmReal deltaSend;
	
	PerfTimer timer;

	// IArmBase
	virtual bool sysRecv(GenConfigspaceCoord& curr);
	virtual bool sysSend(const GenConfigspaceCoord& prev, const GenConfigspaceCoord& next, SecTmReal dt);
	virtual bool sysSync();
	
	bool create(const Desc& desc);
	
	/** Arm initialisation */
	SimArm(golem::Context& context);

	/** Each derived class should have virtual destructor releasing resources
	*	to avoid calling virtual functions of non-existing objects
	*/
	virtual ~SimArm() {
		release();
	}
	
public:
	/** sync() time duration */
	SecTmReal getDeltaSync() const {
		return deltaSync;
	}

	/** recv() time duration */
	SecTmReal getDeltaRecv() const {
		return deltaRecv;
	}

	/** send() time duration */
	SecTmReal getDeltaSend() const {
		return deltaSend;
	}
};

//------------------------------------------------------------------------------

//
//            t1    t2                t3         t4    t5       
//            ^    ^                 ^           ^ Z  ^         
//            |   /                 /            |   /          
//            |  /                 /             |  /           
//            | /                 /              | /            
//            |/       l1        /       l2      |/       Y     
//            O*****************O****************O---------> t6 
//           /*                /                /|              
//          / *               /                / | T            
//         /  *              /                /  |              
//        /   * l0          /                v X |              
//            *                                                 
//            *^ Z                                              
//            *|                                                
//            *|                                                
//            *| S     Y                                        
//             O-------->                                       
//            /                                                 
//           /                                                  
//          /                                                   
//         v X                                                   
//

//------------------------------------------------------------------------------

class GenSimArm: public SimArm {
public:
	/** Generic Simulator (6 DOF) */
	static const U32 NUM_JOINTS = 6;
	/** Links lengths */
	static const Real L0; // [m]
	static const Real L1; // [m]
	static const Real L2; // [m]
	static const Real L3; // [m]
	
	/** GenSimArm body*/
	class Body {
	public:
		/** link #0 */
		Real l0;
		/** link #1 */
		Real l1;
		/** link #2 */
		Real l2;
		/** link #3 */
		Real l3;
		
		/** Bounds model */
		bool simpleBoundsModel;
		
		Body() {
			setToDefault();
		}
		
		void setToDefault() {
			l0 = (Real)L0;	// [m]
			l1 = (Real)L1;	// [m]
			l2 = (Real)L2;	// [m]
			l3 = (Real)L3;	// [m]
			simpleBoundsModel = true;
		}
		
		bool isValid() const {
			if (l0 <= (Real)0.0 || l1 <= (Real)0.0 || l2 <= (Real)0.0 || l3 <= (Real)0.0)
				return false;

			return true;
		}
	};
	
	/** GenSimArm description */
	class Desc : public SimArm::Desc {
	public:
		/** Creates the object from the description. */
		CREATE_FROM_OBJECT_DESC(GenSimArm, Arm::Ptr, Context)

		/** GenSimArm body */
		Body body;

		Desc() {
			setToDefault();
		}

		virtual void setupJoints() {
			joints.clear(); // and joints
			GenSimArm::setupJoints(joints, body);
		}
		
		virtual void setToDefault() {
			SimArm::Desc::setToDefault();

			name = "Simulator of generic 6DOF manipulator";
			
			timeQuant = (SecTmReal)0.002;
			deltaSync = (SecTmReal)0.002;
			deltaRecv = (SecTmReal)0.01;
			deltaSend = (SecTmReal)0.07;

			body.setToDefault();
			referencePose.p.v2 += body.l3;
			
			setupJoints();
		}
		
		virtual bool isValid() const {
			if (!SimArm::Desc::isValid())
				return false;
			if (!body.isValid())
				return false;

			return true;
		}
	};

	/** GenSimArm Joints setup */
	static void setupJoints(Joint::Desc::Seq& joints, const Body &body);

protected:
	/** GenSimArm body */
	Body body;

	// Initialisation
	bool create(const Desc& desc);

	GenSimArm(golem::Context& context);

	/** Each derived class should have virtual destructor releasing resources
	*	to avoid calling virtual functions of non-existing objects
	*/
	virtual ~GenSimArm() {
		release();
	}
	
public:
	// Arm
	virtual void forwardTransform(Mat34& trn, const ConfigspaceCoord& cc) const;
	virtual void inverseTransform(ConfigspaceCoord::Seq& j, const Mat34& trn) const;
	virtual void velocitySpatial(Twist& v, const ConfigspaceCoord& cc, const ConfigspaceCoord& dcc) const;
	virtual void jacobianSpatial(Jacobian& jac, const ConfigspaceCoord& cc) const;

	/** Returns body configuration */
	const Body& getBody() const {
		return body;
	}
};

//------------------------------------------------------------------------------

};	// namespace

#endif /*_GOLEM_CTRL_SIMULATOR_H_*/
