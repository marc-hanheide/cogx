/** @file Message.h
 * 
 * Messages for multithreaded systems.
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#pragma once
#ifndef _GOLEM_TOOLS_MESSAGE_H_
#define _GOLEM_TOOLS_MESSAGE_H_

//------------------------------------------------------------------------------

#include <Golem/Defs/Pointers.h>
#include <Golem/Sys/Timer.h>
#include <stdarg.h>
#include <string>
#include <iostream>
#include <exception>

//------------------------------------------------------------------------------

namespace golem {

//------------------------------------------------------------------------------

class Logger;

/** Massage abstract class comprise a unit base message in
* the multi-threaded message logging system. 
*/
class Message : public std::exception {
public:
	friend class Logger;
	typedef obj_ptr<Message> Ptr;

	/** Maximal length of the formatted message string */
	static const U32 MESSAGE_BUF_LEN = 256;

	/** Message importance level */
	enum Level {
		LEVEL_UNDEF = 0,
		LEVEL_DEBUG,
		LEVEL_INFO,
		LEVEL_NOTICE,
		LEVEL_WARNING,
		LEVEL_ERR,
		LEVEL_CRIT,
		LEVEL_ALERT,
		LEVEL_EMERG,
	};
	
	static const char *const strLevel[];

private:
	static I32 counter;
	
	I32 mid;
	SecTmReal mstamp;
	U32 mthread;
	Level mlevel;
	std::string mstr; // can throw during construction
	
protected:
	/** Message setup called by Message constructor */ 
	void setup(SecTmReal stamp, Level level);
	
	/** Message setup called by Message constructor */ 
	void setup(SecTmReal stamp, Level level, const char* format, va_list argptr);
	
	/** Writes the message to the output stream */ 
	virtual std::ostream& write(std::ostream& ostr) const;
	
public:
	/** Default constructor */
	Message();
	
	/** Copy constructor */
	Message(const Message& message);
	
	/** Construct a message from formated string */
	Message(const char* format, ...);
	
	/** Construct a message from message level and formated string */
	Message(Level level, const char* format, ...);
	
	/** Virtual destructor */
	virtual ~Message() throw();

	/** Returns unique message identifier */
	I32 id() const {
		return mid;
	}
	
	/** Returns message time stamp */
	SecTmReal stamp() const {
		return mstamp;
	}
	
	/** Returns message thread */
	U32 thread() const {
		return mthread;
	}
	
	/** Returns message level */
	Level level() const {
		return mlevel;
	}
	
	/** Returns message string */
	const char *str() const {
		return mstr.c_str();
	}

	/** Exception class override */
	virtual const char *what() const throw() {
		return mstr.c_str();
	}

	/**	Assignment operator. */
	Message& operator = (const Message& message);

	/** Writes the message to the output stream via operator function */ 
	friend std::ostream& operator << (std::ostream& ostr, const Message& message);
};

//------------------------------------------------------------------------------

#define MESSAGE_BODY(NAME)\
public:\
NAME()\
{}\
NAME(const NAME& name) {\
	(Message&)*this = name;\
}\
NAME(const char* format, ...) {\
	va_list argptr;\
	va_start(argptr, format);\
	setup(SEC_TM_REAL_INF, Message::LEVEL_UNDEF, format, argptr);\
	va_end(argptr);\
}\
NAME(Message::Level level, const char* format, ...) {\
	va_list argptr;\
	va_start(argptr, format);\
	setup(SEC_TM_REAL_INF, level, format, argptr);\
	va_end(argptr);\
}

//------------------------------------------------------------------------------

};	// namespace

#endif /*_GOLEM_MESSAGE_H_*/
