/** @file TinyI.cpp
 * 
 * Implementation of Golem Tiny Ice server (source file).
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#include <Golem/TinyIce/Types.h>
#include <Golem/TinyIce/TinyIceI.h>
#include <Golem/Phys/Data.h>
#include <Golem/PhysCtrl/Msg.h>
#include <Golem/PhysCtrl/Creator.h>
#include <IceUtil/UUID.h>

using namespace golem::tinyice;

//------------------------------------------------------------------------------

class golem::tinyice::BoundsDesc {
public:
	golem::Bounds::Desc::Ptr pBoundsDesc;
	BoundsDesc(const golem::Bounds::Desc::Ptr pBoundsDesc) : pBoundsDesc(pBoundsDesc) {}
};

class golem::tinyice::PhysReacPlannerDesc : public golem::PhysReacPlanner::Desc {
public:
};

//------------------------------------------------------------------------------

ShapeI::ShapeI(RigidBodyI &rigidBody) : rigidBody(rigidBody), adapter(rigidBody.adapter), pNxShapeDesc(NULL), pBounds(NULL), owner(false) {
	id.name = IceUtil::generateUUID(); 
}

ShapeI::~ShapeI() {
	if (pBounds == NULL || !owner)
		return;
	rigidBody.pActor->releaseBounds(*pBounds);
}

bool ShapeI::create(const ShapeDesc& desc, ShapeType type, const golem::obj_ptr<BoundsDesc>& pBoundsDesc) {
	this->type = type;
	this->density = desc.density;
	this->color = desc.color;

	// pBoundsDesc must be initialized before
	if (pBoundsDesc == NULL)
		throw ExTinyShape("ShapeI::create(): Unable to create bounds description");
	
	this->pBoundsDesc = pBoundsDesc;

	pNxShapeDesc = rigidBody.scene.createNxShapeDesc(this->pBoundsDesc->pBoundsDesc); // throws
	if (pNxShapeDesc == NULL)
		return false;
	pNxShapeDesc->density = NxReal(this->density);
	// pBounds created in container

	return true;
}

ShapePrx ShapeI::activate() {
	return ShapePrx::uncheckedCast(adapter->add(this, id));
}

void ShapeI::deactivate() {
	adapter->remove(id);
}

ShapeType ShapeI::getType(const ::Ice::Current&) const {
	return type;
}

RGBA ShapeI::getColor(const ::Ice::Current&) const {
	return color;
}

Mat34 ShapeI::getLocalPose(const ::Ice::Current&) const {
	return make(pBounds->getPose());
}

::Ice::Int ShapeI::getGroup(const ::Ice::Current&) const {
	return (::Ice::Int)pBounds->getGroup();
}

void ShapeI::setGroup(::Ice::Int group, const ::Ice::Current&) {
	rigidBody.pActor->setBoundsGroup(*pBounds, U32(group));
}

ShapeDescPtr ShapeI::getDesc(const ::Ice::Current&) const {
	return pShapeDesc;
}

//------------------------------------------------------------------------------

PlaneShapeI::PlaneShapeI(RigidBodyI &rigidBody) : ShapeI(rigidBody) {
}
bool PlaneShapeI::create(const PlaneShapeDesc& desc) {
	BoundingPlane::Desc* pDesc = new BoundingPlane::Desc();
	Bounds::Desc::Ptr pBoundsDesc(pDesc);
	pDesc->pose = make(desc.localPose);
	pDesc->normal = make(desc.normal);
	pDesc->distance = (Real)desc.distance;
	return ShapeI::create(desc, ShapeTypePlane, obj_ptr<BoundsDesc>(new BoundsDesc(pBoundsDesc)));
}

SphereShapeI::SphereShapeI(RigidBodyI &rigidBody) : ShapeI(rigidBody) {
}
bool SphereShapeI::create(const SphereShapeDesc& desc) {
	BoundingSphere::Desc* pDesc = new BoundingSphere::Desc();
	Bounds::Desc::Ptr pBoundsDesc(pDesc);
	pDesc->pose = make(desc.localPose);
	pDesc->radius = (Real)desc.radius;
	return ShapeI::create(desc, ShapeTypeSphere, obj_ptr<BoundsDesc>(new BoundsDesc(pBoundsDesc)));
}

CylinderShapeI::CylinderShapeI(RigidBodyI &rigidBody) : ShapeI(rigidBody) {
}
bool CylinderShapeI::create(const CylinderShapeDesc& desc) {
	BoundingCylinder::Desc* pDesc = new BoundingCylinder::Desc();
	Bounds::Desc::Ptr pBoundsDesc(pDesc);
	pDesc->pose = make(desc.localPose);
	pDesc->radius = (Real)desc.radius;
	pDesc->length = (Real)desc.length;
	return ShapeI::create(desc, ShapeTypeCylinder, obj_ptr<BoundsDesc>(new BoundsDesc(pBoundsDesc)));
}

BoxShapeI::BoxShapeI(RigidBodyI &rigidBody) : ShapeI(rigidBody) {
}
bool BoxShapeI::create(const BoxShapeDesc& desc) {
	BoundingBox::Desc* pDesc = new BoundingBox::Desc();
	Bounds::Desc::Ptr pBoundsDesc(pDesc);
	pDesc->pose = make(desc.localPose);
	pDesc->dimensions = make(desc.dimensions);
	return ShapeI::create(desc, ShapeTypeBox, obj_ptr<BoundsDesc>(new BoundsDesc(pBoundsDesc)));
}

ConvexMeshShapeI::ConvexMeshShapeI(RigidBodyI &rigidBody) : ShapeI(rigidBody) {
}
bool ConvexMeshShapeI::create(const ConvexMeshShapeDesc& desc) {
	BoundingConvexMesh::Desc* pDesc = new BoundingConvexMesh::Desc();
	Bounds::Desc::Ptr pBoundsDesc(pDesc);
	pDesc->pose = make(desc.localPose);
	for (::golem::tinyice::Vec3Seq::const_iterator i = desc.vertices.begin(); i != desc.vertices.end(); ++i)
		pDesc->vertices.push_back(make(*i));
	pDesc->bCook = true;
	return ShapeI::create(desc, ShapeTypeConvexMesh, obj_ptr<BoundsDesc>(new BoundsDesc(pBoundsDesc)));
}

//------------------------------------------------------------------------------

ActorI::ActorI(TinyI &tiny) : tiny(tiny), adapter(tiny.adapter), context(*tiny.pContext), scene(*tiny.pScene), pXMLContext(tiny.pXMLContext), owner(false) {
	id.name = IceUtil::generateUUID(); 
}

ActorI::~ActorI() {
}

ActorPrx ActorI::activate() {
	return ActorPrx::uncheckedCast(adapter->add(this, id));
}

void ActorI::deactivate() {
	adapter->remove(id);
}

RigidBodyI::RigidBodyI(TinyI &tiny) : ActorI(tiny), pActor(NULL) {
}

RigidBodyI::~RigidBodyI() {
	shapeList.clear(); // release shapes before releasing the Actor
	if (pActor == NULL || !owner)
		return;
	scene.releaseObject(*pActor);
}

ShapeIPtr RigidBodyI::createShape(const ShapeDesc* pDesc) {
	if (!pDesc)
		throw ExTinyShapeCreate("RigidBodyI::createShape(): NULL Shape description");
	else if (dynamic_cast<const PlaneShapeDesc*>(pDesc)) {
		PlaneShapeI* pPlaneShape = new PlaneShapeI(*this);
		ShapeIPtr pShape(pPlaneShape);
		if (pPlaneShape->create(*dynamic_cast<const PlaneShapeDesc*>(pDesc)))
			return pShape;
	}
	else if (dynamic_cast<const SphereShapeDesc*>(pDesc)) {
		SphereShapeI* pSphereShape = new SphereShapeI(*this);
		ShapeIPtr pShape(pSphereShape);
		if (pSphereShape->create(*dynamic_cast<const SphereShapeDesc*>(pDesc)))
			return pShape;
	}
	else if (dynamic_cast<const CylinderShapeDesc*>(pDesc)) {
		CylinderShapeI* pCylinderShape = new CylinderShapeI(*this);
		ShapeIPtr pShape(pCylinderShape);
		if (pCylinderShape->create(*dynamic_cast<const CylinderShapeDesc*>(pDesc)))
			return pShape;
	}
	else if (dynamic_cast<const BoxShapeDesc*>(pDesc)) {
		BoxShapeI* pBoxShape = new BoxShapeI(*this);
		ShapeIPtr pShape(pBoxShape);
		if (pBoxShape->create(*dynamic_cast<const BoxShapeDesc*>(pDesc)))
			return pShape;
	}
	else if (dynamic_cast<const ConvexMeshShapeDesc*>(pDesc)) {
		ConvexMeshShapeI* pConvexMeshShape = new ConvexMeshShapeI(*this);
		ShapeIPtr pShape(pConvexMeshShape);
		if (pConvexMeshShape->create(*dynamic_cast<const ConvexMeshShapeDesc*>(pDesc)))
			return pShape;
	}
	else
		throw ExTinyShapeCreate("RigidBodyI::createShape(): Unknown Shape description");

	throw ExTinyShapeCreate("RigidBodyI::createShape(): Unable to create Shape");
}

ShapeIPtr RigidBodyI::createShape(const golem::Bounds* pBounds) {
	ShapeDescPtr pShapeDesc;
	ShapeIPtr pShape;

	switch (pBounds->getType()) {
	case Bounds::TYPE_PLANE:
		{
			PlaneShapeDesc* pDesc = new PlaneShapeDesc;
			pShapeDesc = pDesc;
			pDesc->normal = make(dynamic_cast<const BoundingPlane*>(pBounds)->getNormal());
			pDesc->distance = (Ice::Double)dynamic_cast<const BoundingPlane*>(pBounds)->getDistance();
		}
		break;
	case Bounds::TYPE_SPHERE:
		{
			SphereShapeDesc* pDesc = new SphereShapeDesc;
			pShapeDesc = pDesc;
			pDesc->radius = (Ice::Double)dynamic_cast<const BoundingSphere*>(pBounds)->getRadius();
		}
		break;
	case Bounds::TYPE_CYLINDER:
		{
			CylinderShapeDesc* pDesc = new CylinderShapeDesc;
			pShapeDesc = pDesc;
			pDesc->radius = (Ice::Double)dynamic_cast<const BoundingCylinder*>(pBounds)->getRadius();
			pDesc->length = (Ice::Double)dynamic_cast<const BoundingCylinder*>(pBounds)->getLength();
		}
		break;
	case Bounds::TYPE_BOX:
		{
			BoxShapeDesc* pDesc = new BoxShapeDesc;
			pShapeDesc = pDesc;
			pDesc->dimensions = make(dynamic_cast<const BoundingBox*>(pBounds)->getDimensions());
		}
		break;
	case Bounds::TYPE_CONVEX_MESH:
		{
			ConvexMeshShapeDesc* pDesc = new ConvexMeshShapeDesc;
			pShapeDesc = pDesc;
			const BoundingConvexMesh* pBoundingConvexMesh = dynamic_cast<const BoundingConvexMesh*>(pBounds);
			for (std::vector<golem::Vec3>::const_iterator i = pBoundingConvexMesh->getVertices().begin(); i != pBoundingConvexMesh->getVertices().end(); ++i)
				pDesc->vertices.push_back(make(*i));
		}
		break;
	}
	if (pShapeDesc == NULL)
		return pShape;

	pShapeDesc->localPose = make(pBounds->getPose());
	pShapeDesc->group = (Ice::Int)pBounds->getGroup();

	pShape = createShape(pShapeDesc.get());// throws
	if (pShape == NULL)
		return pShape;
	pShape->pShapeDesc = pShapeDesc;
	pShape->pBounds = pBounds;
	
	return pShape;
}

bool RigidBodyI::create(const RigidBodyDesc& desc) {
	kinematic = desc.kinematic;

	golem::Actor::Desc actorDesc;
	actorDesc.kinematic = desc.kinematic;
	//actorDesc.appearance.solidColour = ;
	actorDesc.nxActorDesc.globalPose.M.setRowMajor(&desc.globalPose.R.m11);
	actorDesc.nxActorDesc.globalPose.t.set(&desc.globalPose.p.v1);
	NxBodyDesc nxBodyDesc;
	actorDesc.nxActorDesc.body = &nxBodyDesc;
	actorDesc.nxActorDesc.density = NxReal(1.0);

	shapeList.clear();
	for (ShapeDescSeq::const_iterator i = desc.shapes.begin(); i != desc.shapes.end(); i++) {
		ShapeIPtr pShape = createShape((*i).get()); // throws
		if (pShape == NULL || pShape->pNxShapeDesc == NULL)
			return false;
		pShape->pShapeDesc = *i;

		if (pShape->getType() == ShapeTypePlane)
			actorDesc.nxActorDesc.body = NULL; // Actors with Plane Shapes cannot have a body
		actorDesc.nxActorDesc.shapes.push_back(pShape->pNxShapeDesc);
		
		ShapePrx shapePrx = pShape->activate();
		shapeList.push_back(ShapeList::Pair(shapePrx, pShape));
	}

	pActor = dynamic_cast<golem::Actor*>(scene.createObject(actorDesc)); // throws
	if (pActor == NULL)
		return false;
	
	const golem::Actor::BoundsConstSeq& boundsSeq = pActor->getBoundsSeq();
	golem::Actor::BoundsConstSeq::const_iterator i = boundsSeq.begin();
	ShapeList::iterator j = shapeList.begin();
	while (i != boundsSeq.end() && j != shapeList.end())
		(j++)->second->pBounds = *i++; // order is preserved
	
	return true;
}

ActorPrx RigidBodyI::activate() {
	return ActorI::activate();
}

void RigidBodyI::deactivate() {
	ActorI::deactivate();
	
	// deactivate shapes
	for (ShapeList::iterator i = shapeList.begin(); i != shapeList.end(); i++)
		i->second->deactivate();
}

ShapePrx RigidBodyI::createShape(const ::golem::tinyice::ShapeDescPtr& pShapeDesc, const ::Ice::Current&) {
	try {
		if (pShapeDesc == NULL)
			throw ExTinyShapeCreate("RigidBodyI::createShape(): empty description");

		ShapeIPtr pShape = createShape(pShapeDesc.get()); // throws
		if (pShape == NULL)
			return NULL;
		pShape->pShapeDesc = pShapeDesc;
		
		pShape->pBounds = pActor->createBounds(pShape->pBoundsDesc->pBoundsDesc); // throws
		if (pShape->pBounds == NULL)
			return NULL;
		pShape->owner = true;

		ShapePrx shapePrx = pShape->activate();
		shapeList.push_back(ShapeList::Pair(shapePrx, pShape));
		return shapePrx;
	}
	catch (const Message& ex) {
		std::string str("RigidBodyI::createShape(): ");
		str.append(ex.str());
		throw ExTinyShapeCreate(str);
	}
	catch (const std::exception &ex) {
		std::string str("RigidBodyI::createShape(): C++ exception: ");
		str.append(ex.what());
		throw ExTinyShapeCreate(str);
	}

	return ShapePrx();
}

void RigidBodyI::releaseShape(const ShapePrx& shape, const ::Ice::Current&) {
	ShapeList::iterator pos = shapeList.find(shape);
	if (pos == shapeList.end())
		throw ExTinyShapeNotFound("RigidBodyI::releaseShape(): Unable to find specified Shape");
	if (!pos->second->owner)
		throw ExTinyShapeNotRemovable("RigidBodyI::releaseShape(): The specified Shape cannot be removed");

	pos->second->deactivate();
	shapeList.erase(pos);
}

ShapeSeq RigidBodyI::getShapes(const ::Ice::Current&) const {
	ShapeSeq shapeSeq;
	for (ShapeList::const_iterator i = shapeList.begin(); i != shapeList.end(); i++)
		shapeSeq.push_back(i->first);
	return shapeSeq;
}

Mat34 RigidBodyI::getGlobalPose(const ::Ice::Current&) const {
	return make(pActor->getPose());
}

void RigidBodyI::setGlobalPose(const Mat34& pose, const ::Ice::Current&) {
	pActor->setPose(make(pose));
}

void RigidBodyI::setGroup(::Ice::Int group, const ::Ice::Current&) {
	pActor->setBoundsGroup(U32(group));
}

//------------------------------------------------------------------------------

JointI::JointI(ArmI &armI) : RigidBodyI(armI.tiny), armI(armI) {
}

bool JointI::create(const JointDesc& desc, golem::JointActor* pJointActor) {
	ASSERT(pJointActor)
	pActor = pJointActor;
	kinematic = true;
	
	shapeList.clear();
	const golem::Actor::BoundsConstSeq& boundsSeq = pActor->getBoundsSeq();
	for (golem::Actor::BoundsConstSeq::const_iterator i = boundsSeq.begin(); i != boundsSeq.end(); i++) {
		ShapeIPtr pShape = RigidBodyI::createShape(*i); // throws
		if (pShape == NULL)
			return false;
		ShapePrx shapePrx = pShape->activate();
		shapeList.push_back(ShapeList::Pair(shapePrx, pShape));
	}

	return true;
}

ArmI::ArmI(TinyI &tiny) : ActorI(tiny), pPhysReacPlanner(NULL) {
}

ArmI::~ArmI() {
	jointList.clear(); // joints wrappers must be released before PhysReacPlanner!
	if (pPhysReacPlanner == NULL || !owner)
		return;
	scene.releaseObject(*pPhysReacPlanner);
}

JointIPtr ArmI::createJoint(const JointDesc* pDesc, golem::JointActor* pJointActor) {
	if (!pDesc)
		throw ExTinyActorCreate("ArmI::createJoint(): NULL Joint description");
	else if (dynamic_cast<const JointDesc*>(pDesc)) {
		JointI* pJointI = new JointI(*this);
		JointIPtr pJoint(pJointI);
		if (pJointI->create(*dynamic_cast<const JointDesc*>(pDesc), pJointActor))
			return pJoint;
	}
	else
		throw ExTinyActorCreate("ArmI::createJoint(): Unknown Joint description");

	throw ExTinyActorCreate("ArmI::createJoint(): Unable to create Joint");
}

bool ArmI::create(const PhysReacPlannerDesc& desc) {
	// create controller
	pPhysReacPlanner = dynamic_cast<PhysReacPlanner*>(scene.createObject(desc));// throws
	if (pPhysReacPlanner == NULL)
		return false;

	// create joints
	jointList.clear();
	const JointActor::Seq& jointActorSeq = pPhysReacPlanner->getJointActors();
	for (JointActor::Seq::const_iterator i = jointActorSeq.begin(); i != jointActorSeq.end(); i++) {
		JointIPtr pJoint;
		if (*i != NULL) { // Joint may have no body
			JointDescPtr pJointDesc(new JointDesc);
			pJoint = createJoint(pJointDesc.get(), *i); // throws
			if (pJoint == NULL)
				return false;
			ActorPrx actorPrx = pJoint->activate();
			jointList.push_back(JointList::Pair(actorPrx, pJoint));
		}
	}

	return true;
}

ActorPrx ArmI::activate() {
	return ActorI::activate();
}

void ArmI::deactivate() {
	ActorI::deactivate();

	// deactivate joints
	for (JointList::iterator i = jointList.begin(); i != jointList.end(); i++)
		i->second->deactivate();
}

::Ice::Double ArmI::getTimeDelta(const ::Ice::Current&) const {
	return (::Ice::Double)pPhysReacPlanner->getReacPlanner().getTimeDelta();
}

::Ice::Double ArmI::getTimeDeltaAsync(const ::Ice::Current&) const {
	return (::Ice::Double)pPhysReacPlanner->getReacPlanner().getTimeDeltaAsync();
}

void ArmI::setGenConfigspaceState(const GenConfigspaceState& target, ActionType action, const ::Ice::Current&) {
	(void)pPhysReacPlanner->getReacPlanner().send(make(target), make(action));
}

void ArmI::setGenWorkspaceState(const GenWorkspaceState& target, ActionType action, const ::Ice::Current&) {
	(void)pPhysReacPlanner->getReacPlanner().send(make(target), make(action));
}

bool ArmI::waitForBegin(::Ice::Double timeOut, const ::Ice::Current&) {
	//if (!pPhysReacPlanner->getReacPlanner().waitForBegin(golem::MSecTmU32(1000.*timeOut)))
	//	throw ExTinyArmTimeOut("ArmI::waitForBegin(): operation time out");
	return pPhysReacPlanner->getReacPlanner().waitForBegin(golem::MSecTmU32(1000.*timeOut));
}

bool ArmI::waitForEnd(::Ice::Double timeOut, const ::Ice::Current&) {
	//if (!pPhysReacPlanner->getReacPlanner().waitForEnd(golem::MSecTmU32(1000.*timeOut)))
	//	throw ExTinyArmTimeOut("ArmI::waitForBegin(): operation time out");
	return pPhysReacPlanner->getReacPlanner().waitForEnd(golem::MSecTmU32(1000.*timeOut));
}

GenConfigspaceState ArmI::getGenConfigspaceState(Ice::Double t, const ::Ice::Current&) const {
	golem::GenConfigspaceState gcs;
	pPhysReacPlanner->getArm().lookupInp(gcs, t);
	return make(gcs);
}

GenWorkspaceState ArmI::getGenWorkspaceState(Ice::Double t, const ::Ice::Current&) const {
	golem::GenConfigspaceState gcs;
	pPhysReacPlanner->getArm().lookupInp(gcs, t);
	golem::GenWorkspaceState gws;
	pPhysReacPlanner->getArm().forwardTransform(gws.pos, gcs.pos);
	gws.vel.set(golem::Vec3(REAL_ZERO), golem::Vec3(REAL_ZERO)); // TODO
	gws.t = gcs.t;
	return make(gws);
}

JointSeq ArmI::getJoints(const ::Ice::Current&) const {
	JointSeq jointSeq;
	for (JointList::const_iterator i = jointList.begin(); i != jointList.end(); i++)
		jointSeq.push_back(JointPrx::uncheckedCast(i->first));
	return jointSeq;
}

::Ice::Int ArmI::getArmGroup(const ::Ice::Current&) const {
	return (::Ice::Int)pPhysReacPlanner->getArmBoundsGroup();
}

::Ice::Int ArmI::getCollisionGroup(const ::Ice::Current&) const {
	return (::Ice::Int)pPhysReacPlanner->getCollisionBoundsGroup();
}

void ArmI::setCollisionGroup(::Ice::Int group, const ::Ice::Current&) {
	pPhysReacPlanner->setCollisionBoundsGroup((int)group);
}

Mat34 ArmI::getGlobalPose(const ::Ice::Current&) const {
	return make(pPhysReacPlanner->getArm().getGlobalPose());
}

void ArmI::setGlobalPose(const Mat34& pose, const ::Ice::Current&) {
	pPhysReacPlanner->getArm().setGlobalPose(make(pose));
}

Mat34 ArmI::getReferencePose(const ::Ice::Current&) const {
	return make(pPhysReacPlanner->getArm().getReferencePose());
}

void ArmI::setReferencePose(const Mat34& pose, const ::Ice::Current&) {
	pPhysReacPlanner->getArm().setReferencePose(make(pose));
}

//------------------------------------------------------------------------------

SimArmI::SimArmI(TinyI &tiny) : ArmI(tiny) {
}

GenSimArmI::GenSimArmI(TinyI &tiny) : SimArmI(tiny) {
}

bool GenSimArmI::create(const GenSimArmDesc& desc) {
	golem::tinyice::PhysReacPlannerDesc physReacPlannerDesc;
	golem::GenSimArm::Desc *pDesc = new golem::GenSimArm::Desc();
	physReacPlannerDesc.pArmDesc.reset(pDesc);
	
	pDesc->globalPose = make(desc.globalPose);

	XMLData("delta_offs", pDesc->deltaOffs, pXMLContext->getContextFirst("arm calibration"));
	XMLData("skew_offs", pDesc->skewOffs, pXMLContext->getContextFirst("arm calibration"));
	return ArmI::create(physReacPlannerDesc);
}

KatSimArmI::KatSimArmI(TinyI &tiny) : SimArmI(tiny) {
}

bool KatSimArmI::create(const KatSimArmDesc& desc) {
	golem::tinyice::PhysReacPlannerDesc physReacPlannerDesc;
	golem::KatSimArm::Desc *pDesc = new golem::KatSimArm::Desc();
	physReacPlannerDesc.pArmDesc.reset(pDesc);
	
	pDesc->globalPose = make(desc.globalPose);
	
	XMLData("delta_offs", pDesc->deltaOffs, pXMLContext->getContextFirst("arm calibration"));
	XMLData("skew_offs", pDesc->skewOffs, pXMLContext->getContextFirst("arm calibration"));
	return ArmI::create(physReacPlannerDesc);
}

//------------------------------------------------------------------------------

KatArmI::KatArmI(TinyI &tiny) : ArmI(tiny) {
}

bool KatArmI::create(const KatArmDesc& desc) {
	golem::tinyice::PhysReacPlannerDesc physReacPlannerDesc;
	golem::KatSerialArm::Desc *pDesc = new golem::KatSerialArm::Desc();
	physReacPlannerDesc.pArmDesc.reset(pDesc);

	pDesc->globalPose = make(desc.globalPose);

	XMLData("path", pDesc->cfgPath, pXMLContext->getContextFirst("arm kat_serial_arm config"));
	XMLData("port", pDesc->serialDesc.commPort, pXMLContext->getContextFirst("arm kat_serial_arm comm"));
	XMLData("delta_offs", pDesc->deltaOffs, pXMLContext->getContextFirst("arm calibration"));
	XMLData("skew_offs", pDesc->skewOffs, pXMLContext->getContextFirst("arm calibration"));

	pDesc->bGripper = desc.bGripper;
	pDesc->sensorIndexSet = desc.sensorIndexSet;

	if (!ArmI::create(physReacPlannerDesc))
		return false;

	pKatArm = dynamic_cast<golem::KatArm*>(&pPhysReacPlanner->getArm());
	ASSERT(pKatArm) // this should never happen
	return true;
}

bool KatArmI::gripperRecvSensorData(double timeOut, KatSensorDataSet& sensorData, const ::Ice::Current&) {
	if (!pKatArm->hasGripper())
		throw ExTinyArm("KatArmI::gripperRecvSensorData(): gripper not initialized");

	golem::KatArm::SensorDataSet data;
	if (!pKatArm->gripperRecvSensorData(data, golem::MSecTmU32(1000.*timeOut)))
		return false;

	sensorData.clear();
	for (golem::KatArm::SensorDataSet::const_iterator i = data.begin(); i != data.end(); i++)
		sensorData.push_back(make(*i));

	return true;
}

bool KatArmI::gripperRecvEncoderData(double timeOut, KatGripperEncoderData& encoderData, const ::Ice::Current&) {
	if (!pKatArm->hasGripper())
		throw ExTinyArm("KatArmI::gripperRecvEncoderData(): gripper not initialized");

	golem::KatArm::GripperEncoderData data;
	if (!pKatArm->gripperRecvEncoderData(data, golem::MSecTmU32(1000.*timeOut)))
		return false;

	encoderData = make(data);

	return true;
}

bool KatArmI::gripperOpen(double timeOut, const ::Ice::Current&) {
	if (!pKatArm->hasGripper())
		throw ExTinyArm("KatArmI::gripperOpen(): gripper not initialized");

	return pKatArm->gripperOpen(golem::MSecTmU32(1000.*timeOut));
}

bool KatArmI::gripperClose(double timeOut, const KatSensorDataSet& sensorThreshold, const ::Ice::Current&) {
	if (!pKatArm->hasGripper())
		throw ExTinyArm("KatArmI::gripperClose(): gripper not initialized");

	golem::KatArm::SensorDataSet threshold;
	for (KatSensorDataSet::const_iterator i = sensorThreshold.begin(); i != sensorThreshold.end(); i++)
		threshold.push_back(make(*i));

	return pKatArm->gripperClose(threshold, golem::MSecTmU32(1000.*timeOut));
}

bool KatArmI::gripperFreeze(double timeOut, const ::Ice::Current&) {
	if (!pKatArm->hasGripper())
		throw ExTinyArm("KatArmI::gripperFreeze(): gripper not initialized");

	return pKatArm->gripperFreeze(golem::MSecTmU32(1000.*timeOut));
}

//------------------------------------------------------------------------------

TinyI::TinyI(int argc, char *argv[], Ice::CommunicatorPtr communicator) : communicator(communicator) {
	try {
		// Determine configuration file name
		std::string cfg;
		// default configuration file name
		cfg.assign(argv[0]);
		size_t pos = cfg.rfind(".exe"); // Windows only
		if (pos != std::string::npos) cfg.erase(pos);
		cfg.append(".xml");

		// Create XML parser and load configuration file
		XMLParser::Desc parserDesc;
		pParser = parserDesc.create();
		FileReadStream fs(cfg.c_str());
		pParser->load(fs); // throw

		// Find program XML root context
		pXMLContext = pParser->getContextRoot()->getContextFirst("golem");
		if (pXMLContext == NULL) {
			std::string str("Unknown configuration file: ");
			str.append(cfg.c_str());
			throw ExTinyCreate(str);
		}

		// Create program context
		Context::Desc contextDesc;
		XMLData(contextDesc, pXMLContext);
		pContext = contextDesc.create(); // throw
		if (pContext == NULL)
			return;
		
		// Create Universe
		golem::Universe::Desc universeDesc;
		universeDesc.name = "Golem (Tiny)";
		XMLData(universeDesc, pXMLContext->getContextFirst("universe"));
		universeDesc.argc = argc;
		universeDesc.argv = argv;
		pUniverse = universeDesc.create(*pContext);

		// Create scene
		golem::Scene::Desc sceneDesc;
		sceneDesc.name = "Ice server";
		XMLData(sceneDesc, pXMLContext->getContextFirst("scene"));
		pScene = pUniverse->createScene(sceneDesc);

		// Launching Universe
		pUniverse->launch();

		// Activate Golem Tiny
		id.name = "GolemTiny";
		XMLData("identity", id.name, pXMLContext->getContextFirst("ice"));
		std::string adapterName = id.name;
		adapterName.append("Adapter");
		std::string adapterTransport = "default -p 8172";
		XMLData("transport", adapterTransport, pXMLContext->getContextFirst("ice"));

		adapter = communicator->createObjectAdapterWithEndpoints(adapterName, adapterTransport);
		activate();
		adapter->activate();
	}
	catch (const ExTinyCreate& ex) {
		throw ex;
	}
	catch (const Message& ex) {
		std::string str("TinyI::createActor(): ");
		str.append(ex.str());
		throw ExTinyActorCreate(str);
	}
	catch (const std::exception &ex) {
		std::string str("TinyI::createActor(): C++ exception: ");
		str.append(ex.what());
		throw ExTinyActorCreate(str);
	}
}

TinyI::~TinyI() {
	actorList.clear();
	pUniverse.release();
}

void TinyI::activate() {
	adapter->add(this, id);
}

void TinyI::deactivate() {
	adapter->remove(id);

	// deactivate actors
	for (ActorList::iterator i = actorList.begin(); i != actorList.end(); i++)
		i->second->deactivate();
}

::Ice::Double TinyI::getTime(const ::Ice::Current&) const {
	return (::Ice::Double)pContext->getTimer()->elapsed();
}

void TinyI::sleep(::Ice::Double duration, const ::Ice::Current&) const {
	pContext->getTimer()->sleep(SecTmReal(duration));
}

bool TinyI::interrupted(const ::Ice::Current&) {
	return pUniverse->interrupted();
}

ActorIPtr TinyI::createActor(const ActorDesc* pDesc) {
	if (!pDesc)
		throw ExTinyActorCreate("TinyI::createActor(): NULL Actor description");
	else if (dynamic_cast<const RigidBodyDesc*>(pDesc)) {
		RigidBodyI* pRigidBodyI = new RigidBodyI(*this);
		ActorIPtr pActor(pRigidBodyI);
		if (pRigidBodyI->create(*dynamic_cast<const RigidBodyDesc*>(pDesc)))
			return pActor;
	}
	else if (dynamic_cast<const GenSimArmDesc*>(pDesc)) {
		GenSimArmI* pGenSimArmI = new GenSimArmI(*this);
		ActorIPtr pActor(pGenSimArmI);
		if (pGenSimArmI->create(*dynamic_cast<const GenSimArmDesc*>(pDesc)))
			return pActor;
	}
	else if (dynamic_cast<const KatSimArmDesc*>(pDesc)) {
		KatSimArmI* pKatSimArmI = new KatSimArmI(*this);
		ActorIPtr pActor(pKatSimArmI);
		if (pKatSimArmI->create(*dynamic_cast<const KatSimArmDesc*>(pDesc)))
			return pActor;
	}
	else if (dynamic_cast<const KatArmDesc*>(pDesc)) {
		KatArmI* pKatArmI = new KatArmI(*this);
		ActorIPtr pActor(pKatArmI);
		if (pKatArmI->create(*dynamic_cast<const KatArmDesc*>(pDesc)))
			return pActor;
	}
	else
		throw ExTinyActorCreate("TinyI::createActor(): Unknown Actor description");

	throw ExTinyActorCreate("TinyI::createActor(): Unable to create Actor");
}

ActorPrx TinyI::createActor(const ActorDescPtr& pActorDesc, const ::Ice::Current&) {
	try {
		if (pActorDesc == NULL)
			throw ExTinyActorCreate("TinyI::createActor(): empty description");

		ActorIPtr pActor = createActor(pActorDesc.get()); // throws
		if (pActor == NULL)
			return NULL;
		pActor->owner = true;
		
		ActorPrx actorPrx = pActor->activate();
		actorList.push_back(ActorList::Pair(actorPrx, pActor));
		return actorPrx;
	}
	catch (const Message& ex) {
		std::string str("TinyI::createActor(): ");
		str.append(ex.str());
		throw ExTinyActorCreate(str);
	}
	catch (const std::exception &ex) {
		std::string str("TinyI::createActor(): C++ exception: ");
		str.append(ex.what());
		throw ExTinyActorCreate(str);
	}

	return ActorPrx();
}

void TinyI::releaseActor(const ActorPrx& actor, const ::Ice::Current&) {
	ActorList::iterator pos = actorList.find(actor);
	if (pos == actorList.end())
		throw ExTinyActorNotFound("TinyI::releaseActor(): Unable to find specified Actor");
	if (!pos->second->owner)
		throw ExTinyActorNotRemovable("TinyI::releaseActor(): The specified Actor cannot be removed");

	pos->second->deactivate();
	actorList.erase(pos);
}

ActorSeq TinyI::getActors(const ::Ice::Current&) const {
	ActorSeq actorSeq;
	for (ActorList::const_iterator i = actorList.begin(); i != actorList.end(); i++)
		actorSeq.push_back(i->first);
	return actorSeq;
}

void TinyI::bang(const ::Ice::Current&) {
	pContext->getLogger()->post(Message::LEVEL_UNDEF, "Bang!");

	Rand rand(pContext->getRandSeed());
	Creator creator(*pScene);
	golem::Actor::Desc *pActorDesc = creator.createTreeDesc(rand.nextUniform(Real(0.07), Real(0.10)));
	pActorDesc->nxActorDesc.globalPose.t.set(
		(NxReal)rand.nextUniform(Real(-0.3), Real(0.3)),
		(NxReal)rand.nextUniform(Real(-0.3), Real(0.3)),
		(NxReal)rand.nextUniform(Real(+0.3), Real(0.9))
	);
	pScene->createObject(*pActorDesc);
}

//------------------------------------------------------------------------------

class TinyIceApp : public Ice::Application {
private:
	// Golem Tiny must be destroyed outside run() and ~Application() because
	// Ice keeps references to all created objects and destroys them after Golem Tiny
	IceInternal::Handle<TinyI> pTiny;

public:
	virtual int run(int argc, char *argv[]) {
		shutdownOnInterrupt();
		pTiny = new TinyI(argc, argv, communicator());
		communicator()->waitForShutdown();
		return 0;
	}
};

//------------------------------------------------------------------------------

int main(int argc, char *argv[]) {
	try {
		return TinyIceApp().main(argc, argv);
	}
	catch (const ExTiny& ex) {
		std::cerr << ex << std::endl;
	}
	return 1;
}
