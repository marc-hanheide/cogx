/** @file Gripper.cpp
 * 
 * Demonstration program testing Katana gripper.
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#include <Golem/Ctrl/Katana.h>
#include <Golem/Ctrl/Simulator.h>
#include <Golem/Demo/Common/Tools.h>
#include <iostream>

using namespace golem;

//------------------------------------------------------------------------------

void armGripper(KatArm &arm) {
	Logger &logger = *arm.getContext().getLogger();
	KatArm::SensorDataSet zero, reading, threshold;

	arm.gripperRecvSensorData(reading);
	for (size_t i = 0; i < reading.size(); i++)
		logger.post("Sensor #%d: {%d, %d}", i, reading[i].index, reading[i].value);

	threshold = zero = reading;
	for (size_t i = 0; i < threshold.size(); i++)
		threshold[i].value += 5;

	logger.post("Closing gripper, high sensitivity...");
	arm.gripperClose(threshold);
	
	arm.gripperRecvSensorData(reading);
	for (size_t i = 0; i < reading.size(); i++)
		logger.post("Sensor #%d: {%d, %d}", i, reading[i].index, reading[i].value);
	
	arm.gripperOpen();
	
	threshold = zero;
	for (size_t i = 0; i < threshold.size(); i++)
		threshold[i].value += 100;
	
	logger.post("Closing gripper, low sensitivity...");
	arm.gripperClose(threshold);
	
	arm.gripperRecvSensorData(reading);
	for (size_t i = 0; i < reading.size(); i++)
		logger.post("Sensor #%d: {%d, %d}", i, reading[i].index, reading[i].value);
	
	arm.gripperOpen();
}

//------------------------------------------------------------------------------

int main(int argc, char *argv[]) {
	if (argc != 3 || argc == 2 && strcmp(argv[1], "-h") == 0) {
		printf("To run Katana: %s <config_file> <com_port_number>\n", argv[0]);
		return 1;
	}
	
	try {
		// Create program context
		golem::Context::Desc contextDesc;
		golem::Context::Ptr context = contextDesc.create();

		// Do not display LEVEL_DEBUG messages (only with level at least LEVEL_INFO)
		//context->getLogger()->setMsgFilter(MessageFilter::Ptr(new LevelFilter<Message>(Message::LEVEL_INFO)));

		//-----------------------------------------------------------------------------

		// Create arm controller description
		KatSerialArm::Desc katSerialArmDesc;
		katSerialArmDesc.cfgPath = argv[1]; // configuration file
		katSerialArmDesc.serialDesc.commPort = ::atoi(argv[2]); // Communication port (RS232)
		katSerialArmDesc.bGripper = true;

		// Create arm controller
		context->getLogger()->post(Message::LEVEL_INFO, "Initialising %s...", katSerialArmDesc.name.c_str());
		Arm::Ptr pArm = katSerialArmDesc.create(*context);
		
		// Display arm information
		armInfo(*pArm);
		
		// Gripper demo
		armGripper((KatArm&)*pArm);

		// Wait for some time
		context->getTimer()->sleep(SecTmReal(5.0));

		context->getLogger()->post(Message::LEVEL_INFO, "Good bye!");
	}
	catch (const Message& msg) {
		std::cerr << msg << std::endl;
	}
	catch (const std::exception &ex) {
		std::cerr << Message(Message::LEVEL_CRIT, "C++ exception: %s", ex.what()) << std::endl;
	}

	return 0;
}
