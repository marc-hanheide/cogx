/** @file Logger.h
 * 
 * Message logger for multithreaded systems.
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#pragma once
#ifndef _GOLEM_TOOLS_LOGGER_H_
#define _GOLEM_TOOLS_LOGGER_H_

//------------------------------------------------------------------------------

#include <Golem/Math/Collection.h>
#include <Golem/Math/Queue.h>
#include <Golem/Sys/Thread.h>
#include <Golem/Tools/Message.h>

//------------------------------------------------------------------------------

namespace golem {

//------------------------------------------------------------------------------

/** Message filter */
class MessageFilter {
public:
	typedef obj_ptr<MessageFilter> Ptr;

	virtual ~MessageFilter() {}
	virtual bool operator () (const Message &message) const = 0;
};

//------------------------------------------------------------------------------

template <typename MESSAGE>
class LevelFilter: public MessageFilter {
	const Message::Level mlevel;

public:
	LevelFilter(Message::Level level = Message::LEVEL_UNDEF) :
		mlevel(level)
	{}
	
	virtual bool operator () (const Message &message) const {
		const MESSAGE *pMessage = dynamic_cast<const MESSAGE*>(&message);
		return pMessage != NULL && pMessage->level() >= mlevel;
//		return typeid(message) == typeid(const MESSAGE) &&
//			pMessage->level() >= mlevel;
	}
};

template <typename MESSAGE>
class ThreadFilter: public MessageFilter {
	const U32 mthread;
	const Message::Level mlevel;

public:
	ThreadFilter(Message::Level level = Message::LEVEL_UNDEF, U32 thread = Thread::getCurrentThreadId()) :
		mthread(thread), mlevel(level)
	{}
	
	virtual bool operator () (const Message &message) const {
		const MESSAGE *pMessage = dynamic_cast<const MESSAGE*>(&message);
		return pMessage != NULL && pMessage->thread() == mthread && pMessage->level() >= mlevel;
//		return typeid(message) == typeid(const MESSAGE) &&
//			pMessage->thread() == mthread && pMessage->level() >= mlevel;
	}
};

template <typename MESSAGE> class LevelExclusiveFilter: public MessageFilter {
	const Message::Level mlevel;

public:
	LevelExclusiveFilter(Message::Level level = Message::LEVEL_DEBUG) :
		mlevel(level)
	{}
	
	virtual bool operator () (const Message &message) const {
		const MESSAGE *pMessage = dynamic_cast<const MESSAGE*>(&message);
		return pMessage != NULL && pMessage->level() != mlevel;
//		return typeid(message) == typeid(const MESSAGE) &&
//			pMessage->level() >= mlevel;
	}
};

//------------------------------------------------------------------------------

class Context;

/** Message logger */
class Logger {
public:
	typedef obj_ptr<Logger> Ptr;
#ifdef WIN32	// FIX
	friend class Ptr;
#endif
	friend class Desc;
	friend class Context;

	/** Logger collection */
	typedef PrivateList<Logger*, Logger::Ptr> List;

	/** Message logger description */
	class Desc {
		friend class Logger;
		friend class Context;
	
	protected:
		/** Creates Logger from the description. */
		virtual Logger::Ptr create(PerfTimer& timer) const {
			Logger::Ptr pLogger(new Logger(timer));

			if (!pLogger->create(*this))
				pLogger.release();

			return pLogger;
		}
		
	public:
		/** Exception filter decides if a message is thrown as an C++ exception (no if NULL) */
		MessageFilter::Ptr exFilter;
		/** Message filter decides if a message is queued in the message queue (yes if NULL) */
		MessageFilter::Ptr msgFilter;
		
		/** Stream output */
		std::ostream* pStream;
		/** FIFO message queue length */
		U32 messageQueueLen;

		/** Queue exceptions */
		bool queueEx;

		/** Constructs Logger description. */
		Desc() {
			setToDefault();
		}
		
		/** Destructor should be virtual */
		virtual ~Desc() {}
		
		/** Sets the parameters to the default values. */
		virtual void setToDefault() {
			exFilter.reset(new ThreadFilter<Message>(Message::LEVEL_CRIT)); // throw LEVEL_CRIT messages
			msgFilter.release();

			pStream = &std::cout; // print on console
			messageQueueLen = 0; // no queue
			queueEx = false;
		}

		/** Checks if the description is valid. */
		virtual bool isValid() const {

			return true;
		}
	};
	
protected:
	typedef golem::queue<Message::Ptr> MessageQueue;

	/** Timer */
	PerfTimer& timer;
	
	/** Exception filter decides if a message is thrown as an C++ exception (no if NULL) */
	MessageFilter::Ptr exFilter;
	/** Input filter decides if a message is queued in the message queue (yes if NULL) */
	MessageFilter::Ptr msgFilter;

	/** Stream output */
	std::ostream* pStream;
	/** Queue exceptions */
	bool queueEx;

	/** Set of message loggers */
	Logger::List loggers;
	/** Message queue */
	MessageQueue messages;
	
	CriticalSection csLoggers;
	CriticalSection csMessages;
	Event evMessages;

	/** Posts the message to the message queue and leaf Loggers */
	virtual bool post(Message::Ptr &pMessage);

	/** Posts a message to the queue and to all leaf Loggers */
	template <typename MESSAGE> bool post(bool bThrow, MESSAGE *message, Message::Level level);
	
	/** Posts a message to the queue and to all leaf Loggers */
	template <typename MESSAGE> bool post(bool bThrow, MESSAGE *message, Message::Level level, const char* format, va_list argptr);
	
	/** Creates logger from description */
	bool create(const Desc &desc);

	/** Constructor */
	Logger(PerfTimer& timer);
	
#ifndef WIN32	// FIX
public:
#endif
	/** Destructor is protected */
	virtual ~Logger();
	
public:
	/** Creates a new "leaf" Logger. */
	virtual Logger *createLogger(const Desc &desc);

	/** Release the Logger and all its leaf Loggers. */
	virtual void releaseLogger(Logger &logger);

	/** Returns leaf Logger collection */
	const Logger::List &getLoggers() const {
		return loggers;
	}
	
	
	/** Posts an empty message */
	bool post();
	
	/** Posts a default message (Message) to the queue and to all leaf Loggers */
	bool post(const char* format, ...);
	
	/** Posts a default message (Message) to the queue and to all leaf Loggers */
	bool post(Message::Level level, const char* format, ...);
	
	/** Posts a message to the queue and to all leaf Loggers */
	template <typename MESSAGE> bool post(MESSAGE *message);
	
	/** Posts a message to the queue and to all leaf Loggers */
	template <typename MESSAGE> bool post(MESSAGE *message, const char* format, ...);
	
	/** Posts a message to the queue and to all leaf Loggers */
	template <typename MESSAGE> bool post(MESSAGE *message, Message::Level level, const char* format, ...);
	

	/** Fetches messages from the Logger message queue */
	virtual bool fetch(Message::Ptr& pMessage, MSecTmU32 timeOut = MSEC_TM_U32_INF);
	
	/** Checks if the message queue is empty */
	virtual bool empty();
	
	/** Clears all messages in the message queue and in the logger set */
	virtual void clear();
		
	
	/** Returns exception message filter */
	const MessageFilter::Ptr &getExFilter() const {
		return exFilter;
	}
	/** Sets exception message filter */
	void setExFilter(const MessageFilter::Ptr &exFilter) {
		this->exFilter = exFilter;
	}

	/** Returns message filter */
	const MessageFilter::Ptr &getMsgFilter() const {
		return msgFilter;
	}
	/** Sets message filter */
	void setMsgFilter(const MessageFilter::Ptr &msgFilter) {
		this->msgFilter = msgFilter;
	}
};

//------------------------------------------------------------------------------

/** Posts a message to the message queue and to all leaf Loggers */
template <typename MESSAGE> bool Logger::post(bool bThrow, MESSAGE *message, Message::Level level) {
	Message::Ptr pMessage(message);
	
	pMessage->setup(timer.elapsed(), level);
	
	if (bThrow && exFilter != NULL && (*exFilter)(*message)) {
		if (queueEx) (void)post(pMessage);
		throw MESSAGE(*message);
	}
	
	return post(pMessage);
}

/** Posts a message to the message queue and to all leaf Loggers */
template <typename MESSAGE> bool Logger::post(bool bThrow, MESSAGE *message, Message::Level level, const char* format, va_list argptr) {
	Message::Ptr pMessage(message);
	
	pMessage->setup(timer.elapsed(), level, format, argptr);
	
	if (bThrow && exFilter != NULL && (*exFilter)(*message)) {
		if (queueEx) (void)post(pMessage);
		throw MESSAGE(*message);
	}
	
	return post(pMessage);
}

//------------------------------------------------------------------------------

/** Posts a message to the message queue and to all leaf Loggers */
template <typename MESSAGE> bool Logger::post(MESSAGE *message) {
	return post(true, message, Message::LEVEL_UNDEF);
}

/** Posts a message to the message queue and to all leaf Loggers */
template <typename MESSAGE> bool Logger::post(MESSAGE *message, const char* format, ...) {
	va_list argptr;
	va_start(argptr, format);
	bool bPosted = post(true, message, Message::LEVEL_UNDEF, format, argptr);
	va_end(argptr);
	return bPosted;
}

/** Posts a message to the message queue and to all leaf Loggers */
template <typename MESSAGE> bool Logger::post(MESSAGE *message, Message::Level level, const char* format, ...) {
	va_list argptr;
	va_start(argptr, format);
	bool bPosted = post(true, message, level, format, argptr);
	va_end(argptr);
	return bPosted;
}

//------------------------------------------------------------------------------

};	// namespace

#endif /*_GOLEM_TOOLS_LOGGER_H_*/
