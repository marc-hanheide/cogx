/** @file Msg.h
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#pragma once
#ifndef _GOLEM_PHYS_MSG_H_
#define _GOLEM_PHYS_MSG_H_

//------------------------------------------------------------------------------

#include <Golem/Tools/Message.h>

//------------------------------------------------------------------------------

namespace golem {

//------------------------------------------------------------------------------

/** LEVEL_CRIT */
class MsgApplication : virtual public Message {MESSAGE_BODY(MsgApplication)};

class MsgObject : public Message {};
/** LEVEL_CRIT */
class MsgObjectInvalidDesc : public MsgObject {};

class MsgActor : public MsgObject {};
/** LEVEL_CRIT */
class MsgActorNxActorCreate : public MsgActor {};
class MsgActorNxShapeCreate : public MsgActor {};
class MsgActorNxShapeDescCreate : public MsgActor {};
class MsgActorBoundsCreate : public MsgActor {};
class MsgActorBoundsNxShapeMismatch : public MsgActor {};

class MsgScene : public Message {};
/** LEVEL_CRIT */
class MsgSceneInvalidDesc : public MsgScene {};
class MsgSceneNxSceneCreate : public MsgScene {};
class MsgSceneDebugInit : public MsgScene {};
class MsgSceneObjectCreate : public MsgScene {};
class MsgSceneBoundsDescInvalidDesc : public MsgScene {};
class MsgSceneBoundsDescCreate : public MsgScene {};
class MsgSceneNxShapeDescInvalidDesc : public MsgScene {};
class MsgSceneNxShapeDescCreate : public MsgScene {};

class MsgUniverse : public Message {};
/** LEVEL_CRIT */
class MsgUniverseInvalidDesc : public MsgUniverse {};
class MsgUniversePhysXInit : public MsgUniverse {};
class MsgUniversePhysXCookInit : public MsgUniverse {};
class MsgUniverseNoScenes : public MsgUniverse {};
class MsgUniverseThreadLaunch : public MsgUniverse {};
class MsgUniverseGlutInit : public MsgUniverse {};
class MsgUniverseSceneCreate : public MsgUniverse {};

class MsgRecorder : public Message {};
/** LEVEL_CRIT */
class MsgRecorderInvalidDesc : public MsgRecorder {};
class MsgRecorderThreadLaunch : public MsgRecorder {};

//------------------------------------------------------------------------------

};	// namespace

#endif /*_GOLEM_PHYS_MSG_H_*/
