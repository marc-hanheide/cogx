/** @file Msg.h
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#pragma once
#ifndef _GOLEM_DEMO_COMMON_MSG_H_
#define _GOLEM_DEMO_COMMON_MSG_H_

//------------------------------------------------------------------------------

#include <Golem/PhysCtrl/Msg.h>

//------------------------------------------------------------------------------

namespace golem {

//------------------------------------------------------------------------------

class MsgEmbod : public MsgObject {};
class MsgChannel : public MsgObject {};


class MsgSensor : public MsgChannel {};
class MsgEffector : public MsgChannel {};
class MsgFilter : public MsgChannel {};
class MsgLearner : public MsgChannel {};


class MsgFTSensor : public MsgSensor {};

class MsgPointTracker : public MsgSensor {};

class MsgRigidBodyTracker : public MsgSensor {};

class MsgRetina : public MsgFilter {};

class MsgRecognition : public MsgFilter {};

class MsgFinger : public MsgEffector {};


class MsgRotations : public MsgEmbod {};

class MsgImageFilter : public MsgEmbod {};

class MsgLayer : public MsgEmbod {};

//------------------------------------------------------------------------------

};	// namespace

#endif /*_GOLEM_DEMO_COMMON_MSG_H_*/
