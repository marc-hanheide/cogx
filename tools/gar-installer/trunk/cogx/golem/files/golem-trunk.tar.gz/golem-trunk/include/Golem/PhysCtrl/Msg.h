/** @file Msg.h
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#pragma once
#ifndef _GOLEM_PHYSCTRL_MSG_H_
#define _GOLEM_PHYSCTRL_MSG_H_

//------------------------------------------------------------------------------

#include <Golem/Ctrl/Msg.h>
#include <Golem/Phys/Msg.h>

//------------------------------------------------------------------------------

namespace golem {

//------------------------------------------------------------------------------

class MsgPhysArm : public MsgActor {};
/** LEVEL_CRIT */
class MsgPhysArmBoundsGroupCreate : public MsgPhysArm {};
class MsgPhysArmShapeDescCreate : public MsgPhysArm {};
class MsgPhysArmJointActor : public MsgPhysArm {};

class MsgPhysPlanner : public MsgPhysArm {};

class MsgPhysReacPlanner : public MsgPhysPlanner {};

//------------------------------------------------------------------------------

};	// namespace

#endif /*_GOLEM_PHYSCTRL_MSG_H_*/
