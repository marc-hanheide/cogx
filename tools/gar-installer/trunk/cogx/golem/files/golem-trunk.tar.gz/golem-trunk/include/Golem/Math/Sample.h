/** @file Sample.h
 * 
 * Sample class.
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#pragma once
#ifndef _GOLEM_MATH_SAMPLE_H_
#define _GOLEM_MATH_SAMPLE_H_

//------------------------------------------------------------------------------

#include <Golem/Math/Math.h>
#include <functional>
#include <cmath>

//------------------------------------------------------------------------------

namespace golem {

//------------------------------------------------------------------------------

/** Cumulative density function sample */
class Sample {
public:
	/** Cumulative density function comparator */
	struct Cmpr : public std::binary_function<Sample, Sample, bool> {
		inline bool operator () (const Sample &l, const Sample &r) const {
			return l.cdf < r.cdf;
		}
	};

public:
	/** Weight */
	Real weight;
	/** Cumulative density */
	Real cdf;

	Sample() {
	}

	Sample(Real weight) : weight(weight) {
		cdf = -REAL_ONE;
	}

	/** Sets the parameters to the default values */
	void setToDefault() {
		weight = REAL_ONE;
		cdf = -REAL_ONE; // invalidate
	}

	/** Sets the sample weight to the specified value; invalidates cdf */
	void set(Real weight) {
		this->weight = weight;
		this->cdf = -REAL_ONE; // invalidate
	}

	/** Sets the parameters to the default values */
	template <typename Seq> static void setToDefault(Seq& seq) {
		for (typename Seq::iterator i = seq.begin(); i != seq.end(); i++)
			i->setToDefault();
	}

	/** Sets the sample weights to the specified value; invalidates cdf */
	template <typename Seq> static void set(Real weight, Seq& seq) {
		for (typename Seq::iterator i = seq.begin(); i != seq.end(); i++)
			i->set(weight);
	}

	/** Checks if sample is valid. */
	inline bool isValid() const {
		if (weight < REAL_ZERO || cdf < REAL_ZERO)
			return false;
		
		return true;
	}
	
	/** Checks if sample sequence is valid. */
	template <typename Seq> static inline bool isValid(const Seq& seq) {
		if (seq.empty() || seq.back().cdf <= REAL_ZERO)
			return false;
		for (typename Seq::const_iterator i = seq.begin(); i != seq.end(); i++)
			if (!i->isValid())
				return false;
		
		return true;
	}
	
	/** Normalisation constant */
	template <typename Seq> static inline Real getNorm(const Seq& seq) {
		if (seq.empty())
			return REAL_ZERO;

		const Real cdf = seq.back().cdf;
		if (cdf <= REAL_ZERO)
			return REAL_ZERO;
		
		return REAL_ONE/seq.back().cdf;
	}

	/** Normalises weighted set of samples */
	template <typename Seq> static inline bool normalise(Seq& seq) {
		if (seq.empty())
			return false;
		
		Real cdf = REAL_ZERO;
		for (typename Seq::iterator i = seq.begin(); i != seq.end(); i++)
			i->cdf = (cdf += i->weight);

		if (cdf <= REAL_ZERO) {
			Real cdf = REAL_ZERO;
			for (typename Seq::iterator i = seq.begin(); i != seq.end(); i++)
				i->cdf = (cdf += (i->weight = REAL_ONE));
		}

		return true;
	}

	/** Normalises weighted set of samples */
	template <typename Seq> static inline bool uniform(Seq& seq) {
		if (seq.empty())
			return false;
		
		const Real delta = REAL_ONE/seq.size();
		size_t j = 1;
		for (typename Seq::iterator i = seq.begin(); i != seq.end(); i++, j++) {
			i->weight = delta;
			i->cdf = delta*j;
		}

		return true;
	}

	/** Draws a sample from set of samples */
	template <typename Seq, typename Rand> static inline const typename Seq::value_type* sample(const Seq& seq, const Rand& rand) {
		if (seq.empty())
			return NULL;

		const Real cdf = seq.back().cdf;
		if (cdf <= REAL_ZERO)
			return NULL;

		Sample s;
		s.cdf = rand.template nextUniform<Real>()*cdf;
		typename Seq::const_iterator ptr = std::lower_bound(seq.begin(), seq.end(), s, Sample::Cmpr());
		
		return ptr == seq.end() ? &seq.back() : &*ptr;
	}

	/** Draws a sample from set of samples */
	template <typename Seq, typename Rand> static inline typename Seq::value_type* sample(Seq& seq, const Rand& rand) {
		if (seq.empty())
			return NULL;

		const Real cdf = seq.back().cdf;
		if (cdf <= REAL_ZERO)
			return NULL;

		Sample s;
		s.cdf = rand.template nextUniform<Real>()*cdf;
		typename Seq::iterator ptr = std::lower_bound(seq.begin(), seq.end(), s, Sample::Cmpr());
		
		return ptr == seq.end() ? &seq.back() : &*ptr;
	}
};

//------------------------------------------------------------------------------

};	// namespace

#endif /*_GOLEM_MATH_SAMPLE_H_*/
