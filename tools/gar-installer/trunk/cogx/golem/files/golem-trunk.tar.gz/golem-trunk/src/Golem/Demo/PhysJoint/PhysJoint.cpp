/** @file PhysJoint.cpp
 * 
 * Demonstration program which moves the arm to the zero pose.
 * 
 * Program can be run in two modes:
 * - the first uses real Katana arm
 * - the second runs the Katana arm simulator
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#include <Golem/Ctrl/Katana.h>
#include <Golem/Ctrl/Simulator.h>
#include <Golem/PhysCtrl/PhysArm.h>
#include <Golem/Demo/Common/Tools.h>
#include <iostream>

using namespace golem;

//------------------------------------------------------------------------------

int main(int argc, char *argv[]) {
	if (argc != 1 && argc != 3 || argc == 2 && strcmp(argv[1], "-h") == 0) {
		printf("To run Katana: %s <config_file> <com_port_number>\n", argv[0]);
		printf("To run Simulation: %s\n", argv[0]);
		return 1;
	}
	
	try {
		printf("Use the arrow keys to move the camera.\n");
		printf("Use the mouse to rotate the camera.\n");
		printf("Press p to pause simulations.\n");
		printf("Press pgup/pgdn/space to switch between simulations.\n");
		printf("Press v to show Actors reference frames.\n");
		printf("Use z, x, c to change randering mode.\n");
		printf("Use F1-F12 to display program specific debug information.\n");
		printf("\tF1 to display/hide the current destination pose.\n");
		printf("\tF2 to display/hide the current trajectory.\n");
		printf("Press esc to exit.\n");
		
		// Create program context
		golem::Context::Desc contextDesc;
		golem::Context::Ptr context = contextDesc.create();

		// Do not display LEVEL_DEBUG messages (only with level at least LEVEL_INFO)
		//context->getLogger()->setMsgFilter(MessageFilter::Ptr(new LevelFilter<Message>(Message::LEVEL_INFO)));

		//-----------------------------------------------------------------------------

		// Simulations or real devices
		const bool simulations = argc == 1;
		
		// Create Universe
		Universe::Desc universeDesc;
		universeDesc.name = "Golem (PhysJoint)";
		universeDesc.argc = argc;
		universeDesc.argv = argv;
		Universe::Ptr pUniverse = universeDesc.create(*context);

		// Create scene
		Scene::Desc sceneDesc;
		sceneDesc.name = "Robotic arm controller demo";
		Scene *pScene = pUniverse->createScene(sceneDesc);

		// Create arm controller description
		PhysArm::Desc physArmDesc;
		if (simulations) {
			// Katana 
			KatSimArm::Desc *pDesc = new KatSimArm::Desc();
			physArmDesc.pArmDesc.reset(pDesc);
			pDesc->body.simpleBoundsModel = false;
			pDesc->setupJoints();
			pDesc->deltaOffs = SecTmReal(0.1);
			pDesc->skewOffs = SecTmReal(0.02);
		}
		else {
			// Katana
			KatSerialArm::Desc *pDesc = new KatSerialArm::Desc();
			physArmDesc.pArmDesc.reset(pDesc);
			pDesc->cfgPath = argv[1]; // configuration file
			pDesc->serialDesc.commPort = ::atoi(argv[2]); // Communication port (RS232)
			pDesc->deltaOffs = SecTmReal(0.1);
			pDesc->skewOffs = SecTmReal(0.02);
		}

		// Create PhysArm controller
		context->getLogger()->post(Message::LEVEL_INFO, "Initialising arm controller...");
		PhysArm *pPhysArm = dynamic_cast<PhysArm*>(pScene->createObject(physArmDesc));
		if (pPhysArm == NULL) {
			context->getLogger()->post(Message::LEVEL_CRIT, "Unable to create arm controller");
			return 1;
		}
		Arm &arm = pPhysArm->getArm();
		
		// Display arm information
		armInfo(arm);

		// Launch universe
		context->getLogger()->post(Message::LEVEL_INFO, "Launching Universe...");
		pUniverse->launch();

		// Get the current position of joints
		GenConfigspaceState begin;
		if (!arm.recv(begin, context->getTimer()->elapsed())) {
			context->getLogger()->post(Message::LEVEL_CRIT, "armZeroMove(): receive error");
			return 1;
		}
		
		// Generate trajectory end-point
		GenConfigspaceCoord end;
		// Zero joint position, velocity and acceleration
		end.set(GenCoord(REAL_ZERO, REAL_ZERO, REAL_ZERO));

		// Choose movement velocity and acceleration to 50%
		context->getLogger()->post(Message::LEVEL_INFO, "Moving to the ZERO pose");
		armMove(arm, end, Real(0.5), Real(0.5)); // zero pose
		armWatch(arm);

		context->getLogger()->post(Message::LEVEL_INFO, "Press the spacebar to continue");
		while (pUniverse->waitKey() != ' ' && !pUniverse->interrupted());

		// Choose movement velocity and acceleration to 50%
		context->getLogger()->post(Message::LEVEL_INFO, "Moving to the INITIAL pose");
		armMove(arm, begin, Real(0.5), Real(0.5)); // and back
		armWatch(arm);

		context->getLogger()->post(Message::LEVEL_INFO, "Good bye!");
	}
	catch (const Message& msg) {
		std::cerr << msg << std::endl;
	}
	catch (const std::exception &ex) {
		std::cerr << Message(Message::LEVEL_CRIT, "C++ exception: %s", ex.what()) << std::endl;
	}

	return 0;
}
