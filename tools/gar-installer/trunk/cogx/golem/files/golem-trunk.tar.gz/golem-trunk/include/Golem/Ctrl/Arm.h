/** @file Arm.h
 * 
 * Implementation of arm controller interface.
 * 
 * Joint Control interface is a set of classes modelling a generic open-chain manipulator. 
 * The robotic arm (master) is assumed to consist of a number of independent 
 * joints (slaves).
 * 
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#pragma once
#ifndef _GOLEM_CTRL_ARM_H_
#define _GOLEM_CTRL_ARM_H_

//------------------------------------------------------------------------------

#include <Golem/Math/Quat.h>
#include <Golem/Math/Bounds.h>
#include <Golem/Ctrl/Controller.h>
#include <Golem/Ctrl/Profile.h>
#include <vector>
#include <list>

//------------------------------------------------------------------------------

namespace golem {

//------------------------------------------------------------------------------

/** (Extended) generalised coordinates.
 */
struct GenCoord {
	/** position */
	Real pos;
	/** velocity */
	Real vel;
	/** acceleration */
	Real acc;

	/** Default constructor does not do anything */
	GenCoord() {
	}
	
	/** Constructs GenCoord with specified pose, pose velocity and pose acceleration */
	GenCoord(Real pos, Real vel, Real acc) : pos(pos), vel(vel), acc(acc) {
	}

	/** sets zero */
	inline void setZero() {
		pos = REAL_ZERO;
		vel = REAL_ZERO;
		acc = REAL_ZERO;
	}

	/** tests for finite vector
	*/
	inline bool isFinite() const {
		if (!Math::isFinite(pos) || !Math::isFinite(vel) || !Math::isFinite(acc))
			return false;
		return true;
	}
};

/** Generalised coordinates in time.
 */
typedef State<GenCoord> GenState;

//------------------------------------------------------------------------------

/** Max configuration space dimensions */
const U32 CONFIG_SPACE_DIM = 6;

/* SI Units:
 * - position/angle: meter [m], radian [rad]
 * - time: second [sec]
 * - velocity: [m/sec], [rad/sec]
 * - acceleration: [m/sec*sec], [rad/sec*sec]
 * - weight: kilogram [kg]
 * - force: Newton [N]
 */

/** Configuration space coordinates of the arm.
 */
struct ConfigspaceCoord {
	typedef std::vector<ConfigspaceCoord> Seq;

	/** configuration space coordinates */
	Real c[CONFIG_SPACE_DIM];

	/**	Sets configuration space coordinates to the specified value. */
	inline void set(U32 index, Real value) {
		c[index] = value;
	}
	
	/**	Sets configuration space coordinates to the specified value. */
	inline void set(Real value) {
		for (U32 i = 0; i < CONFIG_SPACE_DIM; i++)
			c[i] = value;
	}

	/** sets zero */
	inline void setZero() {
		set(REAL_ZERO);
	}

	/**	Sets configuration space coordinates to the specified value. */
	inline Real get(U32 index) const {
		return c[index];
	}

	/** tests for exact zero vector
	*/
	inline bool isZero() const {
		for (U32 i = 0; i < CONFIG_SPACE_DIM; i++)
			if (!Math::abs(c[i]))
				return false;
		return true;
	}

	/** tests for positive vector
	*/
	inline bool isPositive() const {
		for (U32 i = 0; i < CONFIG_SPACE_DIM; i++)
			if (c[i] <= REAL_ZERO)
				return false;
		return true;
	}

	/** tests for finite vector
	*/
	inline bool isFinite() const {
		for (U32 i = 0; i < CONFIG_SPACE_DIM; i++)
			if (!Math::isFinite(c[i]))
				return false;
		return true;
	}
	
	/**	Array subscript operator. */
	inline const Real &operator [] (U32 index) const {
		return c[index];
	}

	/**	Array subscript operator. */
	inline Real &operator [] (U32 index) {
		return c[index];
	}
};

/** Joint coordinates of the arm in time.
 */
typedef State<ConfigspaceCoord> JointState;

/** (Extended) generalised coordinates of the arm joints.
 */
struct GenConfigspaceCoord {
	typedef std::vector<GenConfigspaceCoord> Seq;
	
	/** pose */
	ConfigspaceCoord pos;
	/** pose velocity */
	ConfigspaceCoord vel;
	/** pose acceleration */
	ConfigspaceCoord acc;

	/**	Sets generalised configuration space coordinates to the specified value. */
	inline void set(U32 index, const GenCoord &value) {
		pos.set(index, value.pos);
		vel.set(index, value.vel);
		acc.set(index, value.acc);
	}
	
	/**	Sets configuration space coordinates to the specified value. */
	inline void set(const GenCoord &value) {
		pos.set(value.pos);
		vel.set(value.vel);
		acc.set(value.acc);
	}

	/** sets zero */
	inline void setZero() {
		pos.setZero();
		vel.setZero();
		acc.setZero();
	}

	/**	Sets configuration space coordinates to the specified value. */
	inline GenCoord get(U32 index) const {
		return GenCoord(pos.get(index), vel.get(index), acc.get(index));
	}

	/** tests for finite vector
	*/
	inline bool isFinite() const {
		if (!pos.isFinite() || !vel.isFinite() || !acc.isFinite())
			return false;
		return true;
	}
};

/** Generalised configuration space coordinates of the arm in time.
 */
typedef State<GenConfigspaceCoord> GenConfigspaceState;

//------------------------------------------------------------------------------

/** Workspace coordinates.
 */
typedef Mat34 WorkspaceCoord;

/** Workspace velocity.
 */
typedef Twist WorkspaceVel;

/** Joint coordinates of the arm in time.
 */
typedef State<WorkspaceCoord> WorkspaceState;

/** Generalised workspace coordinates.
 */
struct GenWorkspaceCoord {
	typedef std::vector<GenWorkspaceCoord> Seq;
	
	/** tool frame pose */
	WorkspaceCoord pos;
	/** tool frame velocity */
	WorkspaceVel vel;

	/** sets Id transformation and zero velocity */
	inline void setZero() {
		pos.p.setZero();
		pos.R.setId();
		vel.setZero();
	}

	/** tests for finite vector
	*/
	inline bool isFinite() const {
		if (!pos.isFinite() || !vel.isFinite())
			return false;
		return true;
	}
};

/** Generalised configuration space coordinates of the arm in time.
 */
typedef State<GenWorkspaceCoord> GenWorkspaceState;

//------------------------------------------------------------------------------

/** Exponential coordinates of rigid body transformation (exponential mapping: se(3) -> SE(3)).
*/
struct ExpCoord {
	/** Twist coordinates of rigid body transformation (generator of exponential mapping: se(3) -> SE(3)) */
	Twist twist;
	/** Transformation magnitude */
	Real theta;
};

/** Manipulator Jacobian (in twist coordinates).
*/
struct Jacobian {
	Twist j[CONFIG_SPACE_DIM];

	/**	Array subscript operator. */
	inline const Twist &operator [] (U32 index) const {
		return j[index];
	}

	/**	Array subscript operator. */
	inline Twist &operator [] (U32 index) {
		return j[index];
	}
};

//------------------------------------------------------------------------------

class Arm;

/** Joint.
 */
class Joint {
	friend class Arm;

public:
	typedef obj_ptr<Joint> Ptr;
#ifdef WIN32	// FIX
	friend class Ptr;
#endif
	typedef std::vector<Joint*> Seq;

	/** Callback interface for data synchronization */
	class Callback {
	public:
		virtual ~Callback() {}
		/** Auto synchronization of Joint bounds descriptions */
		virtual void syncJointBoundsDesc() {} //= 0;
	};

	/** Joint description */
	class Desc {
	public:
		typedef obj_ptr<Desc> Ptr;
		typedef std::vector<const Desc*> ConstSeq;
		typedef std::vector<Ptr> Seq;
		
		friend class Joint;
		friend class Arm;
	
	private:
		/** Joint index
		*/
		mutable I32 index;
		
	protected:
		/** Creates Joint given the description object. 
		* @param arm	Arm interface
		* @return		pointer to the Joint, if no errors have occured;
		*				<code>NULL</code> otherwise 
		*/
		virtual Joint::Ptr create(Arm& arm) const = 0;

	public:
		/** Name ASCII string */
		std::string name;
		
 		/** minimum value of generalised coordinate of a joint */
		GenCoord min;
		/** maximum value of generalised coordinate of a joint */
		GenCoord max;
		/** exponential coordinates defining joint transformation */
		ExpCoord trn;
		/** exponential coordinates defining initial frame transformation */
		ExpCoord trnInit;

		/** bounds and visualisation of the joint in local coordinates */
		Bounds::Desc::Seq bounds;
		/** collision detection */
		bool collision;
		/** collision joint offset */
		U32 collisionOffset;

		Desc() {
			Desc::setToDefault();
		}

		virtual ~Desc() {}

		/** Resets the description to default one */
		virtual void setToDefault() {
			index = -1;

			name = "";

			min.pos = -REAL_PI;
			min.vel = -REAL_PI;
			min.acc = -REAL_PI;

			max.pos = +REAL_PI;
			max.vel = +REAL_PI;
			max.acc = +REAL_PI;

			trn.twist.set(REAL_ZERO, REAL_ZERO, REAL_ZERO, REAL_ZERO, REAL_ZERO, REAL_ZERO);
			trn.theta = REAL_ZERO;
			
			trnInit.twist.set(REAL_ZERO, REAL_ZERO, REAL_ZERO, REAL_ZERO, REAL_ZERO, REAL_ZERO);
			trnInit.theta = REAL_ZERO;
			
			bounds.clear();
			collision = true;
			collisionOffset = 0;
		}

		/** Checks validity */
		virtual bool isValid() const {
			if (min.pos >= max.pos || min.vel >= max.vel || min.acc >= max.acc)
				return false;

			// there can be no bounds given, but if they are - they have to be valid
			for (Bounds::Desc::Seq::const_iterator i = bounds.begin(); i != bounds.end(); i++)
				if (*i == NULL || !(*i)->isValid())
					return false;

			return true;
		}
	};

private:
	/** Index */
	U32 index;

protected:
	/** Context object */
	golem::Context& context;
	/** Arm interface */
	Arm& arm;

	/** Name ASCII string */
	std::string name;
	
	/** minimum value of generalised coordinate of a joint */
	GenCoord min;
	/** maximum value of generalised coordinate of a joint */
	GenCoord max;
	/** exponential coordinates defining joint transformation */
	ExpCoord trn;
	/** exponential coordinates defining initial frame transformation */
	ExpCoord trnInit;
	/** bounds and visualisation of the joint */
	Bounds::Desc::Seq boundsDescSeq;
	/** collision detection */
	bool collision;
	/** collision joint offset */
	U32 collisionOffset;

	/** Callback interface for data synchronization */
	Callback* pCallback;

	mutable CriticalSection cs;
	
	virtual bool sysRecv(GenCoord& curr) = 0;
	virtual bool sysSend(const GenCoord& prev, const GenCoord& next, SecTmReal dt) = 0;
	
	/** Creates Joint from the description. 
	* @param desc	Joint description
	* @return		<code>TRUE</code> if no errors have occured;
	*				<code>FALSE</code> otherwise 
	*/
	bool create(const Desc& desc);

	Joint(Arm& arm);

#ifndef WIN32	// FIX
public:
#endif
	/** Destructor is inaccesible */
	virtual ~Joint() {}

public:
	/** Adds the bounds description in the local coordinate frame of a given Joint
	 * @param pDesc			description of the bounds
	*/
	virtual bool addBoundsDesc(Bounds::Desc::Ptr pDesc);

	/** Removes the bounds description of a given Joint
	 * @param pDesc			the bounds to be removed
	*/
	virtual bool removeBoundsDesc(const Bounds::Desc* pDesc);
	
	/** Returns reference to the collection of bounds description of the Joint 
	 * @return				reference to the collection of bounds description
	*/
	virtual Bounds::Desc::SeqPtr getBoundsDescSeq() const;
	
	/** Returns Name ASCII string */
	inline const std::string& getName() const {
		return name;
	}
	
	/** Index */
	inline U32 getIndex() const {
		return index;
	}

	/** Returns minimum value of generalised coordinate of a joint */
	inline const GenCoord& getMin() const {
		return min;
	}
	
	/** Returns maximum value of generalised coordinate of a joint */
	inline const GenCoord& getMax() const {
		return max;
	}
	
	/** Returns exponential coordinates defining joint transformation */
	inline const ExpCoord& getTrn() const {
		return trn;
	}
	
	/** Returns exponential coordinates defining initial frame transformation */
	inline const ExpCoord& getTrnInit() const {
		return trnInit;
	}
	
	/** Callback interface for data synchronization
	 * @param pCallback	pointer to the interface
	*/
	inline void setCallback(Callback* pCallback) {
		this->pCallback = pCallback;
	}
	
	/** Callback interface for data synchronization
	 * @return				pointer to the interface
	*/
	inline Callback* getCallback() {
		return pCallback;
	}
	
	/** collision detection */
	inline bool hasCollision() const {
		return collision;
	}
	
	/** Returns collision joint offset */
	inline U32 getCollisionOffset() const {
		return collisionOffset;
	}
};

//------------------------------------------------------------------------------

typedef Controller<GenConfigspaceCoord, GenConfigspaceCoord> ArmController;

/** Arm controller, both input and output are of GenConfigspaceState type.
 */
class Arm : public ArmController {
public:
	typedef obj_ptr<Arm> Ptr;
#ifdef WIN32	// FIX
	friend class Ptr;
#endif
	friend class Desc;

	/** Transformation mode */
	//enum Transformation {
	//	TRN_GLOBAL_POSE = 0x1,
	//	TRN_REFERENCE_POSE = 0x2,
	//	TRN_DEFAULT_POSE = TRN_GLOBAL_POSE | TRN_REFERENCE_POSE,
	//};

	/** Arm description
	 */
	class Desc : public ArmController::Desc {
	public:
		typedef obj_ptr<Desc> Ptr;
		
		/** Name ASCII string */
		std::string name;
		
		/** joints */
		Joint::Desc::Seq joints;
		
		/** Arm global pose */
		Mat34 globalPose;
		/** Local reference pose in the tool frame */
		Mat34 referencePose;
		/** Arm joint rest position */
		ConfigspaceCoord restPosition;
		
		Desc() {
			Desc::setToDefault();
		}

		/** Creates Arm given the description object. 
		* @param context	golem::Context object
		* @return		pointer to the Arm, if no errors have occured;
		*				<code>NULL</code> otherwise 
		*/
		virtual Arm::Ptr create(golem::Context& context) const = 0;

		virtual void setToDefault() {
			ArmController::Desc::setToDefault();

			name = "";
			joints.clear();	
			globalPose.setId();
			referencePose.setId();
			restPosition.set(REAL_ZERO);
		}

		virtual bool isValid() const {
			if (!ArmController::Desc::isValid())
				return false;

			if (joints.size() <= 0 || joints.size() > CONFIG_SPACE_DIM)
				return false;

			for (Joint::Desc::Seq::const_iterator i = joints.begin(); i != joints.end(); i++)
				if (*i == NULL || !(*i)->isValid())
					return false;
			
			if (!globalPose.isFinite() || !referencePose.isFinite())
				return false;
			
			return true;
		}
	};

protected:
	/** Joints collection */
	typedef std::list<Joint::Ptr> JointList;
	
	/** Name ASCII string */
	std::string name;

	/** Joints collection */
	JointList jointList;
	/** Joints pointers */
	Joint::Seq joints;

	/** Arm global pose */
	Mat34 globalPose;
	/** Trajectory reference pose */
	Mat34 referencePose;
	/** Arm joint rest position */
	ConfigspaceCoord restPosition;

	mutable CriticalSection cs;

	// Arm (protected members), partial implementation
	virtual bool sysRecv(GenConfigspaceCoord& curr);
	virtual bool sysSend(const GenConfigspaceCoord& prev, const GenConfigspaceCoord& next, SecTmReal dt);

	/** Creates Arm from the description. 
	* @param desc	Arm description
	* @return		<code>TRUE</code> if no errors have occured;
	*				<code>FALSE</code> otherwise 
	*/
	bool create(const Desc& desc);

	Arm(golem::Context& context);

#ifndef WIN32	// FIX
public:
#endif
	/** Each derived class should have virtual destructor releasing resources
	*	to avoid calling virtual functions of non-existing objects
	*/
	virtual ~Arm();

public:
	/** Retrieves the arm controller state (output) at a query time t.
	* @param state		state of the arm controller
	* @param t			query time t in seconds (t usually refers to the past)
	* @return			<code>TRUE</code> no errors; <code>FALSE</code> otherwise 
	*/
	virtual bool lookupOut(GenConfigspaceState &state, SecTmReal t);

	/** Retrieves the arm controller planned state (input) at a query time t.
	* @param state			state of the arm controller
	* @param t				query time t in seconds (t usually refers to the future)
	* @return				<code>TRUE</code> no errors; <code>FALSE</code> otherwise 
	*/
	virtual bool lookupInp(GenConfigspaceState &state, SecTmReal t);

	/** Forward transformation for tool frame (involves the arm global pose and the reference pose)
	 * @param trn	SE(3) transformation matrix:
	 *				tool frame pose -> base frame pose
	 * @param cc	configuration space coordinates
	 */
	virtual void forwardTransform(Mat34& trn, const ConfigspaceCoord& cc) const;

	/** (Extended) forward transformation for all joints (involves the arm global pose and the reference pose)
	 * @param trn	pointer to array of SE(3) transformation matrices:
	 *				joint frame poses -> base frame pose
	 * @param cc	configuration space coordinates
	 */
	virtual void forwardTransformEx(Mat34* trn, const ConfigspaceCoord& cc) const;

	/** End-effector spatial velocity
	 * @param v		velocity
	 * @param cc	configuration space coordinates
	 * @param dcc	delta
	 */
	virtual void velocitySpatial(Twist& vs, const ConfigspaceCoord& cc, const ConfigspaceCoord& dcc) const;

	/** End-effector body velocity
	 * @param v		velocity
	 * @param cc	configuration space coordinates
	 * @param dcc	delta
	 */
	virtual void velocityBody(Twist& vb, const ConfigspaceCoord& cc, const ConfigspaceCoord& dcc) const;

	/** End-effector velocity
	 * @param v		velocity
	 * @param cc	configuration space coordinates
	 * @param dcc	delta
	 */
	virtual void velocity(Twist& v, const ConfigspaceCoord& cc, const ConfigspaceCoord& dcc) const;

	/** End-effector velocity
	 * @param v		velocity
	 * @param jac	manipulator Jacobian
	 * @param dcc	delta
	 */
	virtual void velocityFromJacobian(Twist& v, const Jacobian& jac, const ConfigspaceCoord& dcc) const;

	/** End-effector velocity
	 * @param v		velocity
	 * @param vs	spatial velocity
	 * @param trn	forward transformation
	 */
	virtual void velocityFromSpatial(Twist& v, const Twist& vs, const Mat34& trn) const;

	/** End-effector velocity
	 * @param v		velocity
	 * @param vb	body velocity
	 * @param trn	forward transformation
	 */
	virtual void velocityFromBody(Twist& v, const Twist& vb, const Mat34& trn) const;

	/** Spatial manipulator Jacobian
	 * @param jac	spatial manipulator Jacobian
	 * @param j		configuration space coordinates
	 */
	virtual void jacobianSpatial(Jacobian& jac, const ConfigspaceCoord& cc) const;

	/** Body manipulator Jacobian
	 * @param jac	body manipulator Jacobian
	 * @param j		configuration space coordinates
	 */
	virtual void jacobianBody(Jacobian& jac, const ConfigspaceCoord& cc) const;

	/** Manipulator Jacobian
	 * @param jac	manipulator Jacobian
	 * @param j		configuration space coordinates
	 */
	virtual void jacobian(Jacobian& jac, const ConfigspaceCoord& cc) const;

	/** Manipulator Jacobian
	 * @param jac	manipulator Jacobian
	 * @param jacs	spatial manipulator Jacobian
	 * @param trn	forward transformation
	 */
	virtual void jacobianFromSpatial(Jacobian& jac, const Jacobian& jacs, const Mat34& trn) const;

	/** Manipulator Jacobian
	 * @param jac	manipulator Jacobian
	 * @param jacb	body manipulator Jacobian
	 * @param trn	forward transformation
	 */
	virtual void jacobianFromBody(Jacobian& jac, const Jacobian& jacb, const Mat34& trn) const;

	/** Returns Name ASCII string */
	inline const std::string& getName() const {
		return name;
	}	

	/** Access to Joints
	 * @return		reference to Joint container
	 */
	inline const Joint::Seq& getJoints() const {
		return joints;
	}

	/** Returns Arm global pose
	 * @return				Arm global pose
	 */
	virtual Mat34 getGlobalPose() const;

	/** Sets Arm global pose
	 * @param globalPose	Arm global pose
	 */
	virtual void setGlobalPose(const Mat34 &globalPose);
	
	/** Returns Trajectory reference pose
	 * @return				Trajectory reference pose
	 */
	virtual Mat34 getReferencePose() const;

	/** Sets Trajectory reference pose
	 * @param referencePose	Trajectory reference pose
	 */
	virtual void setReferencePose(const Mat34 &referencePose);

	/** Returns Arm rest joint position
	 * @return				arm rest joint position
	*/
	virtual ConfigspaceCoord getRestPosition() const;
	
	/** Sets arm joint rest position
	 * @param restPosition	arm rest joint position
	*/
	virtual void setRestPosition(const ConfigspaceCoord &restPosition);
};

//------------------------------------------------------------------------------

/** Generalised Joint trajectory is a set of velocity profiles */
class GenCoordTrj : public Polynomial4 {
public:
	/** Trajectory description */
	class Desc : public Polynomial4::Desc {
	public:
		/** Sets the trajectory parameters to the default values */
		virtual Profile::Ptr create() const {
			GenCoordTrj *pGenCoordTrj = new GenCoordTrj();
			Profile::Ptr pTrj(pGenCoordTrj);

			if (!pGenCoordTrj->create(*this))
				pTrj.release();

			return pTrj;
		}
	};
	
	/** Default constructor */
	GenCoordTrj();

	GenCoordTrj(Real t0, Real t1, const GenCoord& c0, const GenCoord& c1);
	
	void set(Real t0, Real t1, const GenCoord& c0, const GenCoord& c1);

	GenCoord get(Real t) const;
};

//------------------------------------------------------------------------------

};	// namespace

#endif /*_GOLEM_CTRL_ARM_H_*/
