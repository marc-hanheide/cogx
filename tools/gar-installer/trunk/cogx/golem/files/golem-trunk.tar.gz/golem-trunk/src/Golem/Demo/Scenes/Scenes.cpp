/** @file Scenes.cpp
 * 
 * Demonstration program which creates multiple arms in multiple scenes.
 * 
 * Program can be run in two modes:
 * - the first uses real Katana arm (it's dangerous - no collision detection!)
 * - the second simply runs a specified number of arm simulators
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#include <Golem/Ctrl/Katana.h>
#include <Golem/Ctrl/Simulator.h>
#include <Golem/PhysCtrl/PhysArm.h>
#include <Golem/PhysCtrl/Creator.h>
#include <Golem/Demo/Common/Tools.h>
#include <iostream>
#include <sstream>

using namespace golem;

//------------------------------------------------------------------------------

void setupObjects(Scene &scene) {
	static Rand rand(scene.getContext().getRandSeed());

	// Creator
	Creator creator(scene);
	Actor::Desc *pActorDesc;
	
	// Create ground plane.
	pActorDesc = creator.createGroundPlaneDesc();
	scene.createObject(*pActorDesc);
	
	// add some objects!
	const U32 numOfObject = 10;
	for (U32 i = 0; i < numOfObject; i++) {
		pActorDesc = creator.createTreeDesc(rand.nextUniform(Real(0.07), Real(0.10)));
		pActorDesc->nxActorDesc.globalPose.t.set(
			(NxReal)rand.nextUniform(Real(-0.3), Real(0.3)),
			(NxReal)rand.nextUniform(Real(-0.3), Real(0.3)),
			(NxReal)rand.nextUniform(Real(+0.3), Real(0.9))
		);
		scene.createObject(*pActorDesc);
	}
}

//------------------------------------------------------------------------------

int main(int argc, char *argv[]) {
	if (argc != 2 && argc != 3 || argc == 2 && strcmp(argv[1], "-h") == 0) {
		printf("To run Katana: %s <config_file> <com_port_number>\n", argv[0]);
		printf("To run Simulations: %s <number_of_simulations>\n", argv[0]);
		return 1;
	}
	
	printf("Use the arrow keys to move the camera.\n");
	printf("Use the mouse to rotate the camera.\n");
	printf("Press p to pause simulations.\n");
	printf("Press pgup/pgdn/space to switch between simulations.\n");
	printf("Press v to show Actors reference frames.\n");
	printf("Use z, x, c to change randering mode.\n");
	printf("Use F1-F12 to display program specific debug information.\n");
	printf("\tF1 to display/hide the current destination pose.\n");
	printf("\tF2 to display/hide the current trajectory.\n");
	printf("Press esc to exit.\n");
	
	try {
		// Create program context
		golem::Context::Desc contextDesc;
		golem::Context::Ptr context = contextDesc.create();

		// Do not display LEVEL_DEBUG messages (only with level at least LEVEL_INFO)
		//context->getLogger()->setMsgFilter(MessageFilter::Ptr(new LevelFilter<Message>(Message::LEVEL_INFO)));

		//-----------------------------------------------------------------------------

		// Simulations or real devices
		const bool simulations = argc == 2;
		// Number of simulations
		const U32 numOfSim = simulations ? Math::clamp(::atoi(argv[1]), 1, 5) : 1;
		// Number of arm controllers
		const U32 numOfArms = numOfSim*(numOfSim + 1)/2;
		// Arm controllers
		arr_ptr<PhysArm*> arms(new PhysArm* [numOfArms]);
	
		// Create Universe
		Universe::Desc universeDesc;
		universeDesc.name = "Golem (Scenes)";
		universeDesc.argc = argc;
		universeDesc.argv = argv;
		Universe::Ptr pUniverse = universeDesc.create(*context);

		// Create simulations
		for (U32 i = 0; i < numOfSim; i++) {			
			// Create scene
			Scene::Desc sceneDesc;
			std::stringstream name;
			name << "Scene #" << i + 1;
			sceneDesc.name = name.str();
			Scene *pScene = pUniverse->createScene(sceneDesc);
			
			// Scene objects setup
			setupObjects(*pScene);

			for (U32 j = 0; j <= i ; j++) {
				U32 n = i*(i + 1)/2 + j;

				// Create arm controller description
				PhysArm::Desc physArmDesc;
				if (simulations) {
					if (n%2) {
						GenSimArm::Desc *pDesc = new GenSimArm::Desc();
						physArmDesc.pArmDesc.reset(pDesc);
						pDesc->globalPose.p.set(Real(-1.0 * j), Real(-1.0 * j), Real(0.0));
					}
					else {
						KatSimArm::Desc *pDesc = new KatSimArm::Desc();
						physArmDesc.pArmDesc.reset(pDesc);
						pDesc->globalPose.p.set(Real(-1.0 * j), Real(-1.0 * j), Real(0.0));
					}
				}
				else {
					KatSerialArm::Desc *pDesc = new KatSerialArm::Desc();
					physArmDesc.pArmDesc.reset(pDesc);
					pDesc->cfgPath = argv[1]; // configuration file
					pDesc->serialDesc.commPort = ::atoi(argv[2]); // Communication port (RS232)
				}

				// Create PhysArm controller
				context->getLogger()->post(Message::LEVEL_INFO, "Initialising arm controller #%d...", n + 1);
				arms[n] = dynamic_cast<PhysArm*>(pScene->createObject(physArmDesc));
				
				// Display arm information
				armInfo(arms[n]->getArm());
			}
		}
		//throw std::exception("std::exception()");

		// Launch universe
		context->getLogger()->post(Message::LEVEL_INFO, "Launching Universe...");
		pUniverse->launch();

		// Move joints to a random pose
		while (!pUniverse->interrupted()) {
			for (U32 i = 0; i < numOfArms; i++)
				armRandMove(arms[i]->getArm(), Real(0.5), Real(0.5));
			
			// Wait for some time to give the arm a chance to move
			context->getTimer()->sleep(2.0);

			//for (U32 i = 0; i < numOfArms; i++)
			//	armStop(arms[i]->getArm());
			//context->getTimer()->sleep(1.0);
		}

		context->getLogger()->post(Message::LEVEL_INFO, "Good bye!");
	}
	catch (const Message& msg) {
		std::cerr << msg << std::endl;
	}
	catch (const std::exception &ex) {
		std::cerr << Message(Message::LEVEL_CRIT, "C++ exception: %s", ex.what()) << std::endl;
	}

	return 0;
}
