/** @file Context.cpp
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#include <Golem/Tools/Context.h>
#include <Golem/Tools/Msg.h>

//------------------------------------------------------------------------------

using namespace golem;

//------------------------------------------------------------------------------

Context::Context() {
}

Context::~Context() {
	release();
}

bool Context::create(const Desc &desc) {
	if (!desc.isValid())
		throw MsgContextInvalidDesc(Message::LEVEL_CRIT, "Context::create(): Invalid description");

	timer = desc.timer;
	logger = desc.loggerDesc.create(*timer);
	threadTimeOut = desc.threadTimeOut;

	if (desc.threadParallels > 0) {
		parallels.reset(new Parallels(desc.threadParallels, desc.threadTimeOut));
		if (!parallels->startThreads()) // throws
			return false;
	}

	randSeed = desc.randSeed;
	simulationScale = desc.simulationScale;
	return true;
}

void Context::release() {
	if (parallels != NULL && !parallels->joinThreads(threadTimeOut)) {
	}
}

//------------------------------------------------------------------------------
