/** @file Katana.cpp
 * 
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#include <Golem/Ctrl/Katana.h>
#include <Golem/Ctrl/Msg.h>
#include <math.h>

//------------------------------------------------------------------------------

/** Controller messages */
#define GOLEM_CTRL_KATANA_VERBOSE_

//------------------------------------------------------------------------------

using namespace golem;

//------------------------------------------------------------------------------

// Big-Endian conversions
static inline U16 BigEndian(U16 x) {
	return (x >> 8) | (x << 8);
}

//------------------------------------------------------------------------------

const Real KatJoint::MCU_TM_PERIOD = (Real)1.638e-3;
const SecTmReal KatJoint::TM_QUANT = (SecTmReal)0.01;
const Real KatJoint::VEL_ENC_UNIT = 6.0;

KatJoint::KatJoint(Arm& arm) :
	Joint(arm), pKatana(NULL), pProtocol(NULL)
{
}

/** Creates Katana Joint */
bool KatJoint::create(const Desc& desc) {
	if (!Joint::create(desc))
		return false;

	pKatArm = dynamic_cast<KatArm*>(&arm);
	if (pKatArm == NULL) {
		context.getLogger()->post(new MsgKatanaJointPointerToKatana(), Message::LEVEL_CRIT,
			"KatJoint::create() Unable to obtain pointer to KatArm"
		);
		return false;
	}

	offset = desc.offset;
	gain = desc.gain;
	pKatana = pKatArm->pKatana;
	pProtocol = pKatArm->pProtocol;

	// Initialise parameters: time [sec], position [rad], velocity [rad/sec], accel [rad/sec*sec]
	pMotBase = &pKatana->GetBase()->GetMOT()->arr[getIndex()];
	motInit = *pMotBase->GetInitialParameters();

	// maximal and minimal position of a joint
	max.pos = offset + gain*Real(motInit.angleStop);
	min.pos = offset + gain*Real(motInit.angleOffset);
	if (max.pos < min.pos)
		std::swap(max.pos, min.pos);
	// Katana hack to avoid sub-optimal inverse kinematics solutions:
	if (getIndex() == 2)
		min.pos = (Real)0.0;

	// maximal and minimal velocity
	//max.vel = ;
	//min.vel = ;
	
	// maximal and minimal acceleration
	//max.acc = ;
	//min.acc = ;

	for (U32 i = 0; i < NUM_FILTER_COEFFS; i++)
		coeffs[i] = desc.coeffs[i];
	if (desc.activateFIRFilter)
		(void)setFIRFilter(coeffs);

	limit = desc.limit;
	if (desc.activateSlopeSaturation)
		(void)setSlopeSaturation(limit);

	return true;
}

//------------------------------------------------------------------------------

bool KatJoint::sysSync() {
	ASSERT(pProtocol != NULL)

	try {
		sendBuf[0] = 'I';	// new firmware required!
		sendBuf[1] = (U8)(getIndex() + 1);
		
		U8 size = 0;

		pProtocol->comm(sendBuf, recvBuf, &size);
	} catch (Exception& e) {
		context.getLogger()->post(new MsgKatanaJoint(), Message::LEVEL_ERR,
			"KatJoint::sync() [joint %d]: IO error (%s)", getIndex(), e.what()
		);
		return false;
	}
	
	return recvBuf[2] != IO_SYNC_FLAG;

	//if (recvBuf[2] != IO_SYNC_FLAG) {
	//	context.getLogger()->post("sysSync(1): %f, READY\n", context.getTimer()->elapsed());
	//	return true;
	//}
	//context.getLogger()->post("sysSync(1): %f, WAIT\n", context.getTimer()->elapsed());
	//return false;
}

//------------------------------------------------------------------------------
// IJointBase

bool KatJoint::sysRecv(GenCoord& curr) {
	ASSERT(pMotBase != NULL)

	try {
		pMotBase->recvPVP();
	} catch (Exception& e) {
		context.getLogger()->post(new MsgKatanaJoint(), Message::LEVEL_ERR,
			"KatJoint::recv() [joint %d]: IO error (%s)", getIndex(), e.what()
		);
		return false;
	}

	curr.pos = posEncToSI(pMotBase->GetPVP()->pos);
	curr.vel = velEncToSI(pMotBase->GetPVP()->vel);
	curr.acc = REAL_ZERO;	// not used
	return true;
}

//------------------------------------------------------------------------------

bool KatJoint::setFIRFilter(const U8 *coeffs) {
	for (U32 i = 0; i < NUM_FILTER_COEFFS; i++)
		this->coeffs[i] = coeffs[i];

	try {
		sendBuf[0] = 'S';	// new firmware required!
		sendBuf[1] = (U8)(getIndex() + 1);
		sendBuf[2] = 8;
		sendBuf[3] = coeffs[0];
		sendBuf[4] = coeffs[1];
		sendBuf[5] = coeffs[2];

		U8 size = 0;

		pProtocol->comm(sendBuf, recvBuf, &size);

		sendBuf[0] = 'S';	// new firmware required!
		sendBuf[1] = (U8)(getIndex() + 1);
		sendBuf[2] = 9;
		sendBuf[3] = coeffs[3];
		sendBuf[4] = coeffs[4];
		sendBuf[5] = 0;

		size = 0;

		pProtocol->comm(sendBuf, recvBuf, &size);
	} catch (Exception& e) {
		context.getLogger()->post(new MsgKatanaJoint(), Message::LEVEL_ERR,
			"KatJoint::setFIRFilter() [joint %d]: IO error (%s)", getIndex(), e.what()
		);
		return false;
	}

	return true;
}

const U8 *KatJoint::getFIRFilter() const {
	return coeffs;
}

bool KatJoint::setSlopeSaturation(U8 limit) {
	ASSERT(pProtocol != NULL)

	try {
		sendBuf[0] = 'S';	// new firmware required!
		sendBuf[1] = (U8)(getIndex() + 1);
		sendBuf[2] = 10;
		sendBuf[3] = limit;
		sendBuf[4] = 0;
		sendBuf[5] = 0;

		U8 size = 0;
		
		pProtocol->comm(sendBuf, recvBuf, &size);
	} catch (Exception& e) {
		context.getLogger()->post(new MsgKatanaJoint(), Message::LEVEL_ERR,
			"KatJoint::setSlopeSaturation() [joint %d]: IO error (%s)", getIndex(), e.what()
		);
		return false;
	}

	return true;
}

U8 KatJoint::getSlopeSaturation() const {
	return limit;
}

//------------------------------------------------------------------------------

KatStdJoint::KatStdJoint(Arm& arm) : KatJoint(arm) {
}

bool KatStdJoint::sysSend(const GenCoord& prev, const GenCoord& next, SecTmReal dt) {
	ASSERT(pProtocol != NULL)

	short* buf;

	try {
		sendBuf[0] = 'C';
		sendBuf[1] = (U8)(getIndex() + 1);
		sendBuf[2] = MCF_ON;
		
		buf = (short*)&sendBuf[3*sizeof(U8)];
		// The target point
		buf[0] = BigEndian((short)Math::round(posSIToEnc(next.pos)));

		U8 size = 0;
		
		pProtocol->comm(sendBuf, recvBuf, &size);
	} catch (Exception& e) {
		context.getLogger()->post(new MsgKatanaJoint(), Message::LEVEL_ERR,
			"KatStdJoint::send() [joint %d]: IO error (%s)", getIndex(), e.what()
		);
		return false;
	}

	return true;
}

//------------------------------------------------------------------------------

const Real KatTrjJoint::trj4ScaleFac[4] = {
	(Real)(pow(TM_QUANT, 0) * (1 << 0)),
	(Real)(pow(TM_QUANT, 1) * (1 << 6)),
	(Real)(pow(TM_QUANT, 2) * (1 << 10)),
	(Real)(pow(TM_QUANT, 3) * (1 << 15)),
};

KatTrjJoint::KatTrjJoint(Arm& arm) : KatJoint(arm) {
}

bool KatTrjJoint::sysSend(const GenCoord& prev, const GenCoord& next, SecTmReal dt) {
//golem::SecTmReal t0 = context.getTimer()->elapsed();
	ASSERT(pProtocol != NULL)

	short* buf;
	
	GenCoord x0, x1;
	x0.pos = posSIToEnc(prev.pos); x0.vel = velSIToEnc(prev.vel); x0.acc = accSIToEnc(prev.acc);
	x1.pos = posSIToEnc(next.pos); x1.vel = velSIToEnc(next.vel); x1.acc = accSIToEnc(next.acc);
	
	// set new trajectory (dt > 0)
	GenCoordTrj trj(REAL_ZERO, Real(dt), x0, x1);
	
	sendBuf[0] = 'G';	// new firmware required!
	sendBuf[1] = (U8)(getIndex() + 1);
	
	buf = (short*)&sendBuf[2*sizeof(U8)];
	// The trajectory end-point (the last position of a single movement)
	buf[0] = BigEndian((short)Math::round(x1.pos));
	// Time duration of a single window, rounding
	buf[1] = BigEndian((short)Math::round(SecTmReal(dt)/TM_QUANT));

//short tab[4];
	
	// Rescale coefficients and update send buffer
	buf = (short*)&sendBuf[2*sizeof(U8) + 2*sizeof(short)];
	for (int i = 0; i < 4; i++)
		buf[i] = BigEndian((short)Math::clamp(Math::round(trj4ScaleFac[i] * trj.getCoeffs()[i]), (Real)numeric_const<I16>::MIN, (Real)numeric_const<I16>::MAX));
//buf[i] = BigEndian(tab[i]=(short)Math::clamp(Math::round(trj4ScaleFac[i] * trj.getCoeffs()[i]), (Real)numeric_const<I16>::MIN, (Real)numeric_const<I16>::MAX));

	U8 size = 0;
	try {
		pProtocol->comm(sendBuf, recvBuf, &size);
	} catch (Exception& e) {
		context.getLogger()->post(new MsgKatanaJoint(), Message::LEVEL_ERR,
			"KatTrjJoint::send() [joint %d]: IO error (%s)", getIndex(), e.what()
		);
		return false;
	}

//context.getLogger()->post(Message::LEVEL_UNDEF, "%i, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %i, %i, %i, %i", getIndex(), dt, context.getTimer()->elapsed()-t0, prev.pos, prev.vel, next.pos, next.vel, x0.pos, x0.vel, x1.pos, x1.vel, (int)tab[0], (int)tab[1], (int)tab[2], (int)tab[3]);
//printf("sysSend(1): %f, %i, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %i, %i, %i, %i\n", context.getTimer()->elapsed()-t0, getIndex(), dt, context.getTimer()->elapsed()-t0, prev.pos, prev.vel, next.pos, next.vel, x0.pos, x0.vel, x1.pos, x1.vel, (int)tab[0], (int)tab[1], (int)tab[2], (int)tab[3]);

	return true;
}

//------------------------------------------------------------------------------

// Links lengths
const Real KatArm::L0 = Real(0.2035); // [m]
const Real KatArm::L1 = Real(0.1902); // [m]
const Real KatArm::L2 = Real(0.1391); // [m]
const Real KatArm::L3 = Real(0.1916); // [m]

template <typename _Desc> void setupJoints(Joint::Desc::Seq& joints, const KatArm::Body &body) {
	const Real VelLim = Real(0.25)*REAL_PI; // PI/sec
	const Real AccLim = Real(0.75)*REAL_PI; // PI/sec*sec
	
	// Joint #1
	_Desc *descJ1 = new _Desc;
	joints.push_back(Joint::Desc::Ptr(descJ1));
	
	descJ1->name = "joint #1";	
	descJ1->collision = false;
	descJ1->collisionOffset = KatArm::NUM_JOINTS; // collision joint offset, do not check collisions against other joints

	descJ1->min.pos = (Real)-REAL_PI;	descJ1->min.vel = -VelLim;	descJ1->min.acc = -AccLim;
	descJ1->max.pos = (Real)2.932153;	descJ1->max.vel = +VelLim;	descJ1->max.acc = +AccLim;

	descJ1->trn.twist.set((Real)0.0, (Real)0.0, (Real)0.0, (Real)0.0, (Real)0.0, (Real)1.0); // translation + rotation component
	descJ1->trn.theta = (Real)-3.018751; // init position
	descJ1->trnInit.twist.set((Real)0.0, (Real)0.0, (Real)0.0, (Real)0.0, (Real)0.0, (Real)0.0); // translation + rotation component
	descJ1->trnInit.theta = (Real)0.0; // init position

	if (body.simpleBoundsModel) {
		BoundingBox::Desc* boundsJ1_0 = new BoundingBox::Desc;
		descJ1->bounds.push_back(Bounds::Desc::Ptr(boundsJ1_0));
		boundsJ1_0->dimensions.set(body.l0/(Real)6.0, body.l0/(Real)6.0, body.l0/(Real)2.0); // dimensions
		boundsJ1_0->pose.p.set((Real)0.0, (Real)0.0, body.l0/(Real)2.0 + REAL_EPS); // translation vector
	}
	else {
		BoundingCylinder::Desc* boundsJ1_0 = new BoundingCylinder::Desc;
		descJ1->bounds.push_back(Bounds::Desc::Ptr(boundsJ1_0));
		boundsJ1_0->radius = body.l0/(Real)8.0; // radius
		boundsJ1_0->length = body.l0;
		boundsJ1_0->pose.p.set(Real(0.0), Real(0.0), body.l0/Real(2.0) + REAL_EPS);
	}

	// Joint #2
	_Desc* descJ2 = new _Desc;
	joints.push_back(Joint::Desc::Ptr(descJ2));
	
	descJ2->name = "joint #2";
	descJ2->collisionOffset = KatArm::NUM_JOINTS; // collision joint offset, do not check collisions against other joints

	descJ2->min.pos = (Real)-2.168572;	descJ2->min.vel = -VelLim;	descJ2->min.acc = -AccLim;
	descJ2->max.pos = (Real)0.237365;	descJ2->max.vel = +VelLim;	descJ2->max.acc = +AccLim;

	descJ2->trn.twist.set((Real)0.0, -body.l0, (Real)0.0, (Real)-1.0, (Real)0.0, (Real)0.0); // translation + rotation component
	descJ2->trn.theta = (Real)-2.102416; // init position
	descJ2->trnInit.twist.set((Real)0.0, (Real)0.0, body.l0, (Real)0.0, (Real)0.0, (Real)0.0); // translation + rotation component
	descJ2->trnInit.theta = (Real)1.0; // init position
	
	if (body.simpleBoundsModel) { 
		BoundingSphere::Desc* boundsJ2_0 = new BoundingSphere::Desc;
		descJ2->bounds.push_back(Bounds::Desc::Ptr(boundsJ2_0));
		boundsJ2_0->radius = body.l0/(Real)5.0; // radius
		boundsJ2_0->pose.p.set((Real)0.0, (Real)0.0, (Real)0.0); // position

		BoundingBox::Desc* boundsJ2_1 = new BoundingBox::Desc;
		descJ2->bounds.push_back(Bounds::Desc::Ptr(boundsJ2_1));
		boundsJ2_1->dimensions.set(body.l0/(Real)12.0, body.l1/(Real)2.0, body.l0/(Real)12.0); // dimensions
		boundsJ2_1->pose.p.set((Real)0.0, body.l1/(Real)2.0, (Real)0.0); // translation vector
	}
	else {
		BoundingCylinder::Desc* boundsJ2_0 = new BoundingCylinder::Desc;
		descJ2->bounds.push_back(Bounds::Desc::Ptr(boundsJ2_0));
		boundsJ2_0->radius = body.l0/(Real)12.0; // radius
		boundsJ2_0->length = body.l1;
		boundsJ2_0->pose.p.set(Real(0.0), body.l1/Real(2.0), Real(0.0));
		boundsJ2_0->pose.R.rotX(REAL_PI_2);

		BoundingCylinder::Desc* boundsJ2_1 = new BoundingCylinder::Desc;
		descJ2->bounds.push_back(Bounds::Desc::Ptr(boundsJ2_1));
		boundsJ2_1->radius = body.l0/(Real)7.0; // radius
		boundsJ2_1->length = body.l0/Real(3.0);
		boundsJ2_1->pose.R.rotY(REAL_PI_2);
	}

	// Joint #3
	_Desc* descJ3 = new _Desc;
	joints.push_back(Joint::Desc::Ptr(descJ3));
	
	descJ3->name = "joint #3";
	descJ3->collisionOffset = KatArm::NUM_JOINTS; // collision joint offset, do not check collisions against other joints

	// descJ3->min.pos - Katana hack to avoid sub-optimal inverse kinematics solutions:
	descJ3->min.pos = (Real)0.0/*-2.141519*/;	descJ3->min.vel = -VelLim;	descJ3->min.acc = -AccLim;
	descJ3->max.pos = (Real)2.221804;	descJ3->max.vel = +VelLim;	descJ3->max.acc = +AccLim;
	
	descJ3->trn.twist.set((Real)0.0, -body.l0, body.l1, (Real)-1.0, (Real)0.0, (Real)0.0); // translation + rotation component
	descJ3->trn.theta = (Real)2.144623; // init position
	descJ3->trnInit.twist.set((Real)0.0, body.l1, body.l0, (Real)0.0, (Real)0.0, (Real)0.0); // translation + rotation component
	descJ3->trnInit.theta = (Real)1.0; // init position

	if (body.simpleBoundsModel) { 
		BoundingSphere::Desc* boundsJ3_0 = new BoundingSphere::Desc;
		descJ3->bounds.push_back(Bounds::Desc::Ptr(boundsJ3_0));
		boundsJ3_0->radius = body.l0/(Real)5.0; // radius
		boundsJ3_0->pose.p.set((Real)0.0, (Real)0.0, (Real)0.0); // position

		BoundingBox::Desc* boundsJ3_1 = new BoundingBox::Desc;
		descJ3->bounds.push_back(Bounds::Desc::Ptr(boundsJ3_1));
		boundsJ3_1->dimensions.set(body.l0/(Real)12.0, body.l2/(Real)2.0, body.l0/(Real)12.0); // dimensions
		boundsJ3_1->pose.p.set((Real)0.0, body.l2/(Real)2.0, (Real)0.0); // translation vector
		
		BoundingSphere::Desc* boundsJ3_2 = new BoundingSphere::Desc;
		descJ3->bounds.push_back(Bounds::Desc::Ptr(boundsJ3_2));
		boundsJ3_2->radius = body.l0/(Real)5.0; // radius
		boundsJ3_2->pose.p.set((Real)0.0, body.l2, (Real)0.0); // position
	}
	else {
		BoundingCylinder::Desc* boundsJ3_0 = new BoundingCylinder::Desc;
		descJ3->bounds.push_back(Bounds::Desc::Ptr(boundsJ3_0));
		boundsJ3_0->radius = body.l0/(Real)12.0; // radius
		boundsJ3_0->length = body.l2;
		boundsJ3_0->pose.p.set(Real(0.0), body.l2/Real(2.0), Real(0.0));
		boundsJ3_0->pose.R.rotX(REAL_PI_2);

		BoundingCylinder::Desc* boundsJ3_1 = new BoundingCylinder::Desc;
		descJ3->bounds.push_back(Bounds::Desc::Ptr(boundsJ3_1));
		boundsJ3_1->radius = body.l0/(Real)7.0; // radius
		boundsJ3_1->length = body.l0/Real(3.0);
		boundsJ3_1->pose.R.rotY(REAL_PI_2);	

		BoundingCylinder::Desc* boundsJ3_2 = new BoundingCylinder::Desc;
		descJ3->bounds.push_back(Bounds::Desc::Ptr(boundsJ3_2));
		boundsJ3_2->radius = body.l0/(Real)7.0; // radius
		boundsJ3_2->length = body.l0/Real(3.0);
		boundsJ3_2->pose.p.set(Real(0.0), body.l2, Real(0.0));
		boundsJ3_2->pose.R.rotY(REAL_PI_2);	
	}

	// Joint #4
	_Desc* descJ4 = new _Desc;
	joints.push_back(Joint::Desc::Ptr(descJ4));
	
	descJ4->name = "joint #4";
	descJ4->collisionOffset = KatArm::NUM_JOINTS; // collision joint offset, do not check collisions against other joints
	
	descJ4->min.pos = (Real)-2.033309;	descJ4->min.vel = -VelLim;	descJ4->min.acc = -AccLim;
	descJ4->max.pos = (Real)2.028073;	descJ4->max.vel = +VelLim;	descJ4->max.acc = +AccLim;
	
	descJ4->trn.twist.set((Real)0.0, -body.l0, body.l1 + body.l2, (Real)-1.0, (Real)0.0, (Real)0.0); // translation + rotation component
	descJ4->trn.theta = (Real)-1.910590; // init position
	descJ4->trnInit.twist.set((Real)0.0, body.l1 + body.l2, body.l0, (Real)0.0, (Real)0.0, (Real)0.0); // translation + rotation component
	descJ4->trnInit.theta = (Real)1.0; // init position

	// no physical/visual representation

	// Joint #5
	_Desc* descJ5 = new _Desc;
	joints.push_back(Joint::Desc::Ptr(descJ5));
	
	descJ5->name = "joint #5";
	descJ5->collisionOffset = 3; // collision joint offset, collisions only against joint #1
	
	descJ5->min.pos = (Real)-2.989749;	descJ5->min.vel = -VelLim;	descJ5->min.acc = -AccLim;
	descJ5->max.pos = (Real)2.993240;	descJ5->max.vel = +VelLim;	descJ5->max.acc = +AccLim;
	
	descJ5->trn.twist.set(-body.l0, (Real)0.0, (Real)0.0, (Real)0.0, (Real)1.0, (Real)0.0); // translation + rotation component
	descJ5->trn.theta = (Real)2.870521; // init position
	descJ5->trnInit.twist.set((Real)0.0, body.l1 + body.l2, body.l0, (Real)0.0, (Real)0.0, (Real)0.0); // translation + rotation component
	descJ5->trnInit.theta = (Real)1.0; // init position

	if (body.simpleBoundsModel) { 
		BoundingBox::Desc* boundsJ5_0 = new BoundingBox::Desc;
		descJ5->bounds.push_back(Bounds::Desc::Ptr(boundsJ5_0));
		boundsJ5_0->dimensions.set(body.l3/(Real)12.0, body.l3/(Real)2.0, body.l3/(Real)12.0); // dimensions
		boundsJ5_0->pose.p.set((Real)0.0, body.l3/(Real)2.0, (Real)0.0); // translation vector
	}
	else {
		BoundingCylinder::Desc* boundsJ5_0 = new BoundingCylinder::Desc;
		descJ5->bounds.push_back(Bounds::Desc::Ptr(boundsJ5_0));
		//boundsJ5_0->radius = body.l3/(Real)8.0; // radius
		boundsJ5_0->radius = body.l0/(Real)12.0; // radius
		boundsJ5_0->length = body.l3;
		boundsJ5_0->pose.p.set(Real(0.0), body.l3/Real(2.0), Real(0.0));
		boundsJ5_0->pose.R.rotX(REAL_PI_2);
	}
}

//------------------------------------------------------------------------------

void KatArm::setupJoints(Joint::Desc::Seq& joints, const KatArm::Body &body) {
	::setupJoints<KatTrjJoint::Desc>(joints, body);

	((KatTrjJoint::Desc&)*joints[0]).offset = (Real)-REAL_PI;
	((KatTrjJoint::Desc&)*joints[0]).gain = (Real)1.0;

	((KatTrjJoint::Desc&)*joints[1]).offset = (Real)0.0;
	((KatTrjJoint::Desc&)*joints[1]).gain = (Real)-1.0;

	((KatTrjJoint::Desc&)*joints[2]).offset = REAL_PI;
	((KatTrjJoint::Desc&)*joints[2]).gain = (Real)-1.0;

	((KatTrjJoint::Desc&)*joints[3]).offset = -REAL_PI;
	((KatTrjJoint::Desc&)*joints[3]).gain = (Real)1.0;

	((KatTrjJoint::Desc&)*joints[4]).offset = (Real)REAL_PI;
	((KatTrjJoint::Desc&)*joints[4]).gain = (Real)-1.0;
}

//------------------------------------------------------------------------------

// Katana froward kinematics
void KatArm::forwardTransform(Mat34& trn, const ConfigspaceCoord& cc, const KatArm::Body &body) {
	Real s1, c1, s2, c2, s3, c3, s4, c4, s5, c5, s23, c23, a1, a2, a3;

	Math::sinCos(cc[0], s1, c1);
	Math::sinCos(cc[1], s2, c2);
	Math::sinCos(cc[2], s3, c3);
	Math::sinCos(cc[3], s4, c4);
	Math::sinCos(cc[4], s5, c5);

	s23 = Math::sin(cc[1] + cc[2]); c23 = Math::cos(cc[1] + cc[2]);

	trn.p.v1 = -s1*(c2*body.l1 + c23*body.l2);
	trn.p.v2 = c1*(c2*body.l1 + c23*body.l2);
	trn.p.v3 = body.l0 - s2*body.l1 - s23*body.l2;

	a1 = s1*s23; a2 = s1*c23; a3 = a1*c4 + s4*a2;
	trn.R.m11 =  c5*c1 + s5*a3;
	trn.R.m12 = -c4*a2 + s4*a1;
	trn.R.m13 = -c5*a3 + s5*c1;

	a1 = c1*s23; a2 = c1*c23; a3 = a1*c4 + s4*a2;
	trn.R.m21 =  c5*s1 - s5*a3;
	trn.R.m22 =  c4*a2 - s4*a1;
	trn.R.m23 =  c5*a3 + s5*s1;

	a1 = c23*c4 - s23*s4;
	trn.R.m31 = -s5*a1;
	trn.R.m32 = -s4*c23 - s23*c4;
	trn.R.m33 =  c5*a1;
}

// TODO Katana inverse kinematics
void KatArm::inverseTransform(ConfigspaceCoord::Seq& j, const Mat34& trn, const KatArm::Body &body) {
	j.clear();
}

void KatArm::velocitySpatial(Twist& v, const ConfigspaceCoord& cc, const ConfigspaceCoord& dcc, const KatArm::Body &body) {
	Real s1, c1, s2, c2, s3, c3, s4, c4, s5, c5;

	Math::sinCos(cc[0], s1, c1);
	Math::sinCos(cc[1], s2, c2);
	Math::sinCos(cc[2], s3, c3);
	Math::sinCos(cc[3], s4, c4);
	Math::sinCos(cc[4], s5, c5);

	Real s23 = Math::sin(cc[1] + cc[2]);
	Real c23 = Math::cos(cc[1] + cc[2]);
	
	Vec3 q(
		-s1*(body.l1*c2 + body.l2*c23),
		c1*(body.l1*c2 + body.l2*c23),
		body.l0 - (body.l1*s2 + body.l2*s23)
	);

	Twist tmp;

	// twist #1
	v.getV().set(
		REAL_ZERO, REAL_ZERO, REAL_ZERO
	);
	v.getW().set(
		REAL_ZERO, REAL_ZERO, dcc[0]
	);

	// twist #2
	tmp.getV().set(
		body.l0*s1, -body.l0*c1, REAL_ZERO
	);
	tmp.getW().set(
		-c1, -s1, REAL_ZERO
	);
	v.multiplyAdd(dcc[1], tmp, v);

	// twist #3
	tmp.getV().set(
		s1*(body.l0 - body.l1*s2), c1*(body.l1*s2 - body.l0), body.l1*c2
	);
	tmp.getW().set(
		-c1, -s1, REAL_ZERO
	);
	v.multiplyAdd(dcc[2], tmp, v);

	// twist #4
	tmp.getW().set(
		-c1, -s1, REAL_ZERO
	);
	tmp.getV().cross(q, tmp.getW());
	v.multiplyAdd(dcc[3], tmp, v);

	// twist #5
	tmp.getW().set(
		-s1*(c4*c23 - s4*s23), c1*(c4*c23 - s4*s23), -(c4*s23 + s4*c23)
	);
	tmp.getV().cross(q, tmp.getW());
	v.multiplyAdd(dcc[4], tmp, v);

	// transform to SE(3)
	//trn.twistToSpecial(velocity);
}

void KatArm::jacobianSpatial(Jacobian& jac, const ConfigspaceCoord& cc, const KatArm::Body &body) {
	Real s1, c1, s2, c2, s3, c3, s4, c4, s5, c5;

	Math::sinCos(cc[0], s1, c1);
	Math::sinCos(cc[1], s2, c2);
	Math::sinCos(cc[2], s3, c3);
	Math::sinCos(cc[3], s4, c4);
	Math::sinCos(cc[4], s5, c5);

	Real s23 = Math::sin(cc[1] + cc[2]);
	Real c23 = Math::cos(cc[1] + cc[2]);
	
	Vec3 q(
		-s1*(body.l1*c2 + body.l2*c23),
		c1*(body.l1*c2 + body.l2*c23),
		body.l0 - (body.l1*s2 + body.l2*s23)
	);

	// twist #1
	jac[0].getV().set(
		REAL_ZERO, REAL_ZERO, REAL_ZERO
	);
	jac[0].getW().set(
		REAL_ZERO, REAL_ZERO, REAL_ONE
	);

	// twist #2
	jac[1].getV().set(
		body.l0*s1, -body.l0*c1, REAL_ZERO
	);
	jac[1].getW().set(
		-c1, -s1, REAL_ZERO
	);

	// twist #3
	jac[2].getV().set(
		s1*(body.l0 - body.l1*s2), c1*(body.l1*s2 - body.l0), body.l1*c2
	);
	jac[2].getW().set(
		-c1, -s1, REAL_ZERO
	);

	// twist #4
	jac[3].getW().set(
		-c1, -s1, REAL_ZERO
	);
	jac[3].getV().cross(q, jac[3].getW());

	// twist #5
	jac[4].getW().set(
		-s1*(c4*c23 - s4*s23), c1*(c4*c23 - s4*s23), -(c4*s23 + s4*c23)
	);
	jac[4].getV().cross(q, jac[4].getW());
}

//------------------------------------------------------------------------------

KatArm::KatArm(golem::Context& context) : Arm(context) {
	pKatana = NULL;
	pProtocol = NULL;
	bCalibrationInit = false;
	gripperIsPresent = false;
}

bool KatArm::create(CKatana* pKatana, CCplBase* pProtocol, const Desc& desc) {
	if (!desc.isValid()) {
		context.getLogger()->post(new MsgKatanaInvalidDesc(), Message::LEVEL_CRIT,
			"KatArm::create(): Invalid description"
		);
		return false;
	}
	
	if (pKatana == NULL || pProtocol == NULL) {
		context.getLogger()->post(new MsgKatanaNullKNIPointers(), Message::LEVEL_CRIT,
			"KatArm::create(): Null pointers to CKatana and CCplBase"
		);
		return false;
	}
	
	this->pKatana = pKatana;
	this->pProtocol = pProtocol;
	
	bMeasurements = desc.bMeasurements;
	bGripper = desc.bGripper;
	sensorIndexSet = desc.sensorIndexSet;
	body = desc.body;
	syncJointIndex = desc.syncJointIndex;

	if (bGripper) {
		pKatana->getGripperParameters(gripperIsPresent, gripperEncoderData.open, gripperEncoderData.closed);
		
		if (gripperIsPresent) {
			gripperDur = SEC_TM_REAL_ZERO;
			evGripper.set(false);
			bGripperRecvResult = false;

			evGripperRecv.set(false);
			gripperStatus = OPEN;
			bGripperResult = false;
		}
	}

	katDeltaOffs = desc.katDeltaOffs;

	return Arm::create(desc);
}

//------------------------------------------------------------------------------
// Controller

bool KatArm::sysRecv(GenConfigspaceCoord& curr) {
	if (bMeasurements)
		return Arm::sysRecv(curr);

	if (isCalibrating()) {
		if (!bCalibrationInit && !Arm::sysRecv(current))
			return false;
		
		bCalibrationInit = true;
		curr = current;
		return true;
	}
	
	bCalibrationInit = false;
	
	GenConfigspaceState prev, next;
	GenCoordTrj trj;
	SecTmReal t = context.getTimer()->elapsed();
	if (!ArmController::lookupInp(&prev, &next, t))
		return false;
		
	t = Math::clamp(t, prev.t, next.t);
	
	for (U32 i = 0; i < joints.size(); i++) {
		trj.set(REAL_ZERO, Real(next.t - prev.t), prev.get(i), next.get(i));
		curr.set(i, trj.get(Real(t - prev.t)));
	}
	
	return true;
}

bool KatArm::sysSend(const GenConfigspaceCoord& prev, const GenConfigspaceCoord& next, SecTmReal dt) {
	ASSERT(pProtocol != NULL)

	bool bRet = true;
	
	for (U32 i = 0; i < joints.size(); i++) {
#ifdef GOLEM_CTRL_KATANA_VERBOSE_
		const SecTmReal t0 = context.getTimer()->elapsed();
#endif
		KatJoint* pKatJoint = dynamic_cast<KatJoint*>(joints[i]);
		ASSERT(pKatJoint)
		if (!pKatJoint->sysSend(prev.get(i), next.get(i), dt))
			bRet = false;

#ifdef GOLEM_CTRL_KATANA_VERBOSE_
		const SecTmReal t1 = context.getTimer()->elapsed();
		if (isCalibrating()) {
			msrDeltaJointSend.update(t1 - t0);
		}
		if (isCalibrated()) {
			if ((t1 - t0) > msrDeltaJointSend.getAvr() + katDeltaOffs) {
				context.getLogger()->post(new MsgKatana(), Message::LEVEL_WARNING,
					"KatArm::sysSend(): [joint %d]: timeout = %f", i, (t1 - t0)
				);
			}
		}
#endif
	}

#ifdef GOLEM_CTRL_KATANA_VERBOSE_
	const SecTmReal t2 = context.getTimer()->elapsed();
#endif
	
	sendBuf[0] = (U8)128 + 'G';	// new firmware required!
	sendBuf[1] = 1;
	sendBuf[2] = 0; // = 1 for exact movement
	
	U8 size = 0;
	try {
		pProtocol->comm(sendBuf, recvBuf, &size);
	} catch (Exception& e) {
		context.getLogger()->post(new MsgKatana(), Message::LEVEL_ERR,
			"KatArm::send(): IO error (%s)", e.what()
		);
		bRet = false;
	}

#ifdef GOLEM_CTRL_KATANA_VERBOSE_
	const SecTmReal t3 = context.getTimer()->elapsed();
	if (isCalibrating()) {
		msrDeltaSendSync.update(t3 - t2);
	}
	if (isCalibrated()) {
		if ((t3 - t2) > msrDeltaSendSync.getAvr() + katDeltaOffs) {
			context.getLogger()->post(new MsgKatana(), Message::LEVEL_WARNING,
				"KatArm::sysSend(): sync timeout = %f", (t3 - t2)
			);
		}
	}
#endif
	
	return bRet;
}

bool KatArm::sysSync() {
	// assuming that all trajectories are of the same duration, its sufficient
	// to wait for a 'sync flag' from a single motor
	bool bRet = true;
	for (std::set<U32>::const_iterator i = syncJointIndex.begin(); i != syncJointIndex.end(); i++) {
		KatJoint* pKatJoint = dynamic_cast<KatJoint*>(joints[*i]);
		ASSERT(pKatJoint)
		bRet = bRet && pKatJoint->sysSync(); // detects false positive only
	}
	return bRet;
}

//------------------------------------------------------------------------------

void KatArm::userCalibrate() {
	if (/*bGripper && */gripperIsPresent)
		gripperCalibrate();

	msrDeltaSendSync.reset();
	msrDeltaJointSend.reset();
}

void KatArm::userComm() {
	if (/*bGripper && */gripperIsPresent)
		gripperComm();
}

//------------------------------------------------------------------------------

void KatArm::gripperCalibrate() {
}

void KatArm::gripperComm() {
	SecTmReal t0, t1;

	t0 = context.getTimer()->elapsed();
	
	{
		CriticalSectionWrapper csw(csGripper);

		try {
			CMotBase &base = pKatana->GetBase()->GetMOT()->arr[pKatana->getNumberOfMotors() - 1];

			if (gripperStatus & (OPEN | CLOSE | FREEZE) && !(gripperStatus & READ)) {
				if (gripperStatus & FREEZE) {
					base.recvPVP();
					gripperEncoderData.current = base.GetPVP()->pos;
				}

				TMotTPS tps;
				tps.mcfTPS = gripperStatus & FREEZE ? MCF_FREEZE : MCF_ON;
				tps.tarpos = gripperStatus & OPEN ? gripperEncoderData.open :
					gripperStatus & CLOSE ? gripperEncoderData.closed : gripperEncoderData.current;

				base.sendTPS(&tps);

				if (gripperStatus & FREEZE) {
					gripperStatus &= ~(OPEN | CLOSE | FREEZE);
					bGripperResult = true;
					evGripper.set(true);
				}
				else
					gripperStatus |= READ;
			} else if (gripperStatus & (RECV | READ)) {
				if (gripperStatus & OPEN) {
					base.recvPVP();
					gripperEncoderData.current = base.GetPVP()->pos;

					if (Math::abs(I32(gripperEncoderData.open - gripperEncoderData.current)) < GRIP_ENC_TOLERANCE) {
						gripperStatus &= ~(OPEN | READ);
						bGripperResult = true;
						evGripper.set(true);
					}
				}
				else {
					CSctBase &sctBase = pKatana->GetBase()->GetSCT()->arr[0];
					const TSctDAT* pSctDAT	= sctBase.GetDAT();

					sctBase.recvDAT();

					size_t items = 0;
					for (SensorIndexSet::const_iterator i = sensorIndexSet.begin(); i != sensorIndexSet.end(); i++)
						if (*i < pSctDAT->cnt) {
							if (sensorData.size() < ++items)
								sensorData.resize(items);
							sensorData[items - 1] = SensorData(*i, pSctDAT->arr[*i]);
						}

					sensorData.resize(items);
					
					gripperStatus &= ~RECV;
					bGripperRecvResult = true;
					evGripperRecv.set(true);

					if (gripperStatus & CLOSE) {
						// TODO more advanced check
						for (SensorDataSet::const_iterator i = sensorThreshold.begin(); i != sensorThreshold.end(); i++)
							if (i->index < pSctDAT->cnt && pSctDAT->arr[i->index] > i->value) {
								gripperStatus &= ~(CLOSE | READ);
								gripperStatus |= FREEZE;
								break;
							}
					}
				}
			}
		} catch (Exception& e) {
			//gripperStatus = NOOP;
			//evGripper.set(true);
			context.getLogger()->post(new MsgKatana(), Message::LEVEL_ERR,
				"KatArm::gripperComm(): IO error (%s)", e.what()
			);
		}
	}

	t1 = context.getTimer()->elapsed();
	
	if (isCalibrating()) {
		gripperDur = std::max(gripperDur, t1 - t0);
		context.getTimer()->sleep(std::max(gripperDur - (t1 - t0), SEC_TM_REAL_ZERO));
	}
}

//------------------------------------------------------------------------------

bool KatArm::gripperRecvSensorData(SensorDataSet& sensorData, MSecTmU32 timeWait) {
	if (!gripperIsPresent || isCalibrating())
		return false;

	{
		CriticalSectionWrapper csw(csGripper);
		evGripperRecv.set(false);
		gripperStatus |= RECV;
		bGripperRecvResult = false;
	}
	
	if (timeWait <= 0 || evGripperRecv.wait(timeWait) && bGripperRecvResult)
	{
		CriticalSectionWrapper csw(csGripper);
		sensorData = this->sensorData;
		return true;
	}

	return false;
}

bool KatArm::gripperRecvEncoderData(GripperEncoderData& encoderData, MSecTmU32 timeWait) {
	if (!gripperIsPresent || isCalibrating())
		return false;

	{
		CriticalSectionWrapper csw(csGripper);
		encoderData = gripperEncoderData;
	}
	
	return true;
}

bool KatArm::gripperOpen(MSecTmU32 timeWait) {
	if (!gripperIsPresent || isCalibrating())
		return false;

	{
		CriticalSectionWrapper csw(csGripper);
		evGripper.set(false);
		gripperStatus &= ~(OPEN | CLOSE | FREEZE | READ);
		gripperStatus |= OPEN;
		bGripperResult = false;
	}

	return timeWait <= 0 || evGripper.wait(timeWait) && bGripperResult;
}

bool KatArm::gripperClose(const SensorDataSet& sensorThreshold, MSecTmU32 timeWait) {
	if (!gripperIsPresent || isCalibrating())
		return false;

	{
		CriticalSectionWrapper csw(csGripper);
		evGripper.set(false);
		gripperStatus &= ~(OPEN | CLOSE | FREEZE | READ);
		gripperStatus |= CLOSE;
		bGripperResult = false;
		this->sensorThreshold = sensorThreshold;
	}

	return timeWait <= 0 || evGripper.wait(timeWait) && bGripperResult;
}

bool KatArm::gripperFreeze(MSecTmU32 timeWait) {
	if (!gripperIsPresent || isCalibrating())
		return false;

	{
		CriticalSectionWrapper csw(csGripper);
		evGripper.set(false);
		gripperStatus &= ~(OPEN | CLOSE | FREEZE | READ);
		gripperStatus |= FREEZE;
		bGripperResult = false;
	}

	return timeWait <= 0 || evGripper.wait(timeWait) && bGripperResult;
}

//------------------------------------------------------------------------------
// Arm
// Inverse and forward transforms

void KatArm::forwardTransform(Mat34& trn, const ConfigspaceCoord& cc) const {
	KatArm::forwardTransform(trn, cc, body);	
	trn.multiply(getGlobalPose(), trn);
}

void KatArm::inverseTransform(ConfigspaceCoord::Seq& ccSeq, const Mat34& trn) const {
	KatArm::inverseTransform(ccSeq, trn, body);
}

void KatArm::velocitySpatial(Twist& v, const ConfigspaceCoord& cc, const ConfigspaceCoord& dcc) const {
	KatArm::velocitySpatial(v, cc, dcc, body);
}

void KatArm::jacobianSpatial(Jacobian& jac, const ConfigspaceCoord& cc) const {
	KatArm::jacobianSpatial(jac, cc, body);
}

//------------------------------------------------------------------------------

KatSerialArm::KatSerialArm(golem::Context& context) :
	KatArm(context)
{
}

bool KatSerialArm::create(const Desc& desc) {
	cfgPath = desc.cfgPath;
	serialDesc = desc.serialDesc;

	TCdlCOMDesc ccd = {
		(int)serialDesc.commPort,
		(int)serialDesc.baudRate,
		(int)serialDesc.dataBit,
		(int)serialDesc.parityBit,
		(int)serialDesc.stopBit,
		(int)serialDesc.readTimeout,
		(int)serialDesc.writeTimeout
	};
	
	try {
		device.reset(new CCdlCOM(ccd));
	} catch (Exception& ex) {
		context.getLogger()->post(new MsgKatanaCommPort(), Message::LEVEL_CRIT,
			"KatSerialArm::create(): Unable to open communication port: %s", ex.what()
		);
		return false;
	}

	try {
		protocol.reset(new CCplSerialCRC());
		protocol->init(device.get());
	} catch (Exception& ex) {
		context.getLogger()->post(new MsgKatanaProtocolInit(), Message::LEVEL_CRIT,
			"KatSerialArm::create(): Unable to initialise protocol: %s", ex.what()
		);
		return false;
	}
	
	try {
		katana.reset(new CKatana());
		katana->create(cfgPath.c_str(), protocol.get());
	} catch (Exception& ex) {
		context.getLogger()->post(new MsgKatanaCKatanaCreate(), Message::LEVEL_CRIT,
			"KatSerialArm::create(): Unable to create CKatana: %s", ex.what()
		);
		return false;
	}

	try {
		katana->calibrate();
	} catch (Exception& ex) {
		context.getLogger()->post(new MsgKatanaKNICalibration(), Message::LEVEL_CRIT,
			"KatSerialArm::create(): KNI calibration failure: %s", ex.what()
		);
		return false;
	}
	//throw std::exception("KNI calibration finished, stopping..."); // TEST

	return KatArm::create(katana.get(), protocol.get(), desc);
}

//------------------------------------------------------------------------------

///** Default Katana joint description */
//const Joint::Desc* KatSimArm::jointDescDflt = KatArm::jointDescDflt;

//------------------------------------------------------------------------------

KatSimArm::KatSimArm(golem::Context& context) :
	SimArm(context)
{}

bool KatSimArm::create(const Desc& desc) {
	body = desc.body;

	return SimArm::create(desc);
}

//------------------------------------------------------------------------------

void KatSimArm::setupJoints(Joint::Desc::Seq& joints, const KatArm::Body &body) {
	::setupJoints<SimJoint::Desc>(joints, body);
}

//------------------------------------------------------------------------------
// Inverse and forward transforms, implementation from Katana Controller

void KatSimArm::forwardTransform(Mat34& trn, const ConfigspaceCoord& cc) const {
	KatArm::forwardTransform(trn, cc, body);
	trn.multiply(getGlobalPose(), trn);
}

void KatSimArm::inverseTransform(ConfigspaceCoord::Seq& ccSeq, const Mat34& trn) const {
	KatArm::inverseTransform(ccSeq, trn, body);
}

void KatSimArm::velocitySpatial(Twist& v, const ConfigspaceCoord& cc, const ConfigspaceCoord& dcc) const {
	KatArm::velocitySpatial(v, cc, dcc, body);
}

void KatSimArm::jacobianSpatial(Jacobian& jac, const ConfigspaceCoord& cc) const {
	KatArm::jacobianSpatial(jac, cc, body);
}

//------------------------------------------------------------------------------
