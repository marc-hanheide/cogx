/** @file Planner.cpp
 * 
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#include <Golem/Ctrl/Planner.h>
#include <Golem/Ctrl/Msg.h>

//------------------------------------------------------------------------------

using namespace golem;

//------------------------------------------------------------------------------

Planner::Planner(golem::Arm &arm) :
	arm(arm), context(arm.getContext()),
	rand(context.getRandSeed())
{
}

bool Planner::create(const Desc& desc) {
	if (!desc.isValid()) {
		context.getLogger()->post(new MsgPlannerInvalidDesc(), Message::LEVEL_CRIT,
			"Planner::create(): Invalid description"
		);
		return false;
	}

	velocity = desc.velocity;
	acceleration = desc.acceleration;

	pProfile = desc.pProfileDesc->create();
	if (pProfile == NULL) {
		context.getLogger()->post(new MsgPlannerProfileCreate(), Message::LEVEL_CRIT,
			"Planner::create(): Unable to create Profile object"
		);
		return false;
	}

	pHeuristic = desc.pHeuristicDesc->create(arm);
	if (pHeuristic == NULL)
		return false;

	pCallback = NULL;

	return true;
}

//------------------------------------------------------------------------------

bool Planner::send(Trajectory::iterator begin, Trajectory::iterator end, MSecTmU32 timeWait) {
	SysTimer timer;

	SecTmReal tDelta = std::max(SEC_TM_REAL_ZERO,
		context.getTimer()->elapsed() + arm.getTimeDeltaAsync() - begin->t);
	
	for (Trajectory::iterator i = begin; i != end; i++) {
		MSecTmU32 elapsed = timeWait > MSEC_TM_U32_ZERO ? timer.elapsed() : MSEC_TM_U32_ZERO;
		i->t += tDelta;
		if (!arm.send(*i, timeWait < elapsed ? MSEC_TM_U32_ZERO : timeWait - elapsed)) {
			context.getLogger()->post(new MsgPlanner(), Message::LEVEL_ERR,
				"Planner::send(): unable to send trajectory"
			);
			return false;
		}
	}

	// TODO it should be an atomic call
	if (pCallback != NULL)
		pCallback->syncSendData(begin, end);

	return true;
}

//------------------------------------------------------------------------------

