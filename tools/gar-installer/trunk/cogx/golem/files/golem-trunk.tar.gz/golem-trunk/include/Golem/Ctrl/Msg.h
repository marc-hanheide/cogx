/** @file Msg.h
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#pragma once
#ifndef _GOLEM_CTRL_MSG_H_
#define _GOLEM_CTRL_MSG_H_

//------------------------------------------------------------------------------

#include <Golem/Tools/Message.h>

//------------------------------------------------------------------------------

namespace golem {

//------------------------------------------------------------------------------

class MsgController : public Message {};
/** LEVEL_CRIT */
class MsgControllerInvalidDesc : public MsgController {};
class MsgControllerThreadLaunch : public MsgController {};
class MsgControllerCalibration : public MsgController {};

class MsgArm : public MsgController {};
/** LEVEL_CRIT */
class MsgArmInvalidDesc : public MsgArm {};

class MsgJoint : public MsgArm {};
/** LEVEL_CRIT */
class MsgJointInvalidDesc : public MsgJoint {};

class MsgSim : public MsgArm {};
/** LEVEL_CRIT */
class MsgSimInvalidDesc : public MsgSim {};

class MsgSimJoint : public MsgSim {};

class MsgKatana : public MsgArm {};
/** LEVEL_CRIT */
class MsgKatanaInvalidDesc : public MsgKatana {};
class MsgKatanaNullKNIPointers : public MsgKatana {};
class MsgKatanaCommPort : public MsgKatana {};
class MsgKatanaProtocolInit : public MsgKatana {};
class MsgKatanaCKatanaCreate : public MsgKatana {};
class MsgKatanaKNICalibration : public MsgKatana {};

class MsgKatanaJoint : public MsgKatana {};
/** LEVEL_CRIT */
class MsgKatanaJointPointerToKatana : public MsgKatanaJoint {};


class MsgHeuristic : public MsgArm {};
/** LEVEL_CRIT */
class MsgHeuristicInvalidDesc : public MsgHeuristic {};

class MsgKinematics : public MsgHeuristic {};
/** LEVEL_CRIT */
class MsgKinematicsInvalidDesc : public MsgKinematics {};

class MsgTransmitter : public MsgArm {};
/** LEVEL_CRIT */
class MsgTransmitterInvalidDesc : public MsgTransmitter {};


class MsgPlanner : public MsgArm {};
/** LEVEL_CRIT */
class MsgPlannerInvalidDesc : public MsgPlanner {};
class MsgPlannerProfileCreate : public MsgPlanner {};

class MsgPathFinder : public MsgPlanner {};
/** LEVEL_CRIT */
class MsgPathFinderInvalidDesc : public MsgPathFinder {};

class MsgGraphPlanner : public MsgPlanner {};

class MsgReacPlanner : public MsgPlanner {};
/** LEVEL_CRIT */
class MsgReacPlannerInvalidDesc : public MsgReacPlanner {};
class MsgReacPlannerThreadLaunch : public MsgReacPlanner {};

//------------------------------------------------------------------------------

};	// namespace

#endif /*_GOLEM_CTRL_MSG_H_*/
