/** @file Message.cpp
 * 
 * Messages for multithread systems.
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#include <Golem/Sys/Thread.h>
#include <Golem/Tools/Message.h>
#include <stdio.h>

//------------------------------------------------------------------------------

using namespace golem;

//------------------------------------------------------------------------------

namespace golem {
	std::ostream& operator << (std::ostream& ostr, const Message& message) {
		return message.write(ostr);
	}
};

//------------------------------------------------------------------------------

I32 Message::counter = -1;

const char *const Message::strLevel[] = {
	"UNDEF",
	"DEBUG",
	"INFO",
	"NOTICE",
	"WARNING",
	"ERROR",
	"CRIT",
	"ALERT",
	"EMERG",
};

//------------------------------------------------------------------------------

Message::Message() {
}

Message::Message(const Message& message) {
	*this = message;
}

Message::Message(const char* format, ...) {
	va_list argptr;
	va_start(argptr, format);
	setup(SEC_TM_REAL_INF, Message::LEVEL_UNDEF, format, argptr);
	va_end(argptr);
}

Message::Message(Level level, const char* format, ...) {
	va_list argptr;
	va_start(argptr, format);
	setup(SEC_TM_REAL_INF, level, format, argptr);
	va_end(argptr);
}

Message::~Message() throw() {
}

//------------------------------------------------------------------------------

void Message::setup(SecTmReal stamp, Level level) {
	mid = (I32)InterlockedIncrement((volatile LONG*)&Message::counter);
	mstamp = stamp;
	mthread = Thread::getCurrentThreadId();
	mlevel = level;
}

void Message::setup(SecTmReal stamp, Level level, const char* format, va_list argptr) {
	Message::setup(stamp, level);
	
	char buf[MESSAGE_BUF_LEN];

#ifdef WIN32
	//vsnprintf_s(buf, MESSAGE_BUF_LEN - 1, MESSAGE_BUF_LEN - 1, format, argptr);

	#if defined(_MSC_VER) && _MSC_VER >= 1400
	#pragma warning(push)
	#pragma warning(disable:4996)
	#endif
	vsnprintf(buf, MESSAGE_BUF_LEN - 1, format, argptr);
	#if defined(_MSC_VER) && _MSC_VER >= 1400
	#pragma warning(pop)
	#endif

#elif LINUX
	vsnprintf(buf, MESSAGE_BUF_LEN - 1, format, argptr);
#endif
	
	mstr = buf;
}

std::ostream& Message::write(std::ostream& ostr) const {
	ostr << "[id " << mid;
	
	if (mstamp != SEC_TM_REAL_INF)
		ostr << ", time " << mstamp;

	ostr << ", thread " << (U32)mthread;
	
	if (mlevel != Message::LEVEL_UNDEF)
		ostr << ", level " << strLevel[mlevel];
	
	return ostr << "] " << mstr;
}

//------------------------------------------------------------------------------

Message& Message::operator = (const Message& message) {
	mid = message.mid;
	mstamp = message.mstamp;
	mthread = message.mthread;
	mlevel = message.mlevel;
	mstr = message.mstr;
	return *this;
}	

//------------------------------------------------------------------------------
