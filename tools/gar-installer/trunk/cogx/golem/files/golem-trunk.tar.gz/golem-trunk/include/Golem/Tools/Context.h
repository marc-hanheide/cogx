/** @file Context.h
 * 
 * Context class is a collection of application helper objects.
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#pragma once
#ifndef _GOLEM_TOOLS_CONTEXT_H_
#define _GOLEM_TOOLS_CONTEXT_H_

//------------------------------------------------------------------------------

#include <Golem/Math/Rand.h>
#include <Golem/Tools/Parallels.h>
#include <Golem/Tools/Logger.h>

//------------------------------------------------------------------------------

namespace golem {

//------------------------------------------------------------------------------

/** Context object is a collection of shared object */
class Context {
public:
	typedef obj_ptr<Context> Ptr;
#ifdef WIN32	// FIX
	friend class Ptr;
#endif
	friend class Desc;

	/** Context description */
	class Desc {
		friend class Context;
	
	public:
		/** Timer */
		obj_ptr<PerfTimer> timer;
		
		/** Logger description */
		Logger::Desc loggerDesc;
		
		/** Parallels thread joint time out */
		MSecTmU32 threadTimeOut;
		/** Number of threads in Parallels */
		U32 threadParallels;

		/** Random generator seed */
		RandSeed randSeed;
		
		/** Simulation scale */
		Real simulationScale;

		/** Constructs Logger description. */
		Desc() {
			setToDefault();
		}
		
		/** Destructor should be virtual */
		virtual ~Desc() {}
		
		/** Creates Context from the description. */
		virtual Context::Ptr create() const {
			Context::Ptr pContext(new Context());

			if (!pContext->create(*this))
				pContext.release();

			return pContext;
		}
		
		/** Sets the parameters to the default values. */
		virtual void setToDefault() {
			timer.reset(new PerfTimer);

			loggerDesc.setToDefault();
			
			threadTimeOut = 5000;
			threadParallels = 0; // inactive by default

			simulationScale = Real(10.0);
		}

		/** Checks if the description is valid. */
		virtual bool isValid() const {
			if (timer == NULL)
				return false;
			if (!loggerDesc.isValid())
				return false;
			if (threadTimeOut <= 0)
				return false;
			if (simulationScale <= REAL_ZERO)
				return false;

			return true;
		}
	};
	
protected:
	/** Precision/performance timer */
	obj_ptr<PerfTimer> timer;
	
	/** Message logger */
	obj_ptr<Logger> logger;

	/** Default thread joint time out */
	MSecTmU32 threadTimeOut;
	/** Parallels */
	obj_ptr<Parallels> parallels;

	/** Random generator seed */
	RandSeed randSeed;
	
	/** Simulation scale */
	Real simulationScale;
	
	/** Creates context from description */
	bool create(const Desc &desc);

	/** Releases resources */
	void release();

	/** Default constructror sets data to the default values */
	Context();

#ifndef WIN32	// FIX
public:
#endif
	/** Destructor is inaccesible */
	virtual ~Context();
	
public:
	/** Returns pointer to timer */
	inline const PerfTimer* getTimer() const {
		return timer.get();
	}

	/** Returns pointer to logger */
	inline const Logger* getLogger() const {
		return logger.get();
	}
	inline Logger* getLogger() {
		return logger.get();
	}

	/** Returns pointer to parallels */
	inline const Parallels* getParallels() const {
		return parallels.get();
	}
	inline Parallels* getParallels() {
		return parallels.get();
	}

	/** Default thread joint time out */
	inline MSecTmU32 getThreadTimeOut() const {
		return threadTimeOut;
	}

	/** Returns reference to randseed */
	inline const RandSeed& getRandSeed() const {
		return randSeed;
	}

	/** Returns simulation scale */
	inline Real getSimulationScale() const {
		return simulationScale;
	}
};

/** Default system context */
//extern Context::Ptr context;

//------------------------------------------------------------------------------

};	// namespace

#endif /*_GOLEM_TOOLS_CONTEXT_H_*/
