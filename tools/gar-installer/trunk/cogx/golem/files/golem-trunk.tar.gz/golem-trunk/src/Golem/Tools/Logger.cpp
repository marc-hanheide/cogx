/** @file Logger.cpp
 * 
 * Message logger for distributed systems, implementation.
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#include <Golem/Tools/Logger.h>
#include <Golem/Tools/Msg.h>

//------------------------------------------------------------------------------

using namespace golem;

//------------------------------------------------------------------------------

Logger::Logger(PerfTimer& timer) : timer(timer) {
}

Logger::~Logger() {
}

bool Logger::create(const Desc &desc) {
	if (!desc.isValid())
		throw MsgLoggerInvalidDesc(Message::LEVEL_CRIT, "Logger::create(): Invalid description");

	exFilter = desc.exFilter;
	msgFilter = desc.msgFilter;
	pStream = desc.pStream;
	queueEx = desc.queueEx;

	messages.reserve(desc.messageQueueLen);

	return true;
}

//------------------------------------------------------------------------------

Logger *Logger::createLogger(const Desc &desc) {
	CriticalSectionWrapper csw(csLoggers); // enter critical section

	Logger::Ptr pLogger(desc.create(timer));
	
	if (pLogger != NULL)
		loggers.push_back(Logger::List::Pair(pLogger.get(), pLogger));

	return pLogger.get();
}

void Logger::releaseLogger(Logger &logger) {
	CriticalSectionWrapper csw(csLoggers); // enter critical section
	
	loggers.erase(&logger);
}

//------------------------------------------------------------------------------

bool Logger::post(Message::Ptr &pMessage) {
	bool bPosted = false;
	
	if (msgFilter == NULL || (*msgFilter)(*pMessage)) {
		CriticalSectionWrapper csw(csMessages); // enter critical section
		
		// insert to the stream
		if (pStream != NULL) {
			bPosted = true;
			*pStream << *pMessage << std::endl;// end of line and flush
		}
		// and post to the message queue
		if (messages.capacity() > 0) {
			if (messages.full())
				messages.pop_front();
			messages.push_back(pMessage);
			evMessages.set(true);
			bPosted = true;
		}
	}

	{
		CriticalSectionWrapper csw(csLoggers); // enter critical section
		
		// post to Loggers
		for (List::const_iterator i = loggers.begin(); i != loggers.end(); i++)
			if ((*i)->post(pMessage))
				bPosted = true;
	}

	return bPosted;
}
	
//------------------------------------------------------------------------------

bool Logger::post() {
	CriticalSectionWrapper csw(csMessages); // enter critical section
	return evMessages.set(true) == true;
}

bool Logger::post(const char* format, ...) {
	va_list argptr;
	va_start(argptr, format);
	bool bPosted = post(true, new Message(), Message::LEVEL_UNDEF, format, argptr);
	va_end(argptr);
	return bPosted;
}

bool Logger::post(Message::Level level, const char* format, ...) {
	va_list argptr;
	va_start(argptr, format);
	bool bPosted = post(true, new Message(), level, format, argptr);
	va_end(argptr);
	return bPosted;
}

//------------------------------------------------------------------------------

bool Logger::fetch(Message::Ptr& pMessage, MSecTmU32 timeOut) {
	if (evMessages.wait(timeOut)) {
		CriticalSectionWrapper csw(csMessages); // enter critical section
		
		if (messages.empty()) {
			evMessages.set(false);
			return false;
		}
		else {
			pMessage = messages.front();
			messages.pop_front();
			return true;
		}
	}
	
	return false;
}

bool Logger::empty() {
	return messages.empty();
}

void Logger::clear() {
	{
		CriticalSectionWrapper csw(csMessages); // enter critical section		
		messages.clear();
		evMessages.set(false);
	}

	{
		CriticalSectionWrapper csw(csLoggers); // enter critical section
		for (List::const_iterator i = loggers.begin(); i != loggers.end(); i++)
			(*i)->clear();
	}
}

//------------------------------------------------------------------------------
