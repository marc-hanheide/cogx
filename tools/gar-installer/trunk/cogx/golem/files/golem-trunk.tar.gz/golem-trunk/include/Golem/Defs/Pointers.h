/** @file Pointers.h
 * 
 * Implements smart pointers with reference counting.
 * TODO use BOOST implementation instead
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#pragma once
#ifndef _GOLEM_DEFS_POINTERS_H_
#define _GOLEM_DEFS_POINTERS_H_

#include <stddef.h>

//------------------------------------------------------------------------------

namespace golem {

//------------------------------------------------------------------------------

/** Pointer counter for xxx_ptr classes copying.
 * 
 */
template<class This>
struct ptr_counter {
	ptr_counter(This* ptr = NULL, size_t cnt = 1) : ptr(ptr), cnt(cnt) {}
	
	This* ptr;
	size_t cnt;
};

//------------------------------------------------------------------------------

/** Object pointer wrapper with reference counting.
 * 
 */
template<class This>
class obj_ptr {
public:
	typedef This element_type;

	/** Explicitly constructs from object pointer.
	 * 
	 * Constructor cannot be used for implicit object construction.
	 * 
	 * @param ptr	object pointer
	 */
	explicit obj_ptr(This *ptr = NULL) : pCounter(NULL) {
		create(ptr);
	}

	/** Constructs assuming pointer from ref obj_ptr
	 * 
	 * @param ref	object reference
	 */
	obj_ptr(const obj_ptr<This>& ref) {
		acquire(ref.pCounter);
	}

	/** Destroys the object.
	 */
	~obj_ptr() {
		release();
	}

	/** Assigns ref.
	 */
	obj_ptr<This>& operator = (const obj_ptr<This>& ref) {
		if (this != &ref) {
			release();
			acquire(ref.pCounter);
		}
		return *this;
	}

	/** Returns designated value.
	 */
	This &operator * () const {
		return *pCounter->ptr;
	}

	/** Returns pointer to class object.
	 */
	This *operator -> () const {
		return pCounter->ptr;
	}
	
	/** Returns wrapped pointer.
	 */
	This* get() const {
		return pCounter != NULL ? pCounter->ptr : NULL;
	}

	/** Releases designated object and store a new pointer.
	 */
	void reset(This* ptr = NULL) {
		release();
		create(ptr);
	}

	/** Releases and decrement pointer counter.
	 */
	void release() {
		if (pCounter != NULL) {
			if (--pCounter->cnt <= 0) {
				delete pCounter->ptr;
				delete pCounter;
			}
			pCounter = NULL;
		}
	}

	/** Returns total number of object references.
	 */
	size_t counter() const {
		return pCounter != NULL ? pCounter->cnt : 0;
	}

	/** Is the pointer unique.
	 */
	bool unique() const {
		return pCounter == NULL || pCounter->cnt == 1;
	}

	/** Performs dynamic_cast pointer conversion.
	 * 
	 * @param r	converted pointer
	 */
	template<class Left, class Right>
	friend obj_ptr<Left> dynamic_pointer_cast(obj_ptr<Right> const& r);

	/** Performs static_cast pointer conversion.
	 * 
	 * @param r	converted pointer
	 */
	template<class Left, class Right>
	friend obj_ptr<Left> static_pointer_cast(obj_ptr<Right> const& r);

	/** Performs const_cast pointer conversion.
	 * 
	 * @param r	converted pointer
	 */
	template<class Left, class Right>
	friend obj_ptr<Left> const_pointer_cast(obj_ptr<Right> const& r);

private:

	ptr_counter<This>* pCounter;
	
	/** Create a new pointer counter.
	 * 
	 * @param ptr	object pointer
	 */
	void create(This* ptr) {
		if (ptr != NULL)
			pCounter = new ptr_counter<This>(ptr);
	}
	
	/** Acquire and increment a new pointer counter.
	 * 
	 * @param pCounter	acquired pointer counter
	 */
	void acquire(ptr_counter<This>* pCounter) {
		this->pCounter = pCounter;
		if (pCounter != NULL)
			++pCounter->cnt;
	}
};

template<class Left, class Right>
obj_ptr<Left> dynamic_pointer_cast(obj_ptr<Right> const& r) {
	obj_ptr<Left> ptr;

	if (dynamic_cast<Left*>(r.get()) != NULL) {
		ptr.pCounter = (ptr_counter<Left>*)r.pCounter;
		++ptr.pCounter->cnt;
	}

	return ptr;
}

template<class Left, class Right>
obj_ptr<Left> static_pointer_cast(obj_ptr<Right> const& r) {
	obj_ptr<Left> ptr;

	if (static_cast<Left*>(r.get()) != NULL) {
		ptr.pCounter = (ptr_counter<Left>*)r.pCounter;
		++ptr.pCounter->cnt;
	}

	return ptr;
}

template<class Left, class Right>
obj_ptr<Left> const_pointer_cast(obj_ptr<Right> const& r) {
	obj_ptr<Left> ptr;

	if (const_cast<Left*>(r.get()) != NULL) {
		ptr.pCounter = (ptr_counter<Left>*)r.pCounter;
		++ptr.pCounter->cnt;
	}

	return ptr;
}

template<class Left, class Right>
bool operator == (const obj_ptr<Left>& l, const obj_ptr<Right>& r) {
	return l.get() == r.get();
}

template<class This>
bool operator == (const obj_ptr<This>& l, const void* r) {
	return l.get() == r;
}

template<class This>
bool operator == (const void* l, const obj_ptr<This>& r) {
	return l == r.get();
}

template<class Left, class Right>
bool operator != (const obj_ptr<Left>& l, const obj_ptr<Right>& r) {
	return l.get() != r.get();
}

template<class This>
bool operator != (const obj_ptr<This>& l, const void* r) {
	return l.get() != r;
}

template<class This>
bool operator != (const void* l, const obj_ptr<This>& r) {
	return l != r.get();
}

//------------------------------------------------------------------------------

/** Array pointer wrapper with reference counting.
 * 
 */
template<class This>
class arr_ptr {
public:
	typedef This element_type;

	/** Explicitly constructs from object pointer.
	 * 
	 * Constructor cannot be used for implicit object construction.
	 * 
	 * @param ptr	object pointer
	 */
	explicit arr_ptr(This *ptr = NULL) : pCounter(NULL) {
		create(ptr);
	}

	/** Constructs assuming pointer from ref arr_ptr
	 * 
	 * @param ref	object reference
	 */
	arr_ptr(const arr_ptr<This>& ref) {
		acquire(ref.pCounter);
	}

	/** Destroys the object.
	 */
	~arr_ptr() {
		release();
	}

	/** Assigns ref.
	 */
	arr_ptr<This>& operator = (const arr_ptr<This>& ref) {
		if (this != &ref) {
			release();
			acquire(ref.pCounter);
		}
		return *this;
	}

	/** Returns array object reference.
	 */
	This& operator [] (size_t index) const {
		return pCounter->ptr[index];
	}

	/** Returns wrapped pointer.
	 */
	This* get() const {
		return pCounter != NULL ? pCounter->ptr : NULL;
	}

	/** Releases designated object and store a new pointer.
	 */
	void reset(This* ptr = NULL) {
		release();
		create(ptr);
	}

	/** Releases and decrement pointer counter.
	 */
	void release() {
		if (pCounter != NULL) {
			if (--pCounter->cnt <= 0) {
				delete [] pCounter->ptr;
				delete pCounter;
			}
			pCounter = NULL;
		}
	}

	/** Returns total number of object references.
	 */
	size_t counter() const {
		return pCounter != NULL ? pCounter->cnt : 0;
	}

	/** Is the pointer unique.
	 */
	bool unique() const {
		return pCounter == NULL || pCounter->cnt == 1;
	}

	/** Performs dynamic_cast pointer conversion.
	 * 
	 * @param r	converted pointer
	 */
	template<class Left, class Right>
	friend arr_ptr<Left> dynamic_pointer_cast(arr_ptr<Right> const& r);

	/** Performs static_cast pointer conversion.
	 * 
	 * @param r	converted pointer
	 */
	template<class Left, class Right>
	friend arr_ptr<Left> static_pointer_cast(arr_ptr<Right> const& r);

	/** Performs const_cast pointer conversion.
	 * 
	 * @param r	converted pointer
	 */
	template<class Left, class Right>
	friend arr_ptr<Left> const_pointer_cast(arr_ptr<Right> const& r);

private:

	ptr_counter<This>* pCounter;
	
	/** Create a new pointer counter.
	 * 
	 * @param ptr	object pointer
	 */
	void create(This* ptr) {
		if (ptr != NULL)
			pCounter = new ptr_counter<This>(ptr);
	}
	
	/** Acquire and increment a new pointer counter.
	 * 
	 * @param pCounter	acquired pointer counter
	 */
	void acquire(ptr_counter<This>* pCounter) {
		this->pCounter = pCounter;
		if (pCounter != NULL)
			++pCounter->cnt;
	}
};

template<class Left, class Right>
arr_ptr<Left> dynamic_pointer_cast(arr_ptr<Right> const& r) {
	arr_ptr<Left> ptr;

	if (dynamic_cast<Left*>(r.get()) != NULL) {
		ptr.pCounter = (ptr_counter<Left>*)r.pCounter;
		++ptr.pCounter->cnt;
	}

	return ptr;
}

template<class Left, class Right>
arr_ptr<Left> static_pointer_cast(arr_ptr<Right> const& r) {
	arr_ptr<Left> ptr;

	if (static_cast<Left*>(r.get()) != NULL) {
		ptr.pCounter = (ptr_counter<Left>*)r.pCounter;
		++ptr.pCounter->cnt;
	}

	return ptr;
}

template<class Left, class Right>
arr_ptr<Left> const_pointer_cast(arr_ptr<Right> const& r) {
	arr_ptr<Left> ptr;

	if (const_cast<Left*>(r.get()) != NULL) {
		ptr.pCounter = (ptr_counter<Left>*)r.pCounter;
		++ptr.pCounter->cnt;
	}

	return ptr;
}

template<class Left, class Right>
bool operator == (const arr_ptr<Left>& l, const arr_ptr<Left>& r) {
	return l.get() == r.get();
}

template<class This>
bool operator == (const arr_ptr<This>& l, const void* r) {
	return l.get() == r;
}

template<class This>
bool operator == (const void* l, const arr_ptr<This>& r) {
	return l == r.get();
}

template<class Left, class Right>
bool operator != (const arr_ptr<Left>& l, const arr_ptr<Left>& r) {
	return l.get() != r.get();
}

template<class This>
bool operator != (const arr_ptr<This>& l, const void* r) {
	return l.get() != r;
}

template<class This>
bool operator != (const void* l, const arr_ptr<This>& r) {
	return l != r.get();
}

//------------------------------------------------------------------------------

};	// namespace

#endif /*_GOLEM_DEFS_POINTERS_H_*/
