/** @file Simulator.cpp
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#include <Golem/Ctrl/Simulator.h>
#include <Golem/Ctrl/Msg.h>
#include <math.h>

//------------------------------------------------------------------------------

using namespace golem;

//------------------------------------------------------------------------------

SimJoint::SimJoint(Arm& arm) : Joint(arm) {}

bool SimJoint::create(const Desc& desc) {
	if (!Joint::create(desc))
		return false;
	
	readPtr = writePtr = 0;
	bStart = false;

	current.pos = trn.theta;
	current.vel = REAL_ZERO;
	current.acc = REAL_ZERO;

	return true;
}

//------------------------------------------------------------------------------

bool SimJoint::sysSync() {
	GenCoordTrj& trjRead = trj[readPtr];
	bool bReset = false;

	if (bStart) {
		writePtr = Math::cycle_add((int)Arm::SYS_BUF_LEN, writePtr, 1);
		bStart = false;
		bReset = true;
	}
	else if (trjRead.getEnd() > REAL_ZERO && trjRead.getEnd() < (Real)timer.elapsed()) {
		trjRead.setEnd(REAL_ZERO);
		readPtr = Math::cycle_add((int)Arm::SYS_BUF_LEN, readPtr, 1);
		bReset = true;
	}
	
	if (trj[writePtr].getEnd() > REAL_ZERO)
		return false;

	if (bReset)
		timer.reset();
	
	return true;
}

//------------------------------------------------------------------------------
// IJointWrapper

bool SimJoint::sysRecv(GenCoord& curr) {
	GenCoordTrj& trjRead = trj[readPtr];

	if (trjRead.getEnd() > REAL_ZERO) {
		curr = trjRead.get((Real)timer.elapsed());
		// TODO provide real body movement effects
	}
	else
		curr = current;
	
	return true;
}

bool SimJoint::sysSend(const GenCoord& prev, const GenCoord& next, SecTmReal dt) {
	trj[writePtr].set(REAL_ZERO, (Real)dt, prev, next);
	current = next;
	return true;
}

//------------------------------------------------------------------------------

SimArm::SimArm(golem::Context& context) :
	Arm(context)
{
}

bool SimArm::create(const Desc& desc) {
	if (!desc.isValid()) {
		context.getLogger()->post(new MsgSimInvalidDesc(), Message::LEVEL_CRIT,
			"SimArm::create(): Invalid description"
		);
		return false;
	}
	
	// must be initialized *before* arm creation (used in calibration)!
	deltaSync = desc.deltaSync;
	deltaRecv = desc.deltaRecv;
	deltaSend = desc.deltaSend;

	// create the arm
	if (!Arm::create(desc))
		return false;

	return true;
}

//------------------------------------------------------------------------------
// IArmBase

bool SimArm::sysRecv(GenConfigspaceCoord& curr) {
	bool bRes = Arm::sysRecv(curr);
	timer.sleep(deltaRecv);
	return bRes;
}

bool SimArm::sysSend(const GenConfigspaceCoord& prev, const GenConfigspaceCoord& next, SecTmReal dt) {
	bool bRes = Arm::sysSend(prev, next, dt);
	
	timer.sleep(deltaSend);
	
	for (unsigned i = 0; i < joints.size(); i++)
		((SimJoint*)joints[i])->bStart = true;
	
	return bRes;
}

bool SimArm::sysSync() {
	bool bRes = true;
	
	for (unsigned i = 0; i < joints.size(); i++)
		if (!((SimJoint*)joints[i])->sysSync())
			bRes = false;
	
	timer.sleep(deltaSync);
	
	return bRes;
}

//------------------------------------------------------------------------------

// Links lengths
const Real GenSimArm::L0 = Real(0.2); // [m]
const Real GenSimArm::L1 = Real(0.2); // [m]
const Real GenSimArm::L2 = Real(0.2); // [m]
const Real GenSimArm::L3 = Real(0.05); // [m]

template <typename _Desc> void setupJoints(Joint::Desc::Seq& joints, const GenSimArm::Body &body) {
	const Real Gap = REAL_2_PI/Real(12.0); // 30 deg
	const Real PosLim = REAL_PI - Gap; // PI
	const Real VelLim = Real(1.0)*REAL_PI; // PI/sec
	const Real AccLim = Real(2.0)*REAL_PI; // PI/sec*sec

	// Joint #1
	_Desc *descJ1 = new _Desc;
	joints.push_back(Joint::Desc::Ptr(descJ1));
		
	descJ1->name = "joint #1";
	descJ1->collision = false;
	descJ1->collisionOffset = GenSimArm::NUM_JOINTS; // collision joint offset, do not check collisions against other joints

	descJ1->min.pos = (Real)-PosLim;	descJ1->min.vel = -VelLim;	descJ1->min.acc = -AccLim;
	descJ1->max.pos = (Real)+PosLim;	descJ1->max.vel = +VelLim;	descJ1->max.acc = +AccLim;
	
	descJ1->trn.twist.set((Real)0.0, (Real)0.0, (Real)0.0, (Real)0.0, (Real)0.0, (Real)1.0); // translation + rotation component
	descJ1->trn.theta = (Real)0.0; // init position
	descJ1->trnInit.twist.set((Real)0.0, (Real)0.0, (Real)0.0, (Real)0.0, (Real)0.0, (Real)0.0); // translation + rotation component
	descJ1->trnInit.theta = (Real)0.0; // init position
	
	if (body.simpleBoundsModel) {
		BoundingBox::Desc* boundsJ1_0 = new BoundingBox::Desc;
		descJ1->bounds.push_back(Bounds::Desc::Ptr(boundsJ1_0));
		boundsJ1_0->dimensions.set(body.l0/(Real)8.0, body.l0/(Real)8.0, body.l0/(Real)2.0); // dimensions
		boundsJ1_0->pose.p.set((Real)0.0, (Real)0.0, body.l0/(Real)2.0 + REAL_EPS); // translation vector
	}
	else {
		BoundingCylinder::Desc* boundsJ1_0 = new BoundingCylinder::Desc;
		descJ1->bounds.push_back(Bounds::Desc::Ptr(boundsJ1_0));
		boundsJ1_0->radius = body.l0/(Real)6.0; // radius
		boundsJ1_0->length = body.l0;
		boundsJ1_0->pose.p.set(Real(0.0), Real(0.0), body.l0/Real(2.0) + REAL_EPS);
	}

	// Joint #2
	_Desc *descJ2 = new _Desc;
	joints.push_back(Joint::Desc::Ptr(descJ2));
	
	descJ2->name = "joint #2";
	descJ2->collisionOffset = GenSimArm::NUM_JOINTS; // collision joint offset, do not check collisions against other joints

	descJ2->min.pos = (Real)-PosLim - REAL_PI_2;	descJ2->min.vel = -VelLim;	descJ2->min.acc = -AccLim;
	descJ2->max.pos = (Real)+PosLim - REAL_PI_2;	descJ2->max.vel = +VelLim;	descJ2->max.acc = +AccLim;
	
	descJ2->trn.twist.set((Real)0.0, -body.l0, (Real)0.0, (Real)-1.0, (Real)0.0, (Real)0.0); // translation + rotation component
	descJ2->trn.theta = (Real)0.0; // init position
	descJ2->trnInit.twist.set((Real)0.0, (Real)0.0, body.l0, (Real)0.0, (Real)0.0, (Real)0.0); // translation + rotation component
	descJ2->trnInit.theta = (Real)1.0; // init position
	
	if (body.simpleBoundsModel) {
		BoundingSphere::Desc* boundsJ2_0 = new BoundingSphere::Desc;
		descJ2->bounds.push_back(Bounds::Desc::Ptr(boundsJ2_0));
		boundsJ2_0->radius = body.l0/(Real)5.0; // radius
		boundsJ2_0->pose.p.set((Real)0.0, (Real)0.0, (Real)0.0); // position

		BoundingBox::Desc* boundsJ2_1 = new BoundingBox::Desc;
		descJ2->bounds.push_back(Bounds::Desc::Ptr(boundsJ2_1));
		boundsJ2_1->dimensions.set(body.l0/(Real)12.0, body.l1/(Real)2.0, body.l0/(Real)12.0); // dimensions
		boundsJ2_1->pose.p.set((Real)0.0, body.l1/(Real)2.0, (Real)0.0); // translation vector
	}
	else {
		BoundingCylinder::Desc* boundsJ2_0 = new BoundingCylinder::Desc;
		descJ2->bounds.push_back(Bounds::Desc::Ptr(boundsJ2_0));
		boundsJ2_0->radius = body.l0/(Real)12.0; // radius
		boundsJ2_0->length = body.l1;
		boundsJ2_0->pose.p.set(Real(0.0), body.l1/Real(2.0), Real(0.0));
		boundsJ2_0->pose.R.rotX(REAL_PI_2);

		BoundingCylinder::Desc* boundsJ2_1 = new BoundingCylinder::Desc;
		descJ2->bounds.push_back(Bounds::Desc::Ptr(boundsJ2_1));
		boundsJ2_1->radius = body.l0/(Real)6.0; // radius
		boundsJ2_1->length = body.l0/Real(2.0);
		boundsJ2_1->pose.R.rotY(REAL_PI_2);	
	}

	// Joint #3
	_Desc *descJ3 = new _Desc;
	joints.push_back(Joint::Desc::Ptr(descJ3));
	
	descJ3->name = "joint #3";
	descJ3->collisionOffset = GenSimArm::NUM_JOINTS; // collision joint offset, do not check collisions against other joints

	descJ3->min.pos = (Real)0/*-PosLim*/;	descJ3->min.vel = -VelLim;	descJ3->min.acc = -AccLim;
	descJ3->max.pos = (Real)+PosLim;	descJ3->max.vel = +VelLim;	descJ3->max.acc = +AccLim;
	
	descJ3->trn.twist.set((Real)0.0, -body.l0, body.l1, (Real)-1.0, (Real)0.0, (Real)0.0); // translation + rotation component
	descJ3->trn.theta = (Real)0.0; // init position
	descJ3->trnInit.twist.set((Real)0.0, body.l1, body.l0, (Real)0.0, (Real)0.0, (Real)0.0); // translation + rotation component
	descJ3->trnInit.theta = (Real)1.0; // init position

	if (body.simpleBoundsModel) {
		BoundingSphere::Desc* boundsJ3_0 = new BoundingSphere::Desc;
		descJ3->bounds.push_back(Bounds::Desc::Ptr(boundsJ3_0));
		boundsJ3_0->radius = body.l0/(Real)5.0; // radius
		boundsJ3_0->pose.p.set((Real)0.0, (Real)0.0, (Real)0.0); // position

		BoundingBox::Desc* boundsJ3_1 = new BoundingBox::Desc;
		descJ3->bounds.push_back(Bounds::Desc::Ptr(boundsJ3_1));
		boundsJ3_1->dimensions.set(body.l0/(Real)12.0, body.l2/(Real)2.0, body.l0/(Real)12.0); // dimensions
		boundsJ3_1->pose.p.set((Real)0.0, body.l2/(Real)2.0, (Real)0.0); // translation vector
	}
	else {
		BoundingCylinder::Desc* boundsJ3_0 = new BoundingCylinder::Desc;
		descJ3->bounds.push_back(Bounds::Desc::Ptr(boundsJ3_0));
		boundsJ3_0->radius = body.l0/(Real)12.0; // radius
		boundsJ3_0->length = body.l2;
		boundsJ3_0->pose.p.set(Real(0.0), body.l2/Real(2.0), Real(0.0));
		boundsJ3_0->pose.R.rotX(REAL_PI_2);

		BoundingCylinder::Desc* boundsJ3_1 = new BoundingCylinder::Desc;
		descJ3->bounds.push_back(Bounds::Desc::Ptr(boundsJ3_1));
		boundsJ3_1->radius = body.l0/(Real)6.0; // radius
		boundsJ3_1->length = body.l0/Real(2.0);
		boundsJ3_1->pose.R.rotY(REAL_PI_2);	
	}

	// Joint #4
	_Desc *descJ4 = new _Desc;
	joints.push_back(Joint::Desc::Ptr(descJ4));
	
	descJ4->name = "joint #4";
	descJ4->collisionOffset = GenSimArm::NUM_JOINTS; // collision joint offset, do not check collisions against other joints

	descJ4->min.pos = (Real)-PosLim;	descJ4->min.vel = -VelLim;	descJ4->min.acc = -AccLim;
	descJ4->max.pos = (Real)+PosLim;	descJ4->max.vel = +VelLim;	descJ4->max.acc = +AccLim;
	
	descJ4->trn.twist.set(body.l1 + body.l2, (Real)0.0, (Real)0.0, (Real)0.0, (Real)0.0, (Real)1.0); // translation + rotation component
	descJ4->trn.theta = (Real)0.0; // init position
	descJ4->trnInit.twist.set((Real)0.0, body.l1 + body.l2, body.l0, (Real)0.0, (Real)0.0, (Real)0.0); // translation + rotation component
	descJ4->trnInit.theta = (Real)1.0; // init position

	// no physical/visual representation
	
	// Joint #5
	_Desc *descJ5 = new _Desc;
	joints.push_back(Joint::Desc::Ptr(descJ5));
	
	descJ5->name = "joint #5";
	descJ5->collisionOffset = GenSimArm::NUM_JOINTS; // collision joint offset, do not check collisions against other joints

	descJ5->min.pos = (Real)-PosLim;	descJ5->min.vel = -VelLim;	descJ5->min.acc = -AccLim;
	descJ5->max.pos = (Real)+PosLim;	descJ5->max.vel = +VelLim;	descJ5->max.acc = +AccLim;
	
	descJ5->trn.twist.set((Real)0.0, -body.l0, body.l1 + body.l2, (Real)-1.0, (Real)0.0, (Real)0.0); // translation + rotation component
	descJ5->trn.theta = (Real)0.0; // init position
	descJ5->trnInit.twist.set((Real)0.0, body.l1 + body.l2, body.l0, (Real)0.0, (Real)0.0, (Real)0.0); // translation + rotation component
	descJ5->trnInit.theta = (Real)1.0; // init position

	// no physical/visual representation
	
	// Joint #6	
	_Desc *descJ6 = new _Desc;
	joints.push_back(Joint::Desc::Ptr(descJ6));
	
	descJ6->name = "joint #6";
	descJ6->collisionOffset = 4; // collision joint offset, collisions only against joint #1

	descJ6->min.pos = (Real)-PosLim;	descJ6->min.vel = -VelLim;	descJ6->min.acc = -AccLim;
	descJ6->max.pos = (Real)+PosLim;	descJ6->max.vel = +VelLim;	descJ6->max.acc = +AccLim;
	
	descJ6->trn.twist.set(-body.l0, (Real)0.0, (Real)0.0, (Real)0.0, (Real)1.0, (Real)0.0); // translation + rotation component
	descJ6->trn.theta = (Real)0.0; // init position
	descJ6->trnInit.twist.set((Real)0.0, body.l1 + body.l2, body.l0, (Real)0.0, (Real)0.0, (Real)0.0); // translation + rotation component
	descJ6->trnInit.theta = (Real)1.0; // init position

	BoundingSphere::Desc* boundsJ6_0 = new BoundingSphere::Desc;
	descJ6->bounds.push_back(Bounds::Desc::Ptr(boundsJ6_0));
	boundsJ6_0->pose.p.set((Real)0.0, (Real)0.0, (Real)0.0); // position
	boundsJ6_0->radius = body.l0/(Real)6.0; // radius

	BoundingBox::Desc* boundsJ6_1 = new BoundingBox::Desc;
	descJ6->bounds.push_back(Bounds::Desc::Ptr(boundsJ6_1));
	boundsJ6_1->pose.p.set((Real)0.0, body.l3/(Real)2.0, (Real)0.0); // translation vector	
	boundsJ6_1->dimensions.set(body.l3/(Real)4.0, body.l3/(Real)2.0, body.l3/(Real)4.0); // dimensions
}

//------------------------------------------------------------------------------

void GenSimArm::setupJoints(Joint::Desc::Seq& joints, const GenSimArm::Body &body) {
	::setupJoints<SimJoint::Desc>(joints, body);
}

//------------------------------------------------------------------------------

GenSimArm::GenSimArm(golem::Context& context) :
	SimArm(context)
{}

bool GenSimArm::create(const Desc& desc) {
	body = desc.body;

	return SimArm::create(desc);
}

//------------------------------------------------------------------------------
// Arm
// Inverse and forward transforms, implementation from Generic Arm

void GenSimArm::forwardTransform(Mat34& trn, const ConfigspaceCoord& cc) const {
	Real s1, c1, s2, c2, s3, c3, s4, c4, s5, c5, s6, c6, s23, c23, a1, a2, a3, a4, a5;

	Math::sinCos(cc[0], s1, c1);
	Math::sinCos(cc[1], s2, c2);
	Math::sinCos(cc[2], s3, c3);
	Math::sinCos(cc[3], s4, c4);
	Math::sinCos(cc[4], s5, c5);
	Math::sinCos(cc[5], s6, c6);

	s23 = Math::sin(cc[1] + cc[2]); c23 = Math::cos(cc[1] + cc[2]);

	trn.p.v1 = -s1*(c2*body.l1 + c23*body.l2);
	trn.p.v2 = c1*(c2*body.l1 + c23*body.l2);
	trn.p.v3 = body.l0 - s2*body.l1 - s23*body.l2;

	a1 = s1*s23; a2 = s1*c23; a3 = c1*c4 - a2*s4; a4 = a2*c4 + c1*s4; a5 = a1*c5 + s5*a4;
	trn.R.m11 =  c6*a3 + s6*a5;
	trn.R.m12 = -c5*a4 + s5*a1;
	trn.R.m13 = -c6*a5 + s6*a3;

	a1 = c1*s23; a2 = c1*c23; a3 = c4*s1 + a2*s4; a4 = a2*c4 - s1*s4; a5 = a1*c5 + s5*a4;
	trn.R.m21 =  c6*a3 - s6*a5;
	trn.R.m22 =  c5*a4 - s5*a1;
	trn.R.m23 =  c6*a5 + s6*a3;

	a1 = c23*c5 - s23*c4*s5;
	trn.R.m31 = -s6*a1 - s23*s4*c6;
	trn.R.m32 = -s5*c23- s23*c4*c5;
	trn.R.m33 =  c6*a1 - s23*s4*s6;

	trn.multiply(getGlobalPose(), trn);
}

void GenSimArm::inverseTransform(ConfigspaceCoord::Seq& j, const Mat34& trn) const {
	j.clear();
}

void GenSimArm::velocitySpatial(Twist& v, const ConfigspaceCoord& cc, const ConfigspaceCoord& dcc) const {
	Real s1, c1, s2, c2, s3, c3, s4, c4, s5, c5, s6, c6;

	Math::sinCos(cc[0], s1, c1);
	Math::sinCos(cc[1], s2, c2);
	Math::sinCos(cc[2], s3, c3);
	Math::sinCos(cc[3], s4, c4);
	Math::sinCos(cc[4], s5, c5);
	Math::sinCos(cc[5], s6, c6);

	Real s23 = Math::sin(cc[1] + cc[2]);
	Real c23 = Math::cos(cc[1] + cc[2]);
	Vec3 q(
		-s1*(body.l1*c2 + body.l2*c23),
		c1*(body.l1*c2 + body.l2*c23),
		body.l0 - (body.l1*s2 + body.l2*s23)
	);

	Twist tmp;

	// twist #1
	v.getV().set(
		REAL_ZERO, REAL_ZERO, REAL_ZERO
	);
	v.getW().set(
		REAL_ZERO, REAL_ZERO, dcc[0]
	);

	// twist #2
	tmp.getV().set(
		body.l0*s1, -body.l0*c1, REAL_ZERO
	);
	tmp.getW().set(
		-c1, -s1, REAL_ZERO
	);
	v.multiplyAdd(dcc[1], tmp, v);

	// twist #3
	tmp.getV().set(
		s1*(body.l0 - body.l1*s2), c1*(body.l1*s2 - body.l0), body.l1*c2
	);
	tmp.getW().set(
		-c1, -s1, REAL_ZERO
	);
	v.multiplyAdd(dcc[2], tmp, v);

	// twist #4
	tmp.getW().set(
		-s1*s23, c1*s23, c23
	);
	tmp.getV().cross(q, tmp.getW());
	v.multiplyAdd(dcc[3], tmp, v);

	// twist #5
	tmp.getW().set(
		s1*s4*c23 - c1*c4, -s4*c1*c23 - s1*c4, s4*s23
	);
	tmp.getV().cross(q, tmp.getW());
	v.multiplyAdd(dcc[4], tmp, v);

	// twist #6
	tmp.getW().set(
		-s4*c1*c5 - s1*(c4*c5*c23 - s5*s23), -s1*s4*c5 + c1*(c4*c5*c23 - s5*s23), -(c4*c5*s23 + s5*c23)
	);
	tmp.getV().cross(q, tmp.getW());
	v.multiplyAdd(dcc[5], tmp, v);

	// transform to SE(3)
//	trn.twistToSpecial(velocity);
}

void GenSimArm::jacobianSpatial(Jacobian& jac, const ConfigspaceCoord& cc) const {
	Real s1, c1, s2, c2, s3, c3, s4, c4, s5, c5, s6, c6;

	Math::sinCos(cc[0], s1, c1);
	Math::sinCos(cc[1], s2, c2);
	Math::sinCos(cc[2], s3, c3);
	Math::sinCos(cc[3], s4, c4);
	Math::sinCos(cc[4], s5, c5);
	Math::sinCos(cc[5], s6, c6);

	Real s23 = Math::sin(cc[1] + cc[2]);
	Real c23 = Math::cos(cc[1] + cc[2]);
	Vec3 q(
		-s1*(body.l1*c2 + body.l2*c23),
		c1*(body.l1*c2 + body.l2*c23),
		body.l0 - (body.l1*s2 + body.l2*s23)
	);

	// twist #1
	jac[0].getV().set(
		REAL_ZERO, REAL_ZERO, REAL_ZERO
	);
	jac[0].getW().set(
		REAL_ZERO, REAL_ZERO, REAL_ONE
	);

	// twist #2
	jac[1].getV().set(
		body.l0*s1, -body.l0*c1, REAL_ZERO
	);
	jac[1].getW().set(
		-c1, -s1, REAL_ZERO
	);

	// twist #3
	jac[2].getV().set(
		s1*(body.l0 - body.l1*s2), c1*(body.l1*s2 - body.l0), body.l1*c2
	);
	jac[2].getW().set(
		-c1, -s1, REAL_ZERO
	);

	// twist #4
	jac[3].getW().set(
		-s1*s23, c1*s23, c23
	);
	jac[3].getV().cross(q, jac[3].getW());

	// twist #5
	jac[4].getW().set(
		s1*s4*c23 - c1*c4, -s4*c1*c23 - s1*c4, s4*s23
	);
	jac[4].getV().cross(q, jac[4].getW());

	// twist #6
	jac[5].getW().set(
		-s4*c1*c5 - s1*(c4*c5*c23 - s5*s23), -s1*s4*c5 + c1*(c4*c5*c23 - s5*s23), -(c4*c5*s23 + s5*c23)
	);
	jac[5].getV().cross(q, jac[5].getW());
}

//------------------------------------------------------------------------------
