/** @file Tiny.cpp
 * 
 * @author	Marek Kopicki (The University Of Birmingham)
 *
 * @version 1.0
 *
 */

#include <Golem/Tools/Stream.h>
#include <Golem/Ctrl/Data.h>
#include <Golem/Phys/Data.h>
#include <Golem/PhysCtrl/PhysReacPlanner.h>
#include <Golem/PhysCtrl/Msg.h>
#include <Golem/PhysCtrl/Creator.h>
#include <Golem/Tiny/Tiny.h>
#include <Golem/Tiny/Types.h>

//------------------------------------------------------------------------------

using namespace golem::tiny;

//------------------------------------------------------------------------------

class golem::tiny::BoundsDesc {
public:
	golem::Bounds::Desc::Ptr pBoundsDesc;
	BoundsDesc(const golem::Bounds::Desc::Ptr pBoundsDesc) : pBoundsDesc(pBoundsDesc) {}
};

class golem::tiny::PhysReacPlannerDesc : public golem::PhysReacPlanner::Desc {
public:
};

//------------------------------------------------------------------------------

ExTiny::ExTiny(golem::SecTmReal stamp, Level level, const char* format, va_list argptr) {
	setup(stamp, level, format, argptr);
}

//------------------------------------------------------------------------------

Shape::Shape(RigidBody& rigidBody) : rigidBody(rigidBody), pNxShapeDesc(0), pBounds(0), owner(false) {
}

Shape::~Shape() {
	if (pBounds == 0 || !owner)
		return;
	golem::Mat34 m = pBounds->getPose();
	rigidBody.pActor->releaseBounds(*pBounds);
}

bool Shape::create(const ShapeDesc& desc, ShapeType type, const golem::obj_ptr<BoundsDesc>& pBoundsDesc) {
	this->type = type;
	this->density = desc.density;
	this->color = desc.color;

	// pBoundsDesc must be initialized before
	if (pBoundsDesc == 0)
		throw ExTinyShape(Message::LEVEL_CRIT, "Shape::create(): Unable to create bounds description");
	
	this->pBoundsDesc = pBoundsDesc;

	pNxShapeDesc = rigidBody.scene.createNxShapeDesc(this->pBoundsDesc->pBoundsDesc); // throws
	if (pNxShapeDesc == 0)
		return false;
	pNxShapeDesc->density = NxReal(this->density);
	// pBounds created in container

	return true;
}

ShapeType Shape::getType() const {
	return type;
}

RGBA Shape::getColor() const {
	return color;
}

golem::Mat34 Shape::getLocalPose() const {
	return pBounds->getPose();
}

int Shape::getGroup() const {
	return (int)pBounds->getGroup();
}

void Shape::setGroup(int group) {
	rigidBody.pActor->setBoundsGroup(*pBounds, U32(group));
}

ShapeDescPtr Shape::getDesc() const {
	return pShapeDesc;
}

//------------------------------------------------------------------------------

PlaneShape::PlaneShape(RigidBody& rigidBody) : Shape(rigidBody) {
}
bool PlaneShape::create(const PlaneShapeDesc& desc) {
	BoundingPlane::Desc* pDesc = new BoundingPlane::Desc();
	Bounds::Desc::Ptr pBoundsDesc(pDesc);
	pDesc->pose = desc.localPose;
	pDesc->normal = desc.normal;
	pDesc->distance = (Real)desc.distance;
	return Shape::create(desc, ShapeTypePlane, obj_ptr<BoundsDesc>(new BoundsDesc(pBoundsDesc)));
}

SphereShape::SphereShape(RigidBody& rigidBody) : Shape(rigidBody) {
}
bool SphereShape::create(const SphereShapeDesc& desc) {
	BoundingSphere::Desc* pDesc = new BoundingSphere::Desc();
	Bounds::Desc::Ptr pBoundsDesc(pDesc);
	pDesc->pose = desc.localPose;
	pDesc->radius = (Real)desc.radius;
	return Shape::create(desc, ShapeTypeSphere, obj_ptr<BoundsDesc>(new BoundsDesc(pBoundsDesc)));
}

CylinderShape::CylinderShape(RigidBody& rigidBody) : Shape(rigidBody) {
}
bool CylinderShape::create(const CylinderShapeDesc& desc) {
	BoundingCylinder::Desc* pDesc = new BoundingCylinder::Desc();
	Bounds::Desc::Ptr pBoundsDesc(pDesc);
	pDesc->pose = desc.localPose;
	pDesc->radius = (Real)desc.radius;
	pDesc->length = (Real)desc.length;
	return Shape::create(desc, ShapeTypeCylinder, obj_ptr<BoundsDesc>(new BoundsDesc(pBoundsDesc)));
}

BoxShape::BoxShape(RigidBody& rigidBody) : Shape(rigidBody) {
}
bool BoxShape::create(const BoxShapeDesc& desc) {
	BoundingBox::Desc* pDesc = new BoundingBox::Desc();
	Bounds::Desc::Ptr pBoundsDesc(pDesc);
	pDesc->pose = desc.localPose;
	pDesc->dimensions = desc.dimensions;
	return Shape::create(desc, ShapeTypeBox, obj_ptr<BoundsDesc>(new BoundsDesc(pBoundsDesc)));
}

ConvexMeshShape::ConvexMeshShape(RigidBody& rigidBody) : Shape(rigidBody) {
}
bool ConvexMeshShape::create(const ConvexMeshShapeDesc& desc) {
	BoundingConvexMesh::Desc* pDesc = new BoundingConvexMesh::Desc();
	Bounds::Desc::Ptr pBoundsDesc(pDesc);
	pDesc->pose = desc.localPose;
	pDesc->vertices = desc.vertices;
	pDesc->bCook = true;
	return Shape::create(desc, ShapeTypeConvexMesh, obj_ptr<BoundsDesc>(new BoundsDesc(pBoundsDesc)));
}

//------------------------------------------------------------------------------

Actor::Actor(Tiny& tiny) : tiny(tiny), context(*tiny.pContext), scene(*tiny.pScene), pXMLContext(tiny.pXMLContext), owner(false) {
}

Actor::~Actor() {
}

RigidBody::RigidBody(Tiny& tiny) : Actor(tiny), pActor(0) {
}

RigidBody::~RigidBody() {
	shapeList.clear(); // release shapes before releasing the Actor
	if (pActor == 0 || !owner)
		return;
	scene.releaseObject(*pActor);
}

ShapePtr RigidBody::createShape(const golem::Bounds* pBounds) {
	ShapeDescPtr pShapeDesc;
	ShapePtr pShape;

	switch (pBounds->getType()) {
	case Bounds::TYPE_PLANE:
		{
			PlaneShapeDesc* pDesc = new PlaneShapeDesc;
			pShapeDesc.reset(pDesc);
			pDesc->normal = dynamic_cast<const BoundingPlane*>(pBounds)->getNormal();
			pDesc->distance = (double)dynamic_cast<const BoundingPlane*>(pBounds)->getDistance();
		}
		break;
	case Bounds::TYPE_SPHERE:
		{
			SphereShapeDesc* pDesc = new SphereShapeDesc;
			pShapeDesc.reset(pDesc);
			pDesc->radius = (double)dynamic_cast<const BoundingSphere*>(pBounds)->getRadius();
		}
		break;
	case Bounds::TYPE_CYLINDER:
		{
			CylinderShapeDesc* pDesc = new CylinderShapeDesc;
			pShapeDesc.reset(pDesc);
			pDesc->radius = (double)dynamic_cast<const BoundingCylinder*>(pBounds)->getRadius();
			pDesc->length = (double)dynamic_cast<const BoundingCylinder*>(pBounds)->getLength();
		}
		break;
	case Bounds::TYPE_BOX:
		{
			BoxShapeDesc* pDesc = new BoxShapeDesc;
			pShapeDesc.reset(pDesc);
			pDesc->dimensions = dynamic_cast<const BoundingBox*>(pBounds)->getDimensions();
		}
		break;
	case Bounds::TYPE_CONVEX_MESH:
		{
			ConvexMeshShapeDesc* pDesc = new ConvexMeshShapeDesc;
			pShapeDesc.reset(pDesc);
			const BoundingConvexMesh* pBoundingConvexMesh = dynamic_cast<const BoundingConvexMesh*>(pBounds);
			pDesc->vertices = pBoundingConvexMesh->getVertices();
		}
		break;
	}
	if (pShapeDesc == 0)
		return pShape;

	pShapeDesc->localPose = pBounds->getPose();
	pShapeDesc->group = (int)pBounds->getGroup();

	pShape = pShapeDesc->create(*this);// throws
	if (pShape == 0)
		return pShape;
	pShape->pShapeDesc = pShapeDesc;
	pShape->pBounds = pBounds;
	
	return pShape;
}

bool RigidBody::create(const RigidBodyDesc& desc) {
	kinematic = desc.kinematic;

	golem::Actor::Desc actorDesc;
	actorDesc.kinematic = desc.kinematic;
	//actorDesc.appearance.solidColour = ;
	actorDesc.nxActorDesc.globalPose.M.setRowMajor(&desc.globalPose.R.m11);
	actorDesc.nxActorDesc.globalPose.t.set(&desc.globalPose.p.v1);
	NxBodyDesc nxBodyDesc;
	actorDesc.nxActorDesc.body = &nxBodyDesc;
	actorDesc.nxActorDesc.density = NxReal(1.0);

	shapeList.clear();
	for (ShapeDescSeq::const_iterator i = desc.shapes.begin(); i != desc.shapes.end(); i++) {
		ShapePtr pShape = (**i).create(*this); // throws
		if (pShape == 0 || pShape->pNxShapeDesc == 0)
			return false;
		pShape->pShapeDesc = *i;
		
		if (pShape->getType() == ShapeTypePlane)
			actorDesc.nxActorDesc.body = 0; // Actors with Plane Shapes cannot have a body
		actorDesc.nxActorDesc.shapes.push_back(pShape->pNxShapeDesc);
		
		shapeList.push_back(ShapeList::Pair(pShape.get(), pShape));
	}

	pActor = dynamic_cast<golem::Actor*>(scene.createObject(actorDesc)); // throws
	if (pActor == 0)
		return false;
	
	const golem::Actor::BoundsConstSeq& boundsSeq = pActor->getBoundsSeq();
	golem::Actor::BoundsConstSeq::const_iterator i = boundsSeq.begin();
	ShapeList::iterator j = shapeList.begin();
	while (i != boundsSeq.end() && j != shapeList.end())
		(**j++).pBounds = *i++; // order is preserved
	
	return true;
}

Shape* RigidBody::createShape(const ShapeDescPtr& pShapeDesc) {
	try {
		if (pShapeDesc == 0)
			throw ExTinyShapeCreate(Message::LEVEL_CRIT, "RigidBody::createShape(): empty description");

		ShapePtr pShape = pShapeDesc->create(*this); // throws
		if (pShape == 0)
			return 0;
		pShape->pShapeDesc = pShapeDesc;

		pShape->pBounds = pActor->createBounds(pShape->pBoundsDesc->pBoundsDesc); // throws
		if (pShape->pBounds == 0)
			return 0;
		pShape->owner = true;

		shapeList.push_back(ShapeList::Pair(pShape.get(), pShape));
		return pShape.get();
	}
	catch (const Message& ex) {
		throw ExTinyShapeCreate(Message::LEVEL_CRIT, "RigidBody::createShape(): %s", ex.str()); // translate
	}
	catch (const std::exception &ex) {
		throw ExTinyShapeCreate( Message::LEVEL_CRIT, "RigidBody::createShape(): C++ exception: %s", ex.what()); // translate
	}

	return 0;
}

void RigidBody::releaseShape(Shape* shape) {
	if (!shapeList.contains(shape))
		throw ExTinyShapeNotFound(Message::LEVEL_CRIT, "RigidBody::releaseShape(): Unable to find specified Shape");
	if (!shape->owner)
		throw ExTinyShapeNotRemovable(Message::LEVEL_CRIT, "RigidBody::releaseShape(): The specified Shape cannot be removed");
	shapeList.erase(shape);
}

ShapeSeqPtr RigidBody::getShapes() const {
	ShapeSeqPtr pShapeSeq(new ShapeSeq);
	pShapeSeq->insert(pShapeSeq->begin(), shapeList.begin(), shapeList.end());
	return pShapeSeq;
}

golem::Mat34 RigidBody::getGlobalPose() const {
	return pActor->getPose();
}

void RigidBody::setGlobalPose(const golem::Mat34& pose) {
	pActor->setPose(pose);
}

void RigidBody::setGroup(int group) {
	pActor->setBoundsGroup(U32(group));
}

//------------------------------------------------------------------------------

Joint::Joint(Arm& arm) : RigidBody(arm.tiny), arm(arm) {
}

bool Joint::create(const JointDesc& desc) {
	ASSERT(desc.pJointActor)
	pActor = desc.pJointActor;
	kinematic = true;
	
	shapeList.clear();
	const golem::Actor::BoundsConstSeq& boundsSeq = pActor->getBoundsSeq();
	for (golem::Actor::BoundsConstSeq::const_iterator i = boundsSeq.begin(); i != boundsSeq.end(); i++) {
		ShapePtr pShape = RigidBody::createShape(*i); // throws
		if (pShape == 0)
			return false;
		shapeList.push_back(ShapeList::Pair(pShape.get(), pShape));
	}

	return true;
}

ActorPtr JointDesc::create(Tiny& tiny) const {
	// Joint cannot be created as a normal Actor, return 0
	return ActorPtr();
}

Arm::Arm(Tiny& tiny) : Actor(tiny), pPhysReacPlanner(0) {
}

Arm::~Arm() {
	jointList.clear(); // joints wrappers must be released before PhysReacPlanner!
	if (pPhysReacPlanner == 0 || !owner)
		return;
	scene.releaseObject(*pPhysReacPlanner);
}

bool Arm::create(const PhysReacPlannerDesc& desc) {
	// create controller
	pPhysReacPlanner = dynamic_cast<golem::PhysReacPlanner*>(scene.createObject(desc));// throws
	if (pPhysReacPlanner == 0)
		return false;

	// create joints
	jointList.clear();
	const golem::JointActor::Seq& jointActorSeq = pPhysReacPlanner->getJointActors();
	for (golem::JointActor::Seq::const_iterator i = jointActorSeq.begin(); i != jointActorSeq.end(); i++) {
		JointPtr pJoint;
		if (*i != 0) { // Joint may have no body
			JointDesc jointDesc;
			jointDesc.pJointActor = *i;
			pJoint = jointDesc.create(*this); // throws
			if (pJoint == 0)
				return false;
			jointList.push_back(JointList::Pair(pJoint.get(), pJoint));
		}
	}

	return true;
}

double Arm::getTimeDelta() const {
	return (double)pPhysReacPlanner->getReacPlanner().getTimeDelta();
}

double Arm::getTimeDeltaAsync() const {
	return (double)pPhysReacPlanner->getReacPlanner().getTimeDeltaAsync();
}

void Arm::setGenConfigspaceState(const GenConfigspaceState& target, ActionType action) {
	(void)pPhysReacPlanner->getReacPlanner().send(make(target), make(action));
}

void Arm::setGenWorkspaceState(const GenWorkspaceState& target, ActionType action) {
	(void)pPhysReacPlanner->getReacPlanner().send(make(target), make(action));
}

bool Arm::waitForBegin(double timeOut) {
//	if (!pPhysReacPlanner->getReacPlanner().waitForBegin(golem::MSecTmU32(1000.*timeOut)))
//		throw ExTinyArmTimeOut(Message::LEVEL_CRIT, "Arm::waitForBegin(): operation time out");
	return pPhysReacPlanner->getReacPlanner().waitForBegin(golem::MSecTmU32(1000.*timeOut));
}

bool Arm::waitForEnd(double timeOut) {
//	if (!pPhysReacPlanner->getReacPlanner().waitForEnd(golem::MSecTmU32(1000.*timeOut)))
//		throw ExTinyArmTimeOut(Message::LEVEL_CRIT, "Arm::waitForBegin(): operation time out");
	return pPhysReacPlanner->getReacPlanner().waitForEnd(golem::MSecTmU32(1000.*timeOut));
}

GenConfigspaceState Arm::getGenConfigspaceState(double t) const {
	golem::GenConfigspaceState gcs;
	pPhysReacPlanner->getArm().lookupInp(gcs, t);
	return make(gcs);
}

GenWorkspaceState Arm::getGenWorkspaceState(double t) const {
	golem::GenConfigspaceState gcs;
	pPhysReacPlanner->getArm().lookupInp(gcs, t);
	golem::GenWorkspaceState gws;
	pPhysReacPlanner->getArm().forwardTransform(gws.pos, gcs.pos);
	gws.vel.set(Vec3(REAL_ZERO), Vec3(REAL_ZERO)); // TODO
	gws.t = gcs.t;
	return make(gws);
}

JointSeqPtr Arm::getJoints() const {
	JointSeqPtr pJointSeq(new JointSeq());
	pJointSeq->insert(pJointSeq->begin(), jointList.begin(), jointList.end());
	return pJointSeq;
}

int Arm::getArmGroup() const {
	return (int)pPhysReacPlanner->getArmBoundsGroup();
}

int Arm::getCollisionGroup() const {
	return (int)pPhysReacPlanner->getCollisionBoundsGroup();
}

void Arm::setCollisionGroup(int group) {
	pPhysReacPlanner->setCollisionBoundsGroup((U32)group);
}

golem::Mat34 Arm::getGlobalPose() const {
	return pPhysReacPlanner->getArm().getGlobalPose();
}

void Arm::setGlobalPose(const golem::Mat34& pose) {
	pPhysReacPlanner->getArm().setGlobalPose(pose);
}

golem::Mat34 Arm::getReferencePose() const {
	return pPhysReacPlanner->getArm().getReferencePose();
}

void Arm::setReferencePose(const golem::Mat34& pose) {
	pPhysReacPlanner->getArm().setReferencePose(pose);
}

//------------------------------------------------------------------------------

SimArm::SimArm(Tiny& tiny) : Arm(tiny) {
}


GenSimArm::GenSimArm(Tiny& tiny) : SimArm(tiny) {
}

bool GenSimArm::create(const GenSimArmDesc& desc) {
	golem::tiny::PhysReacPlannerDesc physReacPlannerDesc;
	golem::GenSimArm::Desc *pDesc = new golem::GenSimArm::Desc();
	physReacPlannerDesc.pArmDesc.reset(pDesc);
	
	pDesc->globalPose = desc.globalPose;

	XMLData("delta_offs", pDesc->deltaOffs, pXMLContext->getContextFirst("arm calibration"));
	XMLData("skew_offs", pDesc->skewOffs, pXMLContext->getContextFirst("arm calibration"));
	return Arm::create(physReacPlannerDesc);
}

KatSimArm::KatSimArm(Tiny& tiny) : SimArm(tiny) {
}

bool KatSimArm::create(const KatSimArmDesc& desc) {
	golem::tiny::PhysReacPlannerDesc physReacPlannerDesc;
	golem::KatSimArm::Desc *pDesc = new golem::KatSimArm::Desc();
	physReacPlannerDesc.pArmDesc.reset(pDesc);
	
	pDesc->globalPose = desc.globalPose;
	
	XMLData("delta_offs", pDesc->deltaOffs, pXMLContext->getContextFirst("arm calibration"));
	XMLData("skew_offs", pDesc->skewOffs, pXMLContext->getContextFirst("arm calibration"));
	return Arm::create(physReacPlannerDesc);
}

//------------------------------------------------------------------------------

KatArm::KatArm(Tiny& tiny) : Arm(tiny) {
}

bool KatArm::create(const KatArmDesc& desc) {
	golem::tiny::PhysReacPlannerDesc physReacPlannerDesc;
	golem::KatSerialArm::Desc *pDesc = new golem::KatSerialArm::Desc();
	physReacPlannerDesc.pArmDesc.reset(pDesc);

	pDesc->globalPose = desc.globalPose;
	
	XMLData("path", pDesc->cfgPath, pXMLContext->getContextFirst("arm kat_serial_arm config"));
	XMLData("port", pDesc->serialDesc.commPort, pXMLContext->getContextFirst("arm kat_serial_arm comm"));
	XMLData("delta_offs", pDesc->deltaOffs, pXMLContext->getContextFirst("arm calibration"));
	XMLData("skew_offs", pDesc->skewOffs, pXMLContext->getContextFirst("arm calibration"));

	pDesc->bGripper = desc.bGripper;
	pDesc->sensorIndexSet = desc.sensorIndexSet;

	if (!Arm::create(physReacPlannerDesc))
		return false;

	pKatArm = dynamic_cast<golem::KatArm*>(&pPhysReacPlanner->getArm());
	ASSERT(pKatArm) // this should never happen
	return true;
}

bool KatArm::gripperRecvSensorData(KatSensorDataSet& sensorData, double timeOut) {
	if (!pKatArm->hasGripper())
		throw ExTinyArm(Message::LEVEL_CRIT, "KatArm::gripperRecvSensorData(): gripper not initialized");

	golem::KatArm::SensorDataSet data;
	if (!pKatArm->gripperRecvSensorData(data, golem::MSecTmU32(1000.*timeOut)))
		return false;

	sensorData.clear();
	for (golem::KatArm::SensorDataSet::const_iterator i = data.begin(); i != data.end(); i++)
		sensorData.push_back(make(*i));

	return true;
}

bool KatArm::gripperRecvEncoderData(KatGripperEncoderData& encoderData, double timeOut) {
	if (!pKatArm->hasGripper())
		throw ExTinyArm(Message::LEVEL_CRIT, "KatArm::gripperRecvEncoderData(): gripper not initialized");

	golem::KatArm::GripperEncoderData data;
	if (!pKatArm->gripperRecvEncoderData(data, golem::MSecTmU32(1000.*timeOut)))
		return false;

	encoderData = make(data);

	return true;
}

bool KatArm::gripperOpen(double timeOut) {
	if (!pKatArm->hasGripper())
		throw ExTinyArm(Message::LEVEL_CRIT, "KatArm::gripperOpen(): gripper not initialized");

	return pKatArm->gripperOpen(golem::MSecTmU32(1000.*timeOut));
}

bool KatArm::gripperClose(const KatSensorDataSet& sensorThreshold, double timeOut) {
	if (!pKatArm->hasGripper())
		throw ExTinyArm(Message::LEVEL_CRIT, "KatArm::gripperClose(): gripper not initialized");

	golem::KatArm::SensorDataSet threshold;
	for (KatSensorDataSet::const_iterator i = sensorThreshold.begin(); i != sensorThreshold.end(); i++)
		threshold.push_back(make(*i));

	return pKatArm->gripperClose(threshold, golem::MSecTmU32(1000.*timeOut));
}

bool KatArm::gripperFreeze(double timeOut) {
	if (!pKatArm->hasGripper())
		throw ExTinyArm(Message::LEVEL_CRIT, "KatArm::gripperFreeze(): gripper not initialized");

	return pKatArm->gripperFreeze(golem::MSecTmU32(1000.*timeOut));
}

//------------------------------------------------------------------------------

Tiny::Tiny(int argc, char *argv[]) {
	try {
		// Determine configuration file name
		std::string cfg;
		if (argc == 1) {
			// default configuration file name
			cfg.assign(argv[0]);
#ifdef WIN32
			size_t pos = cfg.rfind(".exe"); // Windows only
			if (pos != std::string::npos) cfg.erase(pos);
#endif
			cfg.append(".xml");
		}
		else
			cfg.assign(argv[1]);

		// Create XML parser and load configuration file
		XMLParser::Desc parserDesc;
		pParser = parserDesc.create();
		FileReadStream fs(cfg.c_str());
		pParser->load(fs); // throw

		// Find program XML root context
		pXMLContext = pParser->getContextRoot()->getContextFirst("golem");
		if (pXMLContext == 0)
			throw ExTinyCreate(Message::LEVEL_CRIT, "Unknown configuration file: %s", cfg.c_str());

		// Create program context
		Context::Desc contextDesc;
		XMLData(contextDesc, pXMLContext);
		pContext = contextDesc.create(); // throw
		if (pContext == 0)
			return;
		
		// Create Universe
		golem::Universe::Desc universeDesc;
		universeDesc.name = "Golem (Tiny)";
		XMLData(universeDesc, pXMLContext->getContextFirst("universe"));
		universeDesc.argc = argc;
		universeDesc.argv = argv;
		pUniverse = universeDesc.create(*pContext);

		// Create scene
		golem::Scene::Desc sceneDesc;
		sceneDesc.name = "Tiny interface";
		XMLData(sceneDesc, pXMLContext->getContextFirst("scene"));
		pScene = pUniverse->createScene(sceneDesc);

		// Launching Universe
		pUniverse->launch();
	}
	catch (const ExTinyCreate& ex) {
		throw ex;
	}
	catch (const golem::Message& ex) {
		throw ExTinyCreate(Message::LEVEL_CRIT, "Tiny::Tiny(): %s", ex.str()); // translate
	}
	catch (const std::exception &ex) {
		throw ExTinyCreate(Message::LEVEL_CRIT, "Tiny::Tiny(): C++ exception: %s", ex.what()); // translate
	}
}

Tiny::~Tiny() {
	actorList.clear();
	pUniverse.release();
}

//------------------------------------------------------------------------------

double Tiny::getTime() const {
	return (double)pContext->getTimer()->elapsed();
}

void Tiny::sleep(double duration) const {
	pContext->getTimer()->sleep(SecTmReal(duration));
}

void Tiny::print(const char* format, ...) {
	va_list argptr;
	va_start(argptr, format);
	pContext->getLogger()->post(new ExTiny(pContext->getTimer()->elapsed(), Message::LEVEL_UNDEF, format, argptr));
	va_end(argptr);
}

bool Tiny::interrupted() const {
	return pUniverse->interrupted();
}

int Tiny::waitKey(double timeOut) {
	return pUniverse->waitKey((MSecTmU32)(1000.0*Math::clamp(timeOut, F64(REAL_ZERO), double(MSEC_TM_U32_INF)/1000.0)));
}

const golem::XMLContext* Tiny::getXMLContext() const {
	return pXMLContext;
}
golem::XMLContext* Tiny::getXMLContext() {
	return pXMLContext;
}

const golem::Context* Tiny::getContext() const {
	return pContext.get();
}
golem::Context* Tiny::getContext() {
	return pContext.get();
}

Actor* Tiny::createActor(const ActorDescPtr& pActorDesc) {
	try {
		if (pActorDesc == 0)
			throw ExTinyActorCreate(Message::LEVEL_CRIT, "Tiny::createActor(): empty description");

		ActorPtr pActor = pActorDesc->create(*this);
		if (pActor == 0)
			return 0;
		
		pActor->owner = true;
		actorList.push_back(ActorList::Pair(pActor.get(), pActor));
		return pActor.get();
	}
	catch (const Message& ex) {
		throw ExTinyActorCreate(Message::LEVEL_CRIT, "Tiny::createActor(): %s", ex.str()); // translate
	}
	catch (const std::exception &ex) {
		throw ExTinyActorCreate(Message::LEVEL_CRIT, "Tiny::createActor(): C++ exception: %s", ex.what()); // translate
	}

	return 0;
}

void Tiny::releaseActor(Actor* actor) {
	if (!actorList.contains(actor))
		throw ExTinyActorNotFound(Message::LEVEL_CRIT, "Tiny::releaseActor(): Unable to find specified Actor");
	if (!actor->owner)
		throw ExTinyActorNotRemovable(Message::LEVEL_CRIT, "Tiny::releaseActor(): The specified Actor cannot be removed");

	actorList.erase(actor);
}

ActorSeqPtr Tiny::getActors() const {
	ActorSeqPtr pActorSeq(new ActorSeq());
	pActorSeq->insert(pActorSeq->begin(), actorList.begin(), actorList.end());
	return pActorSeq;
}

//------------------------------------------------------------------------------

void Tiny::bang() {
	pContext->getLogger()->post(Message::LEVEL_UNDEF, "Bang!");

	Rand rand(pContext->getRandSeed());
	golem::Creator creator(*pScene);
	golem::Actor::Desc *pActorDesc = creator.createTreeDesc(rand.nextUniform(Real(0.07), Real(0.10)));
	pActorDesc->nxActorDesc.globalPose.t.set(
		rand.nextUniform(NxReal(-0.3), NxReal(0.3)),
		rand.nextUniform(NxReal(-0.3), NxReal(0.3)),
		rand.nextUniform(NxReal(+0.3), NxReal(0.9))
	);
	pScene->createObject(*pActorDesc);
}

//------------------------------------------------------------------------------
