#!/usr/bin/env python
import time
import sys
from optparse import OptionParser
from pylab import *
from glob import *
import gobject
from math import *

class Anim:
	def __init__(self, filepattern):
		self.axes = gca()
		self.files = glob(filepattern)
#		print self.files
		self.filenum = 0

	def update(self):
		if gca() <> self.axes:
			sys.exit(1) 
			return False
		data = load(self.files[self.filenum])
		self.filenum += 1
		if self.filenum == len(self.files) - 1:
			self.filenum = 0

		#clear axes
		self.axes.cla()

		# add data to figure

		if options.max:
			maxData = []
			for row in data:
				maxData.append(max(row))
			self.axes.plot(maxData, linewidth=1.5)
		else:
			for c in range(data.shape[1]):
				lineData = data[:, c]
				if options.backward:
					lineData = data[::-1, c]
				else:
					lineData = data[:, c]
				self.axes.plot(lineData, linewidth=1.5)

		#set the axis range, if requested
		if (options.lo <> 0 or  options.hi <> 0):
			self.axes.set_ylim( (options.lo,options.hi))

		#show legend, if requested
		if options.key:
			legend()
		
		# redraw the canvas
		draw()
		return True


# parse command line options
ion()
usage = "usage: %prog [options] filepattern"
parser = OptionParser(usage)
parser.add_option("-l", "--lo", dest="lo", default=0, action="store", type=float, help="lo value for y axis (auto if hi and lo 0)")
parser.add_option("-i", "--hi", dest="hi", default=0, action="store", type=float, help="hi value for y axis (auto if hi and lo 0)")
parser.add_option("-k", "--key", dest="key", default=False, action="store_true", help="display key")
parser.add_option("-b", "--backward", dest="backward", default=False, action="store_true", help="plot backward?")
parser.add_option("-m", "--max", dest="max", default=False, action="store_true", help="only plot maximum value?")
(options, args) = parser.parse_args()
print options
if len(args) != 1:
        parser.error("incorrect number of arguments")
filepattern = args[0]
print "input file pattern", filepattern

#use filepattern to find files
anim = Anim(filepattern)
gobject.idle_add(anim.update)
show()
