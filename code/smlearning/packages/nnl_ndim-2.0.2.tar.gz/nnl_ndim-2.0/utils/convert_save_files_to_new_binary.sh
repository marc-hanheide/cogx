#! /bin/bash
if [ $# = 2 ]
then
	OLD_FILE=$1
	NEW_FILE=$2
	TASK=$3
	sed "s:<ForwardLayers>:<Levels>:g" $OLD_FILE |
	sed 's:<Object name="output">:<Object name="output">\n\t\t\t<Param name="contiguous" val="1"/>:g' |
	sed 's:<Net type="bidirectional ctc":<Net task="transcription" multidirectional="1":g' |
	sed 's:<Net type="bidirectional classification":<Net task="classification" multidirectional="1":g' |
	sed 's:<Net type="ctc":<Net task="transcription" multidirectional="0":g' |
	sed 's:<Net type="classification":<Net task="classification" multidirectional="0":g' |
	sed 's:<Net type="regression":<Net task="regression" multidirectional="0":g' |
	sed 's:<Net type="bidirectional regression":<Net task="regression" multidirectional="1":g' |
	sed "s:</ForwardLayers>:</Levels>:g"|
	sed "s:numBlocks:size:g" |
	sed "s:backwardInput:input:g"|
	sed "s:forward:level_0_subnet_0:g" |
	sed "s:backward:level_0_subnet_1:g" |
	sed "s:level_0_subnet_0_to_level_0_subnet_0_conn:level_0_subnet_0_to_level_0_subnet_0_conn_0:g" |
	sed "s:level_0_subnet_1_to_level_0_subnet_1_conn:level_0_subnet_1_to_level_0_subnet_1_conn_0:g" > $NEW_FILE
else
        echo "usage: old_filename new_filename"
fi

