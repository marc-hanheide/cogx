#! /usr/bin/env python

from matplotlib.transforms import blend_xy_sep_transform
from matplotlib.lines import Line2D
from optparse import OptionParser
from pylab import *
import sys

# parse command line options
usage = "usage: %prog [options] input-file"
parser = OptionParser(usage)
parser.add_option("-s", "--style", dest="linestyle", default="None", action="store", type="string", help="Line styles not implemented yet")
parser.add_option("-o", "--output", dest="outputFilename", default="screen", action="store", type="string", help="output filename (screen = plot to screen)")
parser.add_option("-g", "--gridplot", dest="gridPlot", default=False, action="store_true", help="do grid plot?")
parser.add_option("-n", "--numgrids", dest="numGrids", default=1, action="store", type=int, help="number of grids per data line (gridPlot only)")
parser.add_option("-w", "--gridwidth", dest="gridWidth", default=0, action="store", type=int, help="width of grids (gridPlot only; assumed square if <= 0)")
parser.add_option("-l", "--lo", dest="lo", default=0, action="store", type=float, help="lo value for y axis (auto if hi and lo 0)")
parser.add_option("-i", "--hi", dest="hi", default=0, action="store", type=float, help="hi value for y axis (auto if hi and lo 0)")
parser.add_option("-k", "--key", dest="key", default=False, action="store_true", help="display key")
parser.add_option("-p", "--nosp", dest="noSp", default=False, action="store_true", help="don't print 'sp' labels (IAM specific)")
parser.add_option("-a", "--noaxes", dest="noAxes", default=False, action="store_true", help="don't show axes")
parser.add_option("-c", "--colour", dest="colour", default=False, action="store_true", help="plot in colour? (gridPlot only)")
parser.add_option("-m", "--min", dest="min", default=0, action="store", type=int, help="min value for x axis (auto if 0)")
parser.add_option("-x", "--max", dest="max", default=0, action="store", type=int, help="max value for y axis (auto if 0)")
parser.add_option("-t", "--transpose", dest="transpose", default=False, action="store_true", help="transpose data?")
parser.add_option("-f", "--flipud", dest="flipud", default=False, action="store_true", help="flip data upside down?")
parser.add_option("-b", "--abs", dest="abs", default=False, action="store_true", help="plot absolute values?")
parser.add_option("-r", "--rotate", dest="rotate", default=True, action="store_false", help="rotate data 90 degrees?")
parser.add_option("--ycropbegin", dest="yCropBegin", default=0, action="store", type=int, help="y crop begin")
parser.add_option("--ycropend", dest="yCropEnd", default=-1, action="store", type=int, help="y crop end")
parser.add_option("--xcropbegin", dest="xCropBegin", default=0, action="store", type=int, help="x crop begin")
parser.add_option("--xcropend", dest="xCropEnd", default=-1, action="store", type=int, help="x crop end")
parser.add_option("--showallgrids", dest="showAllGrids", default=False, action="store_true", help="show all grids? (otherwise limited to 10)")
parser.add_option("-v", "--vectorplot", dest="vectorPlot", default=False, action="store_true", help="plot vector field?")
(options, args) = parser.parse_args()

if len(args) != 1:
        parser.error("incorrect number of arguments")
infilename = args[0]

print options
print "input filename", infilename

#read header (if any)
numRowsToSkip = 0
labels = []
data = file(infilename)
plotMax = False
dimensions = []
line = data.readline().split()
while line[0][-1] == ':' or line[0] == "#":
	print line
	if line[0] == "LABELS:" or line[0] == "#":
		labels = line[1:]
		labels.append("blank")
		numRowsToSkip += 1
		plotMax = True
	if line[0] == "DIMENSIONS:":
		for d in line[1:]:
			dimensions.append(int(d))
		numRowsToSkip += 1
		if len(dimensions) >= 2 and int(dimensions[0]) > 1:
			options.gridPlot = True
			options.gridWidth = dimensions[1]
			if (len(dimensions) > 2):
				options.numGrids = product(dimensions[2:])
	line = data.readline().split()
print 'numRowsToSkip',numRowsToSkip
		
# load data file
data = load(infilename, skiprows=numRowsToSkip)
if options.abs:
	new_data = []
	for l in data:
		new_data.append(fabs(l))
	data = array(new_data)

if len(data.shape) == 1:
	data.shape = (1, data.shape[0])
	
print data.shape

if (options.transpose):
	data = transpose(data)
	print data.shape

#print data
if options.max:
	data = data[options.min:options.max]
elif options.min:
	data = data[options.min:]

if options.gridPlot and len(data) > 5 and not options.showAllGrids:
	data = data[:5]

#print data
def pcolorLine(line):
	area = int(len(line)/options.numGrids)
	if options.gridWidth > 1:
		width = options.gridWidth
		height = area / width
	else:	
		height = width = int(sqrt(area))
	print "area",area,"width",width,"height",height
	begin=0
	rowscols = ceil(sqrt(options.numGrids))
	vectorGrids = []
	for i in range(options.numGrids):
		#get the data
		end = begin + area
		grid = line[begin:end]
		if options.abs:
			newgrid = []
			for g in grid:
				newgrid.append(math.fabs(g))
			grid = array(newgrid)
		begin = end
		grid.shape = (width,height)
		if not options.vectorPlot:
			subplot(rowscols, rowscols, i+1) 
		if options.rotate:
			grid = rot90(grid)
		if options.flipud:
			grid = flipud(grid)
		cropped = False
		if options.yCropBegin <> 0 or options.yCropEnd <> -1:
			grid = grid[options.yCropBegin: options.yCropEnd]
			cropped = True
		if options.xCropBegin <> 0 or options.xCropEnd <> -1:
			newGrid = []
			for line in grid:
				newGrid.append(line[options.xCropBegin: options.xCropEnd])
			grid = array(newGrid)
			cropped = True
		if cropped:
			print 'cropped to', grid.shape
		if options.vectorPlot:
			vectorGrids.append(grid)
			#print grid
		else:
			pcolor(grid, shading = 'flat')
			setp(gca(),xticks=[],yticks=[],axisbelow='false',frame_on='false',xlim=(0.0,float(grid.shape[1])),ylim=(0.0,float(grid.shape[0])))
	if options.vectorPlot:
		return vectorGrids, rowscols
	
if options.gridPlot:

	if not options.colour:
		gray()

	if options.vectorPlot:
		fig = figure()
		xGrids, rowscols = pcolorLine(data[0])
		yGrids, rowscols2 = pcolorLine(data[1])
		#print xGrids
		#print yGrids
		for n in range(len(xGrids)):
			subplot(rowscols, rowscols, n+1) 
			quiver(xGrids[n], yGrids[n])
			setp(gca(),xticks=[],yticks=[],axisbelow='false',frame_on='false',xlim=(0.0,float(xGrids[0].shape[0])),ylim=(0.0,float(xGrids[0].shape[1])))
		
	else:
		for line in data:
			fig = figure()
			pcolorLine(line)
else:

	# create figure
	fig = figure()
	axes = axes()

	# add data to figure
	lineLabelMap = dict()
	colors = []
	cEndOffset = 0
	if plotMax and options.noSp:
			cEndOffset = -1
	for c in range(data.shape[0] + cEndOffset):
		label=str(c)
		lineData = data[c,:]
		if len(labels):
			lab = labels[c]
		else:
			lab = str(c)
		line2d = axes.plot(lineData, linewidth=1.5, label = lab)[0]
		colors.append(line2d.get_color())
		lineLabelMap[line2d] = label

	if plotMax:
		prevMaxNum = -1
		#prevMaxRow = 0
		#yCoord = 0
		yPlotCoord = axes.get_ylim()[1] + 0.01 * (axes.get_ylim()[1] - axes.get_ylim()[0])
		#prevXCoord = -1000
		for r in range(data.shape[1]):
			max = 0
			maxNum = -1
			for v in range(len(data[:,r])):
				val = abs(data[v][r])
				if val > max:
					max = val
					maxNum = v
			if maxNum < len(labels) -1 and maxNum <> prevMaxNum:
					text(r, yPlotCoord, labels[maxNum], {'color': 'black', 'fontsize' : 'medium'}, fontweight = 'bold', horizontalalignment = 'center', verticalalignment = 'bottom')
					prevMaxNum = maxNum
			#if maxNum == prevMaxNum and max > abs(yCoord):
				#yCoord = data[maxNum][r]
				#xCoord = r
			#if maxNum <> prevMaxNum or (r==data.shape[1]-1):
				#if prevMaxNum >= 0:
					#prevMaxRow = r
					#if prevMaxNum < len(labels)-1 and not (labels[prevMaxNum] == "sp" and options.noSp):
						#text(xCoord, yPlotCoord, labels[prevMaxNum], {'color': 'black', 'fontsize' : 'medium'}, fontweight = 'bold', horizontalalignment = 'center', verticalalignment = 'bottom')
						#prevXCoord = xCoord
				#yCoord = data[maxNum][r]
				#xCoord = r
				#prevMaxNum = maxNum

if (options.lo <> 0 or  options.hi <> 0):
	axes.set_ylim( (options.lo,options.hi))

if options.noAxes:
	axis('off')
else:
	axis('on')

if options.key:
	legend(prop = matplotlib.font_manager.FontProperties(size = 'smaller'))


def pick(event):
	if event.key=='p' and event.inaxes is not None:
		ax = event.inaxes
		a = ax.pick(event.x, event.y)

		if isinstance(a, Line2D) and a in lineLabelMap:
			labelNum = int(lineLabelMap[a])
			if labelNum >= 0 and labelNum < len(labels):
				print event.xdata, event.ydata, labels[labelNum], labelNum
				text(event.xdata, event.ydata, labels[labelNum], {'color': 'black', 'fontsize' : 'medium'}, fontweight = 'bold', horizontalalignment = 'center', verticalalignment = 'center')
				draw()


# show figure
if options.outputFilename == "screen":
	connect('key_press_event', pick)
	title(infilename)
	show()
else:
	savefig(options.outputFilename)




    












##!/usr/bin/env python
#"""
#Hold the pointer over an object and press "p" to pick it.  When
#picked it will turn red 
#
#Note this algorithm calculates distance to the vertices of the
#polygon, so if you want to pick a patch, click on the edge!
#
#"""
#from pylab import *
#from matplotlib.text import Text
#from matplotlib.lines import Line2D
#from matplotlib.patches import Patch
#
#def pick(event):
#    if event.key=='p' and event.inaxes is not None:
#        ax = event.inaxes
#        a = ax.pick(event.x, event.y)
#        
#	if isinstance(a, Text):
#            a.set_color('r')
#        elif isinstance(a, Line2D):
#            a.set_markerfacecolor('r')
#	elif isinstance(a, Patch):
#            a.set_facecolor('r')
#        draw()
#            
#    
#connect('key_press_event', pick)
#
#ax = subplot(111)
#title('Put mouse over object and press "p" to pick it')
#
#for i in range(20):
#    x, y = rand(2)
#    text(x,y,'hi!')
#
#for i in range(5):
#    x = rand(10)
#    y = rand(10)
#    plot(x,y,'go')
#
#for i in range(5):
#    x = rand()
#    y = rand()
#    center = x,y
#    p = Circle(center, radius=.1)
#    ax.add_patch(p)
#    
#
#show()
