#! /bin/bash
UTILS=/home/alex/code/neural_net_console-1.0/utils
PL=$UTILS/plt.py
BI=$UTILS/bi_error_join.py
DS=$UTILS/display_sequence.sh
MM=$UTILS/min_max.py
MBE=$UTILS/make_bi_errors.sh
if [ $# = 6 ]
then
	TIMESTEPS=$6
	T=0
	echo $TIMESTEPS
	while [ $T -lt  $TIMESTEPS ]
	do
		/bin/sh $DS $1 $2 $3 $4 $5 $T
		T=$[$T+1]
	done

#	LINE=$($MM "display_$1_$2_$3_$4_$5*/input_errors")
#	F_IN_MIN=$(echo $LINE | cut -f1 -d' ' --)
#	F_IN_MAX=$(echo $LINE | cut -f2 -d' ' --)
#	echo "forward input error range" $F_IN_MIN $F_IN_MAX
#	echo $F_IN_MIN $F_IN_MAX > forward_input_errors_min_max.txt
#
#	LINE=$($MM "display_$1_$2_$3_$4_$5*/backwardInput_errors")
#	B_IN_MIN=$(echo $LINE | cut -f1 -d' ' --)
#	B_IN_MAX=$(echo $LINE | cut -f2 -d' ' --)
#	echo "backward input error range" $B_IN_MIN $B_IN_MAX
#	echo $B_IN_MIN $B_IN_MAX > backward_input_errors_min_max.txt
#
#	IN_MIN=$F_IN_MIN
#	if (echo "$B_IN_MIN < $F_IN_MIN" | bc -l)
#	then
#		IN_MIN=$B_IN_MIN
#	fi
#	IN_MAX=$F_IN_MAX
#	if (echo "$B_IN_MAX > $F_IN_MAX" | bc -l)
#	then
#		IN_MAX=$B_IN_MAX
#	fi
#	echo "input error range" $IN_MIN $IN_MAX
#	echo $IN_MIN $IN_MAX > input_errors_min_max.txt
#
#	LINE=$($MM "display_$1_$2_$3_$4_$5*/forward_errors")
#	F_H_MIN=$(echo $LINE | cut -f1 -d' ' --)
#	F_H_MAX=$(echo $LINE | cut -f2 -d' ' --)
#	echo "forward hidden error range" $F_H_MIN $F_H_MAX
#	echo $F_H_MIN $F_H_MAX > forward_hidden_errors_min_max.txt
#
#	LINE=$($MM "display_$1_$2_$3_$4_$5*/backward_errors")
#	B_H_MIN=$(echo $LINE | cut -f1 -d' ' --)
#	B_H_MAX=$(echo $LINE | cut -f2 -d' ' --)
#	echo "backward hidden error range" $B_H_MIN $B_H_MAX
#	echo $B_H_MIN $B_H_MAX > backward_hidden_errors_min_max.txt
#
#	H_MIN=$F_H_MIN
#	if (echo "$B_H_MIN < $F_H_MIN" | bc -l)
#	then
#		H_MIN=$B_H_MIN
#	fi
#	H_MAX=$F_H_MAX
#	if (echo "$B_H_MAX > $F_H_MAX" | bc -l)
#	then
#		H_MAX=$B_H_MAX
#	fi
#	echo "hidden error range" $H_MIN $H_MAX
#	echo $H_MIN $H_MAX > hidden_errors_min_max.txt
#
#	LINE=$($MM "display_$1_$2_$3_$4_$5*/forward_cellErrors")
#	F_CH_MIN=$(echo $LINE | cut -f1 -d' ' --)
#	F_CH_MAX=$(echo $LINE | cut -f2 -d' ' --)
#	echo "foward hidden cell error range" $F_CH_MIN $F_CH_MAX
#	echo $F_CH_MIN $F_CH_MAX > forward_hidden_cell_errors_min_max.txt
#
#	LINE=$($MM "display_$1_$2_$3_$4_$5*/backward_cellErrors")
#	B_CH_MIN=$(echo $LINE | cut -f1 -d' ' --)
#	B_CH_MAX=$(echo $LINE | cut -f2 -d' ' --)
#	echo "backward hidden cell error range" $B_CH_MIN $B_CH_MAX
#	echo $B_CH_MIN $B_CH_MAX > backward_hidden_cell_errors_min_max.txt
#
#	CH_MIN=$F_CH_MIN
#	if (echo "$B_CH_MIN < $F_CH_MIN" | bc -l)
#	then
#		CH_MIN=$B_CH_MIN
#	fi
#	CH_MAX=$F_CH_MAX
#	if (echo "$B_CH_MAX > $F_CH_MAX" | bc -l)
#	then
#		CH_MAX=$B_CH_MAX
#	fi
#	echo "hidden cell error range" $CH_MIN $CH_MAX
#	echo $CH_MIN $CH_MAX > hidden_cell_errors_min_max.txt
#	$MBE

#	for DIR in display_$1_$2_$3_$4_$5*
#	do
#		$BI input_errors backwardInput_errors bi_input_errors
#		$BI forward_errors backward_errors bi_hidden_errors
#		$BI forward_cellErrors backward_cellErrors bi_hidden_cell_errors
		#plot error graphs
#		$PL --lo $IN_MIN --hi $IN_MAX -b -o $DIR/input_errors.png $DIR/input_errors
#		$PL --lo $H_MIN --hi $H_MAX -b -o $DIR/forward_errors.png $DIR/forward_errors
#		$PL --lo $CH_MIN --hi $CH_MAX -b -o $DIR/forward_cellErrors.png $DIR/forward_cellErrors
#		$PL --lo $IN_MIN --hi $IN_MAX -o $DIR/backwardInput_errors.png $DIR/backwardInput_errors
#		$PL --lo $H_MIN --hi $H_MAX -o $DIR/backward_errors.png $DIR/backward_errors
#		$PL --lo $CH_MIN --hi $CH_MAX -o $DIR/backward_cellErrors.png $DIR/backward_cellErrors
#
#		#make backgrounds transparent
#		convert -transparent white $DIR/input_errors.png $DIR/input_errors.png
#		convert -transparent white $DIR/forward_errors.png $DIR/forward_errors.png
#		convert -transparent white $DIR/forward_cellErrors.png $DIR/forward_cellErrors.png
#		convert -transparent white $DIR/backwardInput_errors.png $DIR/backwardInput_errors.png
#		convert -transparent white $DIR/backward_errors.png $DIR/backward_errors.png
#		convert -transparent white $DIR/backward_cellErrors.png $DIR/backward_cellErrors.png
#
#		#create combined plots
#		composite -compose over $DIR/backwardInput_errors.png $DIR/input_errors.png $DIR/inputErrors.png
#		composite -compose over $DIR/backward_errors.png $DIR/forward_errors.png $DIR/hiddenErrors.png
#		composite -compose over $DIR/backward_cellErrors.png $DIR/forward_cellErrors.png $DIR/hiddenCellErrors.png
#
#		#make backgrounds white
#		convert $DIR/inputErrors.png -background white -flatten +matte $DIR/inputErrors.png
#		convert $DIR/hiddenErrors.png -background white -flatten +matte $DIR/hiddenErrors.png
#		convert $DIR/hiddenCellErrors.png -background white -flatten +matte $DIR/hiddenCellErrors.png
#	done

#	#make forward animations
#	convert -delay 10 */input_errors_f.png forward_input_errors.gif
#	convert -delay 10 */forward_errors_f.png forward_hidden_errors.gif
#	convert -delay 10 */forward_cellErrors_f.png forward_hidden_cell_errors.gif
#
#	#make backward animations
#	convert -delay 10 */backwardInput_errors_b.png backward_input_errors.gif
#	convert -delay 10 */backward_errors_b.png backward_hidden_errors.gif
#	convert -delay 10 */backward_cellErrors_b.png backward_hidden_cell_errors.gif

	#make combined animations
#	convert -delay 10 */inputErrors.png input_errors.gif
#	convert -delay 10 */hiddenErrors.png hidden_errors.gif
#	convert -delay 10 */hiddenCellErrors.png hidden_cell_errors.gif
else
	echo "usage: dependency_anim.sh save_file data_set(train|test|val) sequence_number err_layer err_name num_timesteps"
fi
