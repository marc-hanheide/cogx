#!/bin/bash
NN=~/usr/bin/nnl_ndim
if [ $# = 3 ]
then
	DIR=display_$1_$2_$3/
	mkdir $DIR
	echo $NN -d $DIR $2 $3 $1
	nice $NN -d $DIR $2 $3 $1
elif [ $# = 5 ]
then
	TIMESTRING=$(printf "%06d" $4)
	DIR=display_$1_$2_$3_$TIMESTRING/
	mkdir $DIR
	echo $NN -d $DIR $2 $3 -j $4 $5 $1
	nice $NN -d $DIR $2 $3 -j $4 $5 $1
else
	echo "usage: display_sequence.sh save_file data_set(train|test|val) seq_number [timestep output(-1=all)]"
fi
