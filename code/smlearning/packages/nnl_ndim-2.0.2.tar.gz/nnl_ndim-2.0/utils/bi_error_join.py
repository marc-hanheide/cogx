#!/usr/bin/env python
from optparse import OptionParser
from math import *

usage = "usage: %prog forward_file backward_file output_file"
parser = OptionParser(usage)
parser.add_option("-s", "--separate", dest="separate", default=False, action="store_true", help="separate lines for forward and backward values")
#parser.add_option("-m", "--max", dest="max", default=False, action="store_true", help="plot maximum only")
(options, args) = parser.parse_args()
print options
if len(args) != 3:
        parser.error("incorrect number of arguments")
#print "writing",args[0],"and",args[1],"to",args[2]
forwardLines = file(args[0], 'r').readlines()[::-1]
backwardLines = file(args[1], 'r').readlines()
outputFile = file(args[2], 'w')
for l in range(len(forwardLines)):
	if options.separate:
		outputFile.write(forwardLines[l][:-2] + ' ' +  backwardLines[l])
	else:
		fl = forwardLines[l].split()
		bl = backwardLines[l].split()
#		if options.max:
#			vals = []
#			for n in range(len(fl)):
#				vals.append(max(float(fl[n]), float(bl[n])))
#			outputFile.write(str(max(vals)))
#		else:
		for n in range(len(fl)):
			outputFile.write(str(max(float(fl[n]), float(bl[n]))) + " ")
		outputFile.write("\n")
