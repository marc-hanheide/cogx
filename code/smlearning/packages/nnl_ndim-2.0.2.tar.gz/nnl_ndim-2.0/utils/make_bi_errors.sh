#! /bin/bash
UTILS=/home/alex/code/neural_net_console-1.0/utils
BI=$UTILS/bi_error_join.py
for DIR in display_*
do
	cd $DIR
	echo $DIR
	$BI input_errors backwardInput_errors bi_input_errors
	$BI forward_errors backward_errors bi_hidden_errors
	$BI forward_cellErrors backward_cellErrors bi_hidden_cell_errors
	cd ..
done
