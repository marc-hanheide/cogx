import glob
import string
import random
import sys
from optparse import OptionParser
from glob import glob
parser = OptionParser()
#parser.add_option("-i", "--input", action="store", type="string", dest="infile", default="", help="input filename")
#parser.add_option("-o", "--output", action="store", type="string", dest="outfile", default="", help="output filename")
#parser.add_option("-x", "--xscale", action="store", type="float", dest="xscale", default=1.0, help="scale for x axis")
#parser.add_option("-y", "--yscale", action="store", type="float", dest="yscale", default=100.0, help="scale for y axis")
(options, args) = parser.parse_args()
print options
f=file(options.infile)
fout=file(options.outfile,'w')
s=f.readline()
while (s!=""):
	words = s.split()
	words[0] = str(float(words[0])*options.xscale)
	words[1] = str(float(words[1])*options.yscale)
	fout.write(words[0]+' '+words[1]+'\n')
	s=f.readline()


	usage = "usage: %prog log_file"
parser = OptionParser(usage)
(options, args) = parser.parse_args()
errors = dict()

#print options
if (len(args)<1):
	print "usage: -options input_pattern"
	print options
	sys.exit(2)

inputPattern = args[0]
print "input file pattern", inputPattern
filenames = glob(inputPattern)
for f in filenames:
	file = open( f, 'r' )
	data = file.read()
	


# Well, we've got this far - the file must exist!
data = fileToSearch.read()

filename = args[0]
print "plotting errors from", filename
lines = file(filename, 'r').readlines()
errorType = ""
bestEpochs = dict()
for l in lines:
	words = l.split()
	if (l.find("epoch") >= 0 and l.find("took") >= 0):
		epochNum = int(l.split()[1])
	elif (l.find("train errors") >= 0):
		errorType = "train"
	elif (l.find("test errors") >= 0):
		errorType = "test"
	elif (l.find("validation errors") >= 0):
		errorType = "validation"
	elif (len(words) <> 2):
		errorType = ""
		if (l.find("best network") >= 0):
			words = l.split()
			bestEpochs[words[2]] = epochNum
	elif errorType <> "":
		errVal = float(words[1])
		if words[0] not in errors:
			errors[words[0]] = dict()
		if errorType in errors[words[0]]:
			errors[words[0]][errorType][0].append(epochNum)
			errors[words[0]][errorType][1].append(errVal)
		else:
			errors[words[0]][errorType] = [[epochNum],[errVal]]

for err in errors.items():
	figure()
	title(err[0])
	for dataSet in err[1].items():
		plot(dataSet[1][0], dataSet[1][1], linewidth=1.5, label=dataSet[0], marker='+')
	axes = gca()
	yRange = [axis()[2], axis()[3]]
	if len(bestEpochs) > 0:
		bone()
		for best in bestEpochs.items():
			if re.search("\(.*\)", best[0]):
				lab = "best "+best[0]
			else:
				lab = "best network"
			plot([best[1], best[1]], yRange, linestyle ='--', linewidth=1, label=lab)
	legend()
	legend(prop = matplotlib.font_manager.FontProperties(size = 'smaller'))

show()