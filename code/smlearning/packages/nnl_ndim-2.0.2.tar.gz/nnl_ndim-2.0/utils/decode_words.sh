#! /bin/bash
NN=/home/alex/usr/src/neural_net_console-1.0/src/neural_net_console
if [ $# = 4 ]
then
	DIR=$1
	PATT=$2
	NEW_DIR=$3
	DICT_FILE=$4
	for FILE in $DIR/$PATT
	do
		cp $FILE $NEW_DIR
	done
	pushd .
	cd $NEW_DIR
	for FILE in $PATT
	do
		echo old file = $FILE
		NEW_FILE=${FILE}_decode_words
		echo new file = $NEW_FILE
		sed "s:<ForwardLayers>:<Dictionary>${DICT_FILE}</Dictionary>X<ForwardLayers>:" $FILE  |
		sed 's:<totalEpochs>.*</totalEpochs>:<totalEpochs>0</totalEpochs>:' |
		sed 's:<testDataFile>\(.*\)test_t\(.*\)</testDataFile>:<testDataFile>\1test_f\2</testDataFile>:' |
		sed 's:<initErrorTest>.*</initErrorTest>:<initErrorTest>1</initErrorTest>:' > $NEW_FILE
		nn $NEW_FILE | tee $NEW_FILE.log
	done
	popd
else
	echo "usage: decode_words.sh input_dir input_pattern output_dir dict_file"
fi
