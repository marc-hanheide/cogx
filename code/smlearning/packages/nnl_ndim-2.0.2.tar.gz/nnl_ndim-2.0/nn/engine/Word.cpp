/*Copyright 2007,2008 Alex Graves

This file is part of nnl.

nnl is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

nnl is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with nnl.  If not, see <http://www.gnu.org/licenses/>.*/

#include <sstream>
#include <iostream>
#include <algorithm>
#include <numeric>
#include <stdexcept>
#include "Word.h"
#include "NnMath.h"
#include "nn/common/Typedefs.h"

objectStore<Token> Word::tokenStore;

Word::Word(const string& definition, const map<const string, int>& labelNumbers, int bu):
		blankUnit(bu)
{
	stringstream ss;
	ss << definition;
	ss >> word;
	string label;
	while (ss >> label)
	{
		const map<const string, int>::const_iterator it = labelNumbers.find(label);
		if (it == labelNumbers.end())
		{
			stringstream s;
			s <<"WARNING label '" << label << "' found in definition " << definition << " but not in labelNumbers";
			cerr << s.str() << endl;
			error = true;
			return;
			//throw runtime_error (s.str());
		}
		else
		{
			error = false;
			labelSeq.push_back(it->second);
		}
	}
	totalSegments = (2*(int)labelSeq.size()) + 1;
	for (int i = 0; i < totalSegments; ++i)
	{
		tokens.push_back(new Token(this, 0, -doubleMax));
		oldTokens.push_back(new Token(this, 0, -doubleMax));
	}
	transitionToken = new Token(this);
}

Word::~Word()
{
	for_each(tokens.begin(), tokens.end(), deleteT<Token>);
	for_each(oldTokens.begin(), oldTokens.end(), deleteT<Token>);
}

Token* Word::emitToken()
{
	return Token::maxTokenProb (tokens[totalSegments-1], tokens[totalSegments-2]);
}

Token* Word::initTokens(const vector<double> & logActs)
{
	//initialise start tokens (blank and first segment)
	oldTokens[0]->prob = logActs[blankUnit];
	if (oldTokens.size() > 1)
	{
		oldTokens[1]->prob = logActs[labelSeq[0]];
	}
	for (int i = 0; i < (int)tokens.size(); ++i)
	{
		tokens[i]->prev = 0;
		tokens[i]->prob = -doubleMax;
		oldTokens[i]->prev = 0;
		if (i > 1)
		{
			oldTokens[i]->prob = -doubleMax;
		}
	}

	//return output segment
	return emitToken();
}

//TODO put in CONTIGUOUS switch
Token* Word::passTokens(const Token* inputToken, double transitionProb, const double* logActBegin, int time, int totalTime)
{
	//copy the external token to an updated transition token
	transitionToken->prob = inputToken->prob + transitionProb;
	transitionToken->prev = inputToken;

	//loop over the allowed segments, passing the tokens forwards
	int startSegment = max(0, totalSegments - (2 *(totalTime-time)));
	int endSegment = min(totalSegments, 2 * (time + 1));
	for (int s = startSegment; s < endSegment; ++s)
	{
		Token* testToken;
		if (s == 0 || s == 1)
		{
			testToken = Token::maxTokenProb (transitionToken, oldTokens[s]);
		}
		else
		{
			testToken = oldTokens[s];
		}
		if (s)
		{
			testToken = Token::maxTokenProb (testToken, oldTokens[s-1]);
		}
		if (s&1)
		{
			if ((s > 1) && (labelSeq[s/2] != labelSeq[(s/2)-1]))
			{
				testToken = Token::maxTokenProb (testToken, oldTokens[s-2]);
			}
		}
		Token* token = tokens[s];
		token->prob = testToken->prob;
		token->prev = testToken->prev;
		if (s&1)
		{
			token->prob += logActBegin[labelSeq[s/2]];
		}
		else
		{			
			token->prob += logActBegin[blankUnit];
		}
	}
	for (int i = 0; i < (int)tokens.size(); ++i)
	{
		oldTokens[i]->prev = tokens[i]->prev;
		oldTokens[i]->prob = tokens[i]->prob;
	}
	return emitToken();
}

Token::Token(Word* wor, Token* pre, double pro):
		word(wor),
		prev(pre),
		prob(pro),
		chosen(false)
{
}

Token* Token::maxTokenProb (Token* t1, Token*t2)
{
	return t1->prob > t2->prob ? t1 : t2;
}

void Token::print(ostream& out)
{
	list<const Word*> words;
	const Token* t = this;
	while (t && t->word)
	{
		words.push_front(t->word);
		t = t->prev;
	}
	for (list<const Word*>::iterator it = words.begin(); it != words.end(); ++it)
	{
		out << (*it)->word << " ";
	}
	out << endl;
}

int Token::length() const
{
	int l = 0;
	for (const Token* t = this; t; t=t->prev, ++l);
	return l;
}

bool Token::equalWords (const Token* t1, const Token*t2)
{
	for (;t1 && t2; t1 = t1->prev, t2 = t2->prev)
	{
		if (t1->word->word != t2->word->word)
		{
			return false;
		}
	}
	return !(t1 || t2);
}

