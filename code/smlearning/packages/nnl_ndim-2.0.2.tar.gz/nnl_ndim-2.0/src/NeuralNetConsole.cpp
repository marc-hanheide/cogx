/*Copyright 2007,2008 Alex Graves

This file is part of nnl.

nnl is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

nnl is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with nnl.  If not, see <http://www.gnu.org/licenses/>.*/

#include <iostream>
#include <string>
#include <list>
#include <fstream>
#include <map>
#include <time.h>
#include <vector>
#include <limits>
#include <xercesc/parsers/XercesDOMParser.hpp>
#include <xercesc/util/XMLString.hpp>
#include <xercesc/framework/LocalFileInputSource.hpp>
#include <xercesc/dom/DOMException.hpp>
#include <xercesc/dom/DOMElement.hpp>
#include <xercesc/sax/SAXException.hpp>
#include <xercesc/util/NameIdPool.hpp>
#include <xercesc/util/PlatformUtils.hpp>
#include <xercesc/framework/XMLValidator.hpp>
#include <xercesc/validators/schema/SchemaValidator.hpp>
#include <xercesc/validators/common/ContentSpecNode.hpp>
#include <xercesc/validators/schema/SchemaSymbols.hpp>
#include <xercesc/util/OutOfMemoryException.hpp>
#include "nn/netcdf/NetcdfDataset.h"
#include "nn/engine/NetMaker.h"
#include "nn/engine/GradientFollowerMaker.h"
#include "nn/engine/DataExportHandler.h"
#include "nn/engine/GradientTest.h"
#include "nn/random/Random.h"
#include "nn/common/Typedefs.h"
#include "nn/common/Helpers.h"

using namespace std;

//data loaded in from xml file (default values below)
static int totalEpochs = -1;
static int randomSeed = 0;
static double initWeightRange = -1;
static double trainDataFraction = 1;
static double testDataFraction = 1;
static double valDataFraction = 1;
// static string trainDataFile = "";
static vector<string> trainDataFiles;
static string testDataFile = "";
static string valDataFile = "";
static bool initErrorTest = false;
static bool gradTest = false;
static double gradTestPerturbation = 1e-5;
static int gradTestSeq = -1;
static NetcdfDataset* trainData = 0;
static NetcdfDataset* testData = 0;
static NetcdfDataset* valData = 0;
static int epochsPerErrCheck = 5;
static int epochsSinceErrCheck = 0;
static bool batchLearn = false;
static int maxTestsNoBest = 4; 
static bool overwriteSaves = true;
static bool shuffleTrainData = true;
static double staticNoise = 0;	
//static double minStopError = 0;
static int epoch = 0; 
static int saveAfterNSeqs = 0;
static int seqsPerWeightUpdate = 1;
static bool rProp = false;
static string testOutputsFile = "";
static bool dataCheck = false;
static double bestStopError;
static int testsSinceBest;

//global debug switch
bool sequenceDebugOutput = false;

static Net* net;
static GradientFollower* gradientFollower;
static map<const string, pair<int,double> > netErrorMap;
static vector<string> criteria;
static map <const string, pair<double, int> > bestValErrors;
static vector<string> bestValStrings;
static map <const string, pair<double, int> > bestTestErrors;
static vector<string> bestTestStrings;
static map <const string, pair<double, int> > actualTestErrors;

void init(unsigned int randSeed)
{
	//init the xerces lib
	try 
	{
		XMLPlatformUtils::Initialize();
	}
	catch (const XMLException& toCatch) 
	{
		char* message = XMLString::transcode(toCatch.getMessage());
		cerr << "Error during xerces initialization! :" << endl << message << endl;
		XMLString::release(&message);
	}
	Random::setRandSeed(randSeed);
}

NetcdfDataset* getValidDataset()
{
	if (trainData)
	{
		return trainData;
	}
	else if (testData)
	{
		return testData;
	}
	else
	{
		return valData;
	}
}

const char* getChildText(const DOMElement* parent, const char* childName)
{
	const DOMNode* node = parent->getElementsByTagName(XMLString::transcode(childName))->item(0);
	if (node && node->hasChildNodes())
	{
		return XMLString::transcode(node->getFirstChild()->getNodeValue());
	}
	return 0;
}

bool loadElement(const DOMElement* parent, const char* name, string& target)
{
	const char* text = getChildText(parent, name);
	if (text)
	{
		target = text;
		return true;
	}
	return false;
}

bool loadElement(const DOMElement* parent, const char* name, vector<string>& target)
{
	const char* text = getChildText(parent, name);
	if (text)
	{
		stringstream temp(text);
		string s;
		while (temp >> s)
		{
			target.push_back(s);
		}
		return true;
	}
	return false;
}

bool loadElement(const DOMElement* parent, const char* name, int& target)
{
	const char* text = getChildText(parent, name);
	if (text)
	{
		target = atoi(text);
		return true;
	}
	return false;
}

bool loadElement(const DOMElement* parent, const char* name, double& target)
{
	const char* text = getChildText(parent, name);
	if (text)
	{
		target = atof(text);
		return true;
	}
	return false;
}

bool loadElement(const DOMElement* parent, const char* name, bool& target)
{
	const char* text = getChildText(parent, name);
	if (text)
	{
		target = (atoi(text) != 0);
		return true;
	}
	return false;
}

//TODO fix xml validation
void load (XercesDOMParser& parser, const string& filename, int displaySeq = -1, const string& displayDataSet = "")
{
	//parse in the file
	cout << "opening save file \"" << filename << "\"" << endl;
	bool parseFailed = false;
	//XercesDOMParser parser;
	//parser.setValidationScheme(XercesDOMParser::Val_Always);
	parser.setDoNamespaces(true);
	//parser.setDoSchema(true);
	//parser.setValidationSchemaFullChecking(true); 
	//parser.setExternalNoNamespaceSchemaLocation("schema.xsd");
	parser.setValidationConstraintFatal(true);
	parser.setExitOnFirstFatalError(false);
	parser.setIncludeIgnorableWhitespace(false);
	try
	{
		ifstream f(filename.c_str());
		if (f.is_open())
		{
			LocalFileInputSource source(XMLString::transcode(filename.c_str()));
			parser.parse(source);
			//parseFailed = parser.getErrorCount() != 0;
			//Grammar* g = parser.getRootGrammar();
			if (parser.getErrorCount())
			{
				cerr << "Parsing " << filename;
				cerr << " error count: " << parser.getErrorCount() << endl;
				exit(0);
			}
		}
		else
		{
			cerr << "save file " << filename << " not found, exiting" << endl;
			exit(0);
		}
	}
	catch (const DOMException& e)
	{
		cerr << "DOM Exception parsing ";
		cerr << filename;
		cerr << " reports: ";
		// was message provided?
		if (e.msg)
		{
			// yes: display it as ascii.
			char *strMsg = XMLString::transcode(e.msg);
			cerr << strMsg << endl;
			XMLString::release(&strMsg);
		}
		else
		{
			// no: just display the error code.
			cerr << e.code << endl;
		}
		parseFailed = true;
	}
	catch (const XMLException& e)
	{
		cerr << "XML Exception parsing ";
		cerr << filename;
		cerr << " reports: ";
		cerr << e.getMessage() << endl;
		parseFailed = true;
	}
	catch (const SAXException& e)
	{
		cerr << "SAX Exception parsing ";
		cerr << filename;
		cerr << " reports: ";
		cerr << e.getMessage() << endl;
		parseFailed = true;
	}
	catch (...)
	{
		cerr << "An exception parsing ";
		cerr << filename << endl;
		parseFailed = true;
	}

	// did the input document parse okay?
	if (!parseFailed)
	{
		//TODOMNode* domNode = attributes->getNamedItem\(XMLString\:\:transcodeDO search for top nodes by name instead of number (order shouldn't matter)
		const DOMElement* rootNode  = parser.getDocument()->getDocumentElement();
		const DOMElement* consoleDataElement = (DOMElement*)rootNode->getElementsByTagName(XMLString::transcode("ConsoleData"))->item(0);
		if (consoleDataElement)
		{
			loadElement(consoleDataElement, "trainDataFile", trainDataFiles);
			loadElement(consoleDataElement, "testDataFile", testDataFile);			
			loadElement(consoleDataElement, "validationDataFile", valDataFile);
			loadElement(consoleDataElement, "randomSeed", randomSeed);
			loadElement(consoleDataElement, "totalEpochs", totalEpochs);
			loadElement(consoleDataElement, "initWeightRange", initWeightRange);
			loadElement(consoleDataElement, "initErrorTest", initErrorTest);
			loadElement(consoleDataElement, "trainDataFraction", trainDataFraction);
			loadElement(consoleDataElement, "testDataFraction", testDataFraction);
			loadElement(consoleDataElement, "valDataFraction", valDataFraction);
			loadElement(consoleDataElement, "gradTest", gradTest);
			loadElement(consoleDataElement, "gradTestPerturbation", gradTestPerturbation);
			loadElement(consoleDataElement, "gradTestSeq", gradTestSeq);
			loadElement(consoleDataElement, "epochsPerErrCheck", epochsPerErrCheck);
			loadElement(consoleDataElement, "epochsSinceErrCheck", epochsSinceErrCheck);	
			loadElement(consoleDataElement, "maxTestsNoBest", maxTestsNoBest);
			loadElement(consoleDataElement, "epoch", epoch);
			loadElement(consoleDataElement, "overwriteSaves", overwriteSaves);
			loadElement(consoleDataElement, "staticNoise", staticNoise);
			loadElement(consoleDataElement, "batchLearn", batchLearn);
			loadElement(consoleDataElement, "shuffleTrainData", shuffleTrainData);
			loadElement(consoleDataElement, "saveAfterNSeqs", saveAfterNSeqs);
			loadElement(consoleDataElement, "seqsPerWeightUpdate", seqsPerWeightUpdate);
			loadElement(consoleDataElement, "sequenceDebugOutput", sequenceDebugOutput);
			loadElement(consoleDataElement, "rProp", rProp);
			loadElement(consoleDataElement, "testOutputsFile", testOutputsFile);
			loadElement(consoleDataElement, "dataCheck", dataCheck);
			SequenceDebugOutput::instance().set (sequenceDebugOutput);

			//load in the datasets
			if (trainDataFiles.size() && trainDataFraction > 0 && (displaySeq < 0 || displayDataSet == "train"))
			{
				cout << "loading train data file \"" << trainDataFiles.front() << "\"" << endl;
				int seqOffset;
				if (displaySeq >= 0)
				{
					seqOffset = displaySeq;
					trainData = new NetcdfDataset(trainDataFiles.front(), seqOffset);
				}
				else
				{
					seqOffset = 0;
					trainData = new NetcdfDataset(trainDataFiles.front(), trainDataFraction);
				}
			}
			if (testDataFile != "" && testDataFraction > 0 && (displaySeq < 0 || displayDataSet == "test"))
			{
				cout << "loading test data file \"" << testDataFile << "\"" << endl;
				int seqOffset;
				if (displaySeq >= 0)
				{
					seqOffset = displaySeq;
					testData = new NetcdfDataset(testDataFile, seqOffset);
				}
				else
				{
					seqOffset = 0;
					testData = new NetcdfDataset(testDataFile, testDataFraction);
				}
			}
			if (valDataFile != "" && valDataFraction > 0 && (displaySeq < 0 || displayDataSet == "val"))
			{
				cout << "loading validation data file \"" << valDataFile << "\"" << endl;
				int seqOffset;
				if (displaySeq >= 0)
				{
					seqOffset = displaySeq;
					valData = new NetcdfDataset(valDataFile, seqOffset);
				}
				else
				{
					seqOffset = 0;
					valData = new NetcdfDataset(valDataFile, valDataFraction);
				}
			}

			NetcdfDataset* ds = getValidDataset();

			//if datasets loaded succesfully, load net
			if (ds)
			{
				const DOMElement* netElement = (DOMElement*)rootNode->getElementsByTagName(XMLString::transcode("Net"))->item(0);
				if (netElement)
				{
					cout << "loading net" << endl;	

					//create a new net
					criteria.clear();
					delete net;
					net = NetMaker::makeNet(netElement, ds->getDimensions(), criteria);
					for (VSCI it = criteria.begin(); it != criteria.end(); ++it)
					{
						bestTestErrors[*it] = bestValErrors[*it] = make_pair(numeric_limits<double>::max(), -1);
					}
					
					//build the net and create the gradientFollower
 					net->build();
					if (rProp)
					{
						gradientFollower = GradientFollowerMaker::makeRpropGradientFollower(!batchLearn);
					}
					else
					{
						gradientFollower = GradientFollowerMaker::makeStdGradientFollower();
					}

				}
				else
				{
					cerr << "Net element not found, exiting" << endl;
					exit(0);
				}

				//load in the exported data
				const DOMElement* exportDataElement = (DOMElement*)rootNode->getElementsByTagName(XMLString::transcode("ExportedData"))->item(0);
				if (exportDataElement)
				{
					cout << "loading exported data" << endl;
					DataExportHandler::instance().load(exportDataElement);
				}
				return;
			}
			else
			{
				cerr << "no data loaded, exiting" << endl;
				exit(0);
			}
		}
		else
		{
			cerr << "ConsoleData element not found, exiting" << endl;
			exit(0);
		}
	}
	cerr << "xml parse failed, exiting" << endl;
	exit(0);
}

void saveElement(ostream& out, const string& name, bool val, bool xml)
{
	if (xml)
	{
		out << "\t\t<" << name << ">" << val << "</" << name << ">" << endl;
	}
	else
	{
		out << name << " " << val << endl;
	}
}

void saveElement(ostream& out, const string& name, int val, bool xml)
{
	if (xml)
	{
		out << "\t\t<" << name << ">" << val << "</" << name << ">" << endl;
	}
	else
	{
		out << name << " " << val << endl;
	}
}

void saveElement(ostream& out, const string& name, const string&val, bool xml)
{
	if (xml)
	{
		out << "\t\t<" << name << ">" << val << "</" << name << ">" << endl;
	}
	else
	{
		out << name << " " << val << endl;
	}
}

void saveElement(ostream& out, const string& name, const vector<string>&val, bool xml)
{
	if (xml)
	{
		out << "\t\t<" << name << ">";
		copy(val.begin(), val.end(), ostream_iterator<string>(out, " "));
		out << "</" << name << ">" << endl;
	}
	else
	{
		out << name << " ";
		copy(val.begin(), val.end(), ostream_iterator<string>(out, " "));
		out << endl;
	}
}

void saveElement(ostream& out, const string& name, double val, bool xml)
{
	if (xml)
	{
		out << "\t\t<" << name << ">" << val << "</" << name << ">" << endl;
	}
	else
	{
		out << name << " " << val << endl;
	}
}

void saveConsoleData(ostream& out = cout, bool xml = true)
{
	saveElement (out, "trainDataFile", trainDataFiles, xml);
	saveElement (out, "trainDataFraction", trainDataFraction, xml);
	saveElement (out, "testDataFraction", testDataFraction, xml);
	saveElement (out, "valDataFraction", valDataFraction, xml);
	saveElement (out, "testDataFile", testDataFile, xml);
	saveElement (out, "validationDataFile", valDataFile, xml);
	saveElement (out, "randomSeed", randomSeed, xml);
	saveElement (out, "totalEpochs", totalEpochs, xml);
	saveElement (out, "initWeightRange", initWeightRange, xml);
	saveElement (out, "initErrorTest", initErrorTest, xml);
	saveElement (out, "dataCheck", dataCheck, xml);
	saveElement (out, "gradTest", gradTest, xml);
	saveElement (out, "gradTestPerturbation", gradTestPerturbation, xml);
	saveElement (out, "gradTestSeq", gradTestSeq, xml);
	saveElement (out, "overwriteSaves", overwriteSaves, xml);
	saveElement (out, "staticNoise", staticNoise, xml );
	saveElement (out, "epochsPerErrCheck", epochsPerErrCheck, xml);
	saveElement (out, "epochsSinceErrCheck", epochsSinceErrCheck, xml);
	saveElement (out, "maxTestsNoBest", maxTestsNoBest, xml);
	saveElement (out, "epoch", epoch, xml);
	saveElement (out, "batchLearn", batchLearn, xml);
	saveElement (out, "shuffleTrainData", shuffleTrainData, xml);
	saveElement (out, "saveAfterNSeqs", saveAfterNSeqs, xml);
	saveElement (out, "seqsPerWeightUpdate", seqsPerWeightUpdate, xml);
	saveElement (out, "sequenceDebugOutput", SequenceDebugOutput::instance().get(), xml);
	saveElement (out, "rProp", rProp, xml);
	saveElement (out, "testOutputsFile", testOutputsFile, xml);
}

void save(ostream& out = cout)
{
	out << "<NeuralNet>" << endl;
	out << "\t<ConsoleData>" << endl;
	saveConsoleData(out);
	out << "\t</ConsoleData>" << endl;
	net->save("\t", out);
	DataExportHandler::instance().save("\t", out);
	out << "</NeuralNet>" << endl;
}

void print(ostream& out = cout)
{
	out << "console data:" << endl;
	saveConsoleData(out, false);
	out << endl;
	out << "network:" << endl;
	net->print(out);
	out << "gradientFollower:" << endl;
	gradientFollower->print(out);
	out << endl;
	if (trainData)
	{
		out << "training data:" << endl;
		trainData->print(out);
		out << endl;
	}
	if (testData)
	{
		out << "test data:" << endl;
		testData->print(out);
		out << endl;
	}
	if (valData)
	{
		out << "validation data:" << endl;
		valData->print(out);
		out << endl;
	}
}

//TODO put this DataSequence.h ?
void printSeqData (ostream& out, const DataSequence& seq, int seqNum = -1)
{
	if (seqNum >= 0)
	{
		out << "seq " << seqNum << endl;
	}
	out << "tag: " << seq.tag << endl;
	out << "sequence dimensions: ";
	copy(seq.dimensions.begin(), seq.dimensions.end(), ostream_iterator<int>(out, " "));
	out << endl;
	if (!seq.targetSeq.empty())
	{
		out << "target sequence length: " << (int)seq.targetSeq.size() << endl;
	}
	if (seq.targetString != "")
	{
		out << "target label string:" << endl;
		out << seq.targetString << endl;
	}
// 	if (!seq.labelCounts.empty())
// 	{
// 		out << "target label counts:" << endl;
// 		copy(seq.labelCounts.begin(), seq.labelCounts.end(), ostream_iterator<int>(out, " "));
// 		out << endl;
// 	}
	//if (seq.wordTargetString != "")
	//{
	//	out << "target word string:" << endl;
	//	out << seq.wordTargetString << endl;
	//}
}

//make err calc separate
double getNetError(const string& name, const NetcdfDataset* dataset)
{
	double err = netErrorMap[name].second;
	if (netErrorMap[name].first)
	{
		err /= (double) netErrorMap[name].first;
	}
		//TODO: more robust way of scaling errors relative to datasets
	if (name == "rmsError")
	{
		double normFactor = dataset->getDimensions().rmsNormFactor;
			//cout << "normFactor " << normFactor << endl;
		if (normFactor)
		{
			err /= normFactor;
		}
	}
	return err;
}

void printNetErrors(const NetcdfDataset* dataset)
{
	for (MCSPIDCI it = netErrorMap.begin(); it != netErrorMap.end(); ++it)
	{
		cout << '\t' << it->first << ' ' << getNetError(it->first, dataset)  << endl;
	}
}

void checkForBest(vector<string>& bestStrings, map<const string, pair<double, int> >& bestErrors, 
				  int epoch, const NetcdfDataset* dataset)
{
	bestStrings.clear();
	for (VSCI it = criteria.begin(); it != criteria.end(); ++it)
	{
		double currentVal = getNetError(*it, dataset);
		pair<double, int>& best = bestErrors[*it];
		if (currentVal < best.first)
		{
			bestStrings.push_back(*it);
			best.first = currentVal;
			best.second = epoch;
		}
	}
}

void printBestErrors(map<const string, pair<double, int> >& bestErrors, ostream& out = cout)
{
	for (MCSPDICI it = bestErrors.begin(); it != bestErrors.end(); ++it)
	{
		out << it->first << ' ' << it->second.first << " (epoch " << it->second.second << ")" << endl;
	}
}

void calculateDatasetErrors(const NetcdfDataset* dataset)
{
	netErrorMap.clear();
	int numSeqs = dataset->getNumSeqs();
	for (int s=0; s<numSeqs; ++s)
	{
		const DataSequence& seq = dataset->getDataSequence(s);
		if (SequenceDebugOutput::instance().get())
		{
			printSeqData(cout, seq, s);
		}
		net->calculateError(netErrorMap, seq);
		if (SequenceDebugOutput::instance().get())
		{
			cout << endl;
		}
	}
}

char *getTimeStamp()
{
	static char timeStamp[256];
	time_t curtime;
	struct tm *loctime;
	curtime = time (NULL);
	loctime = localtime (&curtime);
	strftime (timeStamp, sizeof(timeStamp), "@%Y%m%d_%H%M", loctime);
	return timeStamp;
}

const DataSequence& injectStaticNoise(const DataSequence& seq, const DataDimensions& dims)
{
	static DataSequence noisySeq;
	static vector<float> noisyInputs;
	noisySeq = seq;
	noisyInputs.resize(seq.size * dims.inputPattSize);
	copy(seq.inputs, seq.inputs + noisyInputs.size(), noisyInputs.begin());
	for (VFI it = noisyInputs.begin(); it != noisyInputs.end(); ++it)
	{
		*it += (float)(Random::gaussRand() * staticNoise);
	}
	noisySeq.inputs = &noisyInputs.front();
	return noisySeq;
}

void cmdErrorExit()
{
	cerr << "usage nnl [-d path data_set(=train|test|val) seq_number [-j timestep output(-1=all)]] input_filename [output_filename]" << endl;
	exit(0);
}

int findIdenticalSequences (NetcdfDataset* d1, NetcdfDataset* d2, const string& name1, const string& name2, ostream& out = cout)
{
	if (d1 && d2)
	{
		int numEqs = 0;
		for (int i1 = 0; i1 < d1->getNumSeqs(); ++i1)
		{
			for (int i2 = 0; i2 < d2->getNumSeqs(); ++i2)
			{
				const DataSequence& s1 = d1->getDataSequence(i1);
				const DataSequence& s2 = d2->getDataSequence(i2);
				if (s1 == s2)
				{
					out << name2 << " sequence " << i2 << " (tag " <<  s2.tag << ")";
					out << " == " << name1 << " sequence " << i1 << " (tag " << s1.tag << ")" << endl;
					++numEqs;
				}
			}
		}
		if (numEqs)
		{
			out << numEqs << "/" <<  d2->getNumSeqs() << " " << name2;
			out << " sequences also found in " << name1 << " set!" << endl << endl;
		}
		return numEqs;		
	}
	return 0;
}

//TODO: include flag to prevent stopping while error is still decreasing (or has recently)
int main(int argc, char * argv[])
{
	if (argc < 2 || argc > 10)
	{
		cmdErrorExit();
	}

	//TODO print out global constants e.g. exp limit etc

	//init the xerces lib
	try 
	{
		XMLPlatformUtils::Initialize();
	}
	catch (const XMLException& toCatch) 
	{
		char* message = XMLString::transcode(toCatch.getMessage());
		cerr << "Error during xerces initialization! :" << endl << message << endl;
		XMLString::release(&message);
	}

	string filename;
	string arg1 (argv[1]);
	bool autosave = false;
	string saveFile;
	bool display = false;
	string displayPath = "";
	int displaySeq = -1;
	int jacTimestep = -1;
	int jacOutput = -1;
	string errLayer = "output";
	string errName = "errors";
	string displayDataSet = "train";
	bool jacobian = false;
	if(arg1 == "-d")
	{
		if (argc < 6)
		{
			cmdErrorExit();
		}
		else
		{
			display = true;
			displayPath = argv[2];
			displayDataSet = argv[3];
			displaySeq = atoi(argv[4]);
			if (string(argv[5]) == "-j")
			{
				jacobian = true;
				if (argc < 9)
				{
					cmdErrorExit();
				}
				jacTimestep = atoi(argv[6]);
				jacOutput = atoi(argv[7]);
				filename = argv[8];
			}
			else
			{
				filename = argv[5];
			}
		}
	}
	else
	{
		filename = arg1;
		if (argc == 3)
		{
			saveFile = argv[2];
			autosave = true;
		}
	}

	//HACK to make sure the document is kept in memory (wasteful)
	//TODO work out how to copy nodes properly
	XercesDOMParser parser;
	if (display)
	{
		load (parser, filename, displaySeq, displayDataSet);
	}
	else
	{
		load (parser, filename);
	}

	print();
	init(randomSeed);

	if (initWeightRange >= 0)
	{
		cout << "randomising weights with mean 0 std dev " << initWeightRange << endl << endl;
		gradientFollower->randomiseWeights(initWeightRange);
		epoch = 0;
	} 
	if (display)
	{
		SequenceDebugOutput::instance().set (true);
		const NetcdfDataset* ds = 0;
		if (displayDataSet == "test")
		{
			ds = testData;
		}
		else if (displayDataSet == "val")
		{
			ds = valData;
		}
		else if (displayDataSet == "train")
		{
			ds = trainData;
		}
		if (ds)
		{
 			print();
			const DataSequence& seq = (ds == trainData && staticNoise != 0) ? 
				injectStaticNoise(ds->getDataSequence(displaySeq), ds->getDimensions()) : 
				ds->getDataSequence(displaySeq);
			cout << "outputting net variables for " << displayDataSet;
			cout << " set sequence " << displaySeq << " to " << displayPath << endl;
			printSeqData(cout, seq);
			if (jacobian)
			{
				net->outputJacobian(seq, displayPath, jacTimestep, jacOutput);
			}
			else
			{
				net->calculateGradient(netErrorMap, seq);
				net->outputInternalVariables(displayPath);
			}

			//print out targets and target classes
			string filename = displayPath + "targets";
			ofstream out (filename.c_str());
			int targetPattSize = ds->getDimensions().targetPattSize;
			for (int x = 0; x < targetPattSize; ++x) 
			{
				for (int y = 0; y < (int)seq.size; ++y)
				{
					out << seq.targetPatterns[(y * targetPattSize) + x] << " ";
				}
				out << endl;
			}
			filename = displayPath + "targetClasses";
			ofstream out2 (filename.c_str());
			out2 << "#";
			copy(ds->getDimensions().labels.begin(), ds->getDimensions().labels.end(), ostream_iterator<string>(out2, " "));
			out2 << endl;
			copy(seq.targetClasses.begin(), seq.targetClasses.end(), ostream_iterator<int>(out2, " "));
			out2 << endl;
			exit(0);
		}
		else
		{
			cerr << "display data set " << displayDataSet << " not found, exiting" << endl;
			exit(0);
		}
	}

	if (gradTest)
	{
		const NetcdfDataset* ds;
		if (trainData)
		{
			ds = trainData;
		}
		else if (testData)
		{
			ds = testData;
		}
		else
		{
			ds = valData;
		}
		if (gradTestSeq < 0)
		{
			int numSeqs = ds->getNumSeqs();
			gradTestSeq = Random::randInt(numSeqs);
		}
		const DataSequence& seq = ds->getDataSequence(gradTestSeq);
		//cout << seq;
		cout << "running gradient test with seq " << gradTestSeq << ", perturbation " << gradTestPerturbation << endl;
		printSeqData(cout, seq, gradTestSeq);
		GradientTest(net,seq, gradTestPerturbation);
		return 0;
	}
	if (testOutputsFile != "")
	{
		if (!testData)
		{
			cerr << "cannot print test outputs with no test set, exiting" << endl;
			exit(0);
		}
		ofstream out(testOutputsFile.c_str());
		if (!out.is_open())
		{
			cerr << "cannot open file " << testOutputsFile << " for writing, exiting" << endl;
			exit(0);	
		}
		netErrorMap.clear();
		int numSeqs = testData->getNumSeqs();
		double err = 0;
		for (int s=0; s<numSeqs; ++s)
		{
			const DataSequence& seq = testData->getDataSequence(s);
			out << "tag: " << seq.tag << endl;
			err += net->calculateError(netErrorMap, seq);
			net->printOutputs(out);
		}
		out << "error: " << err << endl;
		return 0;
	}
	if (initErrorTest)
	{
		if (trainData)
		{
			cout << "calculating train errors:" << endl;  
			calculateDatasetErrors(trainData);
			printNetErrors(trainData);
		}
		if (testData)
		{
			cout << "calculating test errors:" << endl;  
			calculateDatasetErrors(testData);
			printNetErrors(testData);
		}
		if (valData)
		{
			cout << "calculating validation errors:" << endl; 
			calculateDatasetErrors(valData);
			printNetErrors(valData);
		}
	}

	if (dataCheck) 
	{
		int trainValEqualities = findIdenticalSequences(trainData, valData, "train", "validation");
		int trainTestEqualities = findIdenticalSequences(trainData, testData, "train", "test");
		if (trainValEqualities || trainTestEqualities)
		{
			exit(0);
		}
	}

	
	if (trainDataFiles.size() && (totalEpochs < 0 || totalEpochs > epoch))
	{
		//don't randomise again if we save and reload
		initWeightRange = -1;

		//init flags, filenames, times etc
		const DataDimensions& dims = trainData->getDimensions();
		int numTrainSeqs = trainData->getNumSeqs();
		int numTimesteps = trainData->getNumTimesteps();
		string timeStamp = getTimeStamp();
		string bestSaveRoot = saveFile + timeStamp + "_best";
		string lastSaveFile = saveFile + timeStamp + "_last.xml";
		if (autosave)
		{
			cout << "autosave filename " << lastSaveFile << endl; 
			cout << "best save filename root " << bestSaveRoot << endl; 
			cout << endl;
		}
		int oldEpochs = epoch;
		bool stoppingCriteriaReached = false;
		bestStopError = 1e100;
		int numWeights = gradientFollower->getNumWeights();
		time_t seconds = time (NULL);
		bool useStaticNoise = false;
		if (staticNoise != 0)
		{
			useStaticNoise = true;
			cout << "static noise, std dev " << staticNoise << endl << endl; 
		}
		vector<int> seqIndices;
		for (int i = 0; i < numTrainSeqs; ++i)
		{
			seqIndices.push_back(i);
		}
		int saveNum = 0;
		int seqsSinceSave = 0;

		//loop through training data until done
		cout << "training..." << endl;

		//TODO sort out the saveAfterNSeqs stuff
		if (saveAfterNSeqs > 0)
		{
			stringstream ss;
			ss << lastSaveFile << "_" << saveNum;
			++saveNum;
			saveFile = ss.str();
			cout << "autosaving to " << ss.str() << endl;
			ofstream out(ss.str().c_str());
			save(out);
		}
		int seqsSinceWtUpdate = 0;
		vector<int> trainFileIndices;
		for (int i = 0; i < trainDataFiles.size(); ++i)
		{
			trainFileIndices.push_back(i);
		}
		while(!stoppingCriteriaReached && !(totalEpochs > 0 && epoch >= totalEpochs))
		{
			time_t epochSeconds = time (NULL);
			if (shuffleTrainData)
			{
				if (trainFileIndices.size() == 1)
				{
 					random_shuffle(seqIndices.begin(), seqIndices.end());
				}
				else
				{
					random_shuffle(trainFileIndices.begin(), trainFileIndices.end());
				}
			}

			//run through one epoch, collecting errors and updating weights
			netErrorMap.clear();
			for (int i = 0; i < (int)trainFileIndices.size(); ++i)
			{
				if ((int)trainFileIndices.size() > 1)
				{
					string& tf = trainDataFiles[trainFileIndices[i]];
 					cout << "loading train data file \"" << tf << "\"" << endl;
					delete trainData;
					trainData = new NetcdfDataset(tf, trainDataFraction);
// 					cout << "done" << endl;
					int numSeqs = trainData->getNumSeqs();
					seqIndices.resize(numSeqs);
					for (int j = 0; j < seqIndices.size(); ++j)
					{
						seqIndices[j] = j;
					}
					if (shuffleTrainData)
					{
						random_shuffle(seqIndices.begin(), seqIndices.end());
					}
				}
				for (VICI it = seqIndices.begin(); it != seqIndices.end(); ++it)
				{
// 					cout << "sequence " << *it << endl;
					const DataSequence& seq = trainData->getDataSequence(*it);
	
					if (SequenceDebugOutput::instance().get())
					{
						printSeqData(cout, seq, (int)distance<VICI>(seqIndices.begin(),it));
					}
	
					//train the net, injecting static noise if required
					if (useStaticNoise)
					{
						net->calculateGradient(netErrorMap, injectStaticNoise(seq, dims));
					}
					else
					{
						net->calculateGradient(netErrorMap, seq);
					}
					if (!batchLearn && ++seqsSinceWtUpdate >= seqsPerWeightUpdate)
					{
						gradientFollower->updateWeights();
						gradientFollower->resetDerivs();
						seqsSinceWtUpdate = 0;
					}
	
					if (SequenceDebugOutput::instance().get())
					{
						cout << endl;
					}
	
					if (autosave && saveAfterNSeqs > 0 && ++seqsSinceSave >= saveAfterNSeqs)
					{
						stringstream ss;
						ss << lastSaveFile << "_" << saveNum;
						++saveNum;
						saveFile = ss.str();
						cout << "autosaving to " << ss.str() << endl;
						ofstream out(ss.str().c_str());
						save(out);
						seqsSinceSave = 0;
					}
	
				}
			}
			if (batchLearn)
			{
				gradientFollower->updateWeights();
				gradientFollower->resetDerivs();
			}

			//print out epoch data
			epochSeconds = time (NULL) - epochSeconds;
			cout << endl << "epoch " << epoch << " took " << (long)epochSeconds << " seconds";
			double itsPerSec = (double) numTimesteps / epochSeconds;
			double mWtItsPerSec = (itsPerSec * numWeights) / 1e6;
			cout << " (" << itsPerSec << " its/sec, ";
 			cout << mWtItsPerSec << " MwtIts/sec)" << endl;
			cout << "train errors (running):" << endl;  
			printNetErrors(trainData);
			
			//increment epoch number (before saves)
			++epoch;

			//calculate error test, if required
			if (epochsPerErrCheck > 0 && ++epochsSinceErrCheck >= epochsPerErrCheck)
			{
				epochsSinceErrCheck = 0;
				if (valData)
				{
					cout << "calculating validation errors:" << endl;  
					calculateDatasetErrors(valData);
					printNetErrors(valData);
				}
				checkForBest(bestValStrings, bestValErrors, epoch - 1, valData ? valData : trainData);
				if (testData)
				{
					cout << "calculating test errors:" << endl;  
					calculateDatasetErrors(testData);
					printNetErrors(testData);
					checkForBest(bestTestStrings, bestTestErrors, epoch - 1, testData);
				}
				cout << endl;
				for (VSCI it = bestValStrings.begin(); it != bestValStrings.end(); ++it)
				{
					if (testData)
					{
						actualTestErrors[*it] = make_pair(getNetError(*it, testData), epoch - 1);
					}
					cout << "best network (" << *it << ")";
					if (autosave)
					{
						string saveFile = bestSaveRoot + "_" + *it + ".xml";
						cout << ", saving to " << saveFile << endl;
						ofstream out(saveFile.c_str());
						save(out);
					}
					else
					{
						cout << endl;
					}
				}
				//check if training is finished
				if (!bestValStrings.empty())
				{
					testsSinceBest = 0;
				}
				else if (maxTestsNoBest > 0 && (++testsSinceBest > maxTestsNoBest))
				{
					cout << testsSinceBest << " error tests without best, ending training" << endl;
					stoppingCriteriaReached = true;
				}	
			}
			else
			{
				cout << endl;
			}

			//autosave, if required
			if (autosave && saveAfterNSeqs <= 0)
			{
				string saveFile;
				if (overwriteSaves)
				{
					saveFile = lastSaveFile;
				}
				else
				{
					stringstream ss;
					ss << lastSaveFile << "_" << saveNum;
					++saveNum;
					saveFile = ss.str();
				}
				cout << "autosaving to " << saveFile << endl;
				ofstream out(saveFile.c_str());
				save(out);
			}
		}

		//print out overall stats
		seconds = time (NULL) - seconds;
		int epochs = epoch - oldEpochs;
		int seqs = epochs * numTrainSeqs;
		int timesteps = epochs * trainData->getNumTimesteps();
		cout << endl << "training finished" << endl;
		cout << epochs << " epochs ";
		cout << seqs << " sequences ";
		cout << timesteps << " timesteps" << endl;
		cout << "in " << (long)seconds << " seconds" << endl;
		cout << "best validation errors:" << endl;
		printBestErrors(bestValErrors);
		if (testData)
		{
			cout << "best test errors:" << endl;
			printBestErrors(bestTestErrors);
			cout << "actual test errors:" << endl;
			printBestErrors(actualTestErrors);
		}
	}

	XMLPlatformUtils::Terminate();
	return 0; 
}
