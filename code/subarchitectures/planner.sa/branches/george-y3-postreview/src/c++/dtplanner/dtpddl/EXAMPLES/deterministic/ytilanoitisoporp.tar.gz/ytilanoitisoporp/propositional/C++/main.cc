
/*---------------------------------

  Usual suspects C++::1998

  ---------------------------------*/

/*IO, string, files*/
#include<string>
#include<iostream>
#include<iomanip>
#include<sstream>
#include<fstream>

/*Storage*/
#include<vector>
#include<map>
#include<set>

/*Sorting, and set operations*/
#include<algorithm>

/*---------------------------------

  Usual suspects C

  ---------------------------------*/
#include<cstddef>
#include<cstdio>
#include<cmath>
#include<cstdlib>
//#include<cmalloc>
#include<cassert>
#include<cctype>
#include<csignal>
#include<cstdarg>
#include<cstddef>
#include<cstring>

/*---------------------------------

  Usual suspects C++::TR1

  ---------------------------------*/

#include<tr1/unordered_map>
#include<tr1/unordered_set>
//#include<tr1/functional>
//#include<boost/functional/hash.hpp>


/*---------------------------------

  Old fashioned debugging

  ---------------------------------*/
#define DEBUG_LEVEL 1
#define DEBUG_GET_CHAR(Y) {if(Y > DEBUG_LEVEL) {char ch; cin>>ch;} }

#define VERBOSE(X) {cerr<<"INFO :: "<<X<<endl;}
#define VERBOSER(Y, X) {if(Y > DEBUG_LEVEL)cerr<<"INFO ("<<Y<<") :: "<<X;}

#define UNRECOVERABLE_ERROR(X) {cerr<<"UNRECOVERABLE ERROR :: "<<X;assert(0);exit(0);}

using namespace std;

/*Number of objects in the problem being generated.*/
uint objectCount = 0;

/*Maximum cost of flipping a boolean to true.*/
uint MAX_COST = 1000;

void preamble()
{
    cout<<"(define (problem ytilanoitisoporp-"<<time(0)<<" )"<<endl;

    cout<<"(:domain ytilanoitisoporp)"<<endl;
}

void objects()
{
    assert(objectCount > 0);

    cout<<"(:objects "<<endl;
    for(uint i = 1; i <= objectCount; i++){
	cout<<"o"<<i<<" - boolean"<<endl;
    }

    cout<<")"<<endl;
}

void init()
{
    cout<<"(:init "<<endl;
    
    for(uint i = 1; i <= objectCount; i++){
	cout<<"(off "<<"o"<<i<<" )"<<endl;
	cout<<"(= (switch-cost o"<<i<<" ) "<<random()%MAX_COST<<" )"<<endl;
	
	if(i + 1 <= objectCount)
	    cout<<"(related o"<<i<<" o"<<i+1<<" )"<<endl;
    }
    
    cout<<"(= (total-cost) 0)"<<endl;
    
    cout<<")"<<endl;
}

void goal()
{
    cout<<"(:goal "<<endl;

    cout<<"(and "<<endl;
    
    for(uint i = 1; i <= objectCount; i++){
	if(random()%2){
	    cout<<"(off "<<"o"<<i<<" )"<<endl;
	} else {
	    cout<<"(on "<<"o"<<i<<" )"<<endl;
	}
    }
    
    cout<<")"<<endl;
    
    
    cout<<")"<<endl;
}


int main(int argc, char** argv)
{
    /*Write the preamble.*/
    void preamble();

    if(argc <= 1){
	UNRECOVERABLE_ERROR("Please specify the number of objects."<<endl);
    }

    /*_lame_ code for random seed.*/
    unsigned int seed = time(0);
    srand(seed);
    
    /*Get the number of booleans (fist argument).*/
    istringstream iss(argv[1]);
    iss>>objectCount;

    /*Usual problem preamble.*/
    preamble();
    
    /*List objects.*/
    objects();

    /*List initial state.*/
    init();

    /*Goal state completely specified.*/
    goal();
    
    /*PDDL junk*/
    cout<<" (:metric minimize (total-cost))"<<endl;

    cout<<")"<<endl;
    
    return 0;
}
