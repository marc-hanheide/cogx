# This tool creates the dict.xsl file by first converting
# the "user-friendly" dict.list into the appropriate xml format,
# and then appends this to the base grammar in dict template.xsl


$tab = "  ";
$base_input_file = "dictionary-other.xsl";
$append_input_file = "dictionary-basic";
$output_file = "../grammar/dict.xsl";

# Read in the base grammar as defined in grammar template
open (FILE_IN, '<', $base_input_file) || die "Can't read '$input_file': $!";
  $grammar = join ('', <FILE_IN>);
close FILE_IN;

# Create dictionary from the file dict.list and append it
# to the grammar

open(FILE_IN, $append_input_file) or die "Error opening file dict.template";
  build_dict_from_list();
close FILE_IN;  
  
# Append the dict-list to the base
$grammar =~ s/<!-- __INSERT__HERE__ -->/$dictlist/gi;

# Write the grammar out
open (FILE_OUT, '>', $output_file) || die "Can't write '$output_file': $!";
   print FILE_OUT $grammar;
close FILE_OUT;











##########################################################################################
# SUBROUTINES
##########################################################################################

# -------------------------------------------------------------------------------------------
# This subroutine loops throught dict.list, and at each line performs the appropriate action:
# either changing the POS or the class(type), or adding a new dictionary entry
# with the current POS and class
# -------------------------------------------------------------------------------------------

sub build_dict_from_list{

$dictlist="";  # This will be the concantenated string of all
$counter = 0;  # used to count number of entries. Also used in entry stems.

    while ( <FILE_IN> ) { # Run through the dict.list file

		chomp;
   
		if(/^----pos (.*)/){$pos = $1; print_pos_header();}   # 1) part of speech 

		elsif(/^--class (.*)/){$class = $1;}				  # 2) class (i.e. type, specified in moloko/types.xml)

		elsif(/^::/ or $_ eq ""){}						      # 3) comment or blank space

		else{ process_entry();}							      # 4) everything else is an entry

	} 

}


# -------------------------------------------------------------------------------------------
# This subroutine processes an entry. This involves cutting it into forms and args,
# setting the predicate and stem values, and then calling add_entry to handle the 
# POS specific printing of the dictionary entry
# -------------------------------------------------------------------------------------------

sub process_entry{

		@forms=(); @args=(); $entry_printed="no";  # initialize arrays
	  	  
		# split the entry line into its forms and args. 
		# each entry is of the form form1:form2:form3:... (arg1, arg2, ...)
		
		if( /(.*)\s*\((.*)\)/ ){			# check for arguments. enclosed in () after forms
			@forms = split(/:/ , $1);       
			@args  = split(/,/ , $2);
		}else{
			@forms = split(/:/ , $_);
		}
		
		# truncate any preceding or following spaces from @forms and @args
		grep s/^\s*(.+?)\s*$/$1/, @forms;
		grep s/^\s*(.+?)\s*$/$1/, @args;
		foreach $arg (@args) { if($arg eq " "){$arg = "";}}												  

		# Set the predicate value for the entry
		if (@forms[0] =~ /\*(.+)\*/ ){      # if the first word is inclosed in *, then it is the pred value
			$pred =$1;						# but SHOULD NOT be included as a form
			shift @forms;					# get rid of this form
		} else {
		   ($pred)  = split(/ /, $forms[0]);    # 1st word in first form is default pred																
        }
		
		#set up the default stem value ___ pred_pos_class_current-counter-value
		$stem = $pred."_".$pos."_".$class."_".$counter++; 
	  	  
		# add the entry then skip a space, if nothing added, then print to standard output
		add_entry();
		if($entry_printed eq "no"){print "unrecognized entry format at ". $stem. "\n";}
		else{$dictlist .= "\n";} 
		
		}

# -------------------------------------------------------------------------------------------
# This builds the appropriate entry based on the POS and given arguments.
# This involves: 1) reading in all the provided (POS specific) arguments 
#                2) building the word_forms with the necessary macros 
#                3) adding the appropriate families
#
# Note: some single entries in dict.list may result in multiple dictionary entries in dict.xml
# -------------------------------------------------------------------------------------------

sub add_entry{
		
    # empty the lists being used
    @word_forms = ();
    @macros = (); 
    @families = ();


	# EACH CONDITION IS A POS #

	# ----  ADJ  ----
	# Adjectives can have up to 3 forms, basic, comparative and superlative
    if ($pos eq "ADJ"){

		  foreach $form (@forms) {
		   
			 @degrees = split(" ", $form);
			 
			 push (@word_forms, [@degrees[0], "\@degree.base"]);
			 if (@degrees > 1)  {push (@word_forms, [@degrees[1], "\@degree.comparative"]);}
			 if (@degrees == 3) {push (@word_forms, [@degrees[2], "\@degree.superlative"]);}
		  }
			  
		  @families=("adj");	
		  print_entry();


	# ----  NOUN  ----
	# There are many kinds of nouns: bare, mass, and standard sg/pl (with or without of-np argument)
	}elsif($pos eq "N"){
		
		if (@args[0] eq "" or @args[0] eq "of-np") {   # default case, no args given or if arg of-np given
		 		 
			@singular_forms=();@plural_forms=(); # initialize variables
	
			foreach $form (@forms) {
				if ($form =~ /^(.*) (.*)/){      # if irregular plural form given
					$sg = $1;
					$pl = $2;
				}else{						     # otherwise use regular n+s
					$sg = $form;
					$pl = $form."s";
				}	
						
				push (@singular_forms, [$sg, "\@num.sg \@pers.3rd"]);
				push (@plural_forms,   [$pl, "\@num.pl \@pers.3rd"]);
			}

			# add all the single forms 
			$stem .= "-sg";

			@families=("noun");
			if(@args[0] eq "of-np"){push (@families, "noun.of-np");}

			@word_forms = @singular_forms;	
			print_entry();

			# add all the plural forms in a separate entry 
			$stem .= "-pl";
			@word_forms = @plural_forms;
			@families=("noun", "noun.bare-plural");	
			if(@args[0] eq "of-np"){push (@families, ("noun.of-np", "noun.bare-plural.of-np") );}
			print_entry();
		
		} else {
		
			if (@args[0] eq "mass"){
		       foreach $form (@forms) {push (@word_forms, [$form, "\@syn-num.sg \@pers.3rd"]);}
			   @families=("noun.mass");
               print_entry();
				
	        } elsif(@args[0] eq "name"){ # Names (sg, unmodifiable, 3-rd perons bare-np)   
				foreach $form (@forms) {push (@word_forms, [$form, "\@pers.3rd \@num.sg"]);}
				@families=("bare-np");
				print_entry();
			}
		
		} # main if 	   
       
	
	# ---- ADV  ----
	# advs have a family of type adv. The must have complecat-cat (cc) class specified, 
	# and mod-type as well
	
    }elsif($pos eq "ADV"){
	
			
		if(@args[0] eq ""){
			$compcats = "\@adv.all"    # default cc class
		}else{
			$compcats="\@adv.".@args[0]; # cc class specified as first arg
        }

     	$mod_type = substr $class, 2;  # mod-type is just class, stripped of initial m-
		foreach $form (@forms) {push(@word_forms, [$form, "\@mod.".$mod_type." ".$compcats] ); }
	
		@families=("adv");	
		print_entry();
		
	
	# ---- PREP  ----
    }elsif($pos eq "PREP"){
	 
		$append=""; $compcats="";$mod_type="";
		
		if(@args[0] eq ""){
			$compcats = "\@prep.all"    # default cc class
		}else{
			$compcats="\@prep.".@args[0]; # cc class specified as first arg
		}

		if(@args[1] eq ""){}else{$append = ".".@args[1];}
				
     	$mod_type = substr $class, 2;  # mod-type is just class, stripped of initial m-

		foreach $form (@forms) { push(@word_forms, [$form, "\@mod.".$mod_type." ".$compcats] ); }
	
		@families=("prep".$append);	
		print_entry();
		

    # ---- MARKER  ---- 
    # dependent clause markers such as if, when, because, etc.
    }elsif($pos eq "MARKER"){
	
    	foreach $form (@forms) {push (@word_forms, [$form, ""]);}
		
		$clause_type = substr $class, 2;
		@families=("dep-clause-marker.".$clause_type);
		print_entry();


    # ---- DISCOURSE UNIT  ---- 		
     }elsif($pos eq "DU"){
	
    	foreach $form (@forms) {push (@word_forms, [$form, ""]);}
		
		@families=("dis-unit.connective");
		print_entry();



    # ---- VERB  ----	
	# Verbs have different vforms (nonfinite, past, etc), modifier-classes and
	# specify their families explicitly (--> tv iv, etc)
	# This creates two dict entries: ind and imp
	}elsif($pos eq "V"){
	

		@ind_forms=();@imp_forms=();@vforms=();
				
       	foreach $form (@forms) {
		
		   @vforms = split(/ /, $form);
		   
		   if (@vforms == 1){     # if only the base form given, this implies regular
			 @vforms[1] = @vforms[0]."s";
			 @vforms[2] = @vforms[0]."ing";
			 @vforms[3] = @vforms[0]."ed";
		   }
		 
           $mod_class = "\@mod-class.".@args[1];  # the mod-class is given as the second argument
		 
	       push (@ind_forms, [@vforms[0], $mod_class." \@nonfin"]);
		   push (@ind_forms, [@vforms[0], $mod_class." \@finite \@pres \@imp \@pers.3rd-agr"]); # THIS FOR DIRECTED VOCATIVE IMPERATIVES Robot pick that up
		   push (@ind_forms, [@vforms[2], $mod_class." \@vform.progr"]);
		   push (@ind_forms, [@vforms[0], $mod_class." \@finite \@pres \@ind \@pers.non-3rd-agr \@num.sg-agr "]);
           push (@ind_forms, [@vforms[0], $mod_class." \@finite \@pres \@ind \@num.pl-agr "]);
	   	   push (@ind_forms, [@vforms[1], $mod_class." \@finite \@pres \@ind \@pers.3rd-agr \@num.sg-agr"]);
		   push (@ind_forms, [@vforms[3], $mod_class." \@finite \@past \@ind"]);
	
		   push (@imp_forms, [@vforms[0], $mod_class." \@finite \@pres \@imp-addressee"]);           
	    }  
		  		
		# add the indicative entry 
		@families = split(/ /, @args[0]);   # the families are given in 1st argument slot, separated by spaces
		@word_forms = @ind_forms;	
    	print_entry();

        # add the imperitive entry 
		$stem .= "NO-SUBJ";		 
		foreach $family (@families){$family .= ".NO-SUBJ";}
		@word_forms = @imp_forms;	
     	print_entry();



    # ---- MOD  ----
    # mods all have a direction and modifier type (adj, pp, or adv) 
	# in dict.list  listed as , e.g. right.prep -> mod-right.prep
	}elsif($pos eq "MOD"){
	
		@mod_types=();
	
	    foreach $form (@forms) {push (@word_forms, [$form, ""]);}
		   	
		# create families (attach mod- to give forms (dir.type)
		@mod_types = split(/ /, @args[0]);
    
		foreach $type (@mod_types) {
			push(@families, "mod-".$type);
		}
		
		print_entry();



    # ---- WORD ----
    }elsif($pos eq "WORD"){
	    
    	foreach $form (@forms) {push (@word_forms, [$form, ""]);}
		$stem = $pred; # don't want wform to be X__blah	
      	print_entry();
		for ($i = 1; $i <= 3; $i++){
		   $index = 50 + $i;
		   $dictlist .= "<macro name=\"\@mwe". $i . "-". $pred . "\"> <fs id=\"" . $index."\">"
		                 ."<feat attr=\"wform\" val=\"".$pred."\"/> </fs> </macro>\n";

		# Attempting to have generating MWE by marking head with wform1, wform2, etc features....
		#$dictlist .= "<macro name=\"\@mwe". $i . "-". $pred . "\"> <fs id=\"" . $index."\">"
		#            ."<feat attr=\"wform\" val=\"".$pred."\"/> </fs> 
		#				<fs id=\"25\"><feat attr=\"wform".$i."\"  val=\"".$pred."\"/> </fs>
		#				 </macro>\n";


	    }
    }
}



#######################################################################################

sub print_entry{
    $num_of_mw = 0; # this used to counter number of multi-words in the line.
    $dictlist .= header().forms().members().footer();
	$entry_printed = "yes"; # this signifies that at least one entry was added. Otherwise, error printed (see top)
}

sub print_pos_header{

$dictlist .= "<!-- ++++++++++++++++++++++++++++++++++++++++++++++++ \n".  
            "     +  ".$pos."\n".
            "     ++++++++++++++++++++++++++++++++++++++++++++++++ -->\n\n\n";
}

sub header{
    return "<entry pred=\"".$pred."\" stem=\"".$stem."\"  pos=\"".$pos."\" class=\"".$class."\">\n"
}

sub footer{
    return "</entry>"."\n"
}

sub forms{

	$form_string = "";
	
	foreach $wform (@word_forms){
	
		@multi_words = split(/_/, @{$wform}[0]);  #split the entry over _, getting each multi-word if there are any
		if (@multi_words gt 1){			# if any m-w found, then add @mweX-mw for each
			$mw_counter = 0;
			@{$wform}[0] = @multi_words[0];
			shift @multi_words;
		    foreach $mw (@multi_words){ @{$wform}[1] .= " \@mwe".($mw_counter++ +1)."-".$mw; }
			$num_of_mw = $mw_counter; # set the num (used later in families to add _W) to the counter
		}
					
		# Add the wform
	    $form_string .= $tab."<word form=\"".@{$wform}[0]."\"";  #print form
		if (@{$wform}[1] ne ""){
		  $form_string .= " macros=\"".@{$wform}[1]."\"";  #add macros if there are any 
		}
		$form_string .= "/>\n"; # close word form line
   }
	   
    return $form_string;
}

sub members{
	$family_string = "";
    foreach $mem (@families){
	   for ($i = 0; $i < $num_of_mw; $i++){$mem .= "_W";} # if multi-words were found, add a _W to end of family for each
       $family_string .=  $tab."<member-of family=\"".$mem."\"/>"."\n"
	}
	return $family_string;
}