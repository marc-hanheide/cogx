#ifndef CONSTANTS_H__
#define CONSTANTS_H__  1

#define TRUTH_STR          "i"
#define BELIEF_STR         "bel"
#define INTENTION_STR      "int"
#define ATTENTION_STR      "att"
#define EVENT_STR          "event"
#define UNDERSTANDING_STR  "understand"
#define GENERATION_STR     "generate"

#endif
