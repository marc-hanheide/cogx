%-----------------------------------------------------------------------------%
% vim: ft=mercury ts=4 sw=4 et
%-----------------------------------------------------------------------------%
% Copyright (C) 2000-2007 The University of Melbourne.
% This file may only be copied under the terms of the GNU General
% Public License - see the file COPYING in the Mercury distribution.
%-----------------------------------------------------------------------------%
%
% File: smm_fixpoint_table.m
%
% This is currently provided by ctgc.fixpoint_table.
%
%-----------------------------------------------------------------------------%

:- module transform_hlds.smm_fixpoint_table.
:- interface.
