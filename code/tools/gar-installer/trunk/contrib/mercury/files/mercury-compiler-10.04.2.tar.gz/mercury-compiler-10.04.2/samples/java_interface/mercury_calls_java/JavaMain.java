// This source file is hereby placed in the public domain.

package my_package;

public class JavaMain {
	public static void java_main() {
		System.out.println("In java_main().");
	}
}
