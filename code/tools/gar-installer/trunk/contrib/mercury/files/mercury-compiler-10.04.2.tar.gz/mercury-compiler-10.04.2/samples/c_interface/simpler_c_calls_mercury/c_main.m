%-----------------------------------------------------------------------------%
% This source file is hereby placed in the public domain.  -stayl (the author).
%
% This empty module is used to give the executable produced
% by mmake the correct name.
%-----------------------------------------------------------------------------%
:- module c_main.

:- import_module mercury_lib.
