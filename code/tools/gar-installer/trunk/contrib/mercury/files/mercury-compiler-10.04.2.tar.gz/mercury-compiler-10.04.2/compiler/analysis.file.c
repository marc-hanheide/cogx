/*
** Automatically generated from `analysis.file.m'
** by the Mercury compiler,
** version 10.04.2, configured for x86_64-unknown-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
** HIGHLEVEL_CODE=no
**
** END_OF_C_GRADE_INFO
*/

/*
INIT mercury__analysis__file__init
ENDINIT
*/

#define MR_ALLOW_RESET
#include "mercury_imp.h"
#line 3 "analysis.int0"
#include "analysis.mh"

#line 28 "analysis.file.c"
#line 539 "../library/io.int"
#include "io.mh"

#line 32 "analysis.file.c"
#line 547 "../library/io.int"
#include "string.mh"

#line 36 "analysis.file.c"
#line 56 "../library/dir.int"
#include "dir.mh"

#line 40 "analysis.file.c"
#line 29 "../library/bitmap.int2"
#include "bitmap.mh"

#line 44 "analysis.file.c"
#line 28 "../library/time.int2"
#include "time.mh"

#line 48 "analysis.file.c"
#line 31 "../library/array.int2"
#include "array.mh"

#line 52 "analysis.file.c"
#line 33 "../mdbcomp/mdbcomp.rtti_access.int2"
#include "mdbcomp.rtti_access.mh"

#line 56 "analysis.file.c"
#line 21 "../library/stm_builtin.int2"
#include "stm_builtin.mh"

#line 60 "analysis.file.c"
#line 31 "../library/store.int2"
#include "store.mh"

#line 64 "analysis.file.c"
#line 65 "analysis.file.c"
#include "analysis.file.mh"

#line 68 "analysis.file.c"
#line 69 "analysis.file.c"
#ifndef ANALYSIS__FILE_DECL_GUARD
#define ANALYSIS__FILE_DECL_GUARD

#line 73 "analysis.file.c"
#line 74 "analysis.file.c"

#endif
#line 77 "analysis.file.c"

#ifdef _MSC_VER
#define MR_STATIC_LINKAGE extern
#else
#define MR_STATIC_LINKAGE static
#endif

struct mercury_type_0 {
	MR_Word * f1[2];
};
MR_STATIC_LINKAGE const struct mercury_type_0 mercury_common_0[];

struct mercury_type_1 {
	MR_Word * f1[3];
};
MR_STATIC_LINKAGE const struct mercury_type_1 mercury_common_1[];

struct mercury_type_2 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[3];
};
MR_STATIC_LINKAGE const struct mercury_type_2 mercury_common_2[];

struct mercury_type_3 {
	MR_Unsigned f1[2];
};
MR_STATIC_LINKAGE const struct mercury_type_3 mercury_common_3[];

struct mercury_type_4 {
	MR_Word * f1;
	MR_Word * f2;
	MR_Integer f3;
	MR_Word * f4;
	MR_Integer f5;
	MR_Word * f6;
	MR_Word * f7;
	MR_Word * f8;
};
MR_STATIC_LINKAGE const struct mercury_type_4 mercury_common_4[];

struct mercury_type_5 {
	MR_Word * f1;
	MR_Integer f2;
	MR_Word * f3;
	MR_Word * f4;
	MR_Word * f5;
};
MR_STATIC_LINKAGE const struct mercury_type_5 mercury_common_5[];

struct mercury_type_6 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[5];
};
MR_STATIC_LINKAGE const struct mercury_type_6 mercury_common_6[];

struct mercury_type_7 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[4];
};
MR_STATIC_LINKAGE const struct mercury_type_7 mercury_common_7[];

struct mercury_type_8 {
	MR_Word * f1;
	MR_Code * f2;
	MR_Integer f3;
};
MR_STATIC_LINKAGE const struct mercury_type_8 mercury_common_8[];

struct mercury_type_9 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3;
	MR_Integer f4;
	MR_Word * f5[6];
};
MR_STATIC_LINKAGE const struct mercury_type_9 mercury_common_9[];

struct mercury_type_10 {
	MR_Word * f1;
	MR_Word * f2;
	MR_Integer f3;
	MR_Word * f4;
};
MR_STATIC_LINKAGE const struct mercury_type_10 mercury_common_10[];

struct mercury_type_11 {
	MR_Word * f1;
	MR_Integer f2;
	MR_Word * f3;
	MR_Word * f4;
	MR_Integer f5;
	MR_Word * f6;
	MR_Word * f7;
};
MR_STATIC_LINKAGE const struct mercury_type_11 mercury_common_11[];

struct mercury_type_12 {
	MR_Word * f1;
	MR_Integer f2;
};
MR_STATIC_LINKAGE const struct mercury_type_12 mercury_common_12[];

struct mercury_type_13 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[6];
};
MR_STATIC_LINKAGE const struct mercury_type_13 mercury_common_13[];

struct mercury_type_14 {
	MR_Word * f1;
	MR_Integer f2;
	MR_Word * f3;
	MR_Integer f4;
	MR_Integer f5;
};
MR_STATIC_LINKAGE const struct mercury_type_14 mercury_common_14[];

struct mercury_type_15 {
	MR_Word * f1;
	MR_Word * f2;
	MR_Integer f3;
	MR_Word * f4;
	MR_Word * f5;
	MR_Integer f6;
	MR_Integer f7;
	MR_Word * f8;
	MR_Word * f9;
};
MR_STATIC_LINKAGE const struct mercury_type_15 mercury_common_15[];

struct mercury_type_16 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3;
	MR_Integer f4;
	MR_Word * f5[5];
};
MR_STATIC_LINKAGE const struct mercury_type_16 mercury_common_16[];

struct mercury_type_17 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[7];
};
MR_STATIC_LINKAGE const struct mercury_type_17 mercury_common_17[];

struct mercury_type_18 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[4];
	MR_Integer f4;
	MR_Word * f5[2];
};
MR_STATIC_LINKAGE const struct mercury_type_18 mercury_common_18[];

struct mercury_type_19 {
	MR_String f1;
};
MR_STATIC_LINKAGE const struct mercury_type_19 mercury_common_19[];

extern const MR_BaseTypeclassInfo
	mercury_data_base_typeclass_info_analysis__to_term__arity1__analysis__file__dummy_answer__arity0__[],
	mercury_data_base_typeclass_info_analysis__partial_order__arity2__analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0__[],
	mercury_data_base_typeclass_info_analysis__answer_pattern__arity2__analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0__[],
	mercury_data_base_typeclass_info_analysis__analysis__arity3__analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0__[];

extern const MR_TypeCtorInfo_Struct
	mercury_data_analysis__file__type_ctor_info_dummy_answer_0,
	mercury_data_analysis__file__type_ctor_info_invalid_analysis_file_0,
	mercury_data_analysis__file__type_ctor_info_parse_entry_1,
	mercury_data_analysis__file__type_ctor_info_write_entry_1;
MR_decl_label1(analysis__file__ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__from_term_2_2_0, 1)
MR_decl_label2(analysis__file__IntroducedFrom__pred__empty_request_file__913__1_3_0, 2,3)
MR_decl_label6(analysis__file__IntroducedFrom__pred__read_analysis_file__547__1_5_0, 2,3,4,5,6,7)
MR_decl_label2(analysis__file__IntroducedFrom__pred__read_analysis_file__567__1_3_0, 2,3)
MR_decl_label5(analysis__file__IntroducedFrom__pred__read_analysis_file__575__1_6_0, 2,3,9,10,12)
MR_decl_label2(analysis__file__IntroducedFrom__pred__read_analysis_file__592__1_3_0, 2,3)
MR_decl_label2(analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__327__1_3_0, 2,3)
MR_decl_label2(analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__349__1_3_0, 2,3)
MR_decl_label2(analysis__file__IntroducedFrom__pred__write_module_analysis_requests__716__1_3_0, 2,3)
MR_decl_label2(analysis__file__IntroducedFrom__pred__write_module_analysis_results__664__1_3_0, 2,3)
MR_decl_label5(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_114_101_97_100_95_97_110_97_108_121_115_105_115_95_102_105_108_101_95_50_95_95_91_49_93_95_48_5_0, 18,2,4,6,5)
MR_decl_label10(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0, 2,4,6,7,8,9,10,12,3,13)
MR_decl_label1(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0, 14)
MR_decl_label5(analysis__file__check_analysis_file_version_number_2_0, 2,3,9,10,12)
MR_decl_label2(analysis__file__empty_request_file_5_0, 2,4)
MR_decl_label4(analysis__file__parse_func_id_2_0, 9,8,20,1)
MR_decl_label10(analysis__file__parse_imdg_arc_4_0, 16,18,20,22,23,24,27,31,36,33)
MR_decl_label10(analysis__file__parse_imdg_arc_4_0, 39,40,43,41,48,49,26,2,3,54)
MR_decl_label1(analysis__file__parse_imdg_arc_4_0, 55)
MR_decl_label10(analysis__file__parse_request_entry_4_0, 16,18,20,22,23,24,27,31,36,33)
MR_decl_label10(analysis__file__parse_request_entry_4_0, 39,40,43,41,48,49,26,2,3,54)
MR_decl_label1(analysis__file__parse_request_entry_4_0, 55)
MR_decl_label10(analysis__file__parse_result_entry_4_0, 15,17,19,20,21,23,24,25,28,29)
MR_decl_label10(analysis__file__parse_result_entry_4_0, 27,32,40,37,43,44,47,45,52,53)
MR_decl_label5(analysis__file__parse_result_entry_4_0, 31,2,3,58,59)
MR_decl_label7(analysis__file__pickle_analysis_result_4_0, 2,3,4,5,6,7,8)
MR_decl_label9(analysis__file__read_analysis_file_6_0, 2,6,4,8,9,11,12,13,15)
MR_decl_label4(analysis__file__read_module_analysis_requests_6_0, 5,7,11,9)
MR_decl_label10(analysis__file__read_module_analysis_results_6_0, 2,4,8,9,13,14,15,16,17,22)
MR_decl_label10(analysis__file__read_module_analysis_results_6_0, 25,29,32,33,34,35,36,37,38,31)
MR_decl_label3(analysis__file__read_module_analysis_results_6_0, 19,40,41)
MR_decl_label10(analysis__file__read_module_analysis_results_2_5_0, 4,5,9,7,11,12,13,17,18,19)
MR_decl_label1(analysis__file__read_module_analysis_results_2_5_0, 21)
MR_decl_label4(analysis__file__read_module_imdg_6_0, 5,7,11,9)
MR_decl_label10(analysis__file__read_module_overall_status_6_0, 2,4,5,8,9,13,12,16,15,19)
MR_decl_label10(analysis__file__read_module_overall_status_6_0, 18,21,11,27,26,29,30,31,7,33)
MR_decl_label6(analysis__file__read_module_overall_status_6_0, 34,35,3,39,41,37)
MR_decl_label10(analysis__file__write_analysis_cache_file_4_0, 2,3,6,7,8,10,14,15,16,19)
MR_decl_label10(analysis__file__write_analysis_cache_file_4_0, 20,21,22,23,24,5,26,27,28,4)
MR_decl_label10(analysis__file__write_analysis_file_5_0, 2,5,6,7,11,12,4,14,15,16)
MR_decl_label2(analysis__file__write_analysis_file_5_0, 17,18)
MR_decl_label10(analysis__file__write_analysis_file_10_0, 2,4,3,6,9,10,11,15,16,17)
MR_decl_label6(analysis__file__write_analysis_file_10_0, 8,18,19,20,21,22)
MR_decl_label1(analysis__file__write_analysis_file_4_6_0, 2)
MR_decl_label10(analysis__file__write_imdg_arc_6_0, 3,5,2,6,8,9,10,11,12,13)
MR_decl_label10(analysis__file__write_imdg_arc_6_0, 14,16,18,19,20,21,22,23,24,25)
MR_decl_label5(analysis__file__write_imdg_arc_6_0, 26,27,28,29,30)
MR_decl_label10(analysis__file__write_module_analysis_requests_6_0, 2,4,5,7,10,11,12,13,19,21)
MR_decl_label4(analysis__file__write_module_analysis_requests_6_0, 24,26,27,14)
MR_decl_label8(analysis__file__write_module_analysis_results_6_0, 3,5,6,7,13,14,15,17)
MR_decl_label9(analysis__file__write_module_overall_status_6_0, 2,3,7,9,11,5,13,14,15)
MR_decl_label10(analysis__file__write_request_entry_6_0, 3,5,2,6,8,9,10,11,12,13)
MR_decl_label10(analysis__file__write_request_entry_6_0, 14,16,18,19,20,21,22,23,24,25)
MR_decl_label5(analysis__file__write_request_entry_6_0, 26,27,28,29,30)
MR_decl_label10(analysis__file__write_result_entry_5_0, 2,4,5,6,7,8,9,11,13,14)
MR_decl_label10(analysis__file__write_result_entry_5_0, 15,16,17,18,19,20,21,22,23,24)
MR_decl_label10(analysis__file__write_result_entry_5_0, 25,26,27,28,29,30,31,32,33,34)
MR_decl_label1(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_name_2_2_0, 2)
MR_decl_label1(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_version_number_2_2_0, 2)
MR_decl_label1(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__preferred_fixpoint_type_2_2_0, 2)
MR_decl_label1(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_116_111_95_116_101_114_109_95_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_116_111_95_116_101_114_109_95_49_95_95_91_49_93_95_48_1_0, 3)
MR_decl_label3(fn__analysis__file__init_analysis_unpicklers_1_0, 2,3,4)
MR_decl_label1(__Unify___analysis__file__invalid_analysis_file_0_0, 4)
MR_decl_label2(__Compare___analysis__file__invalid_analysis_file_0_0, 3,2)
MR_def_extern_entry(analysis__file__read_module_overall_status_6_0)
MR_def_extern_entry(analysis__file__write_module_overall_status_6_0)
MR_decl_static(analysis__file__check_analysis_file_version_number_2_0)
MR_decl_static(analysis__file__read_module_analysis_results_2_5_0)
MR_decl_static(analysis__file__write_analysis_cache_file_4_0)
MR_decl_static(fn__analysis__file__init_analysis_unpicklers_1_0)
MR_def_extern_entry(analysis__file__read_module_analysis_results_6_0)
MR_decl_static(analysis__file__write_analysis_file_2_4_0)
MR_decl_static(analysis__file__write_analysis_file_5_0)
MR_decl_static(analysis__file__write_analysis_file_10_0)
MR_def_extern_entry(analysis__file__write_module_analysis_results_6_0)
MR_decl_static(analysis__file__read_analysis_file_6_0)
MR_def_extern_entry(analysis__file__read_module_analysis_requests_6_0)
MR_def_extern_entry(analysis__file__write_module_analysis_requests_6_0)
MR_def_extern_entry(analysis__file__read_module_imdg_6_0)
MR_def_extern_entry(analysis__file__write_module_imdg_6_0)
MR_def_extern_entry(analysis__file__empty_request_file_5_0)
MR_decl_static(analysis__file__parse_func_id_2_0)
MR_decl_static(analysis__file__parse_result_entry_4_0)
MR_decl_static(analysis__file__parse_request_entry_4_0)
MR_decl_static(analysis__file__parse_imdg_arc_4_0)
MR_decl_static(analysis__file__write_result_entry_5_0)
MR_decl_static(analysis__file__write_request_entry_6_0)
MR_decl_static(analysis__file__write_imdg_arc_6_0)
MR_decl_static(analysis__file__write_analysis_file_3_5_0)
MR_decl_static(analysis__file__write_analysis_file_4_6_0)
MR_decl_static(analysis__file__dir_sep_1_0)
MR_decl_static(analysis__file__pickle_analysis_result_4_0)
MR_decl_static(analysis__file__unpickle_analysis_result_7_0)
MR_decl_static(__Unify___analysis__file__dummy_answer_0_0)
MR_decl_static(__Compare___analysis__file__dummy_answer_0_0)
MR_decl_static(__Unify___analysis__file__invalid_analysis_file_0_0)
MR_decl_static(__Compare___analysis__file__invalid_analysis_file_0_0)
MR_decl_static(__Unify___analysis__file__parse_entry_1_0)
MR_decl_static(__Compare___analysis__file__parse_entry_1_0)
MR_decl_static(__Unify___analysis__file__write_entry_1_0)
MR_decl_static(__Compare___analysis__file__write_entry_1_0)
MR_decl_static(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_name_2_2_0)
MR_decl_static(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_version_number_2_2_0)
MR_decl_static(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__preferred_fixpoint_type_2_2_0)
MR_decl_static(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__bottom_2_2_0)
MR_decl_static(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__top_2_2_0)
MR_decl_static(analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__get_func_info_6_6_0)
MR_decl_static(analysis__file__ClassMethod_for_analysis__partial_order____analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0______analysis__more_precise_than_3_3_0)
MR_decl_static(analysis__file__ClassMethod_for_analysis__partial_order____analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0______analysis__equivalent_3_3_0)
MR_decl_static(fn__analysis__file__ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__to_term_1_1_0)
MR_decl_static(analysis__file__ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__from_term_2_2_0)
MR_decl_static(analysis__file__IntroducedFrom__pred__write_module_analysis_results__664__1_3_0)
MR_decl_static(analysis__file__IntroducedFrom__pred__write_module_analysis_requests__716__1_3_0)
MR_decl_static(analysis__file__IntroducedFrom__pred__empty_request_file__913__1_3_0)
MR_decl_static(analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__349__1_3_0)
MR_decl_static(analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__327__1_3_0)
MR_decl_static(analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__336__1_5_0)
MR_decl_static(analysis__file__IntroducedFrom__pred__read_analysis_file__547__1_5_0)
MR_decl_static(analysis__file__IntroducedFrom__pred__read_analysis_file__592__1_3_0)
MR_decl_static(analysis__file__IntroducedFrom__pred__read_analysis_file__567__1_3_0)
MR_decl_static(analysis__file__IntroducedFrom__pred__read_analysis_file__575__1_6_0)
MR_decl_static(analysis__file__IntroducedFrom__pred__write_analysis_file_4__904__1_7_0)
MR_decl_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_114_101_97_100_95_97_110_97_108_121_115_105_115_95_102_105_108_101_95_50_95_95_91_49_93_95_48_5_0)
MR_decl_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0)
MR_decl_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_85_110_105_102_121_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_48_95_95_91_49_44_32_50_93_95_48_2_0)
MR_decl_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_67_111_109_112_97_114_101_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_48_95_95_91_50_44_32_51_93_95_48_3_0)
MR_decl_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_85_110_105_102_121_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_112_97_114_115_101_95_101_110_116_114_121_95_49_95_95_91_49_93_95_48_2_0)
MR_decl_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_67_111_109_112_97_114_101_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_112_97_114_115_101_95_101_110_116_114_121_95_49_95_95_91_49_93_95_48_3_0)
MR_decl_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_85_110_105_102_121_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_119_114_105_116_101_95_101_110_116_114_121_95_49_95_95_91_49_93_95_48_2_0)
MR_decl_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_67_111_109_112_97_114_101_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_119_114_105_116_101_95_101_110_116_114_121_95_49_95_95_91_49_93_95_48_3_0)
MR_decl_static(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_110_97_109_101_95_50_95_95_91_49_44_32_50_93_95_48_2_0)
MR_decl_static(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_118_101_114_115_105_111_110_95_110_117_109_98_101_114_95_50_95_95_91_49_44_32_50_93_95_48_2_0)
MR_decl_static(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_112_114_101_102_101_114_114_101_100_95_102_105_120_112_111_105_110_116_95_116_121_112_101_95_50_95_95_91_49_44_32_50_93_95_48_2_0)
MR_decl_static(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_98_111_116_116_111_109_95_50_95_95_91_49_44_32_50_93_95_48_2_0)
MR_decl_static(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_116_111_112_95_50_95_95_91_49_44_32_50_93_95_48_2_0)
MR_decl_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_103_101_116_95_102_117_110_99_95_105_110_102_111_95_54_95_95_91_49_44_32_50_44_32_51_44_32_52_44_32_53_93_95_48_6_0)
MR_decl_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_112_97_114_116_105_97_108_95_111_114_100_101_114_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_109_111_114_101_95_112_114_101_99_105_115_101_95_116_104_97_110_95_51_95_95_91_49_44_32_50_44_32_51_93_95_48_3_0)
MR_decl_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_112_97_114_116_105_97_108_95_111_114_100_101_114_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_101_113_117_105_118_97_108_101_110_116_95_51_95_95_91_49_44_32_50_44_32_51_93_95_48_3_0)
MR_decl_static(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_116_111_95_116_101_114_109_95_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_116_111_95_116_101_114_109_95_49_95_95_91_49_93_95_48_1_0)

extern const MR_TypeCtorInfo_Struct mercury_data_list__type_ctor_info_list_1;
extern const MR_TypeCtorInfo_Struct mercury_data_analysis__type_ctor_info_some_analysis_result_0;
extern const MR_TypeCtorInfo_Struct mercury_data_term__type_ctor_info_term_1;
extern const MR_TypeCtorInfo_Struct mercury_data_term__type_ctor_info_generic_0;
extern const MR_TypeCtorInfo_Struct mercury_data_list__type_ctor_info_list_1;
extern const MR_TypeCtorInfo_Struct mercury_data_analysis__type_ctor_info_some_analysis_result_0;
extern const MR_TypeCtorInfo_Struct mercury_data_term__type_ctor_info_term_1;
extern const MR_TypeCtorInfo_Struct mercury_data_analysis__type_ctor_info_analysis_request_0;
extern const MR_TypeCtorInfo_Struct mercury_data_analysis__type_ctor_info_analysis_request_0;
extern const MR_TypeCtorInfo_Struct mercury_data_analysis__type_ctor_info_imdg_arc_0;
extern const MR_TypeCtorInfo_Struct mercury_data_analysis__type_ctor_info_imdg_arc_0;
extern const MR_TypeCtorInfo_Struct mercury_data_term__type_ctor_info_generic_0;
static const struct mercury_type_0 mercury_common_0[9] =
{
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(analysis, some_analysis_result)
}
},
{
{
MR_CTOR1_ADDR(term, term),
MR_CTOR0_ADDR(term, generic)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(analysis, some_analysis_result)
}
},
{
{
MR_CTOR1_ADDR(term, term),
MR_CTOR0_ADDR(term, generic)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(analysis, analysis_request)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(analysis, analysis_request)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(analysis, imdg_arc)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(analysis, imdg_arc)
}
},
{
{
MR_CTOR1_ADDR(term, term),
MR_CTOR0_ADDR(term, generic)
}
},
};

extern const MR_TypeCtorInfo_Struct mercury_data_tree234__type_ctor_info_tree234_2;
extern const MR_TypeCtorInfo_Struct mercury_data_analysis__type_ctor_info_func_id_0;
extern const MR_TypeCtorInfo_Struct mercury_data_tree234__type_ctor_info_tree234_2;
extern const MR_TypeCtorInfo_Struct mercury_data_analysis__type_ctor_info_func_id_0;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_string_0;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_string_0;
static const struct mercury_type_1 mercury_common_1[14] =
{
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_CTOR0_ADDR(analysis, func_id),
MR_TAG_COMMON(0,0,0)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_CTOR0_ADDR(analysis, func_id),
MR_COMMON(0,2)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_STRING_CTOR_ADDR,
MR_COMMON(1,1)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_STRING_CTOR_ADDR,
MR_COMMON(1,1)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_STRING_CTOR_ADDR,
MR_TAG_COMMON(0,1,0)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_CTOR0_ADDR(analysis, func_id),
MR_COMMON(12,0)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_CTOR0_ADDR(analysis, func_id),
MR_COMMON(0,4)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_STRING_CTOR_ADDR,
MR_COMMON(1,6)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_CTOR0_ADDR(analysis, func_id),
MR_TAG_COMMON(0,0,5)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_STRING_CTOR_ADDR,
MR_TAG_COMMON(0,1,8)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_CTOR0_ADDR(analysis, func_id),
MR_COMMON(0,6)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_STRING_CTOR_ADDR,
MR_COMMON(1,10)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_CTOR0_ADDR(analysis, func_id),
MR_TAG_COMMON(0,0,7)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_STRING_CTOR_ADDR,
MR_TAG_COMMON(0,1,12)
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_module_analysis_results_2_5_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_string_0;
extern const MR_TypeCtorInfo_Struct mercury_data_io__type_ctor_info_state_0;
static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_module_analysis_results_2_5_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_module_analysis_results_6_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_mdbcomp__prim_data__type_ctor_info_sym_name_0;
static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_analysis_file_6_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_analysis_file_6_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_module_analysis_requests_6_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__empty_request_file_5_0_1;
static const struct mercury_type_2 mercury_common_2[7] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__read_module_analysis_results_2_5_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_STRING_CTOR_ADDR,
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__read_module_analysis_results_2_5_0_2,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_STRING_CTOR_ADDR,
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__write_module_analysis_results_6_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__read_analysis_file_6_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_STRING_CTOR_ADDR,
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__read_analysis_file_6_0_2,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_STRING_CTOR_ADDR,
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__write_module_analysis_requests_6_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_STRING_CTOR_ADDR,
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__empty_request_file_5_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_STRING_CTOR_ADDR,
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
};

static const struct mercury_type_3 mercury_common_3[2] =
{
{
{
1,
17437
}
},
{
{
1,
17
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_module_analysis_results_2_5_0_3;
extern const MR_TypeCtorInfo_Struct mercury_data_private_builtin__type_ctor_info_typeclass_info_0;
static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_module_analysis_requests_6_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_module_imdg_6_0_1;
static const struct mercury_type_4 mercury_common_4[3] =
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__read_module_analysis_results_2_5_0_3,
MR_COMMON(3,0),
5,
MR_CTOR0_ADDR(private_builtin, typeclass_info),
1,
MR_COMMON(0,1),
MR_COMMON(1,2),
MR_COMMON(1,2)
},
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__read_module_analysis_requests_6_0_1,
MR_COMMON(3,0),
5,
MR_CTOR0_ADDR(private_builtin, typeclass_info),
1,
MR_COMMON(0,1),
MR_COMMON(1,7),
MR_COMMON(1,7)
},
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__read_module_imdg_6_0_1,
MR_COMMON(3,0),
5,
MR_CTOR0_ADDR(private_builtin, typeclass_info),
1,
MR_COMMON(0,1),
MR_COMMON(1,11),
MR_COMMON(1,11)
},
};

extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_pred_0;
static const struct mercury_type_5 mercury_common_5[1] =
{
{
MR_CTOR0_ADDR(builtin, pred),
3,
MR_COMMON(0,3),
MR_COMMON(1,3),
MR_COMMON(1,3)
},
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_module_analysis_results_2_5_0_4;
static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_module_analysis_results_6_0_2;
extern const MR_TypeCtorInfo_Struct mercury_data_analysis__type_ctor_info_func_id_0;
extern const MR_TypeCtorInfo_Struct mercury_data_analysis__type_ctor_info_some_analysis_result_0;
static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_module_analysis_requests_6_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_module_imdg_6_0_2;
static const struct mercury_type_6 mercury_common_6[4] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__read_module_analysis_results_2_5_0_4,
(MR_Word *) (MR_Integer) 0
},
5,
{
MR_COMMON(1,2),
MR_COMMON(5,0),
MR_COMMON(1,2),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__write_module_analysis_results_6_0_2,
(MR_Word *) (MR_Integer) 0
},
5,
{
MR_STRING_CTOR_ADDR,
MR_CTOR0_ADDR(analysis, func_id),
MR_CTOR0_ADDR(analysis, some_analysis_result),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__read_module_analysis_requests_6_0_2,
(MR_Word *) (MR_Integer) 0
},
5,
{
MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name),
MR_STRING_CTOR_ADDR,
MR_STRING_CTOR_ADDR,
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__read_module_imdg_6_0_2,
(MR_Word *) (MR_Integer) 0
},
5,
{
MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name),
MR_STRING_CTOR_ADDR,
MR_STRING_CTOR_ADDR,
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_analysis_cache_file_4_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_libs__pickle__type_ctor_info_picklers_0;
extern const MR_TypeCtorInfo_Struct mercury_data_univ__type_ctor_info_univ_0;
static const struct mercury_type_7 mercury_common_7[1] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__write_analysis_cache_file_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(libs__pickle, picklers),
MR_CTOR0_ADDR(univ, univ),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
};

static const struct mercury_type_8 mercury_common_8[4] =
{
{
MR_COMMON(7,0),
MR_ENTRY_AP(analysis__file__pickle_analysis_result_4_0),
0
},
{
MR_COMMON(10,0),
MR_ENTRY_AP(analysis__file__dir_sep_1_0),
0
},
{
MR_COMMON(6,1),
MR_ENTRY_AP(analysis__file__write_result_entry_5_0),
0
},
{
MR_COMMON(10,1),
MR_ENTRY_AP(analysis__file__dir_sep_1_0),
0
},
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__analysis__file__init_analysis_unpicklers_1_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_libs__pickle__type_ctor_info_unpicklers_0;
extern const MR_TypeCtorInfo_Struct mercury_data_bitmap__type_ctor_info_bitmap_0;
extern const MR_TypeCtorInfo_Struct mercury_data_type_desc__type_ctor_info_type_desc_0;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_int_0;
static const struct mercury_type_9 mercury_common_9[1] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__fn__analysis__file__init_analysis_unpicklers_1_0_1,
MR_COMMON(3,0)
},
8,
MR_CTOR0_ADDR(private_builtin, typeclass_info),
1,
{
MR_CTOR0_ADDR(libs__pickle, unpicklers),
MR_CTOR0_ADDR(bitmap, bitmap),
MR_CTOR0_ADDR(type_desc, type_desc),
MR_CTOR0_ADDR(univ, univ),
MR_INT_CTOR_ADDR,
MR_INT_CTOR_ADDR
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_module_analysis_results_6_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_character_0;
static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_module_analysis_results_6_0_3;
static const struct mercury_type_10 mercury_common_10[2] =
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__read_module_analysis_results_6_0_1,
(MR_Word *) (MR_Integer) 0,
1,
MR_CHAR_CTOR_ADDR
},
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__write_module_analysis_results_6_0_3,
(MR_Word *) (MR_Integer) 0,
1,
MR_CHAR_CTOR_ADDR
},
};

extern const MR_TypeCtorInfo_Struct mercury_data_io__type_ctor_info_state_0;
static const struct mercury_type_11 mercury_common_11[1] =
{
{
MR_CTOR0_ADDR(builtin, pred),
5,
MR_STRING_CTOR_ADDR,
MR_CTOR0_ADDR(analysis, func_id),
1,
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
},
};

static const struct mercury_type_12 mercury_common_12[1] =
{
{
MR_LIST_CTOR_ADDR,
1
},
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_analysis_file_2_4_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_private_builtin__type_ctor_info_type_info_0;
static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_analysis_file_5_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_analysis_file_10_0_1;
static const struct mercury_type_13 mercury_common_13[3] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__write_analysis_file_2_4_0_1,
MR_COMMON(3,1)
},
6,
{
MR_CTOR0_ADDR(private_builtin, type_info),
MR_COMMON(11,0),
MR_STRING_CTOR_ADDR,
MR_COMMON(1,5),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__write_analysis_file_5_0_1,
MR_COMMON(3,1)
},
6,
{
MR_CTOR0_ADDR(private_builtin, type_info),
MR_COMMON(11,0),
MR_STRING_CTOR_ADDR,
MR_COMMON(1,5),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__write_analysis_file_10_0_1,
MR_COMMON(3,1)
},
6,
{
MR_CTOR0_ADDR(private_builtin, type_info),
MR_COMMON(11,0),
MR_STRING_CTOR_ADDR,
MR_COMMON(1,5),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
};

static const struct mercury_type_14 mercury_common_14[1] =
{
{
MR_CTOR0_ADDR(builtin, pred),
3,
MR_COMMON(0,3),
1,
1
},
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_analysis_file_6_0_3;
static const struct mercury_type_15 mercury_common_15[1] =
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__read_analysis_file_6_0_3,
MR_COMMON(3,1),
6,
MR_CTOR0_ADDR(private_builtin, type_info),
MR_COMMON(14,0),
1,
1,
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
},
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_module_analysis_requests_6_0_2;
extern const MR_TypeCtorInfo_Struct mercury_data_analysis__type_ctor_info_analysis_request_0;
static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_module_analysis_requests_6_0_3;
static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_module_analysis_requests_6_0_4;
static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_module_analysis_requests_6_0_5;
static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_module_imdg_6_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_analysis__type_ctor_info_imdg_arc_0;
static const struct mercury_type_16 mercury_common_16[5] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__write_module_analysis_requests_6_0_2,
MR_COMMON(3,0)
},
7,
MR_CTOR0_ADDR(private_builtin, typeclass_info),
1,
{
MR_STRING_CTOR_ADDR,
MR_CTOR0_ADDR(analysis, func_id),
MR_CTOR0_ADDR(analysis, analysis_request),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__write_module_analysis_requests_6_0_3,
MR_COMMON(3,0)
},
7,
MR_CTOR0_ADDR(private_builtin, typeclass_info),
1,
{
MR_STRING_CTOR_ADDR,
MR_CTOR0_ADDR(analysis, func_id),
MR_CTOR0_ADDR(analysis, analysis_request),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__write_module_analysis_requests_6_0_4,
MR_COMMON(3,0)
},
7,
MR_CTOR0_ADDR(private_builtin, typeclass_info),
1,
{
MR_STRING_CTOR_ADDR,
MR_CTOR0_ADDR(analysis, func_id),
MR_CTOR0_ADDR(analysis, analysis_request),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__write_module_analysis_requests_6_0_5,
MR_COMMON(3,0)
},
7,
MR_CTOR0_ADDR(private_builtin, typeclass_info),
1,
{
MR_STRING_CTOR_ADDR,
MR_CTOR0_ADDR(analysis, func_id),
MR_CTOR0_ADDR(analysis, analysis_request),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__write_module_imdg_6_0_1,
MR_COMMON(3,0)
},
7,
MR_CTOR0_ADDR(private_builtin, typeclass_info),
1,
{
MR_STRING_CTOR_ADDR,
MR_CTOR0_ADDR(analysis, func_id),
MR_CTOR0_ADDR(analysis, imdg_arc),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_analysis_file_3_5_0_1;
static const struct mercury_type_17 mercury_common_17[1] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__write_analysis_file_3_5_0_1,
MR_COMMON(3,1)
},
7,
{
MR_CTOR0_ADDR(private_builtin, type_info),
MR_COMMON(11,0),
MR_STRING_CTOR_ADDR,
MR_CTOR0_ADDR(analysis, func_id),
MR_COMMON(12,0),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_analysis_file_4_6_0_1;
static const struct mercury_type_18 mercury_common_18[1] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__analysis__file__write_analysis_file_4_6_0_1,
MR_COMMON(3,1)
},
7,
{
MR_CTOR0_ADDR(private_builtin, type_info),
MR_COMMON(11,0),
MR_STRING_CTOR_ADDR,
MR_CTOR0_ADDR(analysis, func_id)
},
1,
{
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
};

static const struct mercury_type_19 mercury_common_19[1] =
{
{
MR_string_const("dummy", 5)
},
};

static const MR_EnumFunctorDesc mercury_data_analysis__file__enum_functor_desc_dummy_answer_0_0 = {
	"dummy_answer",
	0
};

const MR_EnumFunctorDescPtr mercury_data_analysis__file__enum_value_ordered_dummy_answer_0[] = {
	&mercury_data_analysis__file__enum_functor_desc_dummy_answer_0_0
};

const MR_EnumFunctorDescPtr mercury_data_analysis__file__enum_name_ordered_dummy_answer_0[] = {
	&mercury_data_analysis__file__enum_functor_desc_dummy_answer_0_0
};

const MR_Integer mercury_data_analysis__file__functor_number_map_dummy_answer_0[] = {
	0 };
	
const MR_TypeCtorInfo_Struct mercury_data_analysis__file__type_ctor_info_dummy_answer_0 = {
	0,
	13,
	-1,
	MR_TYPECTOR_REP_DUMMY,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___analysis__file__dummy_answer_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___analysis__file__dummy_answer_0_0)),
	"analysis.file",
	"dummy_answer",
	{ (void *)mercury_data_analysis__file__enum_name_ordered_dummy_answer_0 },
	{ (void *)mercury_data_analysis__file__enum_value_ordered_dummy_answer_0 },
	1,
	4,
	mercury_data_analysis__file__functor_number_map_dummy_answer_0
};

static const MR_NotagFunctorDesc mercury_data_analysis__file__notag_functor_desc_invalid_analysis_file_0 = {
	"invalid_analysis_file",
	(MR_PseudoTypeInfo) &mercury_data_builtin__type_ctor_info_string_0,
	NULL
};

const MR_Integer mercury_data_analysis__file__functor_number_map_invalid_analysis_file_0[] = {
	0 };
	
const MR_TypeCtorInfo_Struct mercury_data_analysis__file__type_ctor_info_invalid_analysis_file_0 = {
	0,
	13,
	-1,
	MR_TYPECTOR_REP_NOTAG_GROUND,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___analysis__file__invalid_analysis_file_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___analysis__file__invalid_analysis_file_0_0)),
	"analysis.file",
	"invalid_analysis_file",
	{ (void *)&mercury_data_analysis__file__notag_functor_desc_invalid_analysis_file_0 },
	{ (void *)&mercury_data_analysis__file__notag_functor_desc_invalid_analysis_file_0 },
	1,
	4,
	mercury_data_analysis__file__functor_number_map_invalid_analysis_file_0
};

static const MR_FA_TypeInfo_Struct1 mercury_data_term__ti_term_1term__type_ctor_info_generic_0 = {
	&mercury_data_term__type_ctor_info_term_1,
{	(MR_TypeInfo) &mercury_data_term__type_ctor_info_generic_0
}};

static const MR_VA_PseudoTypeInfo_Struct3 mercury_data___vpti_pred_3__plain_term__ti_term_1term__type_ctor_info_generic_0__pseudo_1__pseudo_1 = {
	&mercury_data_builtin__type_ctor_info_pred_0,
	3,
{	(MR_PseudoTypeInfo) &mercury_data_term__ti_term_1term__type_ctor_info_generic_0,
	(MR_PseudoTypeInfo) 1,
	(MR_PseudoTypeInfo) 1
}};

const MR_TypeCtorInfo_Struct mercury_data_analysis__file__type_ctor_info_parse_entry_1 = {
	1,
	13,
	-1,
	MR_TYPECTOR_REP_EQUIV,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___analysis__file__parse_entry_1_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___analysis__file__parse_entry_1_0)),
	"analysis.file",
	"parse_entry",
	{ 0 },
	{ (void *)&mercury_data___vpti_pred_3__plain_term__ti_term_1term__type_ctor_info_generic_0__pseudo_1__pseudo_1 },
	-1,
	0,
	NULL
};

static const MR_VA_PseudoTypeInfo_Struct5 mercury_data___vpti_pred_5__plain_builtin__type_ctor_info_string_0__plain_analysis__type_ctor_info_func_id_0__pseudo_1__plain_io__type_ctor_info_state_0__plain_io__type_ctor_info_state_0 = {
	&mercury_data_builtin__type_ctor_info_pred_0,
	5,
{	(MR_PseudoTypeInfo) &mercury_data_builtin__type_ctor_info_string_0,
	(MR_PseudoTypeInfo) &mercury_data_analysis__type_ctor_info_func_id_0,
	(MR_PseudoTypeInfo) 1,
	(MR_PseudoTypeInfo) &mercury_data_io__type_ctor_info_state_0,
	(MR_PseudoTypeInfo) &mercury_data_io__type_ctor_info_state_0
}};

const MR_TypeCtorInfo_Struct mercury_data_analysis__file__type_ctor_info_write_entry_1 = {
	1,
	13,
	-1,
	MR_TYPECTOR_REP_EQUIV,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___analysis__file__write_entry_1_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___analysis__file__write_entry_1_0)),
	"analysis.file",
	"write_entry",
	{ 0 },
	{ (void *)&mercury_data___vpti_pred_5__plain_builtin__type_ctor_info_string_0__plain_analysis__type_ctor_info_func_id_0__pseudo_1__plain_io__type_ctor_info_state_0__plain_io__type_ctor_info_state_0 },
	-1,
	0,
	NULL
};

const MR_BaseTypeclassInfo mercury_data_base_typeclass_info_analysis__to_term__arity1__analysis__file__dummy_answer__arity0__[] = {
	(MR_Code *) 0,
	(MR_Code *) 0,
	(MR_Code *) 0,
	(MR_Code *) 1,
	(MR_Code *) 2,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(fn__analysis__file__ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__to_term_1_1_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(analysis__file__ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__from_term_2_2_0))
};

const MR_BaseTypeclassInfo mercury_data_base_typeclass_info_analysis__partial_order__arity2__analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0__[] = {
	(MR_Code *) 0,
	(MR_Code *) 0,
	(MR_Code *) 0,
	(MR_Code *) 2,
	(MR_Code *) 2,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(analysis__file__ClassMethod_for_analysis__partial_order____analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0______analysis__more_precise_than_3_3_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(analysis__file__ClassMethod_for_analysis__partial_order____analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0______analysis__equivalent_3_3_0))
};

const MR_BaseTypeclassInfo mercury_data_base_typeclass_info_analysis__answer_pattern__arity2__analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0__[] = {
	(MR_Code *) 0,
	(MR_Code *) 0,
	(MR_Code *) 2,
	(MR_Code *) 2,
	(MR_Code *) 0,
	
};

const MR_BaseTypeclassInfo mercury_data_base_typeclass_info_analysis__analysis__arity3__analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0__[] = {
	(MR_Code *) 0,
	(MR_Code *) 0,
	(MR_Code *) 2,
	(MR_Code *) 3,
	(MR_Code *) 6,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_name_2_2_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_version_number_2_2_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__preferred_fixpoint_type_2_2_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__bottom_2_2_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__top_2_2_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__get_func_info_6_6_0))
};


static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_analysis_file_4_6_0_1 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"lambda_analysis_file_m_904",
7,
0
},
"analysis.file",
"analysis.file.m",
902,
"d1;c8;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_analysis_file_3_5_0_1 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"write_analysis_file_4",
6,
0
},
"analysis.file",
"analysis.file.m",
894,
"d1;c6;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__empty_request_file_5_0_1 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"lambda_analysis_file_m_913",
3,
0
},
"analysis.file",
"analysis.file.m",
913,
"d1;c9;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_module_imdg_6_0_1 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"write_imdg_arc",
6,
0
},
"analysis.file",
"analysis.file.m",
793,
"d1;c10;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_module_imdg_6_0_2 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"lambda_analysis_file_m_547",
5,
0
},
"analysis.file",
"analysis.file.m",
547,
"d1;c11;d2;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_module_imdg_6_0_1 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"parse_imdg_arc",
4,
0
},
"analysis.file",
"analysis.file.m",
459,
"d1;c9;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_module_analysis_requests_6_0_5 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"write_request_entry",
6,
0
},
"analysis.file",
"analysis.file.m",
757,
"d1;c14;d1;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_module_analysis_requests_6_0_4 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"write_request_entry",
6,
0
},
"analysis.file",
"analysis.file.m",
739,
"d1;c13;d1;c7;t;c2;d1;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_module_analysis_requests_6_0_3 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"write_request_entry",
6,
0
},
"analysis.file",
"analysis.file.m",
757,
"d1;c14;d1;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_module_analysis_requests_6_0_2 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"write_request_entry",
6,
0
},
"analysis.file",
"analysis.file.m",
757,
"d1;c14;d1;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_module_analysis_requests_6_0_1 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"lambda_analysis_file_m_716",
3,
0
},
"analysis.file",
"analysis.file.m",
716,
"d1;c10;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_module_analysis_requests_6_0_2 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"lambda_analysis_file_m_547",
5,
0
},
"analysis.file",
"analysis.file.m",
547,
"d1;c11;d2;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_module_analysis_requests_6_0_1 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"parse_request_entry",
4,
0
},
"analysis.file",
"analysis.file.m",
408,
"d1;c9;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_analysis_file_6_0_3 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"lambda_analysis_file_m_575",
6,
0
},
"analysis.file",
"analysis.file.m",
575,
"d1;c8;d1;c5;q;c1;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_analysis_file_6_0_2 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"lambda_analysis_file_m_567",
3,
0
},
"analysis.file",
"analysis.file.m",
567,
"d1;c8;d1;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_analysis_file_6_0_1 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"lambda_analysis_file_m_592",
3,
0
},
"analysis.file",
"analysis.file.m",
592,
"d1;c8;d2;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_module_analysis_results_6_0_3 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"dir_sep",
1,
0
},
"analysis.file",
"analysis.file.m",
936,
"d1;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_module_analysis_results_6_0_2 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"write_result_entry",
5,
0
},
"analysis.file",
"analysis.file.m",
670,
"d1;c12;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_module_analysis_results_6_0_1 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"lambda_analysis_file_m_664",
3,
0
},
"analysis.file",
"analysis.file.m",
664,
"d1;c7;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_analysis_file_10_0_1 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"write_analysis_file_3",
5,
0
},
"analysis.file",
"analysis.file.m",
888,
"d1;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_analysis_file_5_0_1 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"write_analysis_file_3",
5,
0
},
"analysis.file",
"analysis.file.m",
888,
"d1;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_analysis_file_2_4_0_1 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"write_analysis_file_3",
5,
0
},
"analysis.file",
"analysis.file.m",
888,
"d1;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_module_analysis_results_6_0_1 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"dir_sep",
1,
0
},
"analysis.file",
"analysis.file.m",
936,
"d1;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__analysis__file__init_analysis_unpicklers_1_0_1 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"unpickle_analysis_result",
7,
0
},
"analysis.file",
"analysis.file.m",
1003,
"d1;c3;q;c8;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__write_analysis_cache_file_4_0_1 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"pickle_analysis_result",
4,
0
},
"analysis.file",
"analysis.file.m",
981,
"d1;c2;q;c8;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_module_analysis_results_2_5_0_4 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"lambda_analysis_file_m_336",
5,
0
},
"analysis.file",
"analysis.file.m",
336,
"d1;c8;d1;c6;q;c1;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_module_analysis_results_2_5_0_3 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"parse_result_entry",
4,
0
},
"analysis.file",
"analysis.file.m",
336,
"d1;c8;d1;c6;q;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_module_analysis_results_2_5_0_2 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"lambda_analysis_file_m_327",
3,
0
},
"analysis.file",
"analysis.file.m",
327,
"d1;c8;d1;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__analysis__file__read_module_analysis_results_2_5_0_1 = {
{
MR_PREDICATE,
"analysis.file",
"analysis.file",
"lambda_analysis_file_m_349",
3,
0
},
"analysis.file",
"analysis.file.m",
349,
"d1;c8;d2;c2;"
};


MR_declare_entry(mercury__do_call_class_method_5);
MR_decl_entry(io__open_input_4_0);
MR_decl_entry(io__read_line_as_string_4_0);
MR_decl_entry(io__close_input_3_0);
MR_decl_entry(string__prefix_2_0);
MR_decl_entry(fn__analysis__this_file_0_0);
MR_decl_entry(libs__compiler_util__unexpected_2_0);
MR_decl_entry(fn__io__error_message_1_0);
MR_decl_entry(fn__f_115_116_114_105_110_103_95_95_43_43_2_0);

MR_BEGIN_MODULE(analysis__file_module0)
	MR_init_entry1(analysis__file__read_module_overall_status_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__read_module_overall_status_6_0);
	MR_init_label10(analysis__file__read_module_overall_status_6_0,2,4,5,8,9,13,12,16,15,19)
	MR_init_label10(analysis__file__read_module_overall_status_6_0,18,21,11,27,26,29,30,31,7,33)
	MR_init_label6(analysis__file__read_module_overall_status_6_0,34,35,3,39,41,37)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'read_module_overall_status'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__analysis__file__read_module_overall_status_6_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_r4;
	MR_sv(4) = MR_r1;
	MR_r3 = MR_r2;
	MR_r4 = MR_sv(2);
	MR_r5 = MR_sv(3);
	MR_r6 = (MR_Word) MR_string_const(".analysis_status", 16);
	MR_r2 = (MR_Integer) 3;
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__read_module_overall_status_6_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_5),
		mercury__analysis__file__read_module_overall_status_6_0_i2);
MR_def_label(analysis__file__read_module_overall_status_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(analysis__file__read_module_overall_status_6_0_i4);
	}
	MR_r1 = (MR_Integer) 2;
	MR_GOTO_LAB(analysis__file__read_module_overall_status_6_0_i3);
MR_def_label(analysis__file__read_module_overall_status_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_r1, 0);
	MR_np_call_localret_ent(io__open_input_4_0,
		analysis__file__read_module_overall_status_6_0_i5);
MR_def_label(analysis__file__read_module_overall_status_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(analysis__file__read_module_overall_status_6_0_i7);
	}
	MR_sv(5) = MR_tfield(0, MR_r1, 0);
	MR_r1 = MR_sv(5);
	MR_np_call_localret_ent(io__read_line_as_string_4_0,
		analysis__file__read_module_overall_status_6_0_i8);
MR_def_label(analysis__file__read_module_overall_status_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(5);
	MR_sv(5) = MR_r1;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(io__close_input_3_0,
		analysis__file__read_module_overall_status_6_0_i9);
MR_def_label(analysis__file__read_module_overall_status_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(5),1)) {
		MR_GOTO_LAB(analysis__file__read_module_overall_status_6_0_i11);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_sv(5), 0);
	MR_sv(5) = MR_tempr1;
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Word) MR_string_const("optimal.", 8);
	}
	MR_np_call_localret_ent(string__prefix_2_0,
		analysis__file__read_module_overall_status_6_0_i13);
MR_def_label(analysis__file__read_module_overall_status_6_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__read_module_overall_status_6_0_i12);
	}
	MR_r1 = (MR_Integer) 2;
	MR_GOTO_LAB(analysis__file__read_module_overall_status_6_0_i3);
MR_def_label(analysis__file__read_module_overall_status_6_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(5);
	MR_r2 = (MR_Word) MR_string_const("suboptimal.", 11);
	MR_np_call_localret_ent(string__prefix_2_0,
		analysis__file__read_module_overall_status_6_0_i16);
MR_def_label(analysis__file__read_module_overall_status_6_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__read_module_overall_status_6_0_i15);
	}
	MR_r1 = (MR_Integer) 1;
	MR_GOTO_LAB(analysis__file__read_module_overall_status_6_0_i3);
MR_def_label(analysis__file__read_module_overall_status_6_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(5);
	MR_r2 = (MR_Word) MR_string_const("invalid.", 8);
	MR_np_call_localret_ent(string__prefix_2_0,
		analysis__file__read_module_overall_status_6_0_i19);
MR_def_label(analysis__file__read_module_overall_status_6_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__read_module_overall_status_6_0_i18);
	}
	MR_r1 = (MR_Integer) 0;
	MR_GOTO_LAB(analysis__file__read_module_overall_status_6_0_i3);
MR_def_label(analysis__file__read_module_overall_status_6_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__analysis__this_file_0_0,
		analysis__file__read_module_overall_status_6_0_i21);
MR_def_label(analysis__file__read_module_overall_status_6_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_string_const("read_module_overall_status_2: unexpected line", 45);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		analysis__file__read_module_overall_status_6_0_i3);
MR_def_label(analysis__file__read_module_overall_status_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(5),0,0)) {
		MR_GOTO_LAB(analysis__file__read_module_overall_status_6_0_i26);
	}
	MR_np_call_localret_ent(fn__analysis__this_file_0_0,
		analysis__file__read_module_overall_status_6_0_i27);
MR_def_label(analysis__file__read_module_overall_status_6_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_string_const("read_module_overall_status_2: unexpected eof", 44);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		analysis__file__read_module_overall_status_6_0_i3);
MR_def_label(analysis__file__read_module_overall_status_6_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(5) = MR_tfield(2, MR_sv(5), 0);
	MR_np_call_localret_ent(fn__analysis__this_file_0_0,
		analysis__file__read_module_overall_status_6_0_i29);
MR_def_label(analysis__file__read_module_overall_status_6_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(5);
	MR_sv(5) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__io__error_message_1_0,
		analysis__file__read_module_overall_status_6_0_i30);
MR_def_label(analysis__file__read_module_overall_status_6_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("read_module_overall_status_2: ", 30);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		analysis__file__read_module_overall_status_6_0_i31);
MR_def_label(analysis__file__read_module_overall_status_6_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		analysis__file__read_module_overall_status_6_0_i3);
MR_def_label(analysis__file__read_module_overall_status_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(5) = MR_tfield(1, MR_r1, 0);
	MR_np_call_localret_ent(fn__analysis__this_file_0_0,
		analysis__file__read_module_overall_status_6_0_i33);
MR_def_label(analysis__file__read_module_overall_status_6_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(5);
	MR_sv(5) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__io__error_message_1_0,
		analysis__file__read_module_overall_status_6_0_i34);
MR_def_label(analysis__file__read_module_overall_status_6_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("read_module_overall_status_2: ", 30);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		analysis__file__read_module_overall_status_6_0_i35);
MR_def_label(analysis__file__read_module_overall_status_6_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		analysis__file__read_module_overall_status_6_0_i3);
MR_def_label(analysis__file__read_module_overall_status_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,2)) {
		MR_GOTO_LAB(analysis__file__read_module_overall_status_6_0_i37);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(2);
	MR_r5 = MR_sv(3);
	MR_r6 = (MR_Word) MR_string_const(".request", 8);
	MR_r2 = (MR_Integer) 3;
	}
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__read_module_overall_status_6_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_5),
		mercury__analysis__file__read_module_overall_status_6_0_i39);
MR_def_label(analysis__file__read_module_overall_status_6_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(analysis__file__read_module_overall_status_6_0_i41);
	}
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(6);
MR_def_label(analysis__file__read_module_overall_status_6_0,41)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 1;
MR_def_label(analysis__file__read_module_overall_status_6_0,37)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(6);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(io__open_output_4_0);
MR_decl_entry(io__write_string_4_0);
MR_decl_entry(io__close_output_3_0);

MR_BEGIN_MODULE(analysis__file_module1)
	MR_init_entry1(analysis__file__write_module_overall_status_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__write_module_overall_status_6_0);
	MR_init_label9(analysis__file__write_module_overall_status_6_0,2,3,7,9,11,5,13,14,15)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'write_module_overall_status'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__analysis__file__write_module_overall_status_6_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r4;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_tfield(0, MR_r1, 0);
	MR_tempr2 = MR_r3;
	MR_r3 = MR_tfield(0, MR_tempr1, 1);
	MR_r4 = MR_r2;
	MR_r5 = MR_tempr2;
	MR_r6 = (MR_Word) MR_string_const(".analysis_status", 16);
	MR_r2 = (MR_Integer) 4;
	}
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__write_module_overall_status_6_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_5),
		mercury__analysis__file__write_module_overall_status_6_0_i2);
MR_def_label(analysis__file__write_module_overall_status_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__open_output_4_0,
		analysis__file__write_module_overall_status_6_0_i3);
MR_def_label(analysis__file__write_module_overall_status_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(analysis__file__write_module_overall_status_6_0_i5);
	}
	if (MR_INT_NE(MR_sv(1),0)) {
		MR_GOTO_LAB(analysis__file__write_module_overall_status_6_0_i7);
	}
	MR_sv(1) = MR_tfield(0, MR_r1, 0);
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Word) MR_string_const("invalid.\n", 9);
	MR_np_call_localret_ent(io__write_string_4_0,
		analysis__file__write_module_overall_status_6_0_i11);
MR_def_label(analysis__file__write_module_overall_status_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(1),2)) {
		MR_GOTO_LAB(analysis__file__write_module_overall_status_6_0_i9);
	}
	MR_sv(1) = MR_tfield(0, MR_r1, 0);
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Word) MR_string_const("optimal.\n", 9);
	MR_np_call_localret_ent(io__write_string_4_0,
		analysis__file__write_module_overall_status_6_0_i11);
MR_def_label(analysis__file__write_module_overall_status_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_tfield(0, MR_r1, 0);
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Word) MR_string_const("suboptimal.\n", 12);
	MR_np_call_localret_ent(io__write_string_4_0,
		analysis__file__write_module_overall_status_6_0_i11);
MR_def_label(analysis__file__write_module_overall_status_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__close_output_3_0);
MR_def_label(analysis__file__write_module_overall_status_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_tfield(1, MR_r1, 0);
	MR_np_call_localret_ent(fn__analysis__this_file_0_0,
		analysis__file__write_module_overall_status_6_0_i13);
MR_def_label(analysis__file__write_module_overall_status_6_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__io__error_message_1_0,
		analysis__file__write_module_overall_status_6_0_i14);
MR_def_label(analysis__file__write_module_overall_status_6_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("write_module_overall_status: ", 29);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		analysis__file__write_module_overall_status_6_0_i15);
MR_def_label(analysis__file__write_module_overall_status_6_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(libs__compiler_util__unexpected_2_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(parser__read_term_3_0);
extern const MR_TypeCtorInfo_Struct mercury_data_term_io__type_ctor_info_read_term_1;
MR_decl_entry(fn__string__string_1_0);
MR_decl_entry(exception__throw_1_0);

MR_BEGIN_MODULE(analysis__file_module2)
	MR_init_entry1(analysis__file__check_analysis_file_version_number_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__check_analysis_file_version_number_2_0);
	MR_init_label5(analysis__file__check_analysis_file_version_number_2_0,2,3,9,10,12)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'check_analysis_file_version_number'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__check_analysis_file_version_number_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(parser__read_term_3_0,
		analysis__file__check_analysis_file_version_number_2_0_i2);
MR_def_label(analysis__file__check_analysis_file_version_number_2_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(analysis__file__check_analysis_file_version_number_2_0_i3);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_tfield(2, MR_r1, 1);
	if (MR_PTAG_TESTR(MR_tempr1,0)) {
		MR_GOTO_LAB(analysis__file__check_analysis_file_version_number_2_0_i3);
	}
	MR_tempr2 = MR_tfield(0, MR_tempr1, 1);
	if (MR_LTAGS_TESTR(MR_tempr2,0,0)) {
		MR_GOTO_LAB(analysis__file__check_analysis_file_version_number_2_0_i3);
	}
	MR_tempr2 = MR_tfield(0, MR_tempr1, 0);
	if (MR_PTAG_TESTR(MR_tempr2,1)) {
		MR_GOTO_LAB(analysis__file__check_analysis_file_version_number_2_0_i3);
	}
	MR_tempr1 = MR_tfield(1, MR_tempr2, 0);
	if (MR_INT_EQ(MR_tempr1,6)) {
		MR_GOTO_LAB(analysis__file__check_analysis_file_version_number_2_0_i12);
	}
	}
MR_def_label(analysis__file__check_analysis_file_version_number_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_CTOR1_ADDR(term_io, read_term);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(1);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(fn__string__string_1_0,
		analysis__file__check_analysis_file_version_number_2_0_i9);
MR_def_label(analysis__file__check_analysis_file_version_number_2_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("bad analysis file version: ", 27);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		analysis__file__check_analysis_file_version_number_2_0_i10);
MR_def_label(analysis__file__check_analysis_file_version_number_2_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis__file, invalid_analysis_file);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(exception__throw_1_0);
	}
MR_def_label(analysis__file__check_analysis_file_version_number_2_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(2);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__map__init_0_0);
MR_decl_entry(analysis__debug_msg_3_0);
MR_decl_entry(io__set_input_stream_4_0);
MR_decl_entry(exception__try_io_4_0);
MR_decl_entry(exception__rethrow_1_0);

MR_BEGIN_MODULE(analysis__file_module3)
	MR_init_entry1(analysis__file__read_module_analysis_results_2_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__read_module_analysis_results_2_5_0);
	MR_init_label10(analysis__file__read_module_analysis_results_2_5_0,4,5,9,7,11,12,13,17,18,19)
	MR_init_label1(analysis__file__read_module_analysis_results_2_5_0,21)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'read_module_analysis_results_2'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__read_module_analysis_results_2_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r3;
	MR_sv(5) = MR_r1;
	MR_sv(6) = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r2 = MR_sv(6);
	MR_np_call_localret_ent(fn__map__init_0_0,
		analysis__file__read_module_analysis_results_2_5_0_i4);
MR_def_label(analysis__file__read_module_analysis_results_2_5_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(io__open_input_4_0,
		analysis__file__read_module_analysis_results_2_5_0_i5);
MR_def_label(analysis__file__read_module_analysis_results_2_5_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(analysis__file__read_module_analysis_results_2_5_0_i7);
	}
	MR_tag_alloc_heap(MR_r1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_r1, 0) = (MR_Word) MR_COMMON(2,0);
	MR_tfield(0, MR_r1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__349__1_3_0);
	MR_tfield(0, MR_r1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_r1, 3) = MR_sv(2);
	MR_np_call_localret_ent(analysis__debug_msg_3_0,
		analysis__file__read_module_analysis_results_2_5_0_i9);
MR_def_label(analysis__file__read_module_analysis_results_2_5_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(7);
MR_def_label(analysis__file__read_module_analysis_results_2_5_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,1);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__327__1_3_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(2);
	MR_sv(2) = MR_tfield(0, MR_r1, 0);
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(analysis__debug_msg_3_0,
		analysis__file__read_module_analysis_results_2_5_0_i11);
MR_def_label(analysis__file__read_module_analysis_results_2_5_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(io__set_input_stream_4_0,
		analysis__file__read_module_analysis_results_2_5_0_i12);
MR_def_label(analysis__file__read_module_analysis_results_2_5_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_np_call_localret_ent(analysis__file__check_analysis_file_version_number_2_0,
		analysis__file__read_module_analysis_results_2_5_0_i13);
MR_def_label(analysis__file__read_module_analysis_results_2_5_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(4,0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__parse_result_entry_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(5);
	MR_tfield(0, MR_tempr1, 4) = MR_sv(1);
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 5);
	MR_tfield(0, MR_r2, 0) = (MR_Word) MR_COMMON(6,0);
	MR_tfield(0, MR_r2, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__336__1_5_0);
	MR_tfield(0, MR_r2, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_r2, 3) = MR_sv(3);
	MR_tfield(0, MR_r2, 4) = MR_tempr1;
	MR_sv(3) = (MR_Word) MR_TAG_COMMON(0,1,4);
	MR_r1 = MR_sv(3);
	}
	MR_np_call_localret_ent(exception__try_io_4_0,
		analysis__file__read_module_analysis_results_2_5_0_i17);
MR_def_label(analysis__file__read_module_analysis_results_2_5_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(io__set_input_stream_4_0,
		analysis__file__read_module_analysis_results_2_5_0_i18);
MR_def_label(analysis__file__read_module_analysis_results_2_5_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(io__close_input_3_0,
		analysis__file__read_module_analysis_results_2_5_0_i19);
MR_def_label(analysis__file__read_module_analysis_results_2_5_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(1),1)) {
		MR_GOTO_LAB(analysis__file__read_module_analysis_results_2_5_0_i21);
	}
	MR_r1 = MR_tfield(1, MR_sv(1), 0);
	MR_decr_sp_and_return(7);
MR_def_label(analysis__file__read_module_analysis_results_2_5_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(1);
	MR_succip_word = MR_sv(7);
	MR_decr_sp(7);
	MR_np_tailcall_ent(exception__rethrow_1_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(io__tell_binary_4_0);
MR_decl_entry(fn__libs__pickle__init_picklers_0_0);
MR_decl_entry(fn__type_desc__type_of_1_0);
MR_decl_entry(fn__type_desc__type_ctor_1_0);
MR_decl_entry(libs__pickle__register_pickler_4_0);
MR_decl_entry(libs__pickle__pickle_4_0);
MR_decl_entry(io__told_binary_2_0);
MR_decl_entry(io__rename_file_5_0);
MR_decl_entry(io__write_string_3_0);
MR_decl_entry(io__nl_2_0);
MR_decl_entry(io__remove_file_4_0);

MR_BEGIN_MODULE(analysis__file_module4)
	MR_init_entry1(analysis__file__write_analysis_cache_file_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__write_analysis_cache_file_4_0);
	MR_init_label10(analysis__file__write_analysis_cache_file_4_0,2,3,6,7,8,10,14,15,16,19)
	MR_init_label10(analysis__file__write_analysis_cache_file_4_0,20,21,22,23,24,5,26,27,28,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'write_analysis_cache_file'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__write_analysis_cache_file_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r2 = (MR_Word) MR_string_const(".tmp", 4);
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		analysis__file__write_analysis_cache_file_4_0_i2);
MR_def_label(analysis__file__write_analysis_cache_file_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_np_call_localret_ent(io__tell_binary_4_0,
		analysis__file__write_analysis_cache_file_4_0_i3);
MR_def_label(analysis__file__write_analysis_cache_file_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(analysis__file__write_analysis_cache_file_4_0_i5);
	}
	MR_np_call_localret_ent(fn__libs__pickle__init_picklers_0_0,
		analysis__file__write_analysis_cache_file_4_0_i6);
MR_def_label(analysis__file__write_analysis_cache_file_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, some_analysis_result);
	MR_np_call_localret_ent(fn__type_desc__type_of_1_0,
		analysis__file__write_analysis_cache_file_4_0_i7);
MR_def_label(analysis__file__write_analysis_cache_file_4_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__type_desc__type_ctor_1_0,
		analysis__file__write_analysis_cache_file_4_0_i8);
MR_def_label(analysis__file__write_analysis_cache_file_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,8,0);
	MR_r3 = MR_sv(4);
	MR_np_call_localret_ent(libs__pickle__register_pickler_4_0,
		analysis__file__write_analysis_cache_file_4_0_i10);
MR_def_label(analysis__file__write_analysis_cache_file_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,4);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(2);
	}
	MR_np_call_localret_ent(libs__pickle__pickle_4_0,
		analysis__file__write_analysis_cache_file_4_0_i14);
MR_def_label(analysis__file__write_analysis_cache_file_4_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__told_binary_2_0,
		analysis__file__write_analysis_cache_file_4_0_i15);
MR_def_label(analysis__file__write_analysis_cache_file_4_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(io__rename_file_5_0,
		analysis__file__write_analysis_cache_file_4_0_i16);
MR_def_label(analysis__file__write_analysis_cache_file_4_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_r1,0,0)) {
		MR_GOTO_LAB(analysis__file__write_analysis_cache_file_4_0_i4);
	}
	MR_sv(2) = MR_tfield(1, MR_r1, 0);
	MR_r1 = (MR_Word) MR_string_const("Error renaming ", 15);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_analysis_cache_file_4_0_i19);
MR_def_label(analysis__file__write_analysis_cache_file_4_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_analysis_cache_file_4_0_i20);
MR_def_label(analysis__file__write_analysis_cache_file_4_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(": ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_analysis_cache_file_4_0_i21);
MR_def_label(analysis__file__write_analysis_cache_file_4_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(fn__io__error_message_1_0,
		analysis__file__write_analysis_cache_file_4_0_i22);
MR_def_label(analysis__file__write_analysis_cache_file_4_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_analysis_cache_file_4_0_i23);
MR_def_label(analysis__file__write_analysis_cache_file_4_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__nl_2_0,
		analysis__file__write_analysis_cache_file_4_0_i24);
MR_def_label(analysis__file__write_analysis_cache_file_4_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(io__remove_file_4_0);
MR_def_label(analysis__file__write_analysis_cache_file_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_tfield(1, MR_r1, 0);
	MR_np_call_localret_ent(fn__analysis__this_file_0_0,
		analysis__file__write_analysis_cache_file_4_0_i26);
MR_def_label(analysis__file__write_analysis_cache_file_4_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__io__error_message_1_0,
		analysis__file__write_analysis_cache_file_4_0_i27);
MR_def_label(analysis__file__write_analysis_cache_file_4_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("pickle_to_file: ", 16);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		analysis__file__write_analysis_cache_file_4_0_i28);
MR_def_label(analysis__file__write_analysis_cache_file_4_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(libs__compiler_util__unexpected_2_0);
	}
MR_def_label(analysis__file__write_analysis_cache_file_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(5);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__libs__pickle__init_unpicklers_0_0);
MR_decl_entry(libs__pickle__register_unpickler_4_0);

MR_BEGIN_MODULE(analysis__file_module5)
	MR_init_entry1(fn__analysis__file__init_analysis_unpicklers_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__analysis__file__init_analysis_unpicklers_1_0);
	MR_init_label3(fn__analysis__file__init_analysis_unpicklers_1_0,2,3,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'init_analysis_unpicklers'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__analysis__file__init_analysis_unpicklers_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_sv(3) = MR_r1;
	MR_np_call_localret_ent(fn__libs__pickle__init_unpicklers_0_0,
		fn__analysis__file__init_analysis_unpicklers_1_0_i2);
MR_def_label(fn__analysis__file__init_analysis_unpicklers_1_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, some_analysis_result);
	MR_np_call_localret_ent(fn__type_desc__type_of_1_0,
		fn__analysis__file__init_analysis_unpicklers_1_0_i3);
MR_def_label(fn__analysis__file__init_analysis_unpicklers_1_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__type_desc__type_ctor_1_0,
		fn__analysis__file__init_analysis_unpicklers_1_0_i4);
MR_def_label(fn__analysis__file__init_analysis_unpicklers_1_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 5);
	MR_tfield(0, MR_r2, 0) = (MR_Word) MR_COMMON(9,0);
	MR_tfield(0, MR_r2, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__unpickle_analysis_result_7_0);
	MR_tfield(0, MR_r2, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_r2, 3) = MR_sv(3);
	MR_tfield(0, MR_r2, 4) = MR_sv(1);
	MR_r3 = MR_sv(2);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(libs__pickle__register_unpickler_4_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(libs__globals__lookup_string_option_3_0);
MR_decl_entry(fn__string__split_at_separator_2_0);
MR_decl_entry(fn__string__join_list_2_0);
MR_decl_entry(fn__f_100_105_114_95_95_47_2_0);
MR_decl_entry(io__file_modification_time_4_0);
MR_decl_entry(__Compare___time__time_t_0_0);
MR_decl_entry(libs__pickle__unpickle_from_file_5_0);

MR_BEGIN_MODULE(analysis__file_module6)
	MR_init_entry1(analysis__file__read_module_analysis_results_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__read_module_analysis_results_6_0);
	MR_init_label10(analysis__file__read_module_analysis_results_6_0,2,4,8,9,13,14,15,16,17,22)
	MR_init_label10(analysis__file__read_module_analysis_results_6_0,25,29,32,33,34,35,36,37,38,31)
	MR_init_label3(analysis__file__read_module_analysis_results_6_0,19,40,41)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'read_module_analysis_results'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__analysis__file__read_module_analysis_results_6_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_tfield(0, MR_r1, 1);
	MR_sv(5) = MR_tfield(0, MR_r1, 0);
	MR_r1 = MR_sv(5);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_r3 = MR_sv(2);
	MR_r4 = MR_r2;
	MR_r5 = MR_tempr1;
	MR_r6 = (MR_Word) MR_string_const(".analysis", 9);
	MR_r2 = (MR_Integer) 3;
	}
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__read_module_analysis_results_6_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_5),
		mercury__analysis__file__read_module_analysis_results_6_0_i2);
MR_def_label(analysis__file__read_module_analysis_results_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(analysis__file__read_module_analysis_results_6_0_i4);
	}
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_succip_word = MR_sv(6);
	MR_decr_sp(6);
	MR_np_tailcall_ent(fn__map__init_0_0);
MR_def_label(analysis__file__read_module_analysis_results_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_tfield(0, MR_r1, 0);
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Integer) 616;
	}
	MR_np_call_localret_ent(libs__globals__lookup_string_option_3_0,
		analysis__file__read_module_analysis_results_6_0_i8);
MR_def_label(analysis__file__read_module_analysis_results_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("", 0)) != 0)) {
		MR_GOTO_LAB(analysis__file__read_module_analysis_results_6_0_i9);
	}
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(1);
	MR_succip_word = MR_sv(6);
	MR_decr_sp(6);
	MR_np_tailcall_ent(analysis__file__read_module_analysis_results_2_5_0);
MR_def_label(analysis__file__read_module_analysis_results_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,8,1);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(fn__string__split_at_separator_2_0,
		analysis__file__read_module_analysis_results_6_0_i13);
MR_def_label(analysis__file__read_module_analysis_results_6_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(":", 1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__string__join_list_2_0,
		analysis__file__read_module_analysis_results_6_0_i14);
MR_def_label(analysis__file__read_module_analysis_results_6_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_100_105_114_95_95_47_2_0,
		analysis__file__read_module_analysis_results_6_0_i15);
MR_def_label(analysis__file__read_module_analysis_results_6_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(io__file_modification_time_4_0,
		analysis__file__read_module_analysis_results_6_0_i16);
MR_def_label(analysis__file__read_module_analysis_results_6_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(io__file_modification_time_4_0,
		analysis__file__read_module_analysis_results_6_0_i17);
MR_def_label(analysis__file__read_module_analysis_results_6_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(4),0)) {
		MR_GOTO_LAB(analysis__file__read_module_analysis_results_6_0_i19);
	}
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(analysis__file__read_module_analysis_results_6_0_i19);
	}
	MR_r1 = MR_tfield(0, MR_r1, 0);
	MR_r2 = MR_tfield(0, MR_sv(4), 0);
	MR_np_call_localret_ent(__Compare___time__time_t_0_0,
		analysis__file__read_module_analysis_results_6_0_i22);
MR_def_label(analysis__file__read_module_analysis_results_6_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_EQ(MR_r1,1)) {
		MR_GOTO_LAB(analysis__file__read_module_analysis_results_6_0_i19);
	}
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(2);
	MR_np_call_localret_ent(fn__analysis__file__init_analysis_unpicklers_1_0,
		analysis__file__read_module_analysis_results_6_0_i25);
MR_def_label(analysis__file__read_module_analysis_results_6_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,4);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(3);
	}
	MR_np_call_localret_ent(libs__pickle__unpickle_from_file_5_0,
		analysis__file__read_module_analysis_results_6_0_i29);
MR_def_label(analysis__file__read_module_analysis_results_6_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(analysis__file__read_module_analysis_results_6_0_i31);
	}
	MR_sv(4) = MR_tfield(1, MR_r1, 0);
	MR_r1 = (MR_Word) MR_string_const("Error reading ", 14);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__read_module_analysis_results_6_0_i32);
MR_def_label(analysis__file__read_module_analysis_results_6_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__read_module_analysis_results_6_0_i33);
MR_def_label(analysis__file__read_module_analysis_results_6_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(": ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__read_module_analysis_results_6_0_i34);
MR_def_label(analysis__file__read_module_analysis_results_6_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(fn__io__error_message_1_0,
		analysis__file__read_module_analysis_results_6_0_i35);
MR_def_label(analysis__file__read_module_analysis_results_6_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__read_module_analysis_results_6_0_i36);
MR_def_label(analysis__file__read_module_analysis_results_6_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__nl_2_0,
		analysis__file__read_module_analysis_results_6_0_i37);
MR_def_label(analysis__file__read_module_analysis_results_6_0,37)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(1);
	MR_np_call_localret_ent(analysis__file__read_module_analysis_results_2_5_0,
		analysis__file__read_module_analysis_results_6_0_i38);
MR_def_label(analysis__file__read_module_analysis_results_6_0,38)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(analysis__file__write_analysis_cache_file_4_0,
		analysis__file__read_module_analysis_results_6_0_i41);
MR_def_label(analysis__file__read_module_analysis_results_6_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_r1, 0);
	MR_decr_sp_and_return(6);
MR_def_label(analysis__file__read_module_analysis_results_6_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(1);
	MR_np_call_localret_ent(analysis__file__read_module_analysis_results_2_5_0,
		analysis__file__read_module_analysis_results_6_0_i40);
MR_def_label(analysis__file__read_module_analysis_results_6_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(analysis__file__write_analysis_cache_file_4_0,
		analysis__file__read_module_analysis_results_6_0_i41);
MR_def_label(analysis__file__read_module_analysis_results_6_0,41)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(6);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_io__type_ctor_info_state_0;
MR_decl_entry(map__foldl_4_2);

MR_BEGIN_MODULE(analysis__file_module7)
	MR_init_entry1(analysis__file__write_analysis_file_2_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__write_analysis_file_2_4_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'write_analysis_file_2'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__write_analysis_file_2_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(13,0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__write_analysis_file_3_5_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_tfield(0, MR_tempr1, 4) = MR_r2;
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr2, 0) = (MR_Word) MR_LIST_CTOR_ADDR;
	MR_tfield(0, MR_tempr2, 1) = MR_r1;
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 3);
	MR_tfield(0, MR_r2, 0) = (MR_Word) MR_CTOR_ADDR(tree234, tree234, 2);
	MR_tfield(0, MR_r2, 1) = (MR_Word) MR_CTOR0_ADDR(analysis, func_id);
	MR_tfield(0, MR_r2, 2) = MR_tempr2;
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_tempr2 = MR_r3;
	MR_r3 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r4 = MR_tempr1;
	MR_r5 = MR_tempr2;
	MR_np_tailcall_ent(map__foldl_4_2);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(io__set_output_stream_4_0);
MR_decl_entry(io__write_int_3_0);

MR_BEGIN_MODULE(analysis__file_module8)
	MR_init_entry1(analysis__file__write_analysis_file_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__write_analysis_file_5_0);
	MR_init_label10(analysis__file__write_analysis_file_5_0,2,5,6,7,11,12,4,14,15,16)
	MR_init_label2(analysis__file__write_analysis_file_5_0,17,18)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'write_analysis_file'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__write_analysis_file_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_r4;
	MR_sv(5) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(io__open_output_4_0,
		analysis__file__write_analysis_file_5_0_i2);
MR_def_label(analysis__file__write_analysis_file_5_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(analysis__file__write_analysis_file_5_0_i4);
	}
	MR_sv(1) = MR_tfield(0, MR_r1, 0);
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(io__set_output_stream_4_0,
		analysis__file__write_analysis_file_5_0_i5);
MR_def_label(analysis__file__write_analysis_file_5_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_r1 = (MR_Integer) 6;
	MR_np_call_localret_ent(io__write_int_3_0,
		analysis__file__write_analysis_file_5_0_i6);
MR_def_label(analysis__file__write_analysis_file_5_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(".\n", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_analysis_file_5_0_i7);
MR_def_label(analysis__file__write_analysis_file_5_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(13,1);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__write_analysis_file_3_5_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tempr3 = MR_sv(5);
	MR_tfield(0, MR_tempr1, 3) = MR_tempr3;
	MR_tfield(0, MR_tempr1, 4) = MR_sv(2);
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr2, 0) = (MR_Word) MR_LIST_CTOR_ADDR;
	MR_tfield(0, MR_tempr2, 1) = MR_tempr3;
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 3);
	MR_tfield(0, MR_r2, 0) = (MR_Word) MR_CTOR_ADDR(tree234, tree234, 2);
	MR_tfield(0, MR_r2, 1) = (MR_Word) MR_CTOR0_ADDR(analysis, func_id);
	MR_tfield(0, MR_r2, 2) = MR_tempr2;
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r3 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r5 = MR_sv(3);
	}
	MR_np_call_localret_ent(map__foldl_4_2,
		analysis__file__write_analysis_file_5_0_i11);
MR_def_label(analysis__file__write_analysis_file_5_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(io__set_output_stream_4_0,
		analysis__file__write_analysis_file_5_0_i12);
MR_def_label(analysis__file__write_analysis_file_5_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_succip_word = MR_sv(6);
	MR_decr_sp(6);
	MR_np_tailcall_ent(io__close_output_3_0);
MR_def_label(analysis__file__write_analysis_file_5_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_tfield(1, MR_r1, 0);
	MR_np_call_localret_ent(fn__analysis__this_file_0_0,
		analysis__file__write_analysis_file_5_0_i14);
MR_def_label(analysis__file__write_analysis_file_5_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_sv(2) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__io__error_message_1_0,
		analysis__file__write_analysis_file_5_0_i15);
MR_def_label(analysis__file__write_analysis_file_5_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("\' for output: ", 14);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		analysis__file__write_analysis_file_5_0_i16);
MR_def_label(analysis__file__write_analysis_file_5_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		analysis__file__write_analysis_file_5_0_i17);
MR_def_label(analysis__file__write_analysis_file_5_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("write_analysis_file: error opening \140", 36);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		analysis__file__write_analysis_file_5_0_i18);
MR_def_label(analysis__file__write_analysis_file_5_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(6);
	MR_decr_sp(6);
	MR_np_tailcall_ent(libs__compiler_util__unexpected_2_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module9)
	MR_init_entry1(analysis__file__write_analysis_file_10_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__write_analysis_file_10_0);
	MR_init_label10(analysis__file__write_analysis_file_10_0,2,4,3,6,9,10,11,15,16,17)
	MR_init_label6(analysis__file__write_analysis_file_10_0,8,18,19,20,21,22)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'write_analysis_file'/10 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__write_analysis_file_10_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r7;
	MR_sv(2) = MR_r8;
	MR_sv(3) = MR_r9;
	MR_sv(5) = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = (MR_Integer) 4;
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__write_analysis_file_10_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_5),
		mercury__analysis__file__write_analysis_file_10_0_i2);
MR_def_label(analysis__file__write_analysis_file_10_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(1),0)) {
		MR_GOTO_LAB(analysis__file__write_analysis_file_10_0_i4);
	}
	MR_sv(1) = MR_r1;
	MR_GOTO_LAB(analysis__file__write_analysis_file_10_0_i3);
MR_def_label(analysis__file__write_analysis_file_10_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r2 = (MR_Word) MR_string_const(".tmp", 4);
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		analysis__file__write_analysis_file_10_0_i3);
MR_def_label(analysis__file__write_analysis_file_10_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_np_call_localret_ent(io__open_output_4_0,
		analysis__file__write_analysis_file_10_0_i6);
MR_def_label(analysis__file__write_analysis_file_10_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(analysis__file__write_analysis_file_10_0_i8);
	}
	MR_sv(4) = MR_tfield(0, MR_r1, 0);
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(io__set_output_stream_4_0,
		analysis__file__write_analysis_file_10_0_i9);
MR_def_label(analysis__file__write_analysis_file_10_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(6) = MR_r1;
	MR_r1 = (MR_Integer) 6;
	MR_np_call_localret_ent(io__write_int_3_0,
		analysis__file__write_analysis_file_10_0_i10);
MR_def_label(analysis__file__write_analysis_file_10_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(".\n", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_analysis_file_10_0_i11);
MR_def_label(analysis__file__write_analysis_file_10_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(13,2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__write_analysis_file_3_5_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tempr3 = MR_sv(5);
	MR_tfield(0, MR_tempr1, 3) = MR_tempr3;
	MR_tfield(0, MR_tempr1, 4) = MR_sv(2);
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr2, 0) = (MR_Word) MR_LIST_CTOR_ADDR;
	MR_tfield(0, MR_tempr2, 1) = MR_tempr3;
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 3);
	MR_tfield(0, MR_r2, 0) = (MR_Word) MR_CTOR_ADDR(tree234, tree234, 2);
	MR_tfield(0, MR_r2, 1) = (MR_Word) MR_CTOR0_ADDR(analysis, func_id);
	MR_tfield(0, MR_r2, 2) = MR_tempr2;
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r3 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r5 = MR_sv(3);
	}
	MR_np_call_localret_ent(map__foldl_4_2,
		analysis__file__write_analysis_file_10_0_i15);
MR_def_label(analysis__file__write_analysis_file_10_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(6);
	MR_np_call_localret_ent(io__set_output_stream_4_0,
		analysis__file__write_analysis_file_10_0_i16);
MR_def_label(analysis__file__write_analysis_file_10_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(io__close_output_3_0,
		analysis__file__write_analysis_file_10_0_i17);
MR_def_label(analysis__file__write_analysis_file_10_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(7);
MR_def_label(analysis__file__write_analysis_file_10_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_tfield(1, MR_r1, 0);
	MR_np_call_localret_ent(fn__analysis__this_file_0_0,
		analysis__file__write_analysis_file_10_0_i18);
MR_def_label(analysis__file__write_analysis_file_10_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_sv(2) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__io__error_message_1_0,
		analysis__file__write_analysis_file_10_0_i19);
MR_def_label(analysis__file__write_analysis_file_10_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("\' for output: ", 14);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		analysis__file__write_analysis_file_10_0_i20);
MR_def_label(analysis__file__write_analysis_file_10_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		analysis__file__write_analysis_file_10_0_i21);
MR_def_label(analysis__file__write_analysis_file_10_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("write_analysis_file: error opening \140", 36);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		analysis__file__write_analysis_file_10_0_i22);
MR_def_label(analysis__file__write_analysis_file_10_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(7);
	MR_decr_sp(7);
	MR_np_tailcall_ent(libs__compiler_util__unexpected_2_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(parse_tree__module_cmds__update_interface_return_changed_5_0);

MR_BEGIN_MODULE(analysis__file_module10)
	MR_init_entry1(analysis__file__write_module_analysis_results_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__write_module_analysis_results_6_0);
	MR_init_label8(analysis__file__write_module_analysis_results_6_0,3,5,6,7,13,14,15,17)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'write_module_analysis_results'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__analysis__file__write_module_analysis_results_6_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__IntroducedFrom__pred__write_module_analysis_results__664__1_3_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tempr2 = MR_r3;
	MR_tfield(0, MR_tempr1, 3) = MR_tempr2;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_tempr2;
	MR_sv(4) = MR_r4;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(analysis__debug_msg_3_0,
		analysis__file__write_module_analysis_results_6_0_i3);
MR_def_label(analysis__file__write_module_analysis_results_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, some_analysis_result);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_r2 = MR_tfield(0, MR_tempr1, 0);
	MR_r3 = MR_tfield(0, MR_tempr1, 1);
	MR_r4 = MR_sv(2);
	MR_r5 = MR_sv(3);
	MR_r6 = (MR_Word) MR_string_const(".analysis", 9);
	MR_r7 = (MR_Integer) 1;
	MR_r8 = (MR_Word) MR_TAG_COMMON(0,8,2);
	MR_r9 = MR_sv(4);
	}
	MR_np_call_localret_ent(analysis__file__write_analysis_file_10_0,
		analysis__file__write_module_analysis_results_6_0_i5);
MR_def_label(analysis__file__write_module_analysis_results_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(parse_tree__module_cmds__update_interface_return_changed_5_0,
		analysis__file__write_module_analysis_results_6_0_i6);
MR_def_label(analysis__file__write_module_analysis_results_6_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(2);
	MR_sv(2) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Integer) 616;
	}
	MR_np_call_localret_ent(libs__globals__lookup_string_option_3_0,
		analysis__file__write_module_analysis_results_6_0_i7);
MR_def_label(analysis__file__write_module_analysis_results_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("", 0)) == 0)) {
		MR_GOTO_LAB(analysis__file__write_module_analysis_results_6_0_i17);
	}
	if (MR_INT_NE(MR_sv(2),0)) {
		MR_GOTO_LAB(analysis__file__write_module_analysis_results_6_0_i17);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,8,3);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__string__split_at_separator_2_0,
		analysis__file__write_module_analysis_results_6_0_i13);
MR_def_label(analysis__file__write_module_analysis_results_6_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(":", 1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__string__join_list_2_0,
		analysis__file__write_module_analysis_results_6_0_i14);
MR_def_label(analysis__file__write_module_analysis_results_6_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_100_105_114_95_95_47_2_0,
		analysis__file__write_module_analysis_results_6_0_i15);
MR_def_label(analysis__file__write_module_analysis_results_6_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(4);
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(analysis__file__write_analysis_cache_file_4_0);
MR_def_label(analysis__file__write_module_analysis_results_6_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(5);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module11)
	MR_init_entry1(analysis__file__read_analysis_file_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__read_analysis_file_6_0);
	MR_init_label9(analysis__file__read_analysis_file_6_0,2,6,4,8,9,11,12,13,15)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'read_analysis_file'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__read_analysis_file_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_r4;
	MR_sv(4) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(io__open_input_4_0,
		analysis__file__read_analysis_file_6_0_i2);
MR_def_label(analysis__file__read_analysis_file_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(analysis__file__read_analysis_file_6_0_i4);
	}
	MR_tag_alloc_heap(MR_r1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_r1, 0) = (MR_Word) MR_COMMON(2,3);
	MR_tfield(0, MR_r1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__IntroducedFrom__pred__read_analysis_file__592__1_3_0);
	MR_tfield(0, MR_r1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_r1, 3) = MR_sv(1);
	MR_np_call_localret_ent(analysis__debug_msg_3_0,
		analysis__file__read_analysis_file_6_0_i6);
MR_def_label(analysis__file__read_analysis_file_6_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(5);
MR_def_label(analysis__file__read_analysis_file_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,4);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__IntroducedFrom__pred__read_analysis_file__567__1_3_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_sv(1) = MR_tfield(0, MR_r1, 0);
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(analysis__debug_msg_3_0,
		analysis__file__read_analysis_file_6_0_i8);
MR_def_label(analysis__file__read_analysis_file_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(io__set_input_stream_4_0,
		analysis__file__read_analysis_file_6_0_i9);
MR_def_label(analysis__file__read_analysis_file_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 6);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(15,0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__IntroducedFrom__pred__read_analysis_file__575__1_6_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 3;
	MR_tempr2 = MR_sv(4);
	MR_tfield(0, MR_tempr1, 3) = MR_tempr2;
	MR_tfield(0, MR_tempr1, 4) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 5) = MR_sv(3);
	MR_sv(2) = MR_r1;
	MR_r1 = MR_tempr2;
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(exception__try_io_4_0,
		analysis__file__read_analysis_file_6_0_i11);
MR_def_label(analysis__file__read_analysis_file_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(2);
	MR_sv(2) = MR_r1;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(io__set_input_stream_4_0,
		analysis__file__read_analysis_file_6_0_i12);
MR_def_label(analysis__file__read_analysis_file_6_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(io__close_input_3_0,
		analysis__file__read_analysis_file_6_0_i13);
MR_def_label(analysis__file__read_analysis_file_6_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(analysis__file__read_analysis_file_6_0_i15);
	}
	MR_r1 = MR_tfield(1, MR_sv(2), 0);
	MR_decr_sp_and_return(5);
MR_def_label(analysis__file__read_analysis_file_6_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_r2 = MR_sv(2);
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(exception__rethrow_1_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module12)
	MR_init_entry1(analysis__file__read_module_analysis_requests_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__read_module_analysis_requests_6_0);
	MR_init_label4(analysis__file__read_module_analysis_requests_6_0,5,7,11,9)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'read_module_analysis_requests'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__analysis__file__read_module_analysis_requests_6_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_sv(4) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(4,1);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__parse_request_entry_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_tfield(0, MR_r1, 0);
	MR_tfield(0, MR_tempr1, 4) = MR_tfield(0, MR_r1, 1);
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_tfield(0, MR_tempr1, 4);
	MR_sv(5) = MR_tfield(0, MR_tempr1, 3);
	MR_sv(6) = (MR_Word) MR_TAG_COMMON(0,1,8);
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r2 = MR_sv(6);
	}
	MR_np_call_localret_ent(fn__map__init_0_0,
		analysis__file__read_module_analysis_requests_6_0_i5);
MR_def_label(analysis__file__read_module_analysis_requests_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_sv(3) = (MR_Word) MR_TAG_COMMON(0,1,9);
	MR_r1 = MR_sv(5);
	MR_r3 = MR_tfield(0, MR_sv(4), 4);
	MR_r4 = MR_tempr1;
	MR_r5 = MR_sv(2);
	MR_r6 = (MR_Word) MR_string_const(".request", 8);
	MR_r2 = (MR_Integer) 3;
	}
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__read_module_analysis_requests_6_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_5),
		mercury__analysis__file__read_module_analysis_requests_6_0_i7);
MR_def_label(analysis__file__read_module_analysis_requests_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(analysis__file__read_module_analysis_requests_6_0_i9);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 6);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(6,2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__IntroducedFrom__pred__read_analysis_file__547__1_5_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 3;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 4) = (MR_Word) MR_string_const(".request", 8);
	MR_tfield(0, MR_tempr1, 5) = MR_tfield(1, MR_r1, 0);
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(analysis__debug_msg_3_0,
		analysis__file__read_module_analysis_requests_6_0_i11);
MR_def_label(analysis__file__read_module_analysis_requests_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(7);
MR_def_label(analysis__file__read_module_analysis_requests_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tfield(0, MR_tempr1, 0);
	MR_r3 = MR_sv(4);
	MR_r4 = MR_sv(1);
	MR_succip_word = MR_sv(7);
	MR_decr_sp(7);
	MR_np_tailcall_ent(analysis__file__read_analysis_file_6_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(io__open_append_4_0);

MR_BEGIN_MODULE(analysis__file_module13)
	MR_init_entry1(analysis__file__write_module_analysis_requests_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__write_module_analysis_requests_6_0);
	MR_init_label10(analysis__file__write_module_analysis_requests_6_0,2,4,5,7,10,11,12,13,19,21)
	MR_init_label4(analysis__file__write_module_analysis_requests_6_0,24,26,27,14)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'write_module_analysis_requests'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__analysis__file__write_module_analysis_requests_6_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r4;
	MR_sv(2) = MR_tfield(0, MR_r1, 1);
	MR_sv(6) = MR_tfield(0, MR_r1, 0);
	MR_r1 = MR_sv(6);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_r3 = MR_sv(2);
	MR_r4 = MR_r2;
	MR_r5 = MR_tempr1;
	MR_r6 = (MR_Word) MR_string_const(".request", 8);
	MR_r2 = (MR_Integer) 4;
	}
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__write_module_analysis_requests_6_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_5),
		mercury__analysis__file__write_module_analysis_requests_6_0_i2);
MR_def_label(analysis__file__write_module_analysis_requests_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,5);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__IntroducedFrom__pred__write_module_analysis_requests__716__1_3_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_sv(3) = MR_r1;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(analysis__debug_msg_3_0,
		analysis__file__write_module_analysis_requests_6_0_i4);
MR_def_label(analysis__file__write_module_analysis_requests_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(io__open_input_4_0,
		analysis__file__write_module_analysis_requests_6_0_i5);
MR_def_label(analysis__file__write_module_analysis_requests_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(analysis__file__write_module_analysis_requests_6_0_i7);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(16,0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__write_request_entry_6_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(6);
	MR_tfield(0, MR_tempr1, 4) = MR_sv(2);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, analysis_request);
	MR_r2 = MR_sv(3);
	MR_r4 = MR_sv(1);
	MR_succip_word = MR_sv(7);
	MR_decr_sp(7);
	MR_np_tailcall_ent(analysis__file__write_analysis_file_5_0);
	}
MR_def_label(analysis__file__write_module_analysis_requests_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_tfield(0, MR_r1, 0);
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(io__set_input_stream_4_0,
		analysis__file__write_module_analysis_requests_6_0_i10);
MR_def_label(analysis__file__write_module_analysis_requests_6_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(5) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_np_call_localret_ent(parser__read_term_3_0,
		analysis__file__write_module_analysis_requests_6_0_i11);
MR_def_label(analysis__file__write_module_analysis_requests_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(5);
	MR_sv(5) = MR_r1;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(io__set_input_stream_4_0,
		analysis__file__write_module_analysis_requests_6_0_i12);
MR_def_label(analysis__file__write_module_analysis_requests_6_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(io__close_input_3_0,
		analysis__file__write_module_analysis_requests_6_0_i13);
MR_def_label(analysis__file__write_module_analysis_requests_6_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(5),2)) {
		MR_GOTO_LAB(analysis__file__write_module_analysis_requests_6_0_i14);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_tfield(2, MR_sv(5), 1);
	if (MR_PTAG_TESTR(MR_tempr1,0)) {
		MR_GOTO_LAB(analysis__file__write_module_analysis_requests_6_0_i14);
	}
	MR_tempr2 = MR_tfield(0, MR_tempr1, 1);
	if (MR_LTAGS_TESTR(MR_tempr2,0,0)) {
		MR_GOTO_LAB(analysis__file__write_module_analysis_requests_6_0_i14);
	}
	MR_tempr2 = MR_tfield(0, MR_tempr1, 0);
	if (MR_PTAG_TESTR(MR_tempr2,1)) {
		MR_GOTO_LAB(analysis__file__write_module_analysis_requests_6_0_i14);
	}
	MR_tempr1 = MR_tfield(1, MR_tempr2, 0);
	if (MR_INT_NE(MR_tempr1,6)) {
		MR_GOTO_LAB(analysis__file__write_module_analysis_requests_6_0_i14);
	}
	MR_r1 = MR_sv(3);
	}
	MR_np_call_localret_ent(io__open_append_4_0,
		analysis__file__write_module_analysis_requests_6_0_i19);
MR_def_label(analysis__file__write_module_analysis_requests_6_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(analysis__file__write_module_analysis_requests_6_0_i21);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(16,1);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__write_request_entry_6_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(6);
	MR_tfield(0, MR_tempr1, 4) = MR_sv(2);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, analysis_request);
	MR_r2 = MR_sv(3);
	MR_r4 = MR_sv(1);
	MR_succip_word = MR_sv(7);
	MR_decr_sp(7);
	MR_np_tailcall_ent(analysis__file__write_analysis_file_5_0);
	}
MR_def_label(analysis__file__write_module_analysis_requests_6_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_tfield(0, MR_r1, 0);
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(io__set_output_stream_4_0,
		analysis__file__write_module_analysis_requests_6_0_i24);
MR_def_label(analysis__file__write_module_analysis_requests_6_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(16,2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__write_request_entry_6_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(6);
	MR_tfield(0, MR_tempr1, 4) = MR_sv(2);
	MR_tempr2 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, analysis_request);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tempr2;
	}
	MR_np_call_localret_ent(analysis__file__write_analysis_file_2_4_0,
		analysis__file__write_module_analysis_requests_6_0_i26);
MR_def_label(analysis__file__write_module_analysis_requests_6_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(io__set_output_stream_4_0,
		analysis__file__write_module_analysis_requests_6_0_i27);
MR_def_label(analysis__file__write_module_analysis_requests_6_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_succip_word = MR_sv(7);
	MR_decr_sp(7);
	MR_np_tailcall_ent(io__close_output_3_0);
MR_def_label(analysis__file__write_module_analysis_requests_6_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(16,3);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__write_request_entry_6_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(6);
	MR_tfield(0, MR_tempr1, 4) = MR_sv(2);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, analysis_request);
	MR_r2 = MR_sv(3);
	MR_r4 = MR_sv(1);
	MR_succip_word = MR_sv(7);
	MR_decr_sp(7);
	MR_np_tailcall_ent(analysis__file__write_analysis_file_5_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module14)
	MR_init_entry1(analysis__file__read_module_imdg_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__read_module_imdg_6_0);
	MR_init_label4(analysis__file__read_module_imdg_6_0,5,7,11,9)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'read_module_imdg'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__analysis__file__read_module_imdg_6_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_sv(4) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(4,2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__parse_imdg_arc_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_tfield(0, MR_r1, 0);
	MR_tfield(0, MR_tempr1, 4) = MR_tfield(0, MR_r1, 1);
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_tfield(0, MR_tempr1, 4);
	MR_sv(5) = MR_tfield(0, MR_tempr1, 3);
	MR_sv(6) = (MR_Word) MR_TAG_COMMON(0,1,12);
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r2 = MR_sv(6);
	}
	MR_np_call_localret_ent(fn__map__init_0_0,
		analysis__file__read_module_imdg_6_0_i5);
MR_def_label(analysis__file__read_module_imdg_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_sv(3) = (MR_Word) MR_TAG_COMMON(0,1,13);
	MR_r1 = MR_sv(5);
	MR_r3 = MR_tfield(0, MR_sv(4), 4);
	MR_r4 = MR_tempr1;
	MR_r5 = MR_sv(2);
	MR_r6 = (MR_Word) MR_string_const(".imdg", 5);
	MR_r2 = (MR_Integer) 3;
	}
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__read_module_imdg_6_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_5),
		mercury__analysis__file__read_module_imdg_6_0_i7);
MR_def_label(analysis__file__read_module_imdg_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(analysis__file__read_module_imdg_6_0_i9);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 6);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(6,3);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__IntroducedFrom__pred__read_analysis_file__547__1_5_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 3;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 4) = (MR_Word) MR_string_const(".imdg", 5);
	MR_tfield(0, MR_tempr1, 5) = MR_tfield(1, MR_r1, 0);
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(analysis__debug_msg_3_0,
		analysis__file__read_module_imdg_6_0_i11);
MR_def_label(analysis__file__read_module_imdg_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(7);
MR_def_label(analysis__file__read_module_imdg_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tfield(0, MR_tempr1, 0);
	MR_r3 = MR_sv(4);
	MR_r4 = MR_sv(1);
	MR_succip_word = MR_sv(7);
	MR_decr_sp(7);
	MR_np_tailcall_ent(analysis__file__read_analysis_file_6_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module15)
	MR_init_entry1(analysis__file__write_module_imdg_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__write_module_imdg_6_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'write_module_imdg'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__analysis__file__write_module_imdg_6_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_r8 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(16,4);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__write_imdg_arc_6_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_tfield(0, MR_r1, 0);
	MR_tfield(0, MR_tempr1, 4) = MR_tfield(0, MR_r1, 1);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, imdg_arc);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tfield(0, MR_tempr1, 3);
	MR_tempr3 = MR_r3;
	MR_r3 = MR_tfield(0, MR_tempr1, 4);
	MR_tempr4 = MR_r4;
	MR_r4 = MR_tempr2;
	MR_r5 = MR_tempr3;
	MR_r6 = (MR_Word) MR_string_const(".imdg", 5);
	MR_r7 = (MR_Integer) 0;
	MR_r9 = MR_tempr4;
	MR_np_tailcall_ent(analysis__file__write_analysis_file_10_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module16)
	MR_init_entry1(analysis__file__empty_request_file_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__empty_request_file_5_0);
	MR_init_label2(analysis__file__empty_request_file_5_0,2,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'empty_request_file'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__analysis__file__empty_request_file_5_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_tfield(0, MR_r1, 0);
	MR_tempr2 = MR_r3;
	MR_r3 = MR_tfield(0, MR_tempr1, 1);
	MR_r4 = MR_r2;
	MR_r5 = MR_tempr2;
	MR_r6 = (MR_Word) MR_string_const(".request", 8);
	MR_r2 = (MR_Integer) 4;
	}
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__empty_request_file_5_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_5),
		mercury__analysis__file__empty_request_file_5_0_i2);
MR_def_label(analysis__file__empty_request_file_5_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,6);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__IntroducedFrom__pred__empty_request_file__913__1_3_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_sv(1) = MR_r1;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(analysis__debug_msg_3_0,
		analysis__file__empty_request_file_5_0_i4);
MR_def_label(analysis__file__empty_request_file_5_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__remove_file_4_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(hlds__hlds_pred__proc_id_to_int_2_1);

MR_BEGIN_MODULE(analysis__file_module17)
	MR_init_entry1(analysis__file__parse_func_id_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__parse_func_id_2_0);
	MR_init_label4(analysis__file__parse_func_id_2_0,9,8,20,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'parse_func_id'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__parse_func_id_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(analysis__file__parse_func_id_2_0_i1);
	}
	MR_r2 = MR_tfield(0, MR_r1, 0);
	if (MR_PTAG_TESTR(MR_r2,0)) {
		MR_GOTO_LAB(analysis__file__parse_func_id_2_0_i1);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr1 = MR_tfield(0, MR_r1, 1);
	MR_r3 = MR_tempr1;
	if (MR_LTAGS_TEST(MR_tempr1,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_func_id_2_0_i1);
	}
	MR_tempr2 = MR_tfield(1, MR_tempr1, 1);
	MR_r4 = MR_tempr2;
	if (MR_LTAGS_TEST(MR_tempr2,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_func_id_2_0_i1);
	}
	MR_tempr3 = MR_tfield(1, MR_tempr2, 1);
	MR_r5 = MR_tempr3;
	if (MR_LTAGS_TEST(MR_tempr3,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_func_id_2_0_i1);
	}
	MR_r6 = MR_tfield(1, MR_tempr3, 1);
	if (MR_LTAGS_TESTR(MR_r6,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_func_id_2_0_i1);
	}
	MR_r6 = MR_tfield(0, MR_r2, 0);
	if ((strcmp((char *) (MR_Word *) MR_r6, MR_string_const("f", 1)) != 0)) {
		MR_GOTO_LAB(analysis__file__parse_func_id_2_0_i9);
	}
	MR_r1 = MR_tfield(1, MR_tempr1, 0);
	MR_r2 = MR_tfield(1, MR_tempr2, 0);
	MR_r3 = MR_tfield(1, MR_tempr3, 0);
	MR_sv(1) = (MR_Integer) 1;
	MR_GOTO_LAB(analysis__file__parse_func_id_2_0_i8);
	}
MR_def_label(analysis__file__parse_func_id_2_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r6, MR_string_const("p", 1)) != 0)) {
		MR_GOTO_LAB(analysis__file__parse_func_id_2_0_i1);
	}
	MR_r1 = MR_tfield(1, MR_r3, 0);
	MR_r2 = MR_tfield(1, MR_r4, 0);
	MR_r3 = MR_tfield(1, MR_r5, 0);
	MR_sv(1) = (MR_Integer) 0;
MR_def_label(analysis__file__parse_func_id_2_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(analysis__file__parse_func_id_2_0_i1);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tempr1 = MR_tfield(0, MR_r1, 0);
	if (MR_PTAG_TESTR(MR_tempr1,0)) {
		MR_GOTO_LAB(analysis__file__parse_func_id_2_0_i1);
	}
	MR_tempr2 = MR_tfield(0, MR_r1, 1);
	if (MR_LTAGS_TESTR(MR_tempr2,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_func_id_2_0_i1);
	}
	if (MR_PTAG_TESTR(MR_r2,0)) {
		MR_GOTO_LAB(analysis__file__parse_func_id_2_0_i1);
	}
	MR_tempr2 = MR_tfield(0, MR_r2, 0);
	if (MR_PTAG_TESTR(MR_tempr2,1)) {
		MR_GOTO_LAB(analysis__file__parse_func_id_2_0_i1);
	}
	MR_tempr3 = MR_tfield(0, MR_r2, 1);
	if (MR_LTAGS_TESTR(MR_tempr3,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_func_id_2_0_i1);
	}
	if (MR_PTAG_TESTR(MR_r3,0)) {
		MR_GOTO_LAB(analysis__file__parse_func_id_2_0_i1);
	}
	MR_tempr4 = MR_r3;
	MR_r2 = MR_tfield(0, MR_tempr4, 0);
	if (MR_PTAG_TESTR(MR_r2,1)) {
		MR_GOTO_LAB(analysis__file__parse_func_id_2_0_i1);
	}
	MR_tempr3 = MR_tfield(0, MR_tempr4, 1);
	if (MR_LTAGS_TESTR(MR_tempr3,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_func_id_2_0_i1);
	}
	MR_sv(2) = MR_tfield(0, MR_tempr1, 0);
	MR_sv(3) = MR_tfield(1, MR_tempr2, 0);
	MR_r1 = MR_tfield(1, MR_r2, 0);
	}
	MR_np_call_localret_ent(hlds__hlds_pred__proc_id_to_int_2_1,
		analysis__file__parse_func_id_2_0_i20);
MR_def_label(analysis__file__parse_func_id_2_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 4);
	MR_tfield(0, MR_r2, 0) = MR_sv(1);
	MR_tfield(0, MR_r2, 1) = MR_sv(2);
	MR_tfield(0, MR_r2, 2) = MR_sv(3);
	MR_tfield(0, MR_r2, 3) = MR_r1;
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(analysis__file__parse_func_id_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_declare_entry(mercury__do_call_class_method_2);
MR_decl_entry(private_builtin__superclass_from_typeclass_info_3_0);
MR_declare_entry(mercury__do_call_class_method_1);
MR_declare_entry(mercury__do_call_class_method_0);
MR_decl_entry(map__search_3_0);
MR_decl_entry(map__set_4_0);

MR_BEGIN_MODULE(analysis__file_module18)
	MR_init_entry1(analysis__file__parse_result_entry_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__parse_result_entry_4_0);
	MR_init_label10(analysis__file__parse_result_entry_4_0,15,17,19,20,21,23,24,25,28,29)
	MR_init_label10(analysis__file__parse_result_entry_4_0,27,32,40,37,43,44,47,45,52,53)
	MR_init_label5(analysis__file__parse_result_entry_4_0,31,2,3,58,59)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'parse_result_entry'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__parse_result_entry_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(10);
	MR_sv(10) = (MR_Word) MR_succip;
	if (MR_PTAG_TESTR(MR_r3,0)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i3);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6, MR_tempr7, MR_tempr8;
	MR_tempr8 = MR_r3;
	MR_tempr1 = MR_tfield(0, MR_tempr8, 0);
	if (MR_PTAG_TESTR(MR_tempr1,0)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i3);
	}
	MR_tempr2 = MR_tfield(0, MR_tempr8, 1);
	if (MR_LTAGS_TEST(MR_tempr2,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i3);
	}
	MR_tempr3 = MR_tfield(1, MR_tempr2, 1);
	if (MR_LTAGS_TEST(MR_tempr3,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i3);
	}
	MR_tempr4 = MR_tfield(1, MR_tempr3, 1);
	if (MR_LTAGS_TEST(MR_tempr4,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i3);
	}
	MR_tempr5 = MR_tfield(1, MR_tempr4, 1);
	if (MR_LTAGS_TEST(MR_tempr5,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i3);
	}
	MR_tempr6 = MR_tfield(1, MR_tempr5, 1);
	if (MR_LTAGS_TEST(MR_tempr6,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i3);
	}
	MR_tempr7 = MR_tfield(1, MR_tempr6, 1);
	if (MR_LTAGS_TESTR(MR_tempr7,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i3);
	}
	MR_tempr7 = MR_tfield(1, MR_tempr6, 0);
	if (MR_PTAG_TESTR(MR_tempr7,0)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i3);
	}
	MR_tempr6 = MR_tfield(0, MR_tempr7, 1);
	if (MR_LTAGS_TESTR(MR_tempr6,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i3);
	}
	MR_tempr6 = MR_tfield(0, MR_tempr7, 0);
	if (MR_PTAG_TESTR(MR_tempr6,0)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i3);
	}
	MR_sv(1) = MR_tempr8;
	MR_sv(2) = MR_r4;
	MR_sv(3) = MR_tfield(0, MR_tempr1, 0);
	MR_sv(4) = MR_tfield(1, MR_tempr2, 0);
	MR_sv(5) = MR_tfield(1, MR_tempr3, 0);
	MR_sv(6) = MR_tfield(1, MR_tempr4, 0);
	MR_sv(7) = MR_tfield(1, MR_tempr5, 0);
	MR_sv(8) = MR_tfield(0, MR_tempr6, 0);
	MR_r3 = MR_r2;
	MR_r4 = MR_sv(3);
	MR_r2 = (MR_Integer) 2;
	}
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__parse_result_entry_4_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_2),
		mercury__analysis__file__parse_result_entry_4_0_i15);
MR_def_label(analysis__file__parse_result_entry_4_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i2);
	}
	MR_sv(9) = MR_tfield(0, MR_r2, 0);
	MR_r1 = MR_sv(5);
	MR_np_call_localret_ent(analysis__file__parse_func_id_2_0,
		analysis__file__parse_result_entry_4_0_i17);
MR_def_label(analysis__file__parse_result_entry_4_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i2);
	}
	MR_sv(5) = MR_r2;
	MR_r1 = MR_sv(9);
	MR_r2 = (MR_Integer) 1;
	MR_np_call_localret_ent(private_builtin__superclass_from_typeclass_info_3_0,
		analysis__file__parse_result_entry_4_0_i19);
MR_def_label(analysis__file__parse_result_entry_4_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Integer) 2;
	MR_np_call_localret_ent(private_builtin__superclass_from_typeclass_info_3_0,
		analysis__file__parse_result_entry_4_0_i20);
MR_def_label(analysis__file__parse_result_entry_4_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_sv(6);
	MR_r2 = (MR_Integer) 2;
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__parse_result_entry_4_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_1),
		mercury__analysis__file__parse_result_entry_4_0_i21);
MR_def_label(analysis__file__parse_result_entry_4_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i2);
	}
	MR_sv(6) = MR_r2;
	MR_r1 = MR_sv(9);
	MR_r2 = (MR_Integer) 2;
	MR_np_call_localret_ent(private_builtin__superclass_from_typeclass_info_3_0,
		analysis__file__parse_result_entry_4_0_i23);
MR_def_label(analysis__file__parse_result_entry_4_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Integer) 2;
	MR_np_call_localret_ent(private_builtin__superclass_from_typeclass_info_3_0,
		analysis__file__parse_result_entry_4_0_i24);
MR_def_label(analysis__file__parse_result_entry_4_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_sv(7);
	MR_r2 = (MR_Integer) 2;
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__parse_result_entry_4_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_1),
		mercury__analysis__file__parse_result_entry_4_0_i25);
MR_def_label(analysis__file__parse_result_entry_4_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i2);
	}
	if ((strcmp((char *) (MR_Word *) MR_sv(8), MR_string_const("invalid", 7)) != 0)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i28);
	}
	MR_sv(7) = (MR_Integer) 0;
	MR_r1 = MR_sv(9);
	MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i27);
MR_def_label(analysis__file__parse_result_entry_4_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(8), MR_string_const("optimal", 7)) != 0)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i29);
	}
	MR_sv(7) = (MR_Integer) 2;
	MR_r1 = MR_sv(9);
	MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i27);
MR_def_label(analysis__file__parse_result_entry_4_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(8), MR_string_const("suboptimal", 10)) != 0)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i2);
	}
	MR_sv(7) = (MR_Integer) 1;
	MR_r1 = MR_sv(9);
MR_def_label(analysis__file__parse_result_entry_4_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	MR_sv(9) = MR_r1;
	MR_r2 = (MR_Integer) 2;
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__parse_result_entry_4_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_0),
		mercury__analysis__file__parse_result_entry_4_0_i32);
MR_def_label(analysis__file__parse_result_entry_4_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(4),0)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i31);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr3 = MR_sv(4);
	MR_tempr1 = MR_tfield(0, MR_tempr3, 1);
	if (MR_LTAGS_TESTR(MR_tempr1,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i31);
	}
	MR_tempr1 = MR_tfield(0, MR_tempr3, 0);
	if (MR_PTAG_TESTR(MR_tempr1,1)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i31);
	}
	MR_tempr2 = MR_tfield(1, MR_tempr1, 0);
	if ((MR_r3 != MR_tempr2)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i31);
	}
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(9);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(6);
	MR_tfield(0, MR_tempr1, 2) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 3) = MR_sv(7);
	MR_sv(1) = MR_tempr1;
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r3 = MR_sv(2);
	MR_r4 = MR_sv(3);
	}
	MR_np_call_localret_ent(map__search_3_0,
		analysis__file__parse_result_entry_4_0_i40);
MR_def_label(analysis__file__parse_result_entry_4_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i37);
	}
	MR_r4 = MR_sv(5);
	MR_r3 = MR_r2;
	MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i44);
MR_def_label(analysis__file__parse_result_entry_4_0,37)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, func_id);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_np_call_localret_ent(fn__map__init_0_0,
		analysis__file__parse_result_entry_4_0_i43);
MR_def_label(analysis__file__parse_result_entry_4_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r4 = MR_sv(5);
	MR_r3 = MR_r1;
MR_def_label(analysis__file__parse_result_entry_4_0,44)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(5) = MR_r4;
	MR_sv(4) = MR_r3;
	MR_sv(6) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, func_id);
	MR_r2 = MR_sv(6);
	MR_np_call_localret_ent(map__search_3_0,
		analysis__file__parse_result_entry_4_0_i47);
MR_def_label(analysis__file__parse_result_entry_4_0,47)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i45);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_r5 = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = MR_sv(1);
	MR_tfield(1, MR_tempr1, 1) = MR_r2;
	MR_r4 = MR_sv(5);
	MR_r3 = MR_sv(4);
	MR_r2 = MR_sv(6);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, func_id);
	MR_GOTO_LAB(analysis__file__parse_result_entry_4_0_i52);
	}
MR_def_label(analysis__file__parse_result_entry_4_0,45)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_r5 = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = MR_sv(1);
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_r4 = MR_sv(5);
	MR_r3 = MR_sv(4);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, func_id);
	}
MR_def_label(analysis__file__parse_result_entry_4_0,52)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	MR_np_call_localret_ent(map__set_4_0,
		analysis__file__parse_result_entry_4_0_i53);
MR_def_label(analysis__file__parse_result_entry_4_0,53)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 3);
	MR_tfield(0, MR_r2, 0) = (MR_Word) MR_CTOR_ADDR(tree234, tree234, 2);
	MR_tfield(0, MR_r2, 1) = (MR_Word) MR_CTOR0_ADDR(analysis, func_id);
	MR_tfield(0, MR_r2, 2) = MR_sv(1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r3 = MR_sv(2);
	MR_r4 = MR_sv(3);
	MR_r5 = MR_tempr1;
	MR_succip_word = MR_sv(10);
	MR_decr_sp(10);
	MR_np_tailcall_ent(map__set_4_0);
	}
MR_def_label(analysis__file__parse_result_entry_4_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_decr_sp_and_return(10);
MR_def_label(analysis__file__parse_result_entry_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_sv(1);
MR_def_label(analysis__file__parse_result_entry_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,8);
	MR_r2 = MR_r3;
	MR_np_call_localret_ent(fn__string__string_1_0,
		analysis__file__parse_result_entry_4_0_i58);
MR_def_label(analysis__file__parse_result_entry_4_0,58)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("failed to parse result entry: ", 30);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		analysis__file__parse_result_entry_4_0_i59);
MR_def_label(analysis__file__parse_result_entry_4_0,59)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis__file, invalid_analysis_file);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(10);
	MR_decr_sp(10);
	MR_np_tailcall_ent(exception__throw_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(parse_tree__prog_io_sym_name__try_parse_sym_name_and_no_args_2_0);

MR_BEGIN_MODULE(analysis__file_module19)
	MR_init_entry1(analysis__file__parse_request_entry_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__parse_request_entry_4_0);
	MR_init_label10(analysis__file__parse_request_entry_4_0,16,18,20,22,23,24,27,31,36,33)
	MR_init_label10(analysis__file__parse_request_entry_4_0,39,40,43,41,48,49,26,2,3,54)
	MR_init_label1(analysis__file__parse_request_entry_4_0,55)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'parse_request_entry'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__parse_request_entry_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(9);
	MR_sv(9) = (MR_Word) MR_succip;
	if (MR_PTAG_TESTR(MR_r3,0)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i3);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6, MR_tempr7;
	MR_tempr7 = MR_r3;
	MR_tempr1 = MR_tfield(0, MR_tempr7, 0);
	if (MR_PTAG_TESTR(MR_tempr1,0)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i3);
	}
	MR_tempr2 = MR_tfield(0, MR_tempr1, 0);
	if ((strcmp((char *) (MR_Word *) MR_tempr2, MR_string_const("->", 2)) != 0)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i3);
	}
	MR_tempr1 = MR_tfield(0, MR_tempr7, 1);
	if (MR_LTAGS_TEST(MR_tempr1,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i3);
	}
	MR_tempr2 = MR_tfield(1, MR_tempr1, 1);
	if (MR_LTAGS_TEST(MR_tempr2,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i3);
	}
	MR_tempr3 = MR_tfield(1, MR_tempr2, 1);
	if (MR_LTAGS_TESTR(MR_tempr3,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i3);
	}
	MR_tempr3 = MR_tfield(1, MR_tempr2, 0);
	if (MR_PTAG_TESTR(MR_tempr3,0)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i3);
	}
	MR_tempr2 = MR_tfield(0, MR_tempr3, 0);
	if (MR_PTAG_TESTR(MR_tempr2,0)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i3);
	}
	MR_tempr4 = MR_tfield(0, MR_tempr3, 1);
	if (MR_LTAGS_TEST(MR_tempr4,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i3);
	}
	MR_tempr3 = MR_tfield(1, MR_tempr4, 1);
	if (MR_LTAGS_TEST(MR_tempr3,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i3);
	}
	MR_tempr5 = MR_tfield(1, MR_tempr3, 1);
	if (MR_LTAGS_TEST(MR_tempr5,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i3);
	}
	MR_tempr6 = MR_tfield(1, MR_tempr5, 1);
	if (MR_LTAGS_TESTR(MR_tempr6,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i3);
	}
	MR_sv(1) = MR_tempr7;
	MR_sv(2) = MR_r4;
	MR_sv(3) = MR_tfield(1, MR_tempr1, 0);
	MR_sv(4) = MR_tfield(0, MR_tempr2, 0);
	MR_sv(5) = MR_tfield(1, MR_tempr4, 0);
	MR_sv(6) = MR_tfield(1, MR_tempr3, 0);
	MR_sv(7) = MR_tfield(1, MR_tempr5, 0);
	MR_r3 = MR_r2;
	MR_r4 = MR_sv(4);
	MR_r2 = (MR_Integer) 2;
	}
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__parse_request_entry_4_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_2),
		mercury__analysis__file__parse_request_entry_4_0_i16);
MR_def_label(analysis__file__parse_request_entry_4_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i2);
	}
	MR_sv(8) = MR_tfield(0, MR_r2, 0);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(parse_tree__prog_io_sym_name__try_parse_sym_name_and_no_args_2_0,
		analysis__file__parse_request_entry_4_0_i18);
MR_def_label(analysis__file__parse_request_entry_4_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i2);
	}
	MR_sv(3) = MR_r2;
	MR_r1 = MR_sv(6);
	MR_np_call_localret_ent(analysis__file__parse_func_id_2_0,
		analysis__file__parse_request_entry_4_0_i20);
MR_def_label(analysis__file__parse_request_entry_4_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i2);
	}
	MR_sv(6) = MR_r2;
	MR_r1 = MR_sv(8);
	MR_r2 = (MR_Integer) 1;
	MR_np_call_localret_ent(private_builtin__superclass_from_typeclass_info_3_0,
		analysis__file__parse_request_entry_4_0_i22);
MR_def_label(analysis__file__parse_request_entry_4_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Integer) 2;
	MR_np_call_localret_ent(private_builtin__superclass_from_typeclass_info_3_0,
		analysis__file__parse_request_entry_4_0_i23);
MR_def_label(analysis__file__parse_request_entry_4_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_sv(7);
	MR_r2 = (MR_Integer) 2;
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__parse_request_entry_4_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_1),
		mercury__analysis__file__parse_request_entry_4_0_i24);
MR_def_label(analysis__file__parse_request_entry_4_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i2);
	}
	MR_sv(1) = MR_r2;
	MR_r1 = MR_sv(8);
	MR_r2 = (MR_Integer) 2;
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__parse_request_entry_4_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_0),
		mercury__analysis__file__parse_request_entry_4_0_i27);
MR_def_label(analysis__file__parse_request_entry_4_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(5),0)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i26);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr3 = MR_sv(5);
	MR_tempr1 = MR_tfield(0, MR_tempr3, 1);
	if (MR_LTAGS_TESTR(MR_tempr1,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i26);
	}
	MR_tempr1 = MR_tfield(0, MR_tempr3, 0);
	if (MR_PTAG_TESTR(MR_tempr1,1)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i26);
	}
	MR_tempr2 = MR_tfield(1, MR_tempr1, 0);
	if ((MR_r3 != MR_tempr2)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i26);
	}
	MR_r1 = MR_sv(8);
	MR_r2 = (MR_Integer) 1;
	}
	MR_np_call_localret_ent(private_builtin__superclass_from_typeclass_info_3_0,
		analysis__file__parse_request_entry_4_0_i31);
MR_def_label(analysis__file__parse_request_entry_4_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 3);
	MR_tfield(0, MR_tempr1, 0) = MR_r1;
	MR_tfield(0, MR_tempr1, 1) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 2) = MR_sv(3);
	MR_sv(1) = MR_tempr1;
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,1,8);
	MR_r3 = MR_sv(2);
	MR_r4 = MR_sv(4);
	}
	MR_np_call_localret_ent(map__search_3_0,
		analysis__file__parse_request_entry_4_0_i36);
MR_def_label(analysis__file__parse_request_entry_4_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i33);
	}
	MR_r4 = MR_sv(6);
	MR_r3 = MR_r2;
	MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i40);
MR_def_label(analysis__file__parse_request_entry_4_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, func_id);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,5);
	MR_np_call_localret_ent(fn__map__init_0_0,
		analysis__file__parse_request_entry_4_0_i39);
MR_def_label(analysis__file__parse_request_entry_4_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r4 = MR_sv(6);
	MR_r3 = MR_r1;
MR_def_label(analysis__file__parse_request_entry_4_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(6) = MR_r4;
	MR_sv(3) = MR_r3;
	MR_sv(5) = (MR_Word) MR_TAG_COMMON(0,0,5);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, func_id);
	MR_r2 = MR_sv(5);
	MR_np_call_localret_ent(map__search_3_0,
		analysis__file__parse_request_entry_4_0_i43);
MR_def_label(analysis__file__parse_request_entry_4_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i41);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_r5 = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = MR_sv(1);
	MR_tfield(1, MR_tempr1, 1) = MR_r2;
	MR_r4 = MR_sv(6);
	MR_r3 = MR_sv(3);
	MR_r2 = MR_sv(5);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, func_id);
	MR_GOTO_LAB(analysis__file__parse_request_entry_4_0_i48);
	}
MR_def_label(analysis__file__parse_request_entry_4_0,41)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_r5 = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = MR_sv(1);
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_r4 = MR_sv(6);
	MR_r3 = MR_sv(3);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,5);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, func_id);
	}
MR_def_label(analysis__file__parse_request_entry_4_0,48)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	MR_np_call_localret_ent(map__set_4_0,
		analysis__file__parse_request_entry_4_0_i49);
MR_def_label(analysis__file__parse_request_entry_4_0,49)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 3);
	MR_tfield(0, MR_r2, 0) = (MR_Word) MR_CTOR_ADDR(tree234, tree234, 2);
	MR_tfield(0, MR_r2, 1) = (MR_Word) MR_CTOR0_ADDR(analysis, func_id);
	MR_tfield(0, MR_r2, 2) = MR_sv(1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r3 = MR_sv(2);
	MR_r4 = MR_sv(4);
	MR_r5 = MR_tempr1;
	MR_succip_word = MR_sv(9);
	MR_decr_sp(9);
	MR_np_tailcall_ent(map__set_4_0);
	}
MR_def_label(analysis__file__parse_request_entry_4_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_decr_sp_and_return(9);
MR_def_label(analysis__file__parse_request_entry_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_sv(1);
MR_def_label(analysis__file__parse_request_entry_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,8);
	MR_r2 = MR_r3;
	MR_np_call_localret_ent(fn__string__string_1_0,
		analysis__file__parse_request_entry_4_0_i54);
MR_def_label(analysis__file__parse_request_entry_4_0,54)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("failed to parse request entry: ", 31);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		analysis__file__parse_request_entry_4_0_i55);
MR_def_label(analysis__file__parse_request_entry_4_0,55)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis__file, invalid_analysis_file);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(9);
	MR_decr_sp(9);
	MR_np_tailcall_ent(exception__throw_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module20)
	MR_init_entry1(analysis__file__parse_imdg_arc_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__parse_imdg_arc_4_0);
	MR_init_label10(analysis__file__parse_imdg_arc_4_0,16,18,20,22,23,24,27,31,36,33)
	MR_init_label10(analysis__file__parse_imdg_arc_4_0,39,40,43,41,48,49,26,2,3,54)
	MR_init_label1(analysis__file__parse_imdg_arc_4_0,55)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'parse_imdg_arc'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__parse_imdg_arc_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(9);
	MR_sv(9) = (MR_Word) MR_succip;
	if (MR_PTAG_TESTR(MR_r3,0)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i3);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6, MR_tempr7;
	MR_tempr7 = MR_r3;
	MR_tempr1 = MR_tfield(0, MR_tempr7, 0);
	if (MR_PTAG_TESTR(MR_tempr1,0)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i3);
	}
	MR_tempr2 = MR_tfield(0, MR_tempr1, 0);
	if ((strcmp((char *) (MR_Word *) MR_tempr2, MR_string_const("->", 2)) != 0)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i3);
	}
	MR_tempr1 = MR_tfield(0, MR_tempr7, 1);
	if (MR_LTAGS_TEST(MR_tempr1,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i3);
	}
	MR_tempr2 = MR_tfield(1, MR_tempr1, 1);
	if (MR_LTAGS_TEST(MR_tempr2,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i3);
	}
	MR_tempr3 = MR_tfield(1, MR_tempr2, 1);
	if (MR_LTAGS_TESTR(MR_tempr3,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i3);
	}
	MR_tempr3 = MR_tfield(1, MR_tempr2, 0);
	if (MR_PTAG_TESTR(MR_tempr3,0)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i3);
	}
	MR_tempr2 = MR_tfield(0, MR_tempr3, 0);
	if (MR_PTAG_TESTR(MR_tempr2,0)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i3);
	}
	MR_tempr4 = MR_tfield(0, MR_tempr3, 1);
	if (MR_LTAGS_TEST(MR_tempr4,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i3);
	}
	MR_tempr3 = MR_tfield(1, MR_tempr4, 1);
	if (MR_LTAGS_TEST(MR_tempr3,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i3);
	}
	MR_tempr5 = MR_tfield(1, MR_tempr3, 1);
	if (MR_LTAGS_TEST(MR_tempr5,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i3);
	}
	MR_tempr6 = MR_tfield(1, MR_tempr5, 1);
	if (MR_LTAGS_TESTR(MR_tempr6,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i3);
	}
	MR_sv(1) = MR_tempr7;
	MR_sv(2) = MR_r4;
	MR_sv(3) = MR_tfield(1, MR_tempr1, 0);
	MR_sv(4) = MR_tfield(0, MR_tempr2, 0);
	MR_sv(5) = MR_tfield(1, MR_tempr4, 0);
	MR_sv(6) = MR_tfield(1, MR_tempr3, 0);
	MR_sv(7) = MR_tfield(1, MR_tempr5, 0);
	MR_r3 = MR_r2;
	MR_r4 = MR_sv(4);
	MR_r2 = (MR_Integer) 2;
	}
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__parse_imdg_arc_4_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_2),
		mercury__analysis__file__parse_imdg_arc_4_0_i16);
MR_def_label(analysis__file__parse_imdg_arc_4_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i2);
	}
	MR_sv(8) = MR_tfield(0, MR_r2, 0);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(parse_tree__prog_io_sym_name__try_parse_sym_name_and_no_args_2_0,
		analysis__file__parse_imdg_arc_4_0_i18);
MR_def_label(analysis__file__parse_imdg_arc_4_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i2);
	}
	MR_sv(3) = MR_r2;
	MR_r1 = MR_sv(6);
	MR_np_call_localret_ent(analysis__file__parse_func_id_2_0,
		analysis__file__parse_imdg_arc_4_0_i20);
MR_def_label(analysis__file__parse_imdg_arc_4_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i2);
	}
	MR_sv(6) = MR_r2;
	MR_r1 = MR_sv(8);
	MR_r2 = (MR_Integer) 1;
	MR_np_call_localret_ent(private_builtin__superclass_from_typeclass_info_3_0,
		analysis__file__parse_imdg_arc_4_0_i22);
MR_def_label(analysis__file__parse_imdg_arc_4_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Integer) 2;
	MR_np_call_localret_ent(private_builtin__superclass_from_typeclass_info_3_0,
		analysis__file__parse_imdg_arc_4_0_i23);
MR_def_label(analysis__file__parse_imdg_arc_4_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_sv(7);
	MR_r2 = (MR_Integer) 2;
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__parse_imdg_arc_4_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_1),
		mercury__analysis__file__parse_imdg_arc_4_0_i24);
MR_def_label(analysis__file__parse_imdg_arc_4_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i2);
	}
	MR_sv(1) = MR_r2;
	MR_r1 = MR_sv(8);
	MR_r2 = (MR_Integer) 2;
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__parse_imdg_arc_4_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_0),
		mercury__analysis__file__parse_imdg_arc_4_0_i27);
MR_def_label(analysis__file__parse_imdg_arc_4_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(5),0)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i26);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr3 = MR_sv(5);
	MR_tempr1 = MR_tfield(0, MR_tempr3, 1);
	if (MR_LTAGS_TESTR(MR_tempr1,0,0)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i26);
	}
	MR_tempr1 = MR_tfield(0, MR_tempr3, 0);
	if (MR_PTAG_TESTR(MR_tempr1,1)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i26);
	}
	MR_tempr2 = MR_tfield(1, MR_tempr1, 0);
	if ((MR_r3 != MR_tempr2)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i26);
	}
	MR_r1 = MR_sv(8);
	MR_r2 = (MR_Integer) 1;
	}
	MR_np_call_localret_ent(private_builtin__superclass_from_typeclass_info_3_0,
		analysis__file__parse_imdg_arc_4_0_i31);
MR_def_label(analysis__file__parse_imdg_arc_4_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 3);
	MR_tfield(0, MR_tempr1, 0) = MR_r1;
	MR_tfield(0, MR_tempr1, 1) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 2) = MR_sv(3);
	MR_sv(1) = MR_tempr1;
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,1,12);
	MR_r3 = MR_sv(2);
	MR_r4 = MR_sv(4);
	}
	MR_np_call_localret_ent(map__search_3_0,
		analysis__file__parse_imdg_arc_4_0_i36);
MR_def_label(analysis__file__parse_imdg_arc_4_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i33);
	}
	MR_r4 = MR_sv(6);
	MR_r3 = MR_r2;
	MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i40);
MR_def_label(analysis__file__parse_imdg_arc_4_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, func_id);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,7);
	MR_np_call_localret_ent(fn__map__init_0_0,
		analysis__file__parse_imdg_arc_4_0_i39);
MR_def_label(analysis__file__parse_imdg_arc_4_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r4 = MR_sv(6);
	MR_r3 = MR_r1;
MR_def_label(analysis__file__parse_imdg_arc_4_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(6) = MR_r4;
	MR_sv(3) = MR_r3;
	MR_sv(5) = (MR_Word) MR_TAG_COMMON(0,0,7);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, func_id);
	MR_r2 = MR_sv(5);
	MR_np_call_localret_ent(map__search_3_0,
		analysis__file__parse_imdg_arc_4_0_i43);
MR_def_label(analysis__file__parse_imdg_arc_4_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i41);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_r5 = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = MR_sv(1);
	MR_tfield(1, MR_tempr1, 1) = MR_r2;
	MR_r4 = MR_sv(6);
	MR_r3 = MR_sv(3);
	MR_r2 = MR_sv(5);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, func_id);
	MR_GOTO_LAB(analysis__file__parse_imdg_arc_4_0_i48);
	}
MR_def_label(analysis__file__parse_imdg_arc_4_0,41)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_r5 = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = MR_sv(1);
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_r4 = MR_sv(6);
	MR_r3 = MR_sv(3);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,7);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, func_id);
	}
MR_def_label(analysis__file__parse_imdg_arc_4_0,48)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	MR_np_call_localret_ent(map__set_4_0,
		analysis__file__parse_imdg_arc_4_0_i49);
MR_def_label(analysis__file__parse_imdg_arc_4_0,49)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 3);
	MR_tfield(0, MR_r2, 0) = (MR_Word) MR_CTOR_ADDR(tree234, tree234, 2);
	MR_tfield(0, MR_r2, 1) = (MR_Word) MR_CTOR0_ADDR(analysis, func_id);
	MR_tfield(0, MR_r2, 2) = MR_sv(1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r3 = MR_sv(2);
	MR_r4 = MR_sv(4);
	MR_r5 = MR_tempr1;
	MR_succip_word = MR_sv(9);
	MR_decr_sp(9);
	MR_np_tailcall_ent(map__set_4_0);
	}
MR_def_label(analysis__file__parse_imdg_arc_4_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_decr_sp_and_return(9);
MR_def_label(analysis__file__parse_imdg_arc_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_sv(1);
MR_def_label(analysis__file__parse_imdg_arc_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,8);
	MR_r2 = MR_r3;
	MR_np_call_localret_ent(fn__string__string_1_0,
		analysis__file__parse_imdg_arc_4_0_i54);
MR_def_label(analysis__file__parse_imdg_arc_4_0,54)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("failed to parse IMDG arc: ", 26);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		analysis__file__parse_imdg_arc_4_0_i55);
MR_def_label(analysis__file__parse_imdg_arc_4_0,55)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis__file, invalid_analysis_file);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(9);
	MR_decr_sp(9);
	MR_np_tailcall_ent(exception__throw_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(io__write_char_3_0);
MR_decl_entry(term_io__quote_atom_3_0);
MR_decl_entry(fn__hlds__hlds_pred__proc_id_to_int_1_0);
MR_decl_entry(fn__varset__init_0_0);
MR_decl_entry(term_io__write_term_4_0);

MR_BEGIN_MODULE(analysis__file_module21)
	MR_init_entry1(analysis__file__write_result_entry_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__write_result_entry_5_0);
	MR_init_label10(analysis__file__write_result_entry_5_0,2,4,5,6,7,8,9,11,13,14)
	MR_init_label10(analysis__file__write_result_entry_5_0,15,16,17,18,19,20,21,22,23,24)
	MR_init_label10(analysis__file__write_result_entry_5_0,25,26,27,28,29,30,31,32,33,34)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'write_result_entry'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__write_result_entry_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(8);
	MR_sv(8) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_sv(3) = MR_tfield(0, MR_tempr1, 1);
	MR_sv(4) = MR_tfield(0, MR_tempr1, 2);
	MR_sv(5) = MR_tfield(0, MR_tempr1, 3);
	MR_sv(6) = MR_tfield(0, MR_tempr1, 0);
	MR_r1 = MR_sv(6);
	MR_r2 = (MR_Integer) 2;
	}
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__write_result_entry_5_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_0),
		mercury__analysis__file__write_result_entry_5_0_i2);
MR_def_label(analysis__file__write_result_entry_5_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(5),0)) {
		MR_GOTO_LAB(analysis__file__write_result_entry_5_0_i4);
	}
	MR_r1 = MR_sv(1);
	MR_sv(1) = MR_r3;
	MR_sv(5) = (MR_Word) MR_string_const("invalid", 7);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_result_entry_5_0_i6);
MR_def_label(analysis__file__write_result_entry_5_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(5),2)) {
		MR_GOTO_LAB(analysis__file__write_result_entry_5_0_i5);
	}
	MR_r1 = MR_sv(1);
	MR_sv(1) = MR_r3;
	MR_sv(5) = (MR_Word) MR_string_const("optimal", 7);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_result_entry_5_0_i6);
MR_def_label(analysis__file__write_result_entry_5_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_sv(1) = MR_r3;
	MR_sv(5) = (MR_Word) MR_string_const("suboptimal", 10);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_result_entry_5_0_i6);
MR_def_label(analysis__file__write_result_entry_5_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 40;
	MR_np_call_localret_ent(io__write_char_3_0,
		analysis__file__write_result_entry_5_0_i7);
MR_def_label(analysis__file__write_result_entry_5_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(io__write_int_3_0,
		analysis__file__write_result_entry_5_0_i8);
MR_def_label(analysis__file__write_result_entry_5_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_result_entry_5_0_i9);
MR_def_label(analysis__file__write_result_entry_5_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_sv(2);
	MR_tempr1 = MR_tfield(0, MR_tempr2, 0);
	if (MR_INT_NE(MR_tempr1,1)) {
		MR_GOTO_LAB(analysis__file__write_result_entry_5_0_i11);
	}
	MR_sv(1) = MR_tfield(0, MR_tempr2, 1);
	MR_tempr1 = MR_tempr2;
	MR_sv(2) = MR_tfield(0, MR_tempr1, 2);
	MR_sv(7) = MR_tfield(0, MR_tempr1, 3);
	MR_r1 = (MR_Word) MR_string_const("f(", 2);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_result_entry_5_0_i13);
MR_def_label(analysis__file__write_result_entry_5_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_sv(2);
	MR_sv(1) = MR_tfield(0, MR_tempr2, 1);
	MR_tempr1 = MR_tempr2;
	MR_sv(2) = MR_tfield(0, MR_tempr1, 2);
	MR_sv(7) = MR_tfield(0, MR_tempr1, 3);
	MR_r1 = (MR_Word) MR_string_const("p(", 2);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_result_entry_5_0_i13);
MR_def_label(analysis__file__write_result_entry_5_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(term_io__quote_atom_3_0,
		analysis__file__write_result_entry_5_0_i14);
MR_def_label(analysis__file__write_result_entry_5_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_result_entry_5_0_i15);
MR_def_label(analysis__file__write_result_entry_5_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(io__write_int_3_0,
		analysis__file__write_result_entry_5_0_i16);
MR_def_label(analysis__file__write_result_entry_5_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_result_entry_5_0_i17);
MR_def_label(analysis__file__write_result_entry_5_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(7);
	MR_np_call_localret_ent(fn__hlds__hlds_pred__proc_id_to_int_1_0,
		analysis__file__write_result_entry_5_0_i18);
MR_def_label(analysis__file__write_result_entry_5_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_int_3_0,
		analysis__file__write_result_entry_5_0_i19);
MR_def_label(analysis__file__write_result_entry_5_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 41;
	MR_np_call_localret_ent(io__write_char_3_0,
		analysis__file__write_result_entry_5_0_i20);
MR_def_label(analysis__file__write_result_entry_5_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_result_entry_5_0_i21);
MR_def_label(analysis__file__write_result_entry_5_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(fn__varset__init_0_0,
		analysis__file__write_result_entry_5_0_i22);
MR_def_label(analysis__file__write_result_entry_5_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = (MR_Integer) 1;
	MR_np_call_localret_ent(private_builtin__superclass_from_typeclass_info_3_0,
		analysis__file__write_result_entry_5_0_i23);
MR_def_label(analysis__file__write_result_entry_5_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Integer) 2;
	MR_np_call_localret_ent(private_builtin__superclass_from_typeclass_info_3_0,
		analysis__file__write_result_entry_5_0_i24);
MR_def_label(analysis__file__write_result_entry_5_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_sv(3);
	MR_r2 = (MR_Integer) 1;
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__write_result_entry_5_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_1),
		mercury__analysis__file__write_result_entry_5_0_i25);
MR_def_label(analysis__file__write_result_entry_5_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(1);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(term_io__write_term_4_0,
		analysis__file__write_result_entry_5_0_i26);
MR_def_label(analysis__file__write_result_entry_5_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_result_entry_5_0_i27);
MR_def_label(analysis__file__write_result_entry_5_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(fn__varset__init_0_0,
		analysis__file__write_result_entry_5_0_i28);
MR_def_label(analysis__file__write_result_entry_5_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = (MR_Integer) 2;
	MR_np_call_localret_ent(private_builtin__superclass_from_typeclass_info_3_0,
		analysis__file__write_result_entry_5_0_i29);
MR_def_label(analysis__file__write_result_entry_5_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Integer) 2;
	MR_np_call_localret_ent(private_builtin__superclass_from_typeclass_info_3_0,
		analysis__file__write_result_entry_5_0_i30);
MR_def_label(analysis__file__write_result_entry_5_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_sv(4);
	MR_r2 = (MR_Integer) 1;
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__write_result_entry_5_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_1),
		mercury__analysis__file__write_result_entry_5_0_i31);
MR_def_label(analysis__file__write_result_entry_5_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(1);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(term_io__write_term_4_0,
		analysis__file__write_result_entry_5_0_i32);
MR_def_label(analysis__file__write_result_entry_5_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_result_entry_5_0_i33);
MR_def_label(analysis__file__write_result_entry_5_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(5);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_result_entry_5_0_i34);
MR_def_label(analysis__file__write_result_entry_5_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(").\n", 3);
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_np_tailcall_ent(io__write_string_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(parse_tree__prog_out__write_quoted_sym_name_3_0);

MR_BEGIN_MODULE(analysis__file_module22)
	MR_init_entry1(analysis__file__write_request_entry_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__write_request_entry_6_0);
	MR_init_label10(analysis__file__write_request_entry_6_0,3,5,2,6,8,9,10,11,12,13)
	MR_init_label10(analysis__file__write_request_entry_6_0,14,16,18,19,20,21,22,23,24,25)
	MR_init_label5(analysis__file__write_request_entry_6_0,26,27,28,29,30)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'write_request_entry'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__write_request_entry_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r5;
	MR_sv(5) = MR_tfield(0, MR_tempr1, 0);
	MR_sv(4) = MR_tfield(0, MR_tempr1, 2);
	MR_sv(3) = MR_tfield(0, MR_tempr1, 1);
	MR_sv(1) = MR_r3;
	MR_sv(2) = MR_r4;
	MR_r3 = MR_r2;
	MR_r4 = MR_sv(1);
	MR_r2 = (MR_Integer) 2;
	}
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__write_request_entry_6_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_2),
		mercury__analysis__file__write_request_entry_6_0_i3);
MR_def_label(analysis__file__write_request_entry_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__write_request_entry_6_0_i2);
	}
	MR_r1 = MR_tfield(0, MR_r2, 0);
	MR_r2 = (MR_Integer) 2;
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__write_request_entry_6_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_0),
		mercury__analysis__file__write_request_entry_6_0_i5);
MR_def_label(analysis__file__write_request_entry_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_sv(4) = MR_r3;
	MR_np_call_localret_ent(parse_tree__prog_out__write_quoted_sym_name_3_0,
		analysis__file__write_request_entry_6_0_i9);
MR_def_label(analysis__file__write_request_entry_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__analysis__this_file_0_0,
		analysis__file__write_request_entry_6_0_i6);
MR_def_label(analysis__file__write_request_entry_6_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_string_const("write_request_entry: unknown analysis type", 42);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		analysis__file__write_request_entry_6_0_i8);
MR_def_label(analysis__file__write_request_entry_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(parse_tree__prog_out__write_quoted_sym_name_3_0,
		analysis__file__write_request_entry_6_0_i9);
MR_def_label(analysis__file__write_request_entry_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(" -> ", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_request_entry_6_0_i10);
MR_def_label(analysis__file__write_request_entry_6_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_request_entry_6_0_i11);
MR_def_label(analysis__file__write_request_entry_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("(", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_request_entry_6_0_i12);
MR_def_label(analysis__file__write_request_entry_6_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(io__write_int_3_0,
		analysis__file__write_request_entry_6_0_i13);
MR_def_label(analysis__file__write_request_entry_6_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_request_entry_6_0_i14);
MR_def_label(analysis__file__write_request_entry_6_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_sv(2);
	MR_tempr1 = MR_tfield(0, MR_tempr2, 0);
	if (MR_INT_NE(MR_tempr1,1)) {
		MR_GOTO_LAB(analysis__file__write_request_entry_6_0_i16);
	}
	MR_sv(1) = MR_tfield(0, MR_tempr2, 1);
	MR_tempr1 = MR_tempr2;
	MR_sv(2) = MR_tfield(0, MR_tempr1, 2);
	MR_sv(4) = MR_tfield(0, MR_tempr1, 3);
	MR_r1 = (MR_Word) MR_string_const("f(", 2);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_request_entry_6_0_i18);
MR_def_label(analysis__file__write_request_entry_6_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_sv(2);
	MR_sv(1) = MR_tfield(0, MR_tempr2, 1);
	MR_tempr1 = MR_tempr2;
	MR_sv(2) = MR_tfield(0, MR_tempr1, 2);
	MR_sv(4) = MR_tfield(0, MR_tempr1, 3);
	MR_r1 = (MR_Word) MR_string_const("p(", 2);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_request_entry_6_0_i18);
MR_def_label(analysis__file__write_request_entry_6_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(term_io__quote_atom_3_0,
		analysis__file__write_request_entry_6_0_i19);
MR_def_label(analysis__file__write_request_entry_6_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_request_entry_6_0_i20);
MR_def_label(analysis__file__write_request_entry_6_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(io__write_int_3_0,
		analysis__file__write_request_entry_6_0_i21);
MR_def_label(analysis__file__write_request_entry_6_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_request_entry_6_0_i22);
MR_def_label(analysis__file__write_request_entry_6_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(fn__hlds__hlds_pred__proc_id_to_int_1_0,
		analysis__file__write_request_entry_6_0_i23);
MR_def_label(analysis__file__write_request_entry_6_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_int_3_0,
		analysis__file__write_request_entry_6_0_i24);
MR_def_label(analysis__file__write_request_entry_6_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 41;
	MR_np_call_localret_ent(io__write_char_3_0,
		analysis__file__write_request_entry_6_0_i25);
MR_def_label(analysis__file__write_request_entry_6_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_request_entry_6_0_i26);
MR_def_label(analysis__file__write_request_entry_6_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(fn__varset__init_0_0,
		analysis__file__write_request_entry_6_0_i27);
MR_def_label(analysis__file__write_request_entry_6_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = (MR_Integer) 2;
	MR_np_call_localret_ent(private_builtin__superclass_from_typeclass_info_3_0,
		analysis__file__write_request_entry_6_0_i28);
MR_def_label(analysis__file__write_request_entry_6_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_sv(3);
	MR_r2 = (MR_Integer) 1;
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__write_request_entry_6_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_1),
		mercury__analysis__file__write_request_entry_6_0_i29);
MR_def_label(analysis__file__write_request_entry_6_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(1);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(term_io__write_term_4_0,
		analysis__file__write_request_entry_6_0_i30);
MR_def_label(analysis__file__write_request_entry_6_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(").\n", 3);
	MR_succip_word = MR_sv(6);
	MR_decr_sp(6);
	MR_np_tailcall_ent(io__write_string_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module23)
	MR_init_entry1(analysis__file__write_imdg_arc_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__write_imdg_arc_6_0);
	MR_init_label10(analysis__file__write_imdg_arc_6_0,3,5,2,6,8,9,10,11,12,13)
	MR_init_label10(analysis__file__write_imdg_arc_6_0,14,16,18,19,20,21,22,23,24,25)
	MR_init_label5(analysis__file__write_imdg_arc_6_0,26,27,28,29,30)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'write_imdg_arc'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__write_imdg_arc_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r5;
	MR_sv(5) = MR_tfield(0, MR_tempr1, 0);
	MR_sv(4) = MR_tfield(0, MR_tempr1, 2);
	MR_sv(3) = MR_tfield(0, MR_tempr1, 1);
	MR_sv(1) = MR_r3;
	MR_sv(2) = MR_r4;
	MR_r3 = MR_r2;
	MR_r4 = MR_sv(1);
	MR_r2 = (MR_Integer) 2;
	}
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__write_imdg_arc_6_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_2),
		mercury__analysis__file__write_imdg_arc_6_0_i3);
MR_def_label(analysis__file__write_imdg_arc_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(analysis__file__write_imdg_arc_6_0_i2);
	}
	MR_r1 = MR_tfield(0, MR_r2, 0);
	MR_r2 = (MR_Integer) 2;
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__write_imdg_arc_6_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_0),
		mercury__analysis__file__write_imdg_arc_6_0_i5);
MR_def_label(analysis__file__write_imdg_arc_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_sv(4) = MR_r3;
	MR_np_call_localret_ent(parse_tree__prog_out__write_quoted_sym_name_3_0,
		analysis__file__write_imdg_arc_6_0_i9);
MR_def_label(analysis__file__write_imdg_arc_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__analysis__this_file_0_0,
		analysis__file__write_imdg_arc_6_0_i6);
MR_def_label(analysis__file__write_imdg_arc_6_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_string_const("write_imdg_arc: unknown analysis type", 37);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		analysis__file__write_imdg_arc_6_0_i8);
MR_def_label(analysis__file__write_imdg_arc_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(parse_tree__prog_out__write_quoted_sym_name_3_0,
		analysis__file__write_imdg_arc_6_0_i9);
MR_def_label(analysis__file__write_imdg_arc_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(" -> ", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_imdg_arc_6_0_i10);
MR_def_label(analysis__file__write_imdg_arc_6_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_imdg_arc_6_0_i11);
MR_def_label(analysis__file__write_imdg_arc_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 40;
	MR_np_call_localret_ent(io__write_char_3_0,
		analysis__file__write_imdg_arc_6_0_i12);
MR_def_label(analysis__file__write_imdg_arc_6_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(io__write_int_3_0,
		analysis__file__write_imdg_arc_6_0_i13);
MR_def_label(analysis__file__write_imdg_arc_6_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_imdg_arc_6_0_i14);
MR_def_label(analysis__file__write_imdg_arc_6_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_sv(2);
	MR_tempr1 = MR_tfield(0, MR_tempr2, 0);
	if (MR_INT_NE(MR_tempr1,1)) {
		MR_GOTO_LAB(analysis__file__write_imdg_arc_6_0_i16);
	}
	MR_sv(1) = MR_tfield(0, MR_tempr2, 1);
	MR_tempr1 = MR_tempr2;
	MR_sv(2) = MR_tfield(0, MR_tempr1, 2);
	MR_sv(4) = MR_tfield(0, MR_tempr1, 3);
	MR_r1 = (MR_Word) MR_string_const("f(", 2);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_imdg_arc_6_0_i18);
MR_def_label(analysis__file__write_imdg_arc_6_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_sv(2);
	MR_sv(1) = MR_tfield(0, MR_tempr2, 1);
	MR_tempr1 = MR_tempr2;
	MR_sv(2) = MR_tfield(0, MR_tempr1, 2);
	MR_sv(4) = MR_tfield(0, MR_tempr1, 3);
	MR_r1 = (MR_Word) MR_string_const("p(", 2);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_imdg_arc_6_0_i18);
MR_def_label(analysis__file__write_imdg_arc_6_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(term_io__quote_atom_3_0,
		analysis__file__write_imdg_arc_6_0_i19);
MR_def_label(analysis__file__write_imdg_arc_6_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_imdg_arc_6_0_i20);
MR_def_label(analysis__file__write_imdg_arc_6_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(io__write_int_3_0,
		analysis__file__write_imdg_arc_6_0_i21);
MR_def_label(analysis__file__write_imdg_arc_6_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_imdg_arc_6_0_i22);
MR_def_label(analysis__file__write_imdg_arc_6_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(fn__hlds__hlds_pred__proc_id_to_int_1_0,
		analysis__file__write_imdg_arc_6_0_i23);
MR_def_label(analysis__file__write_imdg_arc_6_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_int_3_0,
		analysis__file__write_imdg_arc_6_0_i24);
MR_def_label(analysis__file__write_imdg_arc_6_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 41;
	MR_np_call_localret_ent(io__write_char_3_0,
		analysis__file__write_imdg_arc_6_0_i25);
MR_def_label(analysis__file__write_imdg_arc_6_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__write_imdg_arc_6_0_i26);
MR_def_label(analysis__file__write_imdg_arc_6_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(fn__varset__init_0_0,
		analysis__file__write_imdg_arc_6_0_i27);
MR_def_label(analysis__file__write_imdg_arc_6_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = (MR_Integer) 2;
	MR_np_call_localret_ent(private_builtin__superclass_from_typeclass_info_3_0,
		analysis__file__write_imdg_arc_6_0_i28);
MR_def_label(analysis__file__write_imdg_arc_6_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_sv(3);
	MR_r2 = (MR_Integer) 1;
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__write_imdg_arc_6_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_1),
		mercury__analysis__file__write_imdg_arc_6_0_i29);
MR_def_label(analysis__file__write_imdg_arc_6_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(1);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(term_io__write_term_4_0,
		analysis__file__write_imdg_arc_6_0_i30);
MR_def_label(analysis__file__write_imdg_arc_6_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(").\n", 3);
	MR_succip_word = MR_sv(6);
	MR_decr_sp(6);
	MR_np_tailcall_ent(io__write_string_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module24)
	MR_init_entry1(analysis__file__write_analysis_file_3_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__write_analysis_file_3_5_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'write_analysis_file_3'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__write_analysis_file_3_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 6);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(17,0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__write_analysis_file_4_6_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 3;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_tfield(0, MR_tempr1, 4) = MR_r2;
	MR_tfield(0, MR_tempr1, 5) = MR_r3;
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = (MR_Word) MR_LIST_CTOR_ADDR;
	MR_tfield(0, MR_r2, 1) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, func_id);
	MR_r3 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_tempr2 = MR_r4;
	MR_r4 = MR_tempr1;
	MR_r5 = MR_tempr2;
	MR_np_tailcall_ent(map__foldl_4_2);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(list__sort_2_0);
MR_decl_entry(list__foldl_4_2);

MR_BEGIN_MODULE(analysis__file_module25)
	MR_init_entry1(analysis__file__write_analysis_file_4_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__write_analysis_file_4_6_0);
	MR_init_label1(analysis__file__write_analysis_file_4_6_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'write_analysis_file_4'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__write_analysis_file_4_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_r4;
	MR_sv(4) = MR_r1;
	MR_r2 = MR_r5;
	MR_np_call_localret_ent(list__sort_2_0,
		analysis__file__write_analysis_file_4_6_0_i2);
MR_def_label(analysis__file__write_analysis_file_4_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 7);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(18,0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(analysis__file__IntroducedFrom__pred__write_analysis_file_4__904__1_7_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 4;
	MR_tempr3 = MR_sv(4);
	MR_tfield(0, MR_tempr1, 3) = MR_tempr3;
	MR_tfield(0, MR_tempr1, 4) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 5) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 6) = MR_sv(3);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr3;
	MR_r2 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r4 = MR_tempr2;
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(list__foldl_4_2);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(dir__is_directory_separator_1_0);

MR_BEGIN_MODULE(analysis__file_module26)
	MR_init_entry1(analysis__file__dir_sep_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__dir_sep_1_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'dir_sep'/1 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__dir_sep_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(dir__is_directory_separator_1_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(univ__det_univ_to_type_2_0);
MR_decl_entry(private_builtin__type_info_from_typeclass_info_3_0);
extern const MR_TypeCtorInfo_Struct mercury_data_analysis__type_ctor_info_analysis_status_0;

MR_BEGIN_MODULE(analysis__file_module27)
	MR_init_entry1(analysis__file__pickle_analysis_result_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__pickle_analysis_result_4_0);
	MR_init_label7(analysis__file__pickle_analysis_result_4_0,2,3,4,5,6,7,8)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'pickle_analysis_result'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__pickle_analysis_result_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, some_analysis_result);
	MR_np_call_localret_ent(univ__det_univ_to_type_2_0,
		analysis__file__pickle_analysis_result_4_0_i2);
MR_def_label(analysis__file__pickle_analysis_result_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_tfield(0, MR_r1, 1);
	MR_sv(3) = MR_tfield(0, MR_r1, 2);
	MR_sv(4) = MR_tfield(0, MR_r1, 3);
	MR_sv(5) = MR_tfield(0, MR_r1, 0);
	MR_r1 = MR_sv(5);
	MR_r2 = (MR_Integer) 1;
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__pickle_analysis_result_4_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_0),
		mercury__analysis__file__pickle_analysis_result_4_0_i3);
MR_def_label(analysis__file__pickle_analysis_result_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(libs__pickle__pickle_4_0,
		analysis__file__pickle_analysis_result_4_0_i4);
MR_def_label(analysis__file__pickle_analysis_result_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(5);
	MR_r2 = (MR_Integer) 4;
	MR_np_call_localret_ent(private_builtin__type_info_from_typeclass_info_3_0,
		analysis__file__pickle_analysis_result_4_0_i5);
MR_def_label(analysis__file__pickle_analysis_result_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_r3 = MR_sv(2);
	MR_np_call_localret_ent(libs__pickle__pickle_4_0,
		analysis__file__pickle_analysis_result_4_0_i6);
MR_def_label(analysis__file__pickle_analysis_result_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(5);
	MR_r2 = (MR_Integer) 5;
	MR_np_call_localret_ent(private_builtin__type_info_from_typeclass_info_3_0,
		analysis__file__pickle_analysis_result_4_0_i7);
MR_def_label(analysis__file__pickle_analysis_result_4_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_r3 = MR_sv(3);
	MR_np_call_localret_ent(libs__pickle__pickle_4_0,
		analysis__file__pickle_analysis_result_4_0_i8);
MR_def_label(analysis__file__pickle_analysis_result_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, analysis_status);
	MR_r2 = MR_sv(1);
	MR_r3 = MR_sv(4);
	MR_succip_word = MR_sv(6);
	MR_decr_sp(6);
	MR_np_tailcall_ent(libs__pickle__pickle_4_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module28)
	MR_init_entry1(analysis__file__unpickle_analysis_result_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__unpickle_analysis_result_7_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'unpickle_analysis_result'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__unpickle_analysis_result_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r5 = MR_r6;
	MR_np_tailcall_ent(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module29)
	MR_init_entry1(__Unify___analysis__file__dummy_answer_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___analysis__file__dummy_answer_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Unify___analysis__file__dummy_answer_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_85_110_105_102_121_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_48_95_95_91_49_44_32_50_93_95_48_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module30)
	MR_init_entry1(__Compare___analysis__file__dummy_answer_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___analysis__file__dummy_answer_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Compare___analysis__file__dummy_answer_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_67_111_109_112_97_114_101_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_48_95_95_91_50_44_32_51_93_95_48_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module31)
	MR_init_entry1(__Unify___analysis__file__invalid_analysis_file_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___analysis__file__invalid_analysis_file_0_0);
	MR_init_label1(__Unify___analysis__file__invalid_analysis_file_0_0,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Unify___analysis__file__invalid_analysis_file_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Unify___analysis__file__invalid_analysis_file_0_0_i4);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = (strcmp((char *) (MR_Word *) MR_sv(1), (char *) (MR_Word *) MR_sv(2)) == 0);
	MR_decr_sp(2);
	MR_proceed();
MR_def_label(__Unify___analysis__file__invalid_analysis_file_0_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp(2);
	MR_r1 = MR_TRUE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(private_builtin__builtin_compare_string_3_0);

MR_BEGIN_MODULE(analysis__file_module32)
	MR_init_entry1(__Compare___analysis__file__invalid_analysis_file_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___analysis__file__invalid_analysis_file_0_0);
	MR_init_label2(__Compare___analysis__file__invalid_analysis_file_0_0,3,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Compare___analysis__file__invalid_analysis_file_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Compare___analysis__file__invalid_analysis_file_0_0_i3);
	}
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_GOTO_LAB(__Compare___analysis__file__invalid_analysis_file_0_0_i2);
MR_def_label(__Compare___analysis__file__invalid_analysis_file_0_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_def_label(__Compare___analysis__file__invalid_analysis_file_0_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(private_builtin__builtin_compare_string_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module33)
	MR_init_entry1(__Unify___analysis__file__parse_entry_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___analysis__file__parse_entry_1_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Unify___analysis__file__parse_entry_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_np_tailcall_ent(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_85_110_105_102_121_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_112_97_114_115_101_95_101_110_116_114_121_95_49_95_95_91_49_93_95_48_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module34)
	MR_init_entry1(__Compare___analysis__file__parse_entry_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___analysis__file__parse_entry_1_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Compare___analysis__file__parse_entry_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_np_tailcall_ent(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_67_111_109_112_97_114_101_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_112_97_114_115_101_95_101_110_116_114_121_95_49_95_95_91_49_93_95_48_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module35)
	MR_init_entry1(__Unify___analysis__file__write_entry_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___analysis__file__write_entry_1_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Unify___analysis__file__write_entry_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_np_tailcall_ent(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_85_110_105_102_121_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_119_114_105_116_101_95_101_110_116_114_121_95_49_95_95_91_49_93_95_48_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module36)
	MR_init_entry1(__Compare___analysis__file__write_entry_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___analysis__file__write_entry_1_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Compare___analysis__file__write_entry_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_np_tailcall_ent(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_67_111_109_112_97_114_101_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_119_114_105_116_101_95_101_110_116_114_121_95_49_95_95_91_49_93_95_48_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module37)
	MR_init_entry1(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_name_2_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_name_2_2_0);
	MR_init_label1(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_name_2_2_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_name_2'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_name_2_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(1);
	MR_sv(1) = (MR_Word) MR_succip;
	MR_np_call_localret_ent(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_110_97_109_101_95_50_95_95_91_49_44_32_50_93_95_48_2_0,
		fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_name_2_2_0_i2);
MR_def_label(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_name_2_2_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_r1;
	MR_decr_sp_and_return(1);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module38)
	MR_init_entry1(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_version_number_2_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_version_number_2_2_0);
	MR_init_label1(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_version_number_2_2_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_version_number_2'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_version_number_2_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(1);
	MR_sv(1) = (MR_Word) MR_succip;
	MR_np_call_localret_ent(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_118_101_114_115_105_111_110_95_110_117_109_98_101_114_95_50_95_95_91_49_44_32_50_93_95_48_2_0,
		fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_version_number_2_2_0_i2);
MR_def_label(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_version_number_2_2_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_r1;
	MR_decr_sp_and_return(1);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module39)
	MR_init_entry1(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__preferred_fixpoint_type_2_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__preferred_fixpoint_type_2_2_0);
	MR_init_label1(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__preferred_fixpoint_type_2_2_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__preferred_fixpoint_type_2'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__preferred_fixpoint_type_2_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(1);
	MR_sv(1) = (MR_Word) MR_succip;
	MR_np_call_localret_ent(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_112_114_101_102_101_114_114_101_100_95_102_105_120_112_111_105_110_116_95_116_121_112_101_95_50_95_95_91_49_44_32_50_93_95_48_2_0,
		fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__preferred_fixpoint_type_2_2_0_i2);
MR_def_label(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__preferred_fixpoint_type_2_2_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_r1;
	MR_decr_sp_and_return(1);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module40)
	MR_init_entry1(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__bottom_2_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__bottom_2_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__bottom_2'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__bottom_2_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_98_111_116_116_111_109_95_50_95_95_91_49_44_32_50_93_95_48_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module41)
	MR_init_entry1(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__top_2_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__top_2_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__top_2'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__top_2_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_116_111_112_95_50_95_95_91_49_44_32_50_93_95_48_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module42)
	MR_init_entry1(analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__get_func_info_6_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__get_func_info_6_6_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__get_func_info_6'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__get_func_info_6_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_103_101_116_95_102_117_110_99_95_105_110_102_111_95_54_95_95_91_49_44_32_50_44_32_51_44_32_52_44_32_53_93_95_48_6_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module43)
	MR_init_entry1(analysis__file__ClassMethod_for_analysis__partial_order____analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0______analysis__more_precise_than_3_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__ClassMethod_for_analysis__partial_order____analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0______analysis__more_precise_than_3_3_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'ClassMethod_for_analysis__partial_order____analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0______analysis__more_precise_than_3'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__ClassMethod_for_analysis__partial_order____analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0______analysis__more_precise_than_3_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_112_97_114_116_105_97_108_95_111_114_100_101_114_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_109_111_114_101_95_112_114_101_99_105_115_101_95_116_104_97_110_95_51_95_95_91_49_44_32_50_44_32_51_93_95_48_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module44)
	MR_init_entry1(analysis__file__ClassMethod_for_analysis__partial_order____analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0______analysis__equivalent_3_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__ClassMethod_for_analysis__partial_order____analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0______analysis__equivalent_3_3_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'ClassMethod_for_analysis__partial_order____analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0______analysis__equivalent_3'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__ClassMethod_for_analysis__partial_order____analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0______analysis__equivalent_3_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_112_97_114_116_105_97_108_95_111_114_100_101_114_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_101_113_117_105_118_97_108_101_110_116_95_51_95_95_91_49_44_32_50_44_32_51_93_95_48_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module45)
	MR_init_entry1(fn__analysis__file__ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__to_term_1_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__analysis__file__ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__to_term_1_1_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__to_term_1'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__analysis__file__ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__to_term_1_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_116_111_95_116_101_114_109_95_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_116_111_95_116_101_114_109_95_49_95_95_91_49_93_95_48_1_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module46)
	MR_init_entry1(analysis__file__ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__from_term_2_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__from_term_2_2_0);
	MR_init_label1(analysis__file__ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__from_term_2_2_0,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__from_term_2'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__from_term_2_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(analysis__file__ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__from_term_2_2_0_i1);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_tfield(0, MR_r1, 1);
	if (MR_LTAGS_TESTR(MR_tempr1,0,0)) {
		MR_GOTO_LAB(analysis__file__ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__from_term_2_2_0_i1);
	}
	MR_tempr1 = MR_tfield(0, MR_r1, 0);
	if (MR_PTAG_TESTR(MR_tempr1,0)) {
		MR_GOTO_LAB(analysis__file__ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__from_term_2_2_0_i1);
	}
	MR_tempr2 = MR_tfield(0, MR_tempr1, 0);
	if ((strcmp((char *) (MR_Word *) MR_tempr2, MR_string_const("dummy", 5)) != 0)) {
		MR_GOTO_LAB(analysis__file__ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__from_term_2_2_0_i1);
	}
	MR_r1 = MR_TRUE;
	MR_proceed();
	}
MR_def_label(analysis__file__ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__from_term_2_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_mdbcomp__prim_data__type_ctor_info_sym_name_0;
MR_decl_entry(io__write_3_0);

MR_BEGIN_MODULE(analysis__file_module47)
	MR_init_entry1(analysis__file__IntroducedFrom__pred__write_module_analysis_results__664__1_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__IntroducedFrom__pred__write_module_analysis_results__664__1_3_0);
	MR_init_label2(analysis__file__IntroducedFrom__pred__write_module_analysis_results__664__1_3_0,2,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__write_module_analysis_results__664__1'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__IntroducedFrom__pred__write_module_analysis_results__664__1_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("% Writing module analysis results for ", 38);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__IntroducedFrom__pred__write_module_analysis_results__664__1_3_0_i2);
MR_def_label(analysis__file__IntroducedFrom__pred__write_module_analysis_results__664__1_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(io__write_3_0,
		analysis__file__IntroducedFrom__pred__write_module_analysis_results__664__1_3_0_i3);
MR_def_label(analysis__file__IntroducedFrom__pred__write_module_analysis_results__664__1_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__nl_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module48)
	MR_init_entry1(analysis__file__IntroducedFrom__pred__write_module_analysis_requests__716__1_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__IntroducedFrom__pred__write_module_analysis_requests__716__1_3_0);
	MR_init_label2(analysis__file__IntroducedFrom__pred__write_module_analysis_requests__716__1_3_0,2,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__write_module_analysis_requests__716__1'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__IntroducedFrom__pred__write_module_analysis_requests__716__1_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("% Writing module analysis requests to ", 38);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__IntroducedFrom__pred__write_module_analysis_requests__716__1_3_0_i2);
MR_def_label(analysis__file__IntroducedFrom__pred__write_module_analysis_requests__716__1_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__IntroducedFrom__pred__write_module_analysis_requests__716__1_3_0_i3);
MR_def_label(analysis__file__IntroducedFrom__pred__write_module_analysis_requests__716__1_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__nl_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module49)
	MR_init_entry1(analysis__file__IntroducedFrom__pred__empty_request_file__913__1_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__IntroducedFrom__pred__empty_request_file__913__1_3_0);
	MR_init_label2(analysis__file__IntroducedFrom__pred__empty_request_file__913__1_3_0,2,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__empty_request_file__913__1'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__IntroducedFrom__pred__empty_request_file__913__1_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("% Removing request file ", 24);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__IntroducedFrom__pred__empty_request_file__913__1_3_0_i2);
MR_def_label(analysis__file__IntroducedFrom__pred__empty_request_file__913__1_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__IntroducedFrom__pred__empty_request_file__913__1_3_0_i3);
MR_def_label(analysis__file__IntroducedFrom__pred__empty_request_file__913__1_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__nl_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module50)
	MR_init_entry1(analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__349__1_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__349__1_3_0);
	MR_init_label2(analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__349__1_3_0,2,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__read_module_analysis_results_2__349__1'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__349__1_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("% Error reading analysis registry file: ", 40);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__349__1_3_0_i2);
MR_def_label(analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__349__1_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__349__1_3_0_i3);
MR_def_label(analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__349__1_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__nl_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module51)
	MR_init_entry1(analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__327__1_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__327__1_3_0);
	MR_init_label2(analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__327__1_3_0,2,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__read_module_analysis_results_2__327__1'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__327__1_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("% Reading analysis registry file ", 33);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__327__1_3_0_i2);
MR_def_label(analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__327__1_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__327__1_3_0_i3);
MR_def_label(analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__327__1_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__nl_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module52)
	MR_init_entry1(analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__336__1_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__336__1_5_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__read_module_analysis_results_2__336__1'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__IntroducedFrom__pred__read_module_analysis_results_2__336__1_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_np_tailcall_ent(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_114_101_97_100_95_97_110_97_108_121_115_105_115_95_102_105_108_101_95_50_95_95_91_49_93_95_48_5_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module53)
	MR_init_entry1(analysis__file__IntroducedFrom__pred__read_analysis_file__547__1_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__IntroducedFrom__pred__read_analysis_file__547__1_5_0);
	MR_init_label6(analysis__file__IntroducedFrom__pred__read_analysis_file__547__1_5_0,2,3,4,5,6,7)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__read_analysis_file__547__1'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__IntroducedFrom__pred__read_analysis_file__547__1_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_r1 = (MR_Word) MR_string_const("Couldn\'t open ", 14);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__IntroducedFrom__pred__read_analysis_file__547__1_5_0_i2);
MR_def_label(analysis__file__IntroducedFrom__pred__read_analysis_file__547__1_5_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__IntroducedFrom__pred__read_analysis_file__547__1_5_0_i3);
MR_def_label(analysis__file__IntroducedFrom__pred__read_analysis_file__547__1_5_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(" for module ", 12);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__IntroducedFrom__pred__read_analysis_file__547__1_5_0_i4);
MR_def_label(analysis__file__IntroducedFrom__pred__read_analysis_file__547__1_5_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(io__write_3_0,
		analysis__file__IntroducedFrom__pred__read_analysis_file__547__1_5_0_i5);
MR_def_label(analysis__file__IntroducedFrom__pred__read_analysis_file__547__1_5_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(": ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__IntroducedFrom__pred__read_analysis_file__547__1_5_0_i6);
MR_def_label(analysis__file__IntroducedFrom__pred__read_analysis_file__547__1_5_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__IntroducedFrom__pred__read_analysis_file__547__1_5_0_i7);
MR_def_label(analysis__file__IntroducedFrom__pred__read_analysis_file__547__1_5_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(io__nl_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module54)
	MR_init_entry1(analysis__file__IntroducedFrom__pred__read_analysis_file__592__1_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__IntroducedFrom__pred__read_analysis_file__592__1_3_0);
	MR_init_label2(analysis__file__IntroducedFrom__pred__read_analysis_file__592__1_3_0,2,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__read_analysis_file__592__1'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__IntroducedFrom__pred__read_analysis_file__592__1_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("Error reading analysis file: ", 29);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__IntroducedFrom__pred__read_analysis_file__592__1_3_0_i2);
MR_def_label(analysis__file__IntroducedFrom__pred__read_analysis_file__592__1_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__IntroducedFrom__pred__read_analysis_file__592__1_3_0_i3);
MR_def_label(analysis__file__IntroducedFrom__pred__read_analysis_file__592__1_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__nl_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module55)
	MR_init_entry1(analysis__file__IntroducedFrom__pred__read_analysis_file__567__1_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__IntroducedFrom__pred__read_analysis_file__567__1_3_0);
	MR_init_label2(analysis__file__IntroducedFrom__pred__read_analysis_file__567__1_3_0,2,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__read_analysis_file__567__1'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__IntroducedFrom__pred__read_analysis_file__567__1_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("% Reading analysis file ", 24);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__IntroducedFrom__pred__read_analysis_file__567__1_3_0_i2);
MR_def_label(analysis__file__IntroducedFrom__pred__read_analysis_file__567__1_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(io__write_string_3_0,
		analysis__file__IntroducedFrom__pred__read_analysis_file__567__1_3_0_i3);
MR_def_label(analysis__file__IntroducedFrom__pred__read_analysis_file__567__1_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__nl_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module56)
	MR_init_entry1(analysis__file__IntroducedFrom__pred__read_analysis_file__575__1_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__IntroducedFrom__pred__read_analysis_file__575__1_6_0);
	MR_init_label5(analysis__file__IntroducedFrom__pred__read_analysis_file__575__1_6_0,2,3,9,10,12)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__read_analysis_file__575__1'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__IntroducedFrom__pred__read_analysis_file__575__1_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r3;
	MR_sv(3) = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(parser__read_term_3_0,
		analysis__file__IntroducedFrom__pred__read_analysis_file__575__1_6_0_i2);
MR_def_label(analysis__file__IntroducedFrom__pred__read_analysis_file__575__1_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(analysis__file__IntroducedFrom__pred__read_analysis_file__575__1_6_0_i3);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_tfield(2, MR_r1, 1);
	if (MR_PTAG_TESTR(MR_tempr1,0)) {
		MR_GOTO_LAB(analysis__file__IntroducedFrom__pred__read_analysis_file__575__1_6_0_i3);
	}
	MR_tempr2 = MR_tfield(0, MR_tempr1, 1);
	if (MR_LTAGS_TESTR(MR_tempr2,0,0)) {
		MR_GOTO_LAB(analysis__file__IntroducedFrom__pred__read_analysis_file__575__1_6_0_i3);
	}
	MR_tempr2 = MR_tfield(0, MR_tempr1, 0);
	if (MR_PTAG_TESTR(MR_tempr2,1)) {
		MR_GOTO_LAB(analysis__file__IntroducedFrom__pred__read_analysis_file__575__1_6_0_i3);
	}
	MR_tempr1 = MR_tfield(1, MR_tempr2, 0);
	if (MR_INT_NE(MR_tempr1,6)) {
		MR_GOTO_LAB(analysis__file__IntroducedFrom__pred__read_analysis_file__575__1_6_0_i3);
	}
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_114_101_97_100_95_97_110_97_108_121_115_105_115_95_102_105_108_101_95_50_95_95_91_49_93_95_48_5_0);
	}
MR_def_label(analysis__file__IntroducedFrom__pred__read_analysis_file__575__1_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_CTOR1_ADDR(term_io, read_term);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(3);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(fn__string__string_1_0,
		analysis__file__IntroducedFrom__pred__read_analysis_file__575__1_6_0_i9);
MR_def_label(analysis__file__IntroducedFrom__pred__read_analysis_file__575__1_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("bad analysis file version: ", 27);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		analysis__file__IntroducedFrom__pred__read_analysis_file__575__1_6_0_i10);
MR_def_label(analysis__file__IntroducedFrom__pred__read_analysis_file__575__1_6_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis__file, invalid_analysis_file);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(exception__throw_1_0,
		analysis__file__IntroducedFrom__pred__read_analysis_file__575__1_6_0_i12);
MR_def_label(analysis__file__IntroducedFrom__pred__read_analysis_file__575__1_6_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_114_101_97_100_95_97_110_97_108_121_115_105_115_95_102_105_108_101_95_50_95_95_91_49_93_95_48_5_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_declare_entry(mercury__do_call_closure_4);

MR_BEGIN_MODULE(analysis__file_module57)
	MR_init_entry1(analysis__file__IntroducedFrom__pred__write_analysis_file_4__904__1_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__analysis__file__IntroducedFrom__pred__write_analysis_file_4__904__1_7_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__write_analysis_file_4__904__1'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(analysis__file__IntroducedFrom__pred__write_analysis_file_4__904__1_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_r3 = MR_r4;
	MR_r4 = MR_r5;
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(analysis__file__IntroducedFrom__pred__write_analysis_file_4__904__1_7_0));
	MR_np_tailcall_ent(do_call_closure_4);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_declare_entry(mercury__do_call_closure_2);

MR_BEGIN_MODULE(analysis__file_module58)
	MR_init_entry1(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_114_101_97_100_95_97_110_97_108_121_115_105_115_95_102_105_108_101_95_50_95_95_91_49_93_95_48_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_114_101_97_100_95_97_110_97_108_121_115_105_115_95_102_105_108_101_95_50_95_95_91_49_93_95_48_5_0);
	MR_init_label5(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_114_101_97_100_95_97_110_97_108_121_115_105_115_95_102_105_108_101_95_50_95_95_91_49_93_95_48_5_0,18,2,4,6,5)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__read_analysis_file_2__[1]_0'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_114_101_97_100_95_97_110_97_108_121_115_105_115_95_102_105_108_101_95_50_95_95_91_49_93_95_48_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
MR_def_label(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_114_101_97_100_95_97_110_97_108_121_115_105_115_95_102_105_108_101_95_50_95_95_91_49_93_95_48_5_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_np_call_localret_ent(parser__read_term_3_0,
		f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_114_101_97_100_95_97_110_97_108_121_115_105_115_95_102_105_108_101_95_50_95_95_91_49_93_95_48_5_0_i2);
MR_def_label(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_114_101_97_100_95_97_110_97_108_121_115_105_115_95_102_105_108_101_95_50_95_95_91_49_93_95_48_5_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_114_101_97_100_95_97_110_97_108_121_115_105_115_95_102_105_108_101_95_50_95_95_91_49_93_95_48_5_0_i4);
	}
	MR_r1 = MR_sv(2);
	MR_decr_sp_and_return(3);
MR_def_label(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_114_101_97_100_95_97_110_97_108_121_115_105_115_95_102_105_108_101_95_50_95_95_91_49_93_95_48_5_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_114_101_97_100_95_97_110_97_108_121_115_105_115_95_102_105_108_101_95_50_95_95_91_49_93_95_48_5_0_i5);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tfield(2, MR_tempr1, 1);
	MR_r3 = MR_sv(2);
	}
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_114_101_97_100_95_97_110_97_108_121_115_105_115_95_102_105_108_101_95_50_95_95_91_49_93_95_48_5_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_closure_2),
		mercury__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_114_101_97_100_95_97_110_97_108_121_115_105_115_95_102_105_108_101_95_50_95_95_91_49_93_95_48_5_0_i6);
MR_def_label(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_114_101_97_100_95_97_110_97_108_121_115_105_115_95_102_105_108_101_95_50_95_95_91_49_93_95_48_5_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(3);
	MR_GOTO_LAB(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_114_101_97_100_95_97_110_97_108_121_115_105_115_95_102_105_108_101_95_50_95_95_91_49_93_95_48_5_0_i18);
	}
MR_def_label(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_114_101_97_100_95_97_110_97_108_121_115_105_115_95_102_105_108_101_95_50_95_95_91_49_93_95_48_5_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis__file, invalid_analysis_file);
	MR_r2 = MR_tfield(1, MR_tempr1, 0);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(exception__throw_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(libs__pickle__unpickle_5_0);
MR_decl_entry(univ__type_to_univ_2_1);

MR_BEGIN_MODULE(analysis__file_module59)
	MR_init_entry1(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0);
	MR_init_label10(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0,2,4,6,7,8,9,10,12,3,13)
	MR_init_label1(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0,14)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__unpickle_analysis_result__[5]_0'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r3;
	MR_sv(2) = MR_tempr1;
	MR_tempr2 = MR_r4;
	MR_sv(3) = MR_tempr2;
	MR_sv(4) = MR_r1;
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tempr2;
	MR_r4 = MR_r5;
	}
	MR_np_call_localret_ent(libs__pickle__unpickle_5_0,
		f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0_i2);
MR_def_label(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_tempr2 = MR_sv(4);
	MR_sv(4) = MR_r2;
	MR_r1 = MR_tempr2;
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(1);
	MR_r2 = (MR_Integer) 2;
	}
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_class_method_2),
		mercury__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0_i4);
MR_def_label(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0_i3);
	}
	MR_sv(5) = MR_tfield(0, MR_r2, 0);
	MR_r1 = MR_sv(5);
	MR_r2 = (MR_Integer) 4;
	MR_np_call_localret_ent(private_builtin__type_info_from_typeclass_info_3_0,
		f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0_i6);
MR_def_label(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(3);
	MR_r4 = MR_sv(4);
	MR_np_call_localret_ent(libs__pickle__unpickle_5_0,
		f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0_i7);
MR_def_label(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_sv(4) = MR_r2;
	MR_r1 = MR_sv(5);
	MR_r2 = (MR_Integer) 5;
	MR_np_call_localret_ent(private_builtin__type_info_from_typeclass_info_3_0,
		f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0_i8);
MR_def_label(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(3);
	MR_r4 = MR_sv(4);
	MR_np_call_localret_ent(libs__pickle__unpickle_5_0,
		f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0_i9);
MR_def_label(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_sv(2);
	MR_sv(2) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, analysis_status);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(3);
	MR_r4 = MR_tempr2;
	}
	MR_np_call_localret_ent(libs__pickle__unpickle_5_0,
		f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0_i10);
MR_def_label(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(5);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 2) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_sv(1) = MR_r2;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(analysis, some_analysis_result);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(univ__type_to_univ_2_1,
		f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0_i12);
MR_def_label(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_decr_sp_and_return(6);
MR_def_label(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__analysis__this_file_0_0,
		f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0_i13);
MR_def_label(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("unpickle_analysis_result: ", 26);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0_i14);
MR_def_label(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_110_112_105_99_107_108_101_95_97_110_97_108_121_115_105_115_95_114_101_115_117_108_116_95_95_91_53_93_95_48_7_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(6);
	MR_decr_sp(6);
	MR_np_tailcall_ent(libs__compiler_util__unexpected_2_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module60)
	MR_init_entry1(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_85_110_105_102_121_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_48_95_95_91_49_44_32_50_93_95_48_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_85_110_105_102_121_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_48_95_95_91_49_44_32_50_93_95_48_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred____Unify___analysis__file__dummy_answer_0__[1, 2]_0'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_85_110_105_102_121_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_48_95_95_91_49_44_32_50_93_95_48_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_TRUE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module61)
	MR_init_entry1(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_67_111_109_112_97_114_101_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_48_95_95_91_50_44_32_51_93_95_48_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_67_111_109_112_97_114_101_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_48_95_95_91_50_44_32_51_93_95_48_3_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred____Compare___analysis__file__dummy_answer_0__[2, 3]_0'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_67_111_109_112_97_114_101_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_48_95_95_91_50_44_32_51_93_95_48_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(private_builtin__builtin_unify_pred_2_0);

MR_BEGIN_MODULE(analysis__file_module62)
	MR_init_entry1(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_85_110_105_102_121_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_112_97_114_115_101_95_101_110_116_114_121_95_49_95_95_91_49_93_95_48_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_85_110_105_102_121_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_112_97_114_115_101_95_101_110_116_114_121_95_49_95_95_91_49_93_95_48_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred____Unify___analysis__file__parse_entry_1__[1]_0'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_85_110_105_102_121_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_112_97_114_115_101_95_101_110_116_114_121_95_49_95_95_91_49_93_95_48_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(private_builtin__builtin_unify_pred_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(private_builtin__builtin_compare_pred_3_0);

MR_BEGIN_MODULE(analysis__file_module63)
	MR_init_entry1(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_67_111_109_112_97_114_101_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_112_97_114_115_101_95_101_110_116_114_121_95_49_95_95_91_49_93_95_48_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_67_111_109_112_97_114_101_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_112_97_114_115_101_95_101_110_116_114_121_95_49_95_95_91_49_93_95_48_3_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred____Compare___analysis__file__parse_entry_1__[1]_0'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_67_111_109_112_97_114_101_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_112_97_114_115_101_95_101_110_116_114_121_95_49_95_95_91_49_93_95_48_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(private_builtin__builtin_compare_pred_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module64)
	MR_init_entry1(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_85_110_105_102_121_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_119_114_105_116_101_95_101_110_116_114_121_95_49_95_95_91_49_93_95_48_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_85_110_105_102_121_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_119_114_105_116_101_95_101_110_116_114_121_95_49_95_95_91_49_93_95_48_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred____Unify___analysis__file__write_entry_1__[1]_0'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_85_110_105_102_121_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_119_114_105_116_101_95_101_110_116_114_121_95_49_95_95_91_49_93_95_48_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(private_builtin__builtin_unify_pred_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module65)
	MR_init_entry1(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_67_111_109_112_97_114_101_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_119_114_105_116_101_95_101_110_116_114_121_95_49_95_95_91_49_93_95_48_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_67_111_109_112_97_114_101_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_119_114_105_116_101_95_101_110_116_114_121_95_49_95_95_91_49_93_95_48_3_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred____Compare___analysis__file__write_entry_1__[1]_0'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_95_95_67_111_109_112_97_114_101_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_119_114_105_116_101_95_101_110_116_114_121_95_49_95_95_91_49_93_95_48_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(private_builtin__builtin_compare_pred_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module66)
	MR_init_entry1(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_110_97_109_101_95_50_95_95_91_49_44_32_50_93_95_48_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_110_97_109_101_95_50_95_95_91_49_44_32_50_93_95_48_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__func__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_name_2__[1, 2]_0'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_110_97_109_101_95_50_95_95_91_49_44_32_50_93_95_48_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("dummy", 5);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module67)
	MR_init_entry1(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_118_101_114_115_105_111_110_95_110_117_109_98_101_114_95_50_95_95_91_49_44_32_50_93_95_48_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_118_101_114_115_105_111_110_95_110_117_109_98_101_114_95_50_95_95_91_49_44_32_50_93_95_48_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__func__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_version_number_2__[1, 2]_0'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_118_101_114_115_105_111_110_95_110_117_109_98_101_114_95_50_95_95_91_49_44_32_50_93_95_48_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module68)
	MR_init_entry1(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_112_114_101_102_101_114_114_101_100_95_102_105_120_112_111_105_110_116_95_116_121_112_101_95_50_95_95_91_49_44_32_50_93_95_48_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_112_114_101_102_101_114_114_101_100_95_102_105_120_112_111_105_110_116_95_116_121_112_101_95_50_95_95_91_49_44_32_50_93_95_48_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__func__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__preferred_fixpoint_type_2__[1, 2]_0'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_112_114_101_102_101_114_114_101_100_95_102_105_120_112_111_105_110_116_95_116_121_112_101_95_50_95_95_91_49_44_32_50_93_95_48_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module69)
	MR_init_entry1(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_98_111_116_116_111_109_95_50_95_95_91_49_44_32_50_93_95_48_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_98_111_116_116_111_109_95_50_95_95_91_49_44_32_50_93_95_48_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__func__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__bottom_2__[1, 2]_0'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_98_111_116_116_111_109_95_50_95_95_91_49_44_32_50_93_95_48_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module70)
	MR_init_entry1(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_116_111_112_95_50_95_95_91_49_44_32_50_93_95_48_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_116_111_112_95_50_95_95_91_49_44_32_50_93_95_48_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__func__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__top_2__[1, 2]_0'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_116_111_112_95_50_95_95_91_49_44_32_50_93_95_48_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module71)
	MR_init_entry1(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_103_101_116_95_102_117_110_99_95_105_110_102_111_95_54_95_95_91_49_44_32_50_44_32_51_44_32_52_44_32_53_93_95_48_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_103_101_116_95_102_117_110_99_95_105_110_102_111_95_54_95_95_91_49_44_32_50_44_32_51_44_32_52_44_32_53_93_95_48_6_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__get_func_info_6__[1, 2, 3, 4, 5]_0'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_97_110_97_108_121_115_105_115_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_97_110_121_95_99_97_108_108_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_103_101_116_95_102_117_110_99_95_105_110_102_111_95_54_95_95_91_49_44_32_50_44_32_51_44_32_52_44_32_53_93_95_48_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(builtin__semidet_fail_0_0);

MR_BEGIN_MODULE(analysis__file_module72)
	MR_init_entry1(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_112_97_114_116_105_97_108_95_111_114_100_101_114_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_109_111_114_101_95_112_114_101_99_105_115_101_95_116_104_97_110_95_51_95_95_91_49_44_32_50_44_32_51_93_95_48_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_112_97_114_116_105_97_108_95_111_114_100_101_114_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_109_111_114_101_95_112_114_101_99_105_115_101_95_116_104_97_110_95_51_95_95_91_49_44_32_50_44_32_51_93_95_48_3_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__ClassMethod_for_analysis__partial_order____analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0______analysis__more_precise_than_3__[1, 2, 3]_0'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_112_97_114_116_105_97_108_95_111_114_100_101_114_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_109_111_114_101_95_112_114_101_99_105_115_101_95_116_104_97_110_95_51_95_95_91_49_44_32_50_44_32_51_93_95_48_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(builtin__semidet_fail_0_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(analysis__file_module73)
	MR_init_entry1(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_112_97_114_116_105_97_108_95_111_114_100_101_114_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_101_113_117_105_118_97_108_101_110_116_95_51_95_95_91_49_44_32_50_44_32_51_93_95_48_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_112_97_114_116_105_97_108_95_111_114_100_101_114_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_101_113_117_105_118_97_108_101_110_116_95_51_95_95_91_49_44_32_50_44_32_51_93_95_48_3_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__ClassMethod_for_analysis__partial_order____analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0______analysis__equivalent_3__[1, 2, 3]_0'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_112_97_114_116_105_97_108_95_111_114_100_101_114_95_95_95_95_97_110_97_108_121_115_105_115_95_95_110_111_95_102_117_110_99_95_105_110_102_111_95_95_97_114_105_116_121_48_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_101_113_117_105_118_97_108_101_110_116_95_51_95_95_91_49_44_32_50_44_32_51_93_95_48_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_TRUE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__term__context_init_0_0);

MR_BEGIN_MODULE(analysis__file_module74)
	MR_init_entry1(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_116_111_95_116_101_114_109_95_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_116_111_95_116_101_114_109_95_49_95_95_91_49_93_95_48_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_116_111_95_116_101_114_109_95_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_116_111_95_116_101_114_109_95_49_95_95_91_49_93_95_48_1_0);
	MR_init_label1(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_116_111_95_116_101_114_109_95_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_116_111_95_116_101_114_109_95_49_95_95_91_49_93_95_48_1_0,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__func__ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__to_term_1__[1]_0'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_116_111_95_116_101_114_109_95_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_116_111_95_116_101_114_109_95_49_95_95_91_49_93_95_48_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = (MR_Word) MR_TAG_COMMON(0,19,0);
	MR_np_call_localret_ent(fn__term__context_init_0_0,
		fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_116_111_95_116_101_114_109_95_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_116_111_95_116_101_114_109_95_49_95_95_91_49_93_95_48_1_0_i3);
MR_def_label(fn__f_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_67_108_97_115_115_77_101_116_104_111_100_95_102_111_114_95_97_110_97_108_121_115_105_115_95_95_116_111_95_116_101_114_109_95_95_95_95_97_110_97_108_121_115_105_115_95_95_102_105_108_101_95_95_100_117_109_109_121_95_97_110_115_119_101_114_95_95_97_114_105_116_121_48_95_95_95_95_95_95_97_110_97_108_121_115_105_115_95_95_116_111_95_116_101_114_109_95_49_95_95_91_49_93_95_48_1_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 3);
	MR_tfield(0, MR_r2, 0) = MR_sv(1);
	MR_tfield(0, MR_r2, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_r2, 2) = MR_r1;
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(2);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

static void mercury__analysis__file_maybe_bunch_0(void)
{
	analysis__file_module0();
	analysis__file_module1();
	analysis__file_module2();
	analysis__file_module3();
	analysis__file_module4();
	analysis__file_module5();
	analysis__file_module6();
	analysis__file_module7();
	analysis__file_module8();
	analysis__file_module9();
	analysis__file_module10();
	analysis__file_module11();
	analysis__file_module12();
	analysis__file_module13();
	analysis__file_module14();
	analysis__file_module15();
	analysis__file_module16();
	analysis__file_module17();
	analysis__file_module18();
	analysis__file_module19();
	analysis__file_module20();
	analysis__file_module21();
	analysis__file_module22();
	analysis__file_module23();
	analysis__file_module24();
	analysis__file_module25();
	analysis__file_module26();
	analysis__file_module27();
	analysis__file_module28();
	analysis__file_module29();
	analysis__file_module30();
	analysis__file_module31();
	analysis__file_module32();
	analysis__file_module33();
	analysis__file_module34();
	analysis__file_module35();
	analysis__file_module36();
	analysis__file_module37();
	analysis__file_module38();
	analysis__file_module39();
}

static void mercury__analysis__file_maybe_bunch_1(void)
{
	analysis__file_module40();
	analysis__file_module41();
	analysis__file_module42();
	analysis__file_module43();
	analysis__file_module44();
	analysis__file_module45();
	analysis__file_module46();
	analysis__file_module47();
	analysis__file_module48();
	analysis__file_module49();
	analysis__file_module50();
	analysis__file_module51();
	analysis__file_module52();
	analysis__file_module53();
	analysis__file_module54();
	analysis__file_module55();
	analysis__file_module56();
	analysis__file_module57();
	analysis__file_module58();
	analysis__file_module59();
	analysis__file_module60();
	analysis__file_module61();
	analysis__file_module62();
	analysis__file_module63();
	analysis__file_module64();
	analysis__file_module65();
	analysis__file_module66();
	analysis__file_module67();
	analysis__file_module68();
	analysis__file_module69();
	analysis__file_module70();
	analysis__file_module71();
	analysis__file_module72();
	analysis__file_module73();
	analysis__file_module74();
}

/* suppress gcc -Wmissing-decls warnings */
void mercury__analysis__file__init(void);
void mercury__analysis__file__init_type_tables(void);
void mercury__analysis__file__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__analysis__file__write_out_proc_statics(FILE *deep_fp, FILE *procrep_fp);
#endif
#ifdef MR_RECORD_TERM_SIZES
void mercury__analysis__file__init_complexity_procs(void);
#endif

void mercury__analysis__file__init(void)
{
	static MR_bool done = MR_FALSE;
	if (done) {
		return;
	}
	done = MR_TRUE;
	mercury__analysis__file_maybe_bunch_0();
	mercury__analysis__file_maybe_bunch_1();
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_analysis__file__type_ctor_info_dummy_answer_0,
		analysis__file__dummy_answer_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_analysis__file__type_ctor_info_invalid_analysis_file_0,
		analysis__file__invalid_analysis_file_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_analysis__file__type_ctor_info_parse_entry_1,
		analysis__file__parse_entry_1_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_analysis__file__type_ctor_info_write_entry_1,
		analysis__file__write_entry_1_0);
#ifndef MR_STATIC_CODE_ADDRESSES
		MR_field(MR_mktag(0), mercury_data_base_typeclass_info_analysis__to_term__arity1__analysis__file__dummy_answer__arity0__, 5) =
			MR_ENTRY_AP(fn__analysis__file__ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__to_term_1_1_0);
		MR_field(MR_mktag(0), mercury_data_base_typeclass_info_analysis__to_term__arity1__analysis__file__dummy_answer__arity0__, 6) =
			MR_ENTRY_AP(analysis__file__ClassMethod_for_analysis__to_term____analysis__file__dummy_answer__arity0______analysis__from_term_2_2_0);
#endif /* MR_STATIC_CODE_ADDRESSES */
#ifndef MR_STATIC_CODE_ADDRESSES
		MR_field(MR_mktag(0), mercury_data_base_typeclass_info_analysis__partial_order__arity2__analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0__, 5) =
			MR_ENTRY_AP(analysis__file__ClassMethod_for_analysis__partial_order____analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0______analysis__more_precise_than_3_3_0);
		MR_field(MR_mktag(0), mercury_data_base_typeclass_info_analysis__partial_order__arity2__analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0__, 6) =
			MR_ENTRY_AP(analysis__file__ClassMethod_for_analysis__partial_order____analysis__no_func_info__arity0__analysis__file__dummy_answer__arity0______analysis__equivalent_3_3_0);
#endif /* MR_STATIC_CODE_ADDRESSES */
#ifndef MR_STATIC_CODE_ADDRESSES
#endif /* MR_STATIC_CODE_ADDRESSES */
#ifndef MR_STATIC_CODE_ADDRESSES
		MR_field(MR_mktag(0), mercury_data_base_typeclass_info_analysis__analysis__arity3__analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0__, 5) =
			MR_ENTRY_AP(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_name_2_2_0);
		MR_field(MR_mktag(0), mercury_data_base_typeclass_info_analysis__analysis__arity3__analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0__, 6) =
			MR_ENTRY_AP(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__analysis_version_number_2_2_0);
		MR_field(MR_mktag(0), mercury_data_base_typeclass_info_analysis__analysis__arity3__analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0__, 7) =
			MR_ENTRY_AP(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__preferred_fixpoint_type_2_2_0);
		MR_field(MR_mktag(0), mercury_data_base_typeclass_info_analysis__analysis__arity3__analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0__, 8) =
			MR_ENTRY_AP(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__bottom_2_2_0);
		MR_field(MR_mktag(0), mercury_data_base_typeclass_info_analysis__analysis__arity3__analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0__, 9) =
			MR_ENTRY_AP(fn__analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__top_2_2_0);
		MR_field(MR_mktag(0), mercury_data_base_typeclass_info_analysis__analysis__arity3__analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0__, 10) =
			MR_ENTRY_AP(analysis__file__ClassMethod_for_analysis__analysis____analysis__no_func_info__arity0__analysis__any_call__arity0__analysis__file__dummy_answer__arity0______analysis__get_func_info_6_6_0);
#endif /* MR_STATIC_CODE_ADDRESSES */
	mercury__analysis__file__init_debugger();
}

void mercury__analysis__file__init_type_tables(void)
{
	static MR_bool done = MR_FALSE;
	if (done) {
		return;
	}
	done = MR_TRUE;
	{
		MR_register_type_ctor_info(
		&mercury_data_analysis__file__type_ctor_info_dummy_answer_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_analysis__file__type_ctor_info_invalid_analysis_file_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_analysis__file__type_ctor_info_parse_entry_1);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_analysis__file__type_ctor_info_write_entry_1);
	}
}


void mercury__analysis__file__init_debugger(void)
{
	static MR_bool done = MR_FALSE;
	if (done) {
		return;
	}
	done = MR_TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__analysis__file__write_out_proc_statics(FILE *deep_fp, FILE *procrep_fp)
{
	MR_write_out_module_proc_reps_start(procrep_fp, &mercury_data__module_common_layout__analysis__file);
	MR_write_out_module_proc_reps_end(procrep_fp);
}

#endif

#ifdef MR_RECORD_TERM_SIZES

void mercury__analysis__file__init_complexity_procs(void)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
