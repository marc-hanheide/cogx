/*
** Automatically generated from `lp_rational.m'
** by the Mercury compiler,
** version 10.04.2, configured for x86_64-unknown-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
** HIGHLEVEL_CODE=no
**
** END_OF_C_GRADE_INFO
*/

/*
INIT mercury__libs__lp_rational__init
ENDINIT
*/

#define MR_ALLOW_RESET
#include "mercury_imp.h"
#line 539 "../library/io.int"
#include "io.mh"

#line 28 "libs.lp_rational.c"
#line 547 "../library/io.int"
#include "string.mh"

#line 32 "libs.lp_rational.c"
#line 29 "../library/bitmap.int2"
#include "bitmap.mh"

#line 36 "libs.lp_rational.c"
#line 28 "../library/time.int2"
#include "time.mh"

#line 40 "libs.lp_rational.c"
#line 31 "../library/array.int2"
#include "array.mh"

#line 44 "libs.lp_rational.c"
#line 33 "../mdbcomp/mdbcomp.rtti_access.int2"
#include "mdbcomp.rtti_access.mh"

#line 48 "libs.lp_rational.c"
#line 49 "libs.lp_rational.c"
#include "libs.lp_rational.mh"

#line 52 "libs.lp_rational.c"
#line 53 "libs.lp_rational.c"
#ifndef LIBS__LP_RATIONAL_DECL_GUARD
#define LIBS__LP_RATIONAL_DECL_GUARD

#line 57 "libs.lp_rational.c"
#line 58 "libs.lp_rational.c"

#endif
#line 61 "libs.lp_rational.c"

#ifdef _MSC_VER
#define MR_STATIC_LINKAGE extern
#else
#define MR_STATIC_LINKAGE static
#endif

struct mercury_type_0 {
	MR_Word * f1[2];
};
MR_STATIC_LINKAGE const struct mercury_type_0 mercury_common_0[];

struct mercury_type_1 {
	MR_Word * f1[3];
};
MR_STATIC_LINKAGE const struct mercury_type_1 mercury_common_1[];

struct mercury_type_2 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[3];
};
MR_STATIC_LINKAGE const struct mercury_type_2 mercury_common_2[];

struct mercury_type_3 {
	MR_Word * f1;
	MR_Code * f2;
	MR_Integer f3;
};
MR_STATIC_LINKAGE const struct mercury_type_3 mercury_common_3[];

struct mercury_type_4 {
	MR_Word * f1;
	MR_Word * f2;
	MR_Integer f3;
	MR_Word * f4;
	MR_Word * f5;
};
MR_STATIC_LINKAGE const struct mercury_type_4 mercury_common_4[];

struct mercury_type_5 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[4];
};
MR_STATIC_LINKAGE const struct mercury_type_5 mercury_common_5[];

struct mercury_type_6 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[6];
};
MR_STATIC_LINKAGE const struct mercury_type_6 mercury_common_6[];

struct mercury_type_7 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[5];
};
MR_STATIC_LINKAGE const struct mercury_type_7 mercury_common_7[];

struct mercury_type_8 {
	MR_Word * f1;
	MR_Code * f2;
	MR_Integer f3;
	MR_Integer f4;
	MR_Integer f5;
};
MR_STATIC_LINKAGE const struct mercury_type_8 mercury_common_8[];

struct mercury_type_9 {
	MR_Word * f1;
	MR_Word * f2;
	MR_Integer f3;
	MR_Word * f4;
};
MR_STATIC_LINKAGE const struct mercury_type_9 mercury_common_9[];

struct mercury_type_10 {
	MR_Word * f1;
	MR_Integer f2;
	MR_Word * f3;
	MR_Word * f4;
};
MR_STATIC_LINKAGE const struct mercury_type_10 mercury_common_10[];

struct mercury_type_11 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[8];
};
MR_STATIC_LINKAGE const struct mercury_type_11 mercury_common_11[];

struct mercury_type_12 {
	MR_Integer f1[2];
};
MR_STATIC_LINKAGE const struct mercury_type_12 mercury_common_12[];

struct mercury_type_13 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[10];
};
MR_STATIC_LINKAGE const struct mercury_type_13 mercury_common_13[];

extern const MR_TypeCtorInfo_Struct
	mercury_data_libs__lp_rational__type_ctor_info_cc_map_0,
	mercury_data_libs__lp_rational__type_ctor_info_cell_0,
	mercury_data_libs__lp_rational__type_ctor_info_coeff_info_0,
	mercury_data_libs__lp_rational__type_ctor_info_coefficient_0,
	mercury_data_libs__lp_rational__type_ctor_info_constant_0,
	mercury_data_libs__lp_rational__type_ctor_info_constraint_0,
	mercury_data_libs__lp_rational__type_ctor_info_constraints_0,
	mercury_data_libs__lp_rational__type_ctor_info_direction_0,
	mercury_data_libs__lp_rational__type_ctor_info_entailment_result_0,
	mercury_data_libs__lp_rational__type_ctor_info_lp_info_0;

extern const MR_TypeCtorInfo_Struct
	mercury_data_libs__lp_rational__type_ctor_info_lp_operator_0,
	mercury_data_libs__lp_rational__type_ctor_info_lp_result_0,
	mercury_data_libs__lp_rational__type_ctor_info_lp_term_0,
	mercury_data_libs__lp_rational__type_ctor_info_lp_terms_0,
	mercury_data_libs__lp_rational__type_ctor_info_lp_var_0,
	mercury_data_libs__lp_rational__type_ctor_info_lp_vars_0,
	mercury_data_libs__lp_rational__type_ctor_info_lp_varset_0,
	mercury_data_libs__lp_rational__type_ctor_info_matrix_0,
	mercury_data_libs__lp_rational__type_ctor_info_objective_0,
	mercury_data_libs__lp_rational__type_ctor_info_output_var_0;

extern const MR_TypeCtorInfo_Struct
	mercury_data_libs__lp_rational__type_ctor_info_projection_result_0,
	mercury_data_libs__lp_rational__type_ctor_info_tableau_0,
	mercury_data_libs__lp_rational__type_ctor_info_var_num_map_0,
	mercury_data_libs__lp_rational__type_ctor_info_vector_0;
MR_decl_label8(libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0, 3,6,9,10,11,8,14,4)
MR_decl_label5(libs__lp_rational__IntroducedFrom__pred__collect_vars__945__1_3_0, 3,13,2,17,18)
MR_decl_label2(libs__lp_rational__IntroducedFrom__pred__combine_vectors__1846__1_2_0, 3,1)
MR_decl_label5(libs__lp_rational__IntroducedFrom__pred__ensure_zero_obj_coeffs__1115__1_3_0, 1,3,5,7,8)
MR_decl_label6(libs__lp_rational__IntroducedFrom__pred__extract_obj_var2__1024__1_3_0, 1,3,5,6,7,9)
MR_decl_label4(libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1144__1_5_0, 2,4,5,3)
MR_decl_label4(libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1152__1_4_0, 1,3,5,6)
MR_decl_label4(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1345__1_2_0, 1,4,6,7)
MR_decl_label5(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1347__1_3_0, 1,3,5,7,8)
MR_decl_label2(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1357__1_3_0, 1,3)
MR_decl_label3(libs__lp_rational__IntroducedFrom__pred__nonneg_box__749__1_4_0, 4,2,6)
MR_decl_label2(libs__lp_rational__IntroducedFrom__pred__pivot__1182__1_4_0, 1,3)
MR_decl_label10(libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0, 2,3,4,6,7,5,10,11,12,13)
MR_decl_label1(libs__lp_rational__IntroducedFrom__pred__pivot__1201__1_3_0, 1)
MR_decl_label1(libs__lp_rational__IntroducedFrom__pred__pivot__1205__1_3_0, 2)
MR_decl_label6(libs__lp_rational__IntroducedFrom__pred__pivot__1211__1_5_0, 2,4,5,3,8,9)
MR_decl_label4(libs__lp_rational__IntroducedFrom__pred__row_op__1227__1_6_0, 2,3,4,5)
MR_decl_label2(libs__lp_rational__IntroducedFrom__pred__set_terms_to_zero__713__1_2_0, 4,1)
MR_decl_label8(libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0, 4,6,7,5,3,12,15,14)
MR_decl_label10(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0, 4,6,7,9,11,12,14,10,16,17)
MR_decl_label10(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0, 5,3,21,22,23,25,26,53,24,29)
MR_decl_label6(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0, 30,32,28,34,35,38)
MR_decl_label5(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_49_95_95_91_50_93_95_48_6_0, 20,3,6,8,4)
MR_decl_label5(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_50_95_95_91_50_93_95_48_6_0, 22,3,8,10,4)
MR_decl_label9(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0, 57,3,7,5,13,14,20,18,15)
MR_decl_label10(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0, 57,5,6,8,10,12,15,18,19,21)
MR_decl_label2(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0, 23,9)
MR_decl_label2(libs__lp_rational__add_vectors_6_0, 2,7)
MR_decl_label2(libs__lp_rational__all_cols_2_0, 1,3)
MR_decl_label2(libs__lp_rational__all_cols0_2_0, 1,3)
MR_decl_label2(libs__lp_rational__all_rows_2_0, 1,3)
MR_decl_label2(libs__lp_rational__all_rows0_2_0, 1,3)
MR_decl_label2(libs__lp_rational__between_3_0, 4,2)
MR_decl_label10(libs__lp_rational__check_for_equalities_5_0, 55,7,8,13,14,16,18,3,4,1)
MR_decl_label10(libs__lp_rational__classify_vector_10_0, 4,7,10,11,9,14,15,17,18,20)
MR_decl_label7(libs__lp_rational__classify_vector_10_0, 22,23,25,21,26,2,28)
MR_decl_label10(libs__lp_rational__combine_vectors_8_0, 2,4,5,12,14,15,41,10,19,20)
MR_decl_label10(libs__lp_rational__combine_vectors_8_0, 18,23,28,29,26,31,25,32,33,36)
MR_decl_label2(libs__lp_rational__combine_vectors_8_0, 37,1)
MR_decl_label9(libs__lp_rational__count_coeff_3_0, 4,7,8,6,12,13,11,18,2)
MR_decl_label2(libs__lp_rational__deconstruct_constraint_4_0, 3,4)
MR_decl_label5(libs__lp_rational__deconstruct_non_false_constraint_4_0, 4,2,7,9,10)
MR_decl_label10(libs__lp_rational__duffin_heuristic_4_0, 72,6,8,10,12,13,14,18,20,25)
MR_decl_label9(libs__lp_rational__duffin_heuristic_4_0, 26,24,23,29,31,28,32,71,1)
MR_decl_label10(libs__lp_rational__eliminate_equations_2_6_0, 56,4,7,9,14,15,12,6,17,1)
MR_decl_label10(libs__lp_rational__ensure_zero_obj_coeffs_3_0, 56,3,5,6,8,9,7,14,18,19)
MR_decl_label6(libs__lp_rational__ensure_zero_obj_coeffs_3_0, 17,22,23,24,27,16)
MR_decl_label3(libs__lp_rational__entailed_3_0, 2,3,1)
MR_decl_label10(libs__lp_rational__fix_basis_and_rem_cols_3_0, 62,3,5,10,14,15,19,24,21,25)
MR_decl_label2(libs__lp_rational__fix_basis_and_rem_cols_3_0, 12,29)
MR_decl_label6(libs__lp_rational__fix_coeff_and_const_5_0, 4,3,5,7,6,9)
MR_decl_label10(libs__lp_rational__fm_standardize_5_0, 4,5,7,11,14,15,16,3,22,23)
MR_decl_label6(libs__lp_rational__fm_standardize_5_0, 24,25,21,28,29,31)
MR_decl_label3(libs__lp_rational__get_vars_from_terms_3_0, 14,3,5)
MR_decl_label6(libs__lp_rational__inconsistent_2_0, 6,9,13,20,3,1)
MR_decl_label4(libs__lp_rational__insert_constraints_6_0, 19,3,7,8)
MR_decl_label4(libs__lp_rational__insert_terms_5_0, 15,3,5,6)
MR_decl_label7(libs__lp_rational__is_false_1_0, 6,7,3,11,9,15,1)
MR_decl_label10(libs__lp_rational__is_stronger_2_0, 10,12,7,14,17,19,5,27,29,24)
MR_decl_label10(libs__lp_rational__is_stronger_2_0, 32,35,37,38,31,40,43,45,46,47)
MR_decl_label10(libs__lp_rational__is_stronger_2_0, 115,3,56,57,58,62,64,65,66,69)
MR_decl_label7(libs__lp_rational__is_stronger_2_0, 70,72,54,76,78,79,1)
MR_decl_label6(libs__lp_rational__is_true_1_0, 5,3,10,8,14,1)
MR_decl_label10(libs__lp_rational__lp_standardize_constraint_4_0, 74,5,6,4,10,13,3,20,21,19)
MR_decl_label10(libs__lp_rational__lp_standardize_constraint_4_0, 25,26,27,29,30,18,37,38,40,36)
MR_decl_label2(libs__lp_rational__lp_standardize_constraint_4_0, 42,43)
MR_decl_label9(libs__lp_rational__lp_terms_to_map_2_3_0, 4,6,8,9,7,2,17,18,15)
MR_decl_label1(libs__lp_rational__make_label_3_0, 2)
MR_decl_label1(libs__lp_rational__new_art_var_3_0, 2)
MR_decl_label1(libs__lp_rational__new_slack_var_3_0, 2)
MR_decl_label7(libs__lp_rational__nonneg_constr_1_0, 5,6,7,10,19,3,1)
MR_decl_label10(libs__lp_rational__normalize_terms_and_const_5_0, 5,9,10,12,13,11,17,18,19,6)
MR_decl_label3(libs__lp_rational__number_vars_2_4_0, 14,3,5)
MR_decl_label5(libs__lp_rational__optimize_4_0, 2,4,5,9,10)
MR_decl_label9(libs__lp_rational__output_constraint_4_0, 4,5,9,10,11,12,3,15,14)
MR_decl_label5(libs__lp_rational__output_constraint_2_5_0, 2,6,7,8,9)
MR_decl_label2(libs__lp_rational__output_constraints_4_0, 2,4)
MR_decl_label5(libs__lp_rational__output_term_4_0, 2,3,4,5,6)
MR_decl_label5(libs__lp_rational__pivot_4_0, 2,5,8,11,12)
MR_decl_label10(libs__lp_rational__quasi_syntactic_redundant_2_0, 2,12,17,18,20,10,27,32,33,35)
MR_decl_label3(libs__lp_rational__quasi_syntactic_redundant_2_0, 31,25,1)
MR_decl_label10(libs__lp_rational__remove_some_entailed_constraints_2_4_0, 121,3,6,5,11,12,16,21,23,24)
MR_decl_label10(libs__lp_rational__remove_some_entailed_constraints_2_4_0, 25,10,29,30,34,39,41,42,43,40)
MR_decl_label9(libs__lp_rational__remove_some_entailed_constraints_2_4_0, 38,7,8,46,47,65,49,51,1)
MR_decl_label6(libs__lp_rational__remove_weaker_2_6_0, 4,2,8,10,6,11)
MR_decl_label4(libs__lp_rational__restore_equalities_2_0, 26,5,4,8)
MR_decl_label9(libs__lp_rational__set_cell_5_0, 6,8,4,2,11,13,14,12,22)
MR_decl_label6(libs__lp_rational__simplex_3_0, 29,6,8,11,13,32)
MR_decl_label10(libs__lp_rational__solve_2_6_0, 3,6,8,5,4,12,13,15,16,17)
MR_decl_label7(libs__lp_rational__solve_2_6_0, 18,20,22,24,26,31,27)
MR_decl_label10(libs__lp_rational__substitute_into_constraint_6_0, 3,4,2,7,10,11,9,16,17,18)
MR_decl_label10(libs__lp_rational__substitute_into_constraint_6_0, 20,21,24,25,5,27,29,31,35,39)
MR_decl_label7(libs__lp_rational__substitute_into_constraint_6_0, 41,42,43,44,45,46,34)
MR_decl_label8(libs__lp_rational__substitute_into_constraints_6_0, 47,4,7,9,13,11,17,1)
MR_decl_label10(libs__lp_rational__substitute_variable_7_0, 3,4,2,7,10,11,9,16,17,18)
MR_decl_label10(libs__lp_rational__substitute_variable_7_0, 20,21,24,25,5,27,29,31,34,35)
MR_decl_label4(libs__lp_rational__substitute_variable_7_0, 36,38,40,1)
MR_decl_label4(libs__lp_rational__write_constr_term_4_0, 2,3,4,5)
MR_decl_label8(libs__lp_rational__write_constraint_4_0, 2,7,8,9,10,11,12,13)
MR_decl_label1(fn__libs__lp_rational__IntroducedFrom__func__normalize_constraint__2088__1_2_0, 2)
MR_decl_label1(fn__libs__lp_rational__IntroducedFrom__func__normalize_terms_and_const__580__1_2_0, 2)
MR_decl_label1(fn__libs__lp_rational__IntroducedFrom__func__opposing_inequalities__2198__1_1_0, 2)
MR_decl_label4(fn__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_73_110_116_114_111_100_117_99_101_100_70_114_111_109_95_95_102_117_110_99_95_95_98_111_117_110_100_105_110_103_95_98_111_120_95_95_55_50_54_95_95_49_95_95_91_49_93_95_48_3_0, 3,5,7,6)
MR_decl_label2(fn__libs__lp_rational__bounding_box_2_0, 3,4)
MR_decl_label5(fn__libs__lp_rational__collect_remaining_vars_2_0, 24,3,5,4,8)
MR_decl_label1(fn__libs__lp_rational__collect_vars_2_0, 4)
MR_decl_label10(fn__libs__lp_rational__construct_constraint_3_0, 5,8,7,76,14,18,19,20,12,24)
MR_decl_label8(fn__libs__lp_rational__construct_constraint_3_0, 28,29,30,32,33,22,35,36)
MR_decl_label3(fn__libs__lp_rational__construct_non_false_constraint_3_0, 2,5,3)
MR_decl_label1(fn__libs__lp_rational__count_coeffs_in_vector_2_0, 3)
MR_decl_label7(fn__libs__lp_rational__elem_3_0, 6,8,4,2,11,15,12)
MR_decl_label10(fn__libs__lp_rational__entailed_3_0, 74,5,3,12,14,33,15,17,10,21)
MR_decl_label5(fn__libs__lp_rational__entailed_3_0, 23,36,24,26,82)
MR_decl_label4(fn__libs__lp_rational__extract_obj_var_3_0, 3,5,6,9)
MR_decl_label1(fn__libs__lp_rational__false_constraint_0_0, 2)
MR_decl_label2(fn__libs__lp_rational__find_max_2_2_0, 3,4)
MR_decl_label10(fn__libs__lp_rational__find_target_equality_2_3_0, 62,3,9,7,4,13,24,25,20,27)
MR_decl_label2(fn__libs__lp_rational__find_target_equality_2_3_0, 28,18)
MR_decl_label1(fn__libs__lp_rational__get_basis_vars_1_0, 3)
MR_decl_label1(fn__libs__lp_rational__get_vars_from_constraints_1_0, 3)
MR_decl_label1(fn__libs__lp_rational__lp_term_1_0, 2)
MR_decl_label1(fn__libs__lp_rational__lp_terms_to_map_1_0, 3)
MR_decl_label1(fn__libs__lp_rational__make_expansion_num_2_0, 2)
MR_decl_label3(fn__libs__lp_rational__make_nonneg_constr_1_0, 2,3,6)
MR_decl_label1(fn__libs__lp_rational__make_var_const_eq_constraint_2_0, 2)
MR_decl_label1(fn__libs__lp_rational__make_var_const_gte_constraint_2_0, 2)
MR_decl_label4(fn__libs__lp_rational__make_vars_eq_constraint_2_0, 2,4,5,9)
MR_decl_label8(fn__libs__lp_rational__negate_constraint_1_0, 6,7,3,12,13,9,17,18)
MR_decl_label1(fn__libs__lp_rational__nonneg_box_2_0, 2)
MR_decl_label9(fn__libs__lp_rational__one_phase_4_0, 2,4,5,6,7,9,10,13,14)
MR_decl_label10(fn__libs__lp_rational__remove_trivial_1_0, 149,6,8,4,11,16,12,13,23,71)
MR_decl_label10(fn__libs__lp_rational__remove_trivial_1_0, 21,27,28,32,37,39,40,41,26,45)
MR_decl_label10(fn__libs__lp_rational__remove_trivial_1_0, 46,50,55,57,58,59,56,54,18,19)
MR_decl_label4(fn__libs__lp_rational__remove_weaker_1_0, 27,6,7,26)
MR_decl_label5(fn__libs__lp_rational__set_vars_to_zero_2_2_0, 7,3,13,9,18)
MR_decl_label1(fn__libs__lp_rational__simplify_constraints_1_0, 2)
MR_decl_label1(fn__libs__lp_rational__substitute_term_2_0, 3)
MR_decl_label1(fn__libs__lp_rational__substitute_vars_3_0, 3)
MR_decl_label10(fn__libs__lp_rational__substitute_vars_2_2_0, 7,8,11,12,3,18,19,22,23,14)
MR_decl_label2(fn__libs__lp_rational__sum_like_terms_1_0, 3,7)
MR_decl_label1(fn__libs__lp_rational__true_constraint_0_0, 2)
MR_decl_label10(fn__libs__lp_rational__two_phase_5_0, 5,6,7,8,10,11,14,15,19,20)
MR_decl_label8(fn__libs__lp_rational__two_phase_5_0, 17,22,23,24,25,26,27,28)
MR_decl_label2(fn__libs__lp_rational__vector_to_constraint_1_0, 3,4)
MR_decl_label2(__Unify___libs__lp_rational__cell_0_0, 4,1)
MR_decl_label2(__Unify___libs__lp_rational__coeff_info_0_0, 4,1)
MR_decl_label7(__Unify___libs__lp_rational__constraint_0_0, 9,5,17,37,13,24,1)
MR_decl_label4(__Unify___libs__lp_rational__lp_info_0_0, 4,7,11,1)
MR_decl_label5(__Unify___libs__lp_rational__lp_result_0_0, 5,18,6,8,1)
MR_decl_label4(__Unify___libs__lp_rational__projection_result_0_0, 5,15,6,1)
MR_decl_label5(__Unify___libs__lp_rational__tableau_0_0, 5,7,9,14,1)
MR_decl_label4(__Unify___libs__lp_rational__vector_0_0, 4,7,11,1)
MR_decl_label4(__Compare___libs__lp_rational__cell_0_0, 3,2,5,21)
MR_decl_label4(__Compare___libs__lp_rational__coeff_info_0_0, 3,2,5,21)
MR_decl_label10(__Compare___libs__lp_rational__constraint_0_0, 3,2,11,7,5,59,19,24,17,30)
MR_decl_label3(__Compare___libs__lp_rational__constraint_0_0, 31,35,119)
MR_decl_label5(__Compare___libs__lp_rational__lp_info_0_0, 3,2,5,10,40)
MR_decl_label10(__Compare___libs__lp_rational__lp_result_0_0, 7,5,39,11,40,9,14,15,17,23)
MR_decl_label7(__Compare___libs__lp_rational__projection_result_0_0, 30,5,11,33,9,14,15)
MR_decl_label8(__Compare___libs__lp_rational__tableau_0_0, 3,2,5,9,14,18,22,73)
MR_decl_label5(__Compare___libs__lp_rational__vector_0_0, 3,2,5,10,39)
MR_def_extern_entry(fn__libs__lp_rational__lp_term_1_0)
MR_decl_static(fn__libs__lp_rational__lp_terms_to_map_1_0)
MR_decl_static(fn__libs__lp_rational__sum_like_terms_1_0)
MR_decl_static(fn__libs__lp_rational__this_file_0_0)
MR_decl_static(libs__lp_rational__normalize_terms_and_const_5_0)
MR_decl_static(fn__libs__lp_rational__negate_lp_terms_1_0)
MR_def_extern_entry(fn__libs__lp_rational__construct_constraint_3_0)
MR_def_extern_entry(libs__lp_rational__is_false_1_0)
MR_def_extern_entry(fn__libs__lp_rational__construct_non_false_constraint_3_0)
MR_def_extern_entry(libs__lp_rational__deconstruct_constraint_4_0)
MR_def_extern_entry(libs__lp_rational__deconstruct_non_false_constraint_4_0)
MR_def_extern_entry(libs__lp_rational__nonneg_constr_1_0)
MR_def_extern_entry(fn__libs__lp_rational__make_nonneg_constr_1_0)
MR_def_extern_entry(fn__libs__lp_rational__make_vars_eq_constraint_2_0)
MR_def_extern_entry(fn__libs__lp_rational__make_var_const_eq_constraint_2_0)
MR_def_extern_entry(fn__libs__lp_rational__make_var_const_gte_constraint_2_0)
MR_def_extern_entry(fn__libs__lp_rational__false_constraint_0_0)
MR_def_extern_entry(fn__libs__lp_rational__true_constraint_0_0)
MR_def_extern_entry(libs__lp_rational__is_true_1_0)
MR_decl_static(libs__lp_rational__check_for_equalities_5_0)
MR_def_extern_entry(libs__lp_rational__restore_equalities_2_0)
MR_decl_static(libs__lp_rational__set_cell_5_0)
MR_decl_static(libs__lp_rational__insert_terms_5_0)
MR_decl_static(fn__libs__lp_rational__elem_3_0)
MR_decl_static(libs__lp_rational__pivot_4_0)
MR_decl_static(libs__lp_rational__simplex_3_0)
MR_decl_static(libs__lp_rational__optimize_4_0)
MR_decl_static(libs__lp_rational__get_vars_from_terms_3_0)
MR_decl_static(fn__libs__lp_rational__one_phase_4_0)
MR_decl_static(libs__lp_rational__ensure_zero_obj_coeffs_3_0)
MR_decl_static(libs__lp_rational__remove_row_3_0)
MR_decl_static(libs__lp_rational__remove_col_3_0)
MR_decl_static(libs__lp_rational__fix_basis_and_rem_cols_3_0)
MR_decl_static(fn__libs__lp_rational__get_basis_vars_1_0)
MR_decl_static(fn__libs__lp_rational__two_phase_5_0)
MR_decl_static(fn__libs__lp_rational__negate_constraint_1_0)
MR_decl_static(fn__libs__lp_rational__collect_vars_2_0)
MR_decl_static(libs__lp_rational__number_vars_2_4_0)
MR_decl_static(libs__lp_rational__insert_constraints_6_0)
MR_decl_static(libs__lp_rational__solve_2_6_0)
MR_def_extern_entry(fn__libs__lp_rational__solve_4_0)
MR_def_extern_entry(fn__libs__lp_rational__entailed_3_0)
MR_decl_static(libs__lp_rational__remove_some_entailed_constraints_2_4_0)
MR_def_extern_entry(libs__lp_rational__remove_some_entailed_constraints_3_0)
MR_def_extern_entry(libs__lp_rational__inconsistent_2_0)
MR_decl_static(fn__libs__lp_rational__remove_trivial_1_0)
MR_decl_static(fn__libs__lp_rational__remove_weaker_1_0)
MR_def_extern_entry(fn__libs__lp_rational__simplify_constraints_1_0)
MR_def_extern_entry(fn__libs__lp_rational__substitute_vars_3_0)
MR_def_extern_entry(fn__libs__lp_rational__substitute_vars_2_0)
MR_def_extern_entry(fn__libs__lp_rational__set_vars_to_zero_2_0)
MR_def_extern_entry(fn__libs__lp_rational__get_vars_from_constraints_1_0)
MR_def_extern_entry(fn__libs__lp_rational__bounding_box_2_0)
MR_def_extern_entry(fn__libs__lp_rational__nonneg_box_2_0)
MR_decl_static(fn__libs__lp_rational__find_target_equality_2_3_0)
MR_decl_static(libs__lp_rational__fix_coeff_and_const_5_0)
MR_decl_static(libs__lp_rational__substitute_into_constraint_6_0)
MR_decl_static(libs__lp_rational__substitute_into_constraints_6_0)
MR_decl_static(libs__lp_rational__substitute_variable_7_0)
MR_decl_static(libs__lp_rational__eliminate_equations_2_6_0)
MR_decl_static(fn__libs__lp_rational__collect_remaining_vars_2_0)
MR_decl_static(fn__libs__lp_rational__find_max_2_2_0)
MR_decl_static(libs__lp_rational__duffin_heuristic_4_0)
MR_def_extern_entry(libs__lp_rational__project_5_0)
MR_def_extern_entry(fn__libs__lp_rational__project_3_0)
MR_def_extern_entry(libs__lp_rational__project_4_0)
MR_def_extern_entry(libs__lp_rational__entailed_3_0)
MR_def_extern_entry(libs__lp_rational__output_constraints_4_0)
MR_def_extern_entry(libs__lp_rational__write_constraints_4_0)
MR_decl_static(libs__lp_rational__lp_terms_to_map_2_3_0)
MR_decl_static(libs__lp_rational__is_stronger_2_0)
MR_decl_static(libs__lp_rational__remove_weaker_2_6_0)
MR_decl_static(fn__libs__lp_rational__substitute_vars_2_2_0)
MR_decl_static(fn__libs__lp_rational__substitute_term_2_0)
MR_decl_static(fn__libs__lp_rational__set_vars_to_zero_2_2_0)
MR_decl_static(libs__lp_rational__new_slack_var_3_0)
MR_decl_static(libs__lp_rational__new_art_var_3_0)
MR_decl_static(libs__lp_rational__lp_standardize_constraint_4_0)
MR_decl_static(fn__libs__lp_rational__extract_obj_var_3_0)
MR_decl_static(fn__libs__lp_rational__rhs_col_1_0)
MR_decl_static(libs__lp_rational__between_3_0)
MR_decl_static(libs__lp_rational__all_rows0_2_0)
MR_decl_static(libs__lp_rational__all_rows_2_0)
MR_decl_static(libs__lp_rational__all_cols0_2_0)
MR_decl_static(libs__lp_rational__all_cols_2_0)
MR_decl_static(libs__lp_rational__make_label_3_0)
MR_decl_static(libs__lp_rational__fm_standardize_5_0)
MR_decl_static(fn__libs__lp_rational__vector_to_constraint_1_0)
MR_decl_static(libs__lp_rational__classify_vector_10_0)
MR_decl_static(libs__lp_rational__eliminate_var_8_0)
MR_decl_static(libs__lp_rational__quasi_syntactic_redundant_2_0)
MR_decl_static(libs__lp_rational__add_vectors_6_0)
MR_decl_static(libs__lp_rational__combine_vectors_8_0)
MR_decl_static(libs__lp_rational__relevant_1_0)
MR_decl_static(fn__libs__lp_rational__make_expansion_num_2_0)
MR_decl_static(fn__libs__lp_rational__count_coeffs_in_vector_2_0)
MR_decl_static(libs__lp_rational__count_coeff_3_0)
MR_decl_static(libs__lp_rational__get_vars_from_constraint_3_0)
MR_decl_static(libs__lp_rational__write_constraint_4_0)
MR_decl_static(libs__lp_rational__write_constr_term_4_0)
MR_decl_static(libs__lp_rational__output_constraint_2_5_0)
MR_decl_static(libs__lp_rational__output_constraint_4_0)
MR_decl_static(libs__lp_rational__output_term_4_0)
MR_decl_static(__Unify___libs__lp_rational__cc_map_0_0)
MR_decl_static(__Compare___libs__lp_rational__cc_map_0_0)
MR_decl_static(__Unify___libs__lp_rational__cell_0_0)
MR_decl_static(__Compare___libs__lp_rational__cell_0_0)
MR_decl_static(__Unify___libs__lp_rational__coeff_info_0_0)
MR_decl_static(__Compare___libs__lp_rational__coeff_info_0_0)
MR_def_extern_entry(__Unify___libs__lp_rational__coefficient_0_0)
MR_def_extern_entry(__Compare___libs__lp_rational__coefficient_0_0)
MR_def_extern_entry(__Unify___libs__lp_rational__constant_0_0)
MR_def_extern_entry(__Compare___libs__lp_rational__constant_0_0)
MR_def_extern_entry(__Unify___libs__lp_rational__constraint_0_0)
MR_def_extern_entry(__Compare___libs__lp_rational__constraint_0_0)
MR_def_extern_entry(__Unify___libs__lp_rational__constraints_0_0)
MR_def_extern_entry(__Compare___libs__lp_rational__constraints_0_0)
MR_def_extern_entry(__Unify___libs__lp_rational__direction_0_0)
MR_def_extern_entry(__Compare___libs__lp_rational__direction_0_0)
MR_def_extern_entry(__Unify___libs__lp_rational__entailment_result_0_0)
MR_def_extern_entry(__Compare___libs__lp_rational__entailment_result_0_0)
MR_decl_static(__Unify___libs__lp_rational__lp_info_0_0)
MR_decl_static(__Compare___libs__lp_rational__lp_info_0_0)
MR_def_extern_entry(__Unify___libs__lp_rational__lp_operator_0_0)
MR_def_extern_entry(__Compare___libs__lp_rational__lp_operator_0_0)
MR_def_extern_entry(__Unify___libs__lp_rational__lp_result_0_0)
MR_def_extern_entry(__Compare___libs__lp_rational__lp_result_0_0)
MR_def_extern_entry(__Unify___libs__lp_rational__lp_term_0_0)
MR_def_extern_entry(__Compare___libs__lp_rational__lp_term_0_0)
MR_def_extern_entry(__Unify___libs__lp_rational__lp_terms_0_0)
MR_def_extern_entry(__Compare___libs__lp_rational__lp_terms_0_0)
MR_def_extern_entry(__Unify___libs__lp_rational__lp_var_0_0)
MR_def_extern_entry(__Compare___libs__lp_rational__lp_var_0_0)
MR_def_extern_entry(__Unify___libs__lp_rational__lp_vars_0_0)
MR_def_extern_entry(__Compare___libs__lp_rational__lp_vars_0_0)
MR_def_extern_entry(__Unify___libs__lp_rational__lp_varset_0_0)
MR_def_extern_entry(__Compare___libs__lp_rational__lp_varset_0_0)
MR_decl_static(__Unify___libs__lp_rational__matrix_0_0)
MR_decl_static(__Compare___libs__lp_rational__matrix_0_0)
MR_def_extern_entry(__Unify___libs__lp_rational__objective_0_0)
MR_def_extern_entry(__Compare___libs__lp_rational__objective_0_0)
MR_def_extern_entry(__Unify___libs__lp_rational__output_var_0_0)
MR_def_extern_entry(__Compare___libs__lp_rational__output_var_0_0)
MR_def_extern_entry(__Unify___libs__lp_rational__projection_result_0_0)
MR_def_extern_entry(__Compare___libs__lp_rational__projection_result_0_0)
MR_decl_static(__Unify___libs__lp_rational__tableau_0_0)
MR_decl_static(__Compare___libs__lp_rational__tableau_0_0)
MR_decl_static(__Unify___libs__lp_rational__var_num_map_0_0)
MR_decl_static(__Compare___libs__lp_rational__var_num_map_0_0)
MR_decl_static(__Unify___libs__lp_rational__vector_0_0)
MR_decl_static(__Compare___libs__lp_rational__vector_0_0)
MR_decl_static(fn__libs__lp_rational__IntroducedFrom__func__bounding_box__726__1_3_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__nonneg_box__749__1_4_0)
MR_decl_static(fn__libs__lp_rational__IntroducedFrom__func__normalize_terms_and_const__562__1_2_0)
MR_decl_static(fn__libs__lp_rational__IntroducedFrom__func__normalize_terms_and_const__580__1_2_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__set_terms_to_zero__713__1_2_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__collect_vars__945__1_3_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__extract_obj_var2__1024__1_3_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__ensure_zero_obj_coeffs__1115__1_3_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1144__1_5_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1152__1_4_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__pivot__1182__1_4_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__pivot__1201__1_3_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__pivot__1205__1_3_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__pivot__1211__1_5_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__row_op__1227__1_6_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1347__1_3_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1345__1_2_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1357__1_3_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__eliminate_equations__1557__1_1_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__substitute_variable__1635__1_2_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__combine_vectors__1846__1_2_0)
MR_decl_static(fn__libs__lp_rational__IntroducedFrom__func__init_cc_map__2037__1_2_0)
MR_decl_static(fn__libs__lp_rational__IntroducedFrom__func__normalize_vector__2062__1_2_0)
MR_decl_static(fn__libs__lp_rational__IntroducedFrom__func__normalize_constraint__2088__1_2_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__add_vectors__2108__1_2_0)
MR_decl_static(libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0)
MR_decl_static(fn__libs__lp_rational__IntroducedFrom__func__opposing_inequalities__2198__1_1_0)
MR_def_extern_entry(fn__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_3_0)
MR_def_extern_entry(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_4_0)
MR_def_extern_entry(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0)
MR_decl_static(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0)
MR_decl_static(fn__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_73_110_116_114_111_100_117_99_101_100_70_114_111_109_95_95_102_117_110_99_95_95_98_111_117_110_100_105_110_103_95_98_111_120_95_95_55_50_54_95_95_49_95_95_91_49_93_95_48_3_0)
MR_decl_static(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_49_95_95_91_50_93_95_48_6_0)
MR_decl_static(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_50_95_95_91_50_93_95_48_6_0)

extern const MR_TypeCtorInfo_Struct mercury_data_term__type_ctor_info_var_1;
extern const MR_TypeCtorInfo_Struct mercury_data_term__type_ctor_info_generic_0;
extern const MR_TypeCtorInfo_Struct mercury_data_term__type_ctor_info_var_1;
extern const MR_TypeCtorInfo_Struct mercury_data_term__type_ctor_info_generic_0;
extern const MR_TypeCtorInfo_Struct mercury_data_maybe__type_ctor_info_maybe_1;
extern const MR_TypeCtorInfo_Struct mercury_data_list__type_ctor_info_list_1;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_int_0;
extern const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_constraint_0;
extern const MR_TypeCtorInfo_Struct mercury_data_set_ordlist__type_ctor_info_set_ordlist_1;
extern const MR_TypeCtorInfo_Struct mercury_data_varset__type_ctor_info_varset_1;
extern const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_vector_0;
static const struct mercury_type_0 mercury_common_0[18] =
{
{
{
MR_CTOR1_ADDR(term, var),
MR_CTOR0_ADDR(term, generic)
}
},
{
{
MR_CTOR1_ADDR(term, var),
MR_CTOR0_ADDR(term, generic)
}
},
{
{
MR_CTOR1_ADDR(maybe, maybe),
MR_COMMON(1,5)
}
},
{
{
MR_CTOR1_ADDR(maybe, maybe),
MR_TAG_COMMON(0,1,6)
}
},
{
{
MR_CTOR1_ADDR(term, var),
MR_CTOR0_ADDR(term, generic)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_COMMON(1,8)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_TAG_COMMON(0,1,9)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_INT_CTOR_ADDR
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(libs__lp_rational, constraint)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_COMMON(1,10)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(libs__lp_rational, constraint)
}
},
{
{
MR_CTOR1_ADDR(set_ordlist, set_ordlist),
MR_COMMON(0,1)
}
},
{
{
MR_CTOR1_ADDR(set_ordlist, set_ordlist),
MR_TAG_COMMON(0,0,0)
}
},
{
{
MR_CTOR1_ADDR(varset, varset),
MR_CTOR0_ADDR(term, generic)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_COMMON(0,1)
}
},
{
{
MR_CTOR1_ADDR(maybe, maybe),
MR_INT_CTOR_ADDR
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(libs__lp_rational, vector)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(libs__lp_rational, vector)
}
},
};

extern const MR_TypeCtorInfo_Struct mercury_data_pair__type_ctor_info_pair_2;
extern const MR_TypeCtorInfo_Struct mercury_data_libs__rat__type_ctor_info_rat_0;
extern const MR_TypeCtorInfo_Struct mercury_data_tree234__type_ctor_info_tree234_2;
extern const MR_TypeCtorInfo_Struct mercury_data_libs__rat__type_ctor_info_rat_0;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_int_0;
extern const MR_TypeCtorInfo_Struct mercury_data_pair__type_ctor_info_pair_2;
extern const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_coeff_info_0;
static const struct mercury_type_1 mercury_common_1[18] =
{
{
{
MR_CTOR_ADDR(pair, pair, 2),
MR_TAG_COMMON(0,0,0),
MR_CTOR0_ADDR(libs__rat, rat)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_TAG_COMMON(0,0,0),
MR_CTOR0_ADDR(libs__rat, rat)
}
},
{
{
MR_CTOR_ADDR(pair, pair, 2),
MR_COMMON(0,1),
MR_CTOR0_ADDR(libs__rat, rat)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_COMMON(0,1),
MR_CTOR0_ADDR(libs__rat, rat)
}
},
{
{
MR_CTOR_ADDR(pair, pair, 2),
MR_INT_CTOR_ADDR,
MR_INT_CTOR_ADDR
}
},
{
{
MR_CTOR_ADDR(pair, pair, 2),
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(libs__rat, rat)
}
},
{
{
MR_CTOR_ADDR(pair, pair, 2),
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(libs__rat, rat)
}
},
{
{
MR_CTOR_ADDR(pair, pair, 2),
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(libs__rat, rat)
}
},
{
{
MR_CTOR_ADDR(pair, pair, 2),
MR_CTOR0_ADDR(libs__rat, rat),
MR_INT_CTOR_ADDR
}
},
{
{
MR_CTOR_ADDR(pair, pair, 2),
MR_CTOR0_ADDR(libs__rat, rat),
MR_INT_CTOR_ADDR
}
},
{
{
MR_CTOR_ADDR(pair, pair, 2),
MR_COMMON(0,1),
MR_CTOR0_ADDR(libs__rat, rat)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_COMMON(0,1),
MR_COMMON(0,1)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_TAG_COMMON(0,0,0),
MR_CTOR0_ADDR(libs__lp_rational, coeff_info)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_COMMON(0,1),
MR_CTOR0_ADDR(libs__lp_rational, coeff_info)
}
},
{
{
MR_CTOR_ADDR(pair, pair, 2),
MR_TAG_COMMON(0,0,0),
MR_CTOR0_ADDR(libs__lp_rational, coeff_info)
}
},
{
{
MR_CTOR_ADDR(pair, pair, 2),
MR_TAG_COMMON(0,0,0),
MR_INT_CTOR_ADDR
}
},
{
{
MR_CTOR_ADDR(pair, pair, 2),
MR_COMMON(0,1),
MR_CTOR0_ADDR(libs__lp_rational, coeff_info)
}
},
{
{
MR_CTOR_ADDR(pair, pair, 2),
MR_COMMON(0,1),
MR_INT_CTOR_ADDR
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__lp_terms_to_map_1_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__sum_like_terms_1_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__normalize_terms_and_const_5_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_comparison_result_0;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__normalize_terms_and_const_5_0_2;
extern const MR_TypeCtorInfo_Struct mercury_data_libs__rat__type_ctor_info_rat_0;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__construct_constraint_3_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__construct_constraint_3_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__pivot_4_0_3;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_int_0;
extern const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_tableau_0;
extern const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_cell_0;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__pivot_4_0_4;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__ensure_zero_obj_coeffs_3_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__get_basis_vars_1_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__collect_vars_2_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__substitute_vars_3_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_constraint_0;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__substitute_vars_2_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__set_vars_to_zero_2_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__get_vars_from_constraints_1_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__substitute_into_constraint_6_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__substitute_variable_7_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__duffin_heuristic_4_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__duffin_heuristic_4_0_2;
extern const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_vector_0;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__duffin_heuristic_4_0_3;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__substitute_vars_2_2_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__substitute_vars_2_2_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__substitute_vars_2_2_0_3;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__substitute_vars_2_2_0_4;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__extract_obj_var_3_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__fm_standardize_5_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__classify_vector_10_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__count_coeffs_in_vector_2_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1345__1_2_0_1;
static const struct mercury_type_2 mercury_common_2[29] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__lp_terms_to_map_1_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_COMMON(1,2),
MR_COMMON(1,3),
MR_COMMON(1,3)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__sum_like_terms_1_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_COMMON(1,2),
MR_COMMON(1,3),
MR_COMMON(1,3)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__normalize_terms_and_const_5_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_COMMON(1,2),
MR_COMMON(1,2),
MR_CTOR0_ADDR(builtin, comparison_result)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__normalize_terms_and_const_5_0_2,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(libs__rat, rat),
MR_COMMON(1,2),
MR_COMMON(1,2)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__construct_constraint_3_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_COMMON(1,2),
MR_COMMON(1,3),
MR_COMMON(1,3)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__construct_constraint_3_0_2,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_COMMON(1,2),
MR_COMMON(1,3),
MR_COMMON(1,3)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__pivot_4_0_3,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_CTOR0_ADDR(libs__lp_rational, cell)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__pivot_4_0_4,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(libs__lp_rational, cell),
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_CTOR0_ADDR(libs__lp_rational, tableau)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__ensure_zero_obj_coeffs_3_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_INT_CTOR_ADDR,
MR_COMMON(1,7)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__get_basis_vars_1_0_2,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_COMMON(0,7),
MR_COMMON(0,4)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__collect_vars_2_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_COMMON(0,8),
MR_COMMON(0,9),
MR_COMMON(0,4)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__substitute_vars_3_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_COMMON(1,11),
MR_CTOR0_ADDR(libs__lp_rational, constraint),
MR_CTOR0_ADDR(libs__lp_rational, constraint)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__substitute_vars_2_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_COMMON(1,11),
MR_CTOR0_ADDR(libs__lp_rational, constraint),
MR_CTOR0_ADDR(libs__lp_rational, constraint)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__set_vars_to_zero_2_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_COMMON(0,11),
MR_CTOR0_ADDR(libs__lp_rational, constraint),
MR_CTOR0_ADDR(libs__lp_rational, constraint)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__get_vars_from_constraints_1_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(libs__lp_rational, constraint),
MR_COMMON(0,11),
MR_COMMON(0,11)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__substitute_into_constraint_6_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(libs__rat, rat),
MR_COMMON(1,2),
MR_COMMON(1,2)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__substitute_variable_7_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(libs__rat, rat),
MR_COMMON(1,2),
MR_COMMON(1,2)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__duffin_heuristic_4_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_COMMON(0,4),
MR_COMMON(1,13),
MR_COMMON(1,13)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__duffin_heuristic_4_0_2,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(libs__lp_rational, vector),
MR_COMMON(1,13),
MR_COMMON(1,13)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__duffin_heuristic_4_0_3,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_INT_CTOR_ADDR,
MR_COMMON(1,16),
MR_COMMON(1,17)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__substitute_vars_2_2_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_COMMON(1,11),
MR_COMMON(1,2),
MR_COMMON(1,2)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__substitute_vars_2_2_0_2,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_COMMON(1,2),
MR_COMMON(1,3),
MR_COMMON(1,3)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__substitute_vars_2_2_0_3,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_COMMON(1,11),
MR_COMMON(1,2),
MR_COMMON(1,2)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__substitute_vars_2_2_0_4,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_COMMON(1,2),
MR_COMMON(1,3),
MR_COMMON(1,3)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__extract_obj_var_3_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(libs__rat, rat)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__fm_standardize_5_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_COMMON(1,2),
MR_COMMON(1,3),
MR_COMMON(1,3)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__classify_vector_10_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(libs__rat, rat),
MR_CTOR0_ADDR(libs__rat, rat),
MR_CTOR0_ADDR(libs__rat, rat)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__count_coeffs_in_vector_2_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_COMMON(1,2),
MR_COMMON(1,13),
MR_COMMON(1,13)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1345__1_2_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_INT_CTOR_ADDR,
MR_COMMON(1,7)
}
},
};

MR_decl_entry(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0);
static const struct mercury_type_3 mercury_common_3[26] =
{
{
MR_COMMON(2,0),
MR_ENTRY_AP(libs__lp_rational__lp_terms_to_map_2_3_0),
0
},
{
MR_COMMON(2,1),
MR_ENTRY_AP(libs__lp_rational__lp_terms_to_map_2_3_0),
0
},
{
MR_COMMON(2,2),
MR_ENTRY_AP(fn__libs__lp_rational__IntroducedFrom__func__normalize_terms_and_const__562__1_2_0),
0
},
{
MR_COMMON(4,0),
MR_ENTRY_AP(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0),
0
},
{
MR_COMMON(2,4),
MR_ENTRY_AP(libs__lp_rational__lp_terms_to_map_2_3_0),
0
},
{
MR_COMMON(2,5),
MR_ENTRY_AP(libs__lp_rational__lp_terms_to_map_2_3_0),
0
},
{
MR_COMMON(4,1),
MR_ENTRY_AP(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0),
0
},
{
MR_COMMON(4,2),
MR_ENTRY_AP(fn__libs__lp_rational__IntroducedFrom__func__opposing_inequalities__2198__1_1_0),
0
},
{
MR_COMMON(2,7),
MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__pivot__1205__1_3_0),
0
},
{
MR_COMMON(4,9),
MR_ENTRY_AP(fn__libs__lp_rational__lp_term_1_0),
0
},
{
MR_COMMON(4,10),
MR_ENTRY_AP(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0),
0
},
{
MR_COMMON(4,11),
MR_ENTRY_AP(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0),
0
},
{
MR_COMMON(4,12),
MR_ENTRY_AP(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0),
0
},
{
MR_COMMON(5,6),
MR_ENTRY_AP(libs__lp_rational__lp_standardize_constraint_4_0),
0
},
{
MR_COMMON(2,14),
MR_ENTRY_AP(libs__lp_rational__get_vars_from_constraint_3_0),
0
},
{
MR_COMMON(2,17),
MR_ENTRY_AP(fn__libs__lp_rational__IntroducedFrom__func__init_cc_map__2037__1_2_0),
0
},
{
MR_COMMON(2,18),
MR_ENTRY_AP(fn__libs__lp_rational__count_coeffs_in_vector_2_0),
0
},
{
MR_COMMON(9,0),
MR_ENTRY_AP(libs__lp_rational__relevant_1_0),
0
},
{
MR_COMMON(2,21),
MR_ENTRY_AP(libs__lp_rational__lp_terms_to_map_2_3_0),
0
},
{
MR_COMMON(2,23),
MR_ENTRY_AP(libs__lp_rational__lp_terms_to_map_2_3_0),
0
},
{
MR_COMMON(2,25),
MR_ENTRY_AP(libs__lp_rational__lp_terms_to_map_2_3_0),
0
},
{
MR_COMMON(4,19),
MR_ENTRY_AP(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0),
0
},
{
MR_COMMON(2,27),
MR_ENTRY_AP(libs__lp_rational__count_coeff_3_0),
0
},
{
MR_COMMON(9,1),
MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__eliminate_equations__1557__1_1_0),
0
},
{
MR_COMMON(7,3),
MR_ENTRY_AP(libs__lp_rational__fm_standardize_5_0),
0
},
{
MR_COMMON(4,21),
MR_ENTRY_AP(fn__libs__lp_rational__vector_to_constraint_1_0),
0
},
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__negate_lp_terms_1_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__construct_constraint_3_0_3;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__check_for_equalities_5_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__pivot_4_0_5;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__simplex_3_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__simplex_3_0_3;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__ensure_zero_obj_coeffs_3_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__fix_basis_and_rem_cols_3_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__get_basis_vars_1_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__two_phase_5_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__negate_constraint_1_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__negate_constraint_1_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__negate_constraint_1_0_3;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__substitute_variable_7_0_2;
extern const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_lp_operator_0;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__substitute_variable_7_0_3;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__substitute_variable_7_0_4;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__set_vars_to_zero_2_2_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__set_vars_to_zero_2_2_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__set_vars_to_zero_2_2_0_3;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__fm_standardize_5_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__add_vectors_6_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0_3;
static const struct mercury_type_4 mercury_common_4[22] =
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__negate_lp_terms_1_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(libs__rat, rat),
MR_CTOR0_ADDR(libs__rat, rat)
},
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__construct_constraint_3_0_3,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(libs__rat, rat),
MR_CTOR0_ADDR(libs__rat, rat)
},
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__check_for_equalities_5_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(1,2),
MR_COMMON(1,2)
},
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__pivot_4_0_5,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_INT_CTOR_ADDR
},
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__simplex_3_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_INT_CTOR_ADDR
},
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__simplex_3_0_3,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_INT_CTOR_ADDR
},
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__ensure_zero_obj_coeffs_3_0_2,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_INT_CTOR_ADDR
},
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__fix_basis_and_rem_cols_3_0_2,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_INT_CTOR_ADDR
},
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__get_basis_vars_1_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_INT_CTOR_ADDR
},
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__two_phase_5_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(0,4),
MR_COMMON(1,2)
},
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__negate_constraint_1_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(libs__rat, rat),
MR_CTOR0_ADDR(libs__rat, rat)
},
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__negate_constraint_1_0_2,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(libs__rat, rat),
MR_CTOR0_ADDR(libs__rat, rat)
},
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__negate_constraint_1_0_3,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(libs__rat, rat),
MR_CTOR0_ADDR(libs__rat, rat)
},
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__substitute_variable_7_0_2,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(libs__lp_rational, lp_operator),
MR_CTOR0_ADDR(libs__lp_rational, lp_operator)
},
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__substitute_variable_7_0_3,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(libs__lp_rational, lp_operator),
MR_CTOR0_ADDR(libs__lp_rational, lp_operator)
},
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__substitute_variable_7_0_4,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(libs__lp_rational, lp_operator),
MR_CTOR0_ADDR(libs__lp_rational, lp_operator)
},
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__set_vars_to_zero_2_2_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(0,11),
MR_COMMON(1,2)
},
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__set_vars_to_zero_2_2_0_2,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(0,11),
MR_COMMON(1,2)
},
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__set_vars_to_zero_2_2_0_3,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(0,11),
MR_COMMON(1,2)
},
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__fm_standardize_5_0_2,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(libs__rat, rat),
MR_CTOR0_ADDR(libs__rat, rat)
},
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__add_vectors_6_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(1,3),
MR_COMMON(0,4)
},
{
(MR_Word *) &mercury_data__closure_layout__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0_3,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(libs__lp_rational, vector),
MR_CTOR0_ADDR(libs__lp_rational, constraint)
},
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__pivot_4_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__simplex_3_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__optimize_4_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__one_phase_4_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__fix_basis_and_rem_cols_3_0_3;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__two_phase_5_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__solve_2_6_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_lp_info_0;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__bounding_box_2_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__nonneg_box_2_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__output_constraints_4_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_io__type_ctor_info_state_0;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__write_constraints_4_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__add_vectors_6_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__write_constraint_4_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__output_constraint_2_5_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__output_constraint_4_0_1;
static const struct mercury_type_5 mercury_common_5[15] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__pivot_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_INT_CTOR_ADDR,
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_CTOR0_ADDR(libs__lp_rational, cell)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__simplex_3_0_2,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_INT_CTOR_ADDR,
MR_COMMON(0,2),
MR_COMMON(0,2)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__optimize_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_COMMON(0,4),
MR_COMMON(1,3),
MR_COMMON(1,3)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__one_phase_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_COMMON(0,4),
MR_COMMON(1,3),
MR_COMMON(1,3)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__fix_basis_and_rem_cols_3_0_3,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_INT_CTOR_ADDR,
MR_INT_CTOR_ADDR,
MR_INT_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__two_phase_5_0_2,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_COMMON(0,4),
MR_COMMON(1,3),
MR_COMMON(1,3)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__solve_2_6_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(libs__lp_rational, constraint),
MR_CTOR0_ADDR(libs__lp_rational, constraint),
MR_CTOR0_ADDR(libs__lp_rational, lp_info),
MR_CTOR0_ADDR(libs__lp_rational, lp_info)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__bounding_box_2_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_COMMON(0,13),
MR_COMMON(0,4),
MR_COMMON(0,8),
MR_COMMON(0,8)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__nonneg_box_2_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_COMMON(0,14),
MR_COMMON(0,4),
MR_COMMON(0,8),
MR_COMMON(0,8)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__output_constraints_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_COMMON(10,0),
MR_CTOR0_ADDR(libs__lp_rational, constraint),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__write_constraints_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_COMMON(0,13),
MR_CTOR0_ADDR(libs__lp_rational, constraint),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__add_vectors_6_0_2,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_COMMON(1,3),
MR_COMMON(0,4),
MR_COMMON(1,3),
MR_COMMON(1,3)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__write_constraint_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_COMMON(0,13),
MR_COMMON(1,2),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__output_constraint_2_5_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_COMMON(10,0),
MR_COMMON(1,2),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__output_constraint_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_COMMON(10,0),
MR_COMMON(1,2),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__pivot_4_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__ensure_zero_obj_coeffs_3_0_3;
static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__remove_weaker_1_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_bool__type_ctor_info_bool_0;
static const struct mercury_type_6 mercury_common_6[3] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__pivot_4_0_2,
(MR_Word *) (MR_Integer) 0
},
6,
{
MR_INT_CTOR_ADDR,
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(libs__rat, rat),
MR_CTOR0_ADDR(libs__lp_rational, cell),
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_CTOR0_ADDR(libs__lp_rational, tableau)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__ensure_zero_obj_coeffs_3_0_3,
(MR_Word *) (MR_Integer) 0
},
6,
{
MR_CTOR0_ADDR(libs__rat, rat),
MR_INT_CTOR_ADDR,
MR_INT_CTOR_ADDR,
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_CTOR0_ADDR(libs__lp_rational, tableau)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__fn__libs__lp_rational__remove_weaker_1_0_1,
(MR_Word *) (MR_Integer) 0
},
6,
{
MR_CTOR0_ADDR(libs__lp_rational, constraint),
MR_CTOR0_ADDR(libs__lp_rational, constraint),
MR_COMMON(0,8),
MR_COMMON(0,8),
MR_BOOL_CTOR_ADDR,
MR_BOOL_CTOR_ADDR
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__pivot_4_0_6;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__simplex_3_0_4;
static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__fix_basis_and_rem_cols_3_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0_2;
static const struct mercury_type_7 mercury_common_7[4] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__pivot_4_0_6,
(MR_Word *) (MR_Integer) 0
},
5,
{
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(libs__rat, rat),
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_CTOR0_ADDR(libs__lp_rational, tableau)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__simplex_3_0_4,
(MR_Word *) (MR_Integer) 0
},
5,
{
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_INT_CTOR_ADDR,
MR_COMMON(0,2),
MR_COMMON(0,2)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__fix_basis_and_rem_cols_3_0_1,
(MR_Word *) (MR_Integer) 0
},
5,
{
MR_CTOR0_ADDR(libs__lp_rational, tableau),
MR_INT_CTOR_ADDR,
MR_INT_CTOR_ADDR,
MR_COMMON(0,5),
MR_COMMON(0,5)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0_2,
(MR_Word *) (MR_Integer) 0
},
5,
{
MR_CTOR0_ADDR(libs__lp_rational, constraint),
MR_INT_CTOR_ADDR,
MR_INT_CTOR_ADDR,
MR_COMMON(0,16),
MR_COMMON(0,16)
}
},
};

static const struct mercury_type_8 mercury_common_8[3] =
{
{
MR_COMMON(4,13),
MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__substitute_variable__1635__1_2_0),
2,
1,
1
},
{
MR_COMMON(4,14),
MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__substitute_variable__1635__1_2_0),
2,
2,
1
},
{
MR_COMMON(4,15),
MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__substitute_variable__1635__1_2_0),
2,
0,
1
},
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__duffin_heuristic_4_0_4;
static const MR_UserClosureId
mercury_data__closure_layout__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0_1;
static const struct mercury_type_9 mercury_common_9[2] =
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__duffin_heuristic_4_0_4,
(MR_Word *) (MR_Integer) 0,
1,
MR_COMMON(1,17)
},
{
(MR_Word *) &mercury_data__closure_layout__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0_1,
(MR_Word *) (MR_Integer) 0,
1,
MR_CTOR0_ADDR(libs__lp_rational, constraint)
},
};

extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_func_0;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_string_0;
static const struct mercury_type_10 mercury_common_10[1] =
{
{
MR_CTOR0_ADDR(builtin, func),
2,
MR_COMMON(0,1),
MR_STRING_CTOR_ADDR
},
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__eliminate_var_8_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0_3;
static const struct mercury_type_11 mercury_common_11[2] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__libs__lp_rational__eliminate_var_8_0_1,
(MR_Word *) (MR_Integer) 0
},
8,
{
MR_INT_CTOR_ADDR,
MR_COMMON(0,15),
MR_CTOR0_ADDR(libs__lp_rational, vector),
MR_CTOR0_ADDR(libs__lp_rational, vector),
MR_COMMON(0,16),
MR_COMMON(0,16),
MR_INT_CTOR_ADDR,
MR_INT_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0_3,
(MR_Word *) (MR_Integer) 0
},
8,
{
MR_INT_CTOR_ADDR,
MR_COMMON(0,15),
MR_COMMON(0,16),
MR_CTOR0_ADDR(libs__lp_rational, vector),
MR_COMMON(0,16),
MR_COMMON(0,16),
MR_INT_CTOR_ADDR,
MR_INT_CTOR_ADDR
}
},
};

static const struct mercury_type_12 mercury_common_12[1] =
{
{
{
0,
0
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0_2;
static const struct mercury_type_13 mercury_common_13[2] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0_1,
(MR_Word *) (MR_Integer) 0
},
10,
{
MR_COMMON(0,4),
MR_CTOR0_ADDR(libs__lp_rational, vector),
MR_COMMON(0,16),
MR_COMMON(0,16),
MR_COMMON(0,16),
MR_COMMON(0,16),
MR_COMMON(0,16),
MR_COMMON(0,16),
MR_INT_CTOR_ADDR,
MR_INT_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0_2,
(MR_Word *) (MR_Integer) 0
},
10,
{
MR_COMMON(0,4),
MR_CTOR0_ADDR(libs__lp_rational, vector),
MR_COMMON(0,16),
MR_COMMON(0,16),
MR_COMMON(0,16),
MR_COMMON(0,16),
MR_COMMON(0,16),
MR_COMMON(0,16),
MR_INT_CTOR_ADDR,
MR_INT_CTOR_ADDR
}
},
};

static const MR_FA_TypeInfo_Struct1 mercury_data_term__ti_var_1term__type_ctor_info_generic_0 = {
	&mercury_data_term__type_ctor_info_var_1,
{	(MR_TypeInfo) &mercury_data_term__type_ctor_info_generic_0
}};

static const MR_FA_TypeInfo_Struct2 mercury_data_tree234__ti_tree234_2term__ti_var_1term__type_ctor_info_generic_0libs__lp_rational__type_ctor_info_coeff_info_0 = {
	&mercury_data_tree234__type_ctor_info_tree234_2,
{	(MR_TypeInfo) &mercury_data_term__ti_var_1term__type_ctor_info_generic_0,
	(MR_TypeInfo) &mercury_data_libs__lp_rational__type_ctor_info_coeff_info_0
}};

const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_cc_map_0 = {
	0,
	13,
	-1,
	MR_TYPECTOR_REP_EQUIV_GROUND,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__cc_map_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__cc_map_0_0)),
	"libs.lp_rational",
	"cc_map",
	{ 0 },
	{ (void *)&mercury_data_tree234__ti_tree234_2term__ti_var_1term__type_ctor_info_generic_0libs__lp_rational__type_ctor_info_coeff_info_0 },
	-1,
	0,
	NULL
};

const MR_PseudoTypeInfo mercury_data_libs__lp_rational__field_types_cell_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_builtin__type_ctor_info_int_0,
	(MR_PseudoTypeInfo) &mercury_data_builtin__type_ctor_info_int_0
};

static const MR_DuFunctorDesc mercury_data_libs__lp_rational__du_functor_desc_cell_0_0 = {
	"cell",
	2,
	0,
	MR_SECTAG_NONE,
	0,
	-1,
	0,
	(MR_PseudoTypeInfo *) mercury_data_libs__lp_rational__field_types_cell_0_0,
	NULL,
	NULL
};

const MR_DuFunctorDescPtr mercury_data_libs__lp_rational__du_stag_ordered_cell_0_0[] = {
	&mercury_data_libs__lp_rational__du_functor_desc_cell_0_0

};

const MR_DuPtagLayout mercury_data_libs__lp_rational__du_ptag_ordered_cell_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_libs__lp_rational__du_stag_ordered_cell_0_0 }

};

const MR_DuFunctorDescPtr mercury_data_libs__lp_rational__du_name_ordered_cell_0[] = {
	&mercury_data_libs__lp_rational__du_functor_desc_cell_0_0
};

const MR_Integer mercury_data_libs__lp_rational__functor_number_map_cell_0[] = {
	0 };
	
const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_cell_0 = {
	0,
	13,
	1,
	MR_TYPECTOR_REP_DU,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__cell_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__cell_0_0)),
	"libs.lp_rational",
	"cell",
	{ (void *)mercury_data_libs__lp_rational__du_name_ordered_cell_0 },
	{ (void *)mercury_data_libs__lp_rational__du_ptag_ordered_cell_0 },
	1,
	4,
	mercury_data_libs__lp_rational__functor_number_map_cell_0
};

const MR_PseudoTypeInfo mercury_data_libs__lp_rational__field_types_coeff_info_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_builtin__type_ctor_info_int_0,
	(MR_PseudoTypeInfo) &mercury_data_builtin__type_ctor_info_int_0
};

const MR_ConstString mercury_data_libs__lp_rational__field_names_coeff_info_0_0[] = {
	"pos",
	"neg"
};

static const MR_DuFunctorDesc mercury_data_libs__lp_rational__du_functor_desc_coeff_info_0_0 = {
	"coeff_info",
	2,
	0,
	MR_SECTAG_NONE,
	0,
	-1,
	0,
	(MR_PseudoTypeInfo *) mercury_data_libs__lp_rational__field_types_coeff_info_0_0,
	mercury_data_libs__lp_rational__field_names_coeff_info_0_0,
	NULL
};

const MR_DuFunctorDescPtr mercury_data_libs__lp_rational__du_stag_ordered_coeff_info_0_0[] = {
	&mercury_data_libs__lp_rational__du_functor_desc_coeff_info_0_0

};

const MR_DuPtagLayout mercury_data_libs__lp_rational__du_ptag_ordered_coeff_info_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_libs__lp_rational__du_stag_ordered_coeff_info_0_0 }

};

const MR_DuFunctorDescPtr mercury_data_libs__lp_rational__du_name_ordered_coeff_info_0[] = {
	&mercury_data_libs__lp_rational__du_functor_desc_coeff_info_0_0
};

const MR_Integer mercury_data_libs__lp_rational__functor_number_map_coeff_info_0[] = {
	0 };
	
const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_coeff_info_0 = {
	0,
	13,
	1,
	MR_TYPECTOR_REP_DU,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__coeff_info_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__coeff_info_0_0)),
	"libs.lp_rational",
	"coeff_info",
	{ (void *)mercury_data_libs__lp_rational__du_name_ordered_coeff_info_0 },
	{ (void *)mercury_data_libs__lp_rational__du_ptag_ordered_coeff_info_0 },
	1,
	4,
	mercury_data_libs__lp_rational__functor_number_map_coeff_info_0
};

const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_coefficient_0 = {
	0,
	13,
	-1,
	MR_TYPECTOR_REP_EQUIV_GROUND,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__coefficient_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__coefficient_0_0)),
	"libs.lp_rational",
	"coefficient",
	{ 0 },
	{ (void *)&mercury_data_libs__rat__type_ctor_info_rat_0 },
	-1,
	0,
	NULL
};

const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_constant_0 = {
	0,
	13,
	-1,
	MR_TYPECTOR_REP_EQUIV_GROUND,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__constant_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__constant_0_0)),
	"libs.lp_rational",
	"constant",
	{ 0 },
	{ (void *)&mercury_data_libs__rat__type_ctor_info_rat_0 },
	-1,
	0,
	NULL
};

static const MR_FA_TypeInfo_Struct2 mercury_data_pair__ti_pair_2term__ti_var_1term__type_ctor_info_generic_0libs__rat__type_ctor_info_rat_0 = {
	&mercury_data_pair__type_ctor_info_pair_2,
{	(MR_TypeInfo) &mercury_data_term__ti_var_1term__type_ctor_info_generic_0,
	(MR_TypeInfo) &mercury_data_libs__rat__type_ctor_info_rat_0
}};

static const MR_FA_TypeInfo_Struct1 mercury_data_list__ti_list_1pair__ti_pair_2term__ti_var_1term__type_ctor_info_generic_0libs__rat__type_ctor_info_rat_0 = {
	&mercury_data_list__type_ctor_info_list_1,
{	(MR_TypeInfo) &mercury_data_pair__ti_pair_2term__ti_var_1term__type_ctor_info_generic_0libs__rat__type_ctor_info_rat_0
}};

const MR_PseudoTypeInfo mercury_data_libs__lp_rational__field_types_constraint_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_list__ti_list_1pair__ti_pair_2term__ti_var_1term__type_ctor_info_generic_0libs__rat__type_ctor_info_rat_0,
	(MR_PseudoTypeInfo) &mercury_data_libs__rat__type_ctor_info_rat_0
};

static const MR_DuFunctorDesc mercury_data_libs__lp_rational__du_functor_desc_constraint_0_0 = {
	"lte",
	2,
	0,
	MR_SECTAG_NONE,
	0,
	-1,
	0,
	(MR_PseudoTypeInfo *) mercury_data_libs__lp_rational__field_types_constraint_0_0,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_libs__lp_rational__field_types_constraint_0_1[] = {
	(MR_PseudoTypeInfo) &mercury_data_list__ti_list_1pair__ti_pair_2term__ti_var_1term__type_ctor_info_generic_0libs__rat__type_ctor_info_rat_0,
	(MR_PseudoTypeInfo) &mercury_data_libs__rat__type_ctor_info_rat_0
};

static const MR_DuFunctorDesc mercury_data_libs__lp_rational__du_functor_desc_constraint_0_1 = {
	"eq",
	2,
	0,
	MR_SECTAG_NONE,
	1,
	-1,
	1,
	(MR_PseudoTypeInfo *) mercury_data_libs__lp_rational__field_types_constraint_0_1,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_libs__lp_rational__field_types_constraint_0_2[] = {
	(MR_PseudoTypeInfo) &mercury_data_list__ti_list_1pair__ti_pair_2term__ti_var_1term__type_ctor_info_generic_0libs__rat__type_ctor_info_rat_0,
	(MR_PseudoTypeInfo) &mercury_data_libs__rat__type_ctor_info_rat_0
};

static const MR_DuFunctorDesc mercury_data_libs__lp_rational__du_functor_desc_constraint_0_2 = {
	"gte",
	2,
	0,
	MR_SECTAG_NONE,
	2,
	-1,
	2,
	(MR_PseudoTypeInfo *) mercury_data_libs__lp_rational__field_types_constraint_0_2,
	NULL,
	NULL
};

const MR_DuFunctorDescPtr mercury_data_libs__lp_rational__du_stag_ordered_constraint_0_0[] = {
	&mercury_data_libs__lp_rational__du_functor_desc_constraint_0_0

};

const MR_DuFunctorDescPtr mercury_data_libs__lp_rational__du_stag_ordered_constraint_0_1[] = {
	&mercury_data_libs__lp_rational__du_functor_desc_constraint_0_1

};

const MR_DuFunctorDescPtr mercury_data_libs__lp_rational__du_stag_ordered_constraint_0_2[] = {
	&mercury_data_libs__lp_rational__du_functor_desc_constraint_0_2

};

const MR_DuPtagLayout mercury_data_libs__lp_rational__du_ptag_ordered_constraint_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_libs__lp_rational__du_stag_ordered_constraint_0_0 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_libs__lp_rational__du_stag_ordered_constraint_0_1 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_libs__lp_rational__du_stag_ordered_constraint_0_2 }

};

const MR_DuFunctorDescPtr mercury_data_libs__lp_rational__du_name_ordered_constraint_0[] = {
	&mercury_data_libs__lp_rational__du_functor_desc_constraint_0_1,
	&mercury_data_libs__lp_rational__du_functor_desc_constraint_0_2,
	&mercury_data_libs__lp_rational__du_functor_desc_constraint_0_0
};

const MR_Integer mercury_data_libs__lp_rational__functor_number_map_constraint_0[] = {
	2,
	0,
	1 };
	
const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_constraint_0 = {
	0,
	13,
	3,
	MR_TYPECTOR_REP_DU,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__constraint_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__constraint_0_0)),
	"libs.lp_rational",
	"constraint",
	{ (void *)mercury_data_libs__lp_rational__du_name_ordered_constraint_0 },
	{ (void *)mercury_data_libs__lp_rational__du_ptag_ordered_constraint_0 },
	3,
	4,
	mercury_data_libs__lp_rational__functor_number_map_constraint_0
};

static const MR_FA_TypeInfo_Struct1 mercury_data_list__ti_list_1libs__lp_rational__type_ctor_info_constraint_0 = {
	&mercury_data_list__type_ctor_info_list_1,
{	(MR_TypeInfo) &mercury_data_libs__lp_rational__type_ctor_info_constraint_0
}};

const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_constraints_0 = {
	0,
	13,
	-1,
	MR_TYPECTOR_REP_EQUIV_GROUND,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__constraints_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__constraints_0_0)),
	"libs.lp_rational",
	"constraints",
	{ 0 },
	{ (void *)&mercury_data_list__ti_list_1libs__lp_rational__type_ctor_info_constraint_0 },
	-1,
	0,
	NULL
};

static const MR_EnumFunctorDesc mercury_data_libs__lp_rational__enum_functor_desc_direction_0_0 = {
	"max",
	0
};

static const MR_EnumFunctorDesc mercury_data_libs__lp_rational__enum_functor_desc_direction_0_1 = {
	"min",
	1
};

const MR_EnumFunctorDescPtr mercury_data_libs__lp_rational__enum_value_ordered_direction_0[] = {
	&mercury_data_libs__lp_rational__enum_functor_desc_direction_0_0,
	&mercury_data_libs__lp_rational__enum_functor_desc_direction_0_1
};

const MR_EnumFunctorDescPtr mercury_data_libs__lp_rational__enum_name_ordered_direction_0[] = {
	&mercury_data_libs__lp_rational__enum_functor_desc_direction_0_0,
	&mercury_data_libs__lp_rational__enum_functor_desc_direction_0_1
};

const MR_Integer mercury_data_libs__lp_rational__functor_number_map_direction_0[] = {
	0,
	1 };
	
const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_direction_0 = {
	0,
	13,
	-1,
	MR_TYPECTOR_REP_ENUM,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__direction_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__direction_0_0)),
	"libs.lp_rational",
	"direction",
	{ (void *)mercury_data_libs__lp_rational__enum_name_ordered_direction_0 },
	{ (void *)mercury_data_libs__lp_rational__enum_value_ordered_direction_0 },
	2,
	4,
	mercury_data_libs__lp_rational__functor_number_map_direction_0
};

static const MR_EnumFunctorDesc mercury_data_libs__lp_rational__enum_functor_desc_entailment_result_0_0 = {
	"entailed",
	0
};

static const MR_EnumFunctorDesc mercury_data_libs__lp_rational__enum_functor_desc_entailment_result_0_1 = {
	"not_entailed",
	1
};

static const MR_EnumFunctorDesc mercury_data_libs__lp_rational__enum_functor_desc_entailment_result_0_2 = {
	"inconsistent",
	2
};

const MR_EnumFunctorDescPtr mercury_data_libs__lp_rational__enum_value_ordered_entailment_result_0[] = {
	&mercury_data_libs__lp_rational__enum_functor_desc_entailment_result_0_0,
	&mercury_data_libs__lp_rational__enum_functor_desc_entailment_result_0_1,
	&mercury_data_libs__lp_rational__enum_functor_desc_entailment_result_0_2
};

const MR_EnumFunctorDescPtr mercury_data_libs__lp_rational__enum_name_ordered_entailment_result_0[] = {
	&mercury_data_libs__lp_rational__enum_functor_desc_entailment_result_0_0,
	&mercury_data_libs__lp_rational__enum_functor_desc_entailment_result_0_2,
	&mercury_data_libs__lp_rational__enum_functor_desc_entailment_result_0_1
};

const MR_Integer mercury_data_libs__lp_rational__functor_number_map_entailment_result_0[] = {
	0,
	2,
	1 };
	
const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_entailment_result_0 = {
	0,
	13,
	-1,
	MR_TYPECTOR_REP_ENUM,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__entailment_result_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__entailment_result_0_0)),
	"libs.lp_rational",
	"entailment_result",
	{ (void *)mercury_data_libs__lp_rational__enum_name_ordered_entailment_result_0 },
	{ (void *)mercury_data_libs__lp_rational__enum_value_ordered_entailment_result_0 },
	3,
	4,
	mercury_data_libs__lp_rational__functor_number_map_entailment_result_0
};

static const MR_FA_TypeInfo_Struct1 mercury_data_varset__ti_varset_1term__type_ctor_info_generic_0 = {
	&mercury_data_varset__type_ctor_info_varset_1,
{	(MR_TypeInfo) &mercury_data_term__type_ctor_info_generic_0
}};

static const MR_FA_TypeInfo_Struct1 mercury_data_list__ti_list_1term__ti_var_1term__type_ctor_info_generic_0 = {
	&mercury_data_list__type_ctor_info_list_1,
{	(MR_TypeInfo) &mercury_data_term__ti_var_1term__type_ctor_info_generic_0
}};

const MR_PseudoTypeInfo mercury_data_libs__lp_rational__field_types_lp_info_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_varset__ti_varset_1term__type_ctor_info_generic_0,
	(MR_PseudoTypeInfo) &mercury_data_list__ti_list_1term__ti_var_1term__type_ctor_info_generic_0,
	(MR_PseudoTypeInfo) &mercury_data_list__ti_list_1term__ti_var_1term__type_ctor_info_generic_0
};

const MR_ConstString mercury_data_libs__lp_rational__field_names_lp_info_0_0[] = {
	"varset",
	"slack_vars",
	"art_vars"
};

static const MR_DuFunctorDesc mercury_data_libs__lp_rational__du_functor_desc_lp_info_0_0 = {
	"lp",
	3,
	0,
	MR_SECTAG_NONE,
	0,
	-1,
	0,
	(MR_PseudoTypeInfo *) mercury_data_libs__lp_rational__field_types_lp_info_0_0,
	mercury_data_libs__lp_rational__field_names_lp_info_0_0,
	NULL
};

const MR_DuFunctorDescPtr mercury_data_libs__lp_rational__du_stag_ordered_lp_info_0_0[] = {
	&mercury_data_libs__lp_rational__du_functor_desc_lp_info_0_0

};

const MR_DuPtagLayout mercury_data_libs__lp_rational__du_ptag_ordered_lp_info_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_libs__lp_rational__du_stag_ordered_lp_info_0_0 }

};

const MR_DuFunctorDescPtr mercury_data_libs__lp_rational__du_name_ordered_lp_info_0[] = {
	&mercury_data_libs__lp_rational__du_functor_desc_lp_info_0_0
};

const MR_Integer mercury_data_libs__lp_rational__functor_number_map_lp_info_0[] = {
	0 };
	
const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_lp_info_0 = {
	0,
	13,
	1,
	MR_TYPECTOR_REP_DU,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__lp_info_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__lp_info_0_0)),
	"libs.lp_rational",
	"lp_info",
	{ (void *)mercury_data_libs__lp_rational__du_name_ordered_lp_info_0 },
	{ (void *)mercury_data_libs__lp_rational__du_ptag_ordered_lp_info_0 },
	1,
	4,
	mercury_data_libs__lp_rational__functor_number_map_lp_info_0
};

static const MR_EnumFunctorDesc mercury_data_libs__lp_rational__enum_functor_desc_lp_operator_0_0 = {
	"lp_lt_eq",
	0
};

static const MR_EnumFunctorDesc mercury_data_libs__lp_rational__enum_functor_desc_lp_operator_0_1 = {
	"lp_eq",
	1
};

static const MR_EnumFunctorDesc mercury_data_libs__lp_rational__enum_functor_desc_lp_operator_0_2 = {
	"lp_gt_eq",
	2
};

const MR_EnumFunctorDescPtr mercury_data_libs__lp_rational__enum_value_ordered_lp_operator_0[] = {
	&mercury_data_libs__lp_rational__enum_functor_desc_lp_operator_0_0,
	&mercury_data_libs__lp_rational__enum_functor_desc_lp_operator_0_1,
	&mercury_data_libs__lp_rational__enum_functor_desc_lp_operator_0_2
};

const MR_EnumFunctorDescPtr mercury_data_libs__lp_rational__enum_name_ordered_lp_operator_0[] = {
	&mercury_data_libs__lp_rational__enum_functor_desc_lp_operator_0_1,
	&mercury_data_libs__lp_rational__enum_functor_desc_lp_operator_0_2,
	&mercury_data_libs__lp_rational__enum_functor_desc_lp_operator_0_0
};

const MR_Integer mercury_data_libs__lp_rational__functor_number_map_lp_operator_0[] = {
	2,
	0,
	1 };
	
const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_lp_operator_0 = {
	0,
	13,
	-1,
	MR_TYPECTOR_REP_ENUM,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__lp_operator_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__lp_operator_0_0)),
	"libs.lp_rational",
	"lp_operator",
	{ (void *)mercury_data_libs__lp_rational__enum_name_ordered_lp_operator_0 },
	{ (void *)mercury_data_libs__lp_rational__enum_value_ordered_lp_operator_0 },
	3,
	4,
	mercury_data_libs__lp_rational__functor_number_map_lp_operator_0
};

static const MR_DuFunctorDesc mercury_data_libs__lp_rational__du_functor_desc_lp_result_0_0 = {
	"lp_res_unbounded",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_libs__lp_rational__du_functor_desc_lp_result_0_1 = {
	"lp_res_inconsistent",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	1,
	1,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};

static const MR_FA_TypeInfo_Struct2 mercury_data_tree234__ti_tree234_2term__ti_var_1term__type_ctor_info_generic_0libs__rat__type_ctor_info_rat_0 = {
	&mercury_data_tree234__type_ctor_info_tree234_2,
{	(MR_TypeInfo) &mercury_data_term__ti_var_1term__type_ctor_info_generic_0,
	(MR_TypeInfo) &mercury_data_libs__rat__type_ctor_info_rat_0
}};

const MR_PseudoTypeInfo mercury_data_libs__lp_rational__field_types_lp_result_0_2[] = {
	(MR_PseudoTypeInfo) &mercury_data_libs__rat__type_ctor_info_rat_0,
	(MR_PseudoTypeInfo) &mercury_data_tree234__ti_tree234_2term__ti_var_1term__type_ctor_info_generic_0libs__rat__type_ctor_info_rat_0
};

static const MR_DuFunctorDesc mercury_data_libs__lp_rational__du_functor_desc_lp_result_0_2 = {
	"lp_res_satisfiable",
	2,
	0,
	MR_SECTAG_NONE,
	1,
	-1,
	2,
	(MR_PseudoTypeInfo *) mercury_data_libs__lp_rational__field_types_lp_result_0_2,
	NULL,
	NULL
};

const MR_DuFunctorDescPtr mercury_data_libs__lp_rational__du_stag_ordered_lp_result_0_0[] = {
	&mercury_data_libs__lp_rational__du_functor_desc_lp_result_0_0,
	&mercury_data_libs__lp_rational__du_functor_desc_lp_result_0_1

};

const MR_DuFunctorDescPtr mercury_data_libs__lp_rational__du_stag_ordered_lp_result_0_1[] = {
	&mercury_data_libs__lp_rational__du_functor_desc_lp_result_0_2

};

const MR_DuPtagLayout mercury_data_libs__lp_rational__du_ptag_ordered_lp_result_0[] = {
	{ 2, MR_SECTAG_LOCAL,
	mercury_data_libs__lp_rational__du_stag_ordered_lp_result_0_0 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_libs__lp_rational__du_stag_ordered_lp_result_0_1 }

};

const MR_DuFunctorDescPtr mercury_data_libs__lp_rational__du_name_ordered_lp_result_0[] = {
	&mercury_data_libs__lp_rational__du_functor_desc_lp_result_0_1,
	&mercury_data_libs__lp_rational__du_functor_desc_lp_result_0_2,
	&mercury_data_libs__lp_rational__du_functor_desc_lp_result_0_0
};

const MR_Integer mercury_data_libs__lp_rational__functor_number_map_lp_result_0[] = {
	2,
	0,
	1 };
	
const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_lp_result_0 = {
	0,
	13,
	2,
	MR_TYPECTOR_REP_DU,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__lp_result_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__lp_result_0_0)),
	"libs.lp_rational",
	"lp_result",
	{ (void *)mercury_data_libs__lp_rational__du_name_ordered_lp_result_0 },
	{ (void *)mercury_data_libs__lp_rational__du_ptag_ordered_lp_result_0 },
	3,
	4,
	mercury_data_libs__lp_rational__functor_number_map_lp_result_0
};

const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_lp_term_0 = {
	0,
	13,
	-1,
	MR_TYPECTOR_REP_EQUIV_GROUND,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__lp_term_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__lp_term_0_0)),
	"libs.lp_rational",
	"lp_term",
	{ 0 },
	{ (void *)&mercury_data_pair__ti_pair_2term__ti_var_1term__type_ctor_info_generic_0libs__rat__type_ctor_info_rat_0 },
	-1,
	0,
	NULL
};

const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_lp_terms_0 = {
	0,
	13,
	-1,
	MR_TYPECTOR_REP_EQUIV_GROUND,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__lp_terms_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__lp_terms_0_0)),
	"libs.lp_rational",
	"lp_terms",
	{ 0 },
	{ (void *)&mercury_data_list__ti_list_1pair__ti_pair_2term__ti_var_1term__type_ctor_info_generic_0libs__rat__type_ctor_info_rat_0 },
	-1,
	0,
	NULL
};

const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_lp_var_0 = {
	0,
	13,
	-1,
	MR_TYPECTOR_REP_EQUIV_GROUND,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__lp_var_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__lp_var_0_0)),
	"libs.lp_rational",
	"lp_var",
	{ 0 },
	{ (void *)&mercury_data_term__ti_var_1term__type_ctor_info_generic_0 },
	-1,
	0,
	NULL
};

const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_lp_vars_0 = {
	0,
	13,
	-1,
	MR_TYPECTOR_REP_EQUIV_GROUND,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__lp_vars_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__lp_vars_0_0)),
	"libs.lp_rational",
	"lp_vars",
	{ 0 },
	{ (void *)&mercury_data_list__ti_list_1term__ti_var_1term__type_ctor_info_generic_0 },
	-1,
	0,
	NULL
};

const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_lp_varset_0 = {
	0,
	13,
	-1,
	MR_TYPECTOR_REP_EQUIV_GROUND,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__lp_varset_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__lp_varset_0_0)),
	"libs.lp_rational",
	"lp_varset",
	{ 0 },
	{ (void *)&mercury_data_varset__ti_varset_1term__type_ctor_info_generic_0 },
	-1,
	0,
	NULL
};

static const MR_FA_TypeInfo_Struct1 mercury_data_list__ti_list_1libs__lp_rational__type_ctor_info_vector_0 = {
	&mercury_data_list__type_ctor_info_list_1,
{	(MR_TypeInfo) &mercury_data_libs__lp_rational__type_ctor_info_vector_0
}};

const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_matrix_0 = {
	0,
	13,
	-1,
	MR_TYPECTOR_REP_EQUIV_GROUND,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__matrix_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__matrix_0_0)),
	"libs.lp_rational",
	"matrix",
	{ 0 },
	{ (void *)&mercury_data_list__ti_list_1libs__lp_rational__type_ctor_info_vector_0 },
	-1,
	0,
	NULL
};

const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_objective_0 = {
	0,
	13,
	-1,
	MR_TYPECTOR_REP_EQUIV_GROUND,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__objective_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__objective_0_0)),
	"libs.lp_rational",
	"objective",
	{ 0 },
	{ (void *)&mercury_data_list__ti_list_1pair__ti_pair_2term__ti_var_1term__type_ctor_info_generic_0libs__rat__type_ctor_info_rat_0 },
	-1,
	0,
	NULL
};

static const MR_VA_TypeInfo_Struct2 mercury_data___vti_func_2term__ti_var_1term__type_ctor_info_generic_0builtin__type_ctor_info_string_0 = {
	&mercury_data_builtin__type_ctor_info_func_0,
	2,
{	(MR_TypeInfo) &mercury_data_term__ti_var_1term__type_ctor_info_generic_0,
	(MR_TypeInfo) &mercury_data_builtin__type_ctor_info_string_0
}};

const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_output_var_0 = {
	0,
	13,
	-1,
	MR_TYPECTOR_REP_EQUIV_GROUND,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__output_var_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__output_var_0_0)),
	"libs.lp_rational",
	"output_var",
	{ 0 },
	{ (void *)&mercury_data___vti_func_2term__ti_var_1term__type_ctor_info_generic_0builtin__type_ctor_info_string_0 },
	-1,
	0,
	NULL
};

const MR_PseudoTypeInfo mercury_data_libs__lp_rational__field_types_projection_result_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_list__ti_list_1libs__lp_rational__type_ctor_info_constraint_0
};

static const MR_DuFunctorDesc mercury_data_libs__lp_rational__du_functor_desc_projection_result_0_0 = {
	"pr_res_ok",
	1,
	0,
	MR_SECTAG_NONE,
	1,
	-1,
	0,
	(MR_PseudoTypeInfo *) mercury_data_libs__lp_rational__field_types_projection_result_0_0,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_libs__lp_rational__du_functor_desc_projection_result_0_1 = {
	"pr_res_inconsistent",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	0,
	1,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_libs__lp_rational__du_functor_desc_projection_result_0_2 = {
	"pr_res_aborted",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	1,
	2,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};

const MR_DuFunctorDescPtr mercury_data_libs__lp_rational__du_stag_ordered_projection_result_0_0[] = {
	&mercury_data_libs__lp_rational__du_functor_desc_projection_result_0_1,
	&mercury_data_libs__lp_rational__du_functor_desc_projection_result_0_2

};

const MR_DuFunctorDescPtr mercury_data_libs__lp_rational__du_stag_ordered_projection_result_0_1[] = {
	&mercury_data_libs__lp_rational__du_functor_desc_projection_result_0_0

};

const MR_DuPtagLayout mercury_data_libs__lp_rational__du_ptag_ordered_projection_result_0[] = {
	{ 2, MR_SECTAG_LOCAL,
	mercury_data_libs__lp_rational__du_stag_ordered_projection_result_0_0 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_libs__lp_rational__du_stag_ordered_projection_result_0_1 }

};

const MR_DuFunctorDescPtr mercury_data_libs__lp_rational__du_name_ordered_projection_result_0[] = {
	&mercury_data_libs__lp_rational__du_functor_desc_projection_result_0_2,
	&mercury_data_libs__lp_rational__du_functor_desc_projection_result_0_1,
	&mercury_data_libs__lp_rational__du_functor_desc_projection_result_0_0
};

const MR_Integer mercury_data_libs__lp_rational__functor_number_map_projection_result_0[] = {
	2,
	1,
	0 };
	
const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_projection_result_0 = {
	0,
	13,
	2,
	MR_TYPECTOR_REP_DU,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__projection_result_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__projection_result_0_0)),
	"libs.lp_rational",
	"projection_result",
	{ (void *)mercury_data_libs__lp_rational__du_name_ordered_projection_result_0 },
	{ (void *)mercury_data_libs__lp_rational__du_ptag_ordered_projection_result_0 },
	3,
	4,
	mercury_data_libs__lp_rational__functor_number_map_projection_result_0
};

static const MR_FA_TypeInfo_Struct2 mercury_data_tree234__ti_tree234_2term__ti_var_1term__type_ctor_info_generic_0builtin__type_ctor_info_int_0 = {
	&mercury_data_tree234__type_ctor_info_tree234_2,
{	(MR_TypeInfo) &mercury_data_term__ti_var_1term__type_ctor_info_generic_0,
	(MR_TypeInfo) &mercury_data_builtin__type_ctor_info_int_0
}};

static const MR_FA_TypeInfo_Struct1 mercury_data_list__ti_list_1builtin__type_ctor_info_int_0 = {
	&mercury_data_list__type_ctor_info_list_1,
{	(MR_TypeInfo) &mercury_data_builtin__type_ctor_info_int_0
}};

static const MR_FA_TypeInfo_Struct2 mercury_data_pair__ti_pair_2builtin__type_ctor_info_int_0builtin__type_ctor_info_int_0 = {
	&mercury_data_pair__type_ctor_info_pair_2,
{	(MR_TypeInfo) &mercury_data_builtin__type_ctor_info_int_0,
	(MR_TypeInfo) &mercury_data_builtin__type_ctor_info_int_0
}};

static const MR_FA_TypeInfo_Struct2 mercury_data_tree234__ti_tree234_2pair__ti_pair_2builtin__type_ctor_info_int_0builtin__type_ctor_info_int_0libs__rat__type_ctor_info_rat_0 = {
	&mercury_data_tree234__type_ctor_info_tree234_2,
{	(MR_TypeInfo) &mercury_data_pair__ti_pair_2builtin__type_ctor_info_int_0builtin__type_ctor_info_int_0,
	(MR_TypeInfo) &mercury_data_libs__rat__type_ctor_info_rat_0
}};

const MR_PseudoTypeInfo mercury_data_libs__lp_rational__field_types_tableau_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_builtin__type_ctor_info_int_0,
	(MR_PseudoTypeInfo) &mercury_data_builtin__type_ctor_info_int_0,
	(MR_PseudoTypeInfo) &mercury_data_tree234__ti_tree234_2term__ti_var_1term__type_ctor_info_generic_0builtin__type_ctor_info_int_0,
	(MR_PseudoTypeInfo) &mercury_data_list__ti_list_1builtin__type_ctor_info_int_0,
	(MR_PseudoTypeInfo) &mercury_data_list__ti_list_1builtin__type_ctor_info_int_0,
	(MR_PseudoTypeInfo) &mercury_data_tree234__ti_tree234_2pair__ti_pair_2builtin__type_ctor_info_int_0builtin__type_ctor_info_int_0libs__rat__type_ctor_info_rat_0
};

const MR_ConstString mercury_data_libs__lp_rational__field_names_tableau_0_0[] = {
	"rows",
	"cols",
	"var_nums",
	"shunned_rows",
	"shunned_cols",
	"cells"
};

static const MR_DuFunctorDesc mercury_data_libs__lp_rational__du_functor_desc_tableau_0_0 = {
	"tableau",
	6,
	0,
	MR_SECTAG_NONE,
	0,
	-1,
	0,
	(MR_PseudoTypeInfo *) mercury_data_libs__lp_rational__field_types_tableau_0_0,
	mercury_data_libs__lp_rational__field_names_tableau_0_0,
	NULL
};

const MR_DuFunctorDescPtr mercury_data_libs__lp_rational__du_stag_ordered_tableau_0_0[] = {
	&mercury_data_libs__lp_rational__du_functor_desc_tableau_0_0

};

const MR_DuPtagLayout mercury_data_libs__lp_rational__du_ptag_ordered_tableau_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_libs__lp_rational__du_stag_ordered_tableau_0_0 }

};

const MR_DuFunctorDescPtr mercury_data_libs__lp_rational__du_name_ordered_tableau_0[] = {
	&mercury_data_libs__lp_rational__du_functor_desc_tableau_0_0
};

const MR_Integer mercury_data_libs__lp_rational__functor_number_map_tableau_0[] = {
	0 };
	
const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_tableau_0 = {
	0,
	13,
	1,
	MR_TYPECTOR_REP_DU,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__tableau_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__tableau_0_0)),
	"libs.lp_rational",
	"tableau",
	{ (void *)mercury_data_libs__lp_rational__du_name_ordered_tableau_0 },
	{ (void *)mercury_data_libs__lp_rational__du_ptag_ordered_tableau_0 },
	1,
	4,
	mercury_data_libs__lp_rational__functor_number_map_tableau_0
};

const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_var_num_map_0 = {
	0,
	13,
	-1,
	MR_TYPECTOR_REP_EQUIV_GROUND,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__var_num_map_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__var_num_map_0_0)),
	"libs.lp_rational",
	"var_num_map",
	{ 0 },
	{ (void *)&mercury_data_tree234__ti_tree234_2term__ti_var_1term__type_ctor_info_generic_0builtin__type_ctor_info_int_0 },
	-1,
	0,
	NULL
};

static const MR_FA_TypeInfo_Struct1 mercury_data_set_ordlist__ti_set_ordlist_1builtin__type_ctor_info_int_0 = {
	&mercury_data_set_ordlist__type_ctor_info_set_ordlist_1,
{	(MR_TypeInfo) &mercury_data_builtin__type_ctor_info_int_0
}};

const MR_PseudoTypeInfo mercury_data_libs__lp_rational__field_types_vector_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_set_ordlist__ti_set_ordlist_1builtin__type_ctor_info_int_0,
	(MR_PseudoTypeInfo) &mercury_data_tree234__ti_tree234_2term__ti_var_1term__type_ctor_info_generic_0libs__rat__type_ctor_info_rat_0,
	(MR_PseudoTypeInfo) &mercury_data_libs__rat__type_ctor_info_rat_0
};

const MR_ConstString mercury_data_libs__lp_rational__field_names_vector_0_0[] = {
	"label",
	"terms",
	"const"
};

static const MR_DuFunctorDesc mercury_data_libs__lp_rational__du_functor_desc_vector_0_0 = {
	"vector",
	3,
	0,
	MR_SECTAG_NONE,
	0,
	-1,
	0,
	(MR_PseudoTypeInfo *) mercury_data_libs__lp_rational__field_types_vector_0_0,
	mercury_data_libs__lp_rational__field_names_vector_0_0,
	NULL
};

const MR_DuFunctorDescPtr mercury_data_libs__lp_rational__du_stag_ordered_vector_0_0[] = {
	&mercury_data_libs__lp_rational__du_functor_desc_vector_0_0

};

const MR_DuPtagLayout mercury_data_libs__lp_rational__du_ptag_ordered_vector_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_libs__lp_rational__du_stag_ordered_vector_0_0 }

};

const MR_DuFunctorDescPtr mercury_data_libs__lp_rational__du_name_ordered_vector_0[] = {
	&mercury_data_libs__lp_rational__du_functor_desc_vector_0_0
};

const MR_Integer mercury_data_libs__lp_rational__functor_number_map_vector_0[] = {
	0 };
	
const MR_TypeCtorInfo_Struct mercury_data_libs__lp_rational__type_ctor_info_vector_0 = {
	0,
	13,
	1,
	MR_TYPECTOR_REP_DU,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___libs__lp_rational__vector_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___libs__lp_rational__vector_0_0)),
	"libs.lp_rational",
	"vector",
	{ (void *)mercury_data_libs__lp_rational__du_name_ordered_vector_0 },
	{ (void *)mercury_data_libs__lp_rational__du_ptag_ordered_vector_0 },
	1,
	4,
	mercury_data_libs__lp_rational__functor_number_map_vector_0
};


static const MR_UserClosureId
mercury_data__closure_layout__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0_3 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"eliminate_var",
8,
0
},
"libs.lp_rational",
"lp_rational.m",
1738,
"d2;c10;t;c3;?;c1;"
};

static const MR_UserClosureId
mercury_data__closure_layout__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0_2 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"classify_vector",
10,
0
},
"libs.lp_rational",
"lp_rational.m",
1768,
"d1;c7;"
};

static const MR_UserClosureId
mercury_data__closure_layout__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"classify_vector",
10,
0
},
"libs.lp_rational",
"lp_rational.m",
1768,
"d1;c7;"
};

static const MR_UserClosureId
mercury_data__closure_layout__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0_3 = {
{
MR_FUNCTION,
"libs.lp_rational",
"libs.lp_rational",
"vector_to_constraint",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
1530,
"d1;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0_2 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"fm_standardize",
5,
0
},
"libs.lp_rational",
"lp_rational.m",
1502,
"d1;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_1557",
1,
0
},
"libs.lp_rational",
"lp_rational.m",
1557,
"d1;c6;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1345__1_2_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_1347",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
1347,
"d1;c3;q;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__output_constraint_4_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"output_term",
4,
0
},
"libs.lp_rational",
"lp_rational.m",
2409,
"d1;c8;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__output_constraint_2_5_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"output_term",
4,
0
},
"libs.lp_rational",
"lp_rational.m",
2409,
"d1;c8;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__write_constraint_4_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"write_constr_term",
4,
0
},
"libs.lp_rational",
"lp_rational.m",
2311,
"c4;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__count_coeffs_in_vector_2_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"count_coeff",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
2013,
"d1;c6;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__add_vectors_6_0_2 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_2111",
4,
0
},
"libs.lp_rational",
"lp_rational.m",
2111,
"d1;c8;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__add_vectors_6_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_2108",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
2108,
"d1;c7;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__eliminate_var_8_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"combine_vectors",
8,
0
},
"libs.lp_rational",
"lp_rational.m",
1794,
"d1;c9;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__classify_vector_10_0_1 = {
{
MR_FUNCTION,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_2062",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
2062,
"d1;c6;t;c4;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__fm_standardize_5_0_2 = {
{
MR_FUNCTION,
"libs.rat",
"libs.rat",
"-",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
931,
"d1;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__fm_standardize_5_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lp_terms_to_map_2",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
427,
"d1;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__extract_obj_var_3_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_1024",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
1024,
"d1;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__set_vars_to_zero_2_2_0_3 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_713",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
713,
"d1;c4;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__set_vars_to_zero_2_2_0_2 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_713",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
713,
"d1;c4;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__set_vars_to_zero_2_2_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_713",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
713,
"d1;c4;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__substitute_vars_2_2_0_4 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lp_terms_to_map_2",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
427,
"d1;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__substitute_vars_2_2_0_3 = {
{
MR_FUNCTION,
"libs.lp_rational",
"libs.lp_rational",
"substitute_term",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
686,
"d1;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__substitute_vars_2_2_0_2 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lp_terms_to_map_2",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
427,
"d1;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__substitute_vars_2_2_0_1 = {
{
MR_FUNCTION,
"libs.lp_rational",
"libs.lp_rational",
"substitute_term",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
689,
"d2;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__write_constraints_4_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"write_constraint",
4,
0
},
"libs.lp_rational",
"lp_rational.m",
2304,
"d1;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__output_constraints_4_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"output_constraint",
4,
0
},
"libs.lp_rational",
"lp_rational.m",
2380,
"d1;c8;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__duffin_heuristic_4_0_4 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"relevant",
1,
0
},
"libs.lp_rational",
"lp_rational.m",
1953,
"d2;c9;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__duffin_heuristic_4_0_3 = {
{
MR_FUNCTION,
"libs.lp_rational",
"libs.lp_rational",
"make_expansion_num",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
1998,
"d1;c11;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__duffin_heuristic_4_0_2 = {
{
MR_FUNCTION,
"libs.lp_rational",
"libs.lp_rational",
"count_coeffs_in_vector",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
1995,
"d1;c7;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__duffin_heuristic_4_0_1 = {
{
MR_FUNCTION,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_2037",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
2037,
"d1;c4;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__substitute_variable_7_0_4 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_1635",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
1635,
"d1;c10;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__substitute_variable_7_0_3 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_1635",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
1635,
"d1;c10;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__substitute_variable_7_0_2 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_1635",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
1635,
"d1;c10;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__substitute_variable_7_0_1 = {
{
MR_FUNCTION,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_2088",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
2088,
"d1;c5;t;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__substitute_into_constraint_6_0_1 = {
{
MR_FUNCTION,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_2088",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
2088,
"d1;c5;t;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__nonneg_box_2_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_749",
4,
0
},
"libs.lp_rational",
"lp_rational.m",
746,
"d1;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__bounding_box_2_0_1 = {
{
MR_FUNCTION,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_726",
4,
0
},
"libs.lp_rational",
"lp_rational.m",
726,
"d1;c6;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__get_vars_from_constraints_1_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"get_vars_from_constraint",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
2257,
"d1;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__set_vars_to_zero_2_0_1 = {
{
MR_FUNCTION,
"libs.lp_rational",
"libs.lp_rational",
"set_vars_to_zero_2",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
699,
"d1;c4;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__substitute_vars_2_0_1 = {
{
MR_FUNCTION,
"libs.lp_rational",
"libs.lp_rational",
"substitute_vars_2",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
681,
"d1;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__substitute_vars_3_0_1 = {
{
MR_FUNCTION,
"libs.lp_rational",
"libs.lp_rational",
"substitute_vars_2",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
679,
"d1;c7;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__remove_weaker_1_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"remove_weaker_2",
6,
0
},
"libs.lp_rational",
"lp_rational.m",
645,
"d2;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__solve_2_6_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lp_standardize_constraint",
4,
0
},
"libs.lp_rational",
"lp_rational.m",
886,
"d1;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__collect_vars_2_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_945",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
945,
"d1;c4;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__negate_constraint_1_0_3 = {
{
MR_FUNCTION,
"libs.rat",
"libs.rat",
"-",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
931,
"d1;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__negate_constraint_1_0_2 = {
{
MR_FUNCTION,
"libs.rat",
"libs.rat",
"-",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
931,
"d1;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__negate_constraint_1_0_1 = {
{
MR_FUNCTION,
"libs.rat",
"libs.rat",
"-",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
931,
"d1;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__two_phase_5_0_2 = {
{
MR_FUNCTION,
"libs.lp_rational",
"libs.lp_rational",
"extract_obj_var",
4,
0
},
"libs.lp_rational",
"lp_rational.m",
1011,
"d1;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__two_phase_5_0_1 = {
{
MR_FUNCTION,
"libs.lp_rational",
"libs.lp_rational",
"lp_term",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
850,
"d1;c8;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__get_basis_vars_1_0_2 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_1357",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
1357,
"d1;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__get_basis_vars_1_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_1345",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
1345,
"d1;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__fix_basis_and_rem_cols_3_0_3 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_1152",
4,
0
},
"libs.lp_rational",
"lp_rational.m",
1152,
"d2;c9;t;c1;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__fix_basis_and_rem_cols_3_0_2 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"all_rows",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
1148,
"d2;c6;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__fix_basis_and_rem_cols_3_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_1144",
5,
0
},
"libs.lp_rational",
"lp_rational.m",
1144,
"d2;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__ensure_zero_obj_coeffs_3_0_3 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_1227",
6,
0
},
"libs.lp_rational",
"lp_rational.m",
1227,
"d1;c7;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__ensure_zero_obj_coeffs_3_0_2 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"all_cols0",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
1226,
"d1;c6;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__ensure_zero_obj_coeffs_3_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_1115",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
1115,
"d2;c7;e;c1;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__one_phase_4_0_1 = {
{
MR_FUNCTION,
"libs.lp_rational",
"libs.lp_rational",
"extract_obj_var",
4,
0
},
"libs.lp_rational",
"lp_rational.m",
1011,
"d1;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__optimize_4_0_1 = {
{
MR_FUNCTION,
"libs.lp_rational",
"libs.lp_rational",
"extract_obj_var",
4,
0
},
"libs.lp_rational",
"lp_rational.m",
1011,
"d1;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__simplex_3_0_4 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_1072",
5,
0
},
"libs.lp_rational",
"lp_rational.m",
1054,
"d1;c8;d2;c4;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__simplex_3_0_3 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"all_rows",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
1053,
"d1;c8;d2;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__simplex_3_0_2 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_1041",
4,
0
},
"libs.lp_rational",
"lp_rational.m",
1036,
"d1;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__simplex_3_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"all_cols",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
1035,
"d1;c4;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__pivot_4_0_6 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_1211",
5,
0
},
"libs.lp_rational",
"lp_rational.m",
1211,
"d1;c13;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__pivot_4_0_5 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"all_cols0",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
1210,
"d1;c12;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__pivot_4_0_4 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_1205",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
1205,
"d1;c10;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__pivot_4_0_3 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_1201",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
1201,
"d1;c9;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__pivot_4_0_2 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_1189",
6,
0
},
"libs.lp_rational",
"lp_rational.m",
1189,
"d1;c7;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__pivot_4_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_1182",
4,
0
},
"libs.lp_rational",
"lp_rational.m",
1182,
"d1;c6;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__check_for_equalities_5_0_1 = {
{
MR_FUNCTION,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_2198",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
2198,
"d1;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__construct_constraint_3_0_3 = {
{
MR_FUNCTION,
"libs.rat",
"libs.rat",
"-",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
931,
"d1;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__construct_constraint_3_0_2 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lp_terms_to_map_2",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
427,
"d1;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__construct_constraint_3_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lp_terms_to_map_2",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
427,
"d1;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__negate_lp_terms_1_0_1 = {
{
MR_FUNCTION,
"libs.rat",
"libs.rat",
"-",
2,
0
},
"libs.lp_rational",
"lp_rational.m",
931,
"d1;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__normalize_terms_and_const_5_0_2 = {
{
MR_FUNCTION,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_580",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
580,
"d1;c8;t;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__libs__lp_rational__normalize_terms_and_const_5_0_1 = {
{
MR_FUNCTION,
"libs.lp_rational",
"libs.lp_rational",
"lambda_lp_rational_m_562",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
562,
"d1;c6;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__sum_like_terms_1_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lp_terms_to_map_2",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
427,
"d1;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__libs__lp_rational__lp_terms_to_map_1_0_1 = {
{
MR_PREDICATE,
"libs.lp_rational",
"libs.lp_rational",
"lp_terms_to_map_2",
3,
0
},
"libs.lp_rational",
"lp_rational.m",
427,
"d1;c3;"
};


MR_decl_entry(fn__libs__rat__one_0_0);

MR_BEGIN_MODULE(libs__lp_rational_module0)
	MR_init_entry1(fn__libs__lp_rational__lp_term_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__lp_term_1_0);
	MR_init_label1(fn__libs__lp_rational__lp_term_1_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'lp_term'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__libs__lp_rational__lp_term_1_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		fn__libs__lp_rational__lp_term_1_0_i2);
MR_def_label(fn__libs__lp_rational__lp_term_1_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(1);
	MR_tfield(0, MR_r2, 1) = MR_r1;
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(2);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__map__init_0_0);
MR_decl_entry(list__foldl_4_0);

MR_BEGIN_MODULE(libs__lp_rational_module1)
	MR_init_entry1(fn__libs__lp_rational__lp_terms_to_map_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__lp_terms_to_map_1_0);
	MR_init_label1(fn__libs__lp_rational__lp_terms_to_map_1_0,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'lp_terms_to_map'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__lp_terms_to_map_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_sv(3) = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__map__init_0_0,
		fn__libs__lp_rational__lp_terms_to_map_1_0_i3);
MR_def_label(fn__libs__lp_rational__lp_terms_to_map_1_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,1,1);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,3,0);
	MR_r4 = MR_sv(1);
	MR_r5 = MR_tempr1;
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__map__to_assoc_list_1_0);

MR_BEGIN_MODULE(libs__lp_rational_module2)
	MR_init_entry1(fn__libs__lp_rational__sum_like_terms_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__sum_like_terms_1_0);
	MR_init_label2(fn__libs__lp_rational__sum_like_terms_1_0,3,7)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'sum_like_terms'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__sum_like_terms_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_sv(3) = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__map__init_0_0,
		fn__libs__lp_rational__sum_like_terms_1_0_i3);
MR_def_label(fn__libs__lp_rational__sum_like_terms_1_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,1,1);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,3,1);
	MR_r4 = MR_sv(1);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__foldl_4_0,
		fn__libs__lp_rational__sum_like_terms_1_0_i7);
MR_def_label(fn__libs__lp_rational__sum_like_terms_1_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_tempr1;
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(fn__map__to_assoc_list_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module3)
	MR_init_entry1(fn__libs__lp_rational__this_file_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__this_file_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'this_file'/1 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__this_file_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__list__sort_2_0);
MR_decl_entry(fn__libs__rat__zero_0_0);
MR_decl_entry(fn__libs__rat__abs_1_0);
MR_decl_entry(__Unify___libs__rat__rat_0_0);
MR_decl_entry(libs__compiler_util__unexpected_2_0);
MR_decl_entry(fn__list__map_2_0);
MR_decl_entry(fn__f_108_105_98_115_95_95_114_97_116_95_95_47_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module4)
	MR_init_entry1(libs__lp_rational__normalize_terms_and_const_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__normalize_terms_and_const_5_0);
	MR_init_label10(libs__lp_rational__normalize_terms_and_const_5_0,5,9,10,12,13,11,17,18,19,6)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'normalize_terms_and_const'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__normalize_terms_and_const_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r3;
	MR_sv(4) = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r1 = MR_sv(4);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,3,2);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__list__sort_2_0,
		libs__lp_rational__normalize_terms_and_const_5_0_i5);
MR_def_label(libs__lp_rational__normalize_terms_and_const_5_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_r1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__normalize_terms_and_const_5_0_i6);
	}
	if (MR_INT_NE(MR_sv(1),0)) {
		MR_GOTO_LAB(libs__lp_rational__normalize_terms_and_const_5_0_i9);
	}
	MR_sv(1) = MR_tfield(0, MR_tfield(1, MR_r1, 0), 1);
	MR_sv(3) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__normalize_terms_and_const_5_0_i12);
MR_def_label(libs__lp_rational__normalize_terms_and_const_5_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_r1 = MR_tfield(0, MR_tfield(1, MR_r1, 0), 1);
	MR_np_call_localret_ent(fn__libs__rat__abs_1_0,
		libs__lp_rational__normalize_terms_and_const_5_0_i10);
MR_def_label(libs__lp_rational__normalize_terms_and_const_5_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__normalize_terms_and_const_5_0_i12);
MR_def_label(libs__lp_rational__normalize_terms_and_const_5_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__normalize_terms_and_const_5_0_i13);
MR_def_label(libs__lp_rational__normalize_terms_and_const_5_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__normalize_terms_and_const_5_0_i11);
	}
	MR_r1 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r2 = (MR_Word) MR_string_const("normalize_term_and_const/5: zero coefficient.", 45);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		libs__lp_rational__normalize_terms_and_const_5_0_i17);
MR_def_label(libs__lp_rational__normalize_terms_and_const_5_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,3);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(fn__libs__lp_rational__IntroducedFrom__func__normalize_terms_and_const__580__1_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_r4 = MR_sv(3);
	MR_r1 = MR_sv(4);
	}
MR_def_label(libs__lp_rational__normalize_terms_and_const_5_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_r1;
	MR_np_call_localret_ent(fn__list__map_2_0,
		libs__lp_rational__normalize_terms_and_const_5_0_i18);
MR_def_label(libs__lp_rational__normalize_terms_and_const_5_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_47_2_0,
		libs__lp_rational__normalize_terms_and_const_5_0_i19);
MR_def_label(libs__lp_rational__normalize_terms_and_const_5_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_decr_sp_and_return(5);
	}
MR_def_label(libs__lp_rational__normalize_terms_and_const_5_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_decr_sp_and_return(5);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__assoc_list__map_values_only_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module5)
	MR_init_entry1(fn__libs__lp_rational__negate_lp_terms_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__negate_lp_terms_1_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'negate_lp_terms'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__negate_lp_terms_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r2 = MR_r1;
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r4 = (MR_Word) MR_TAG_COMMON(0,3,3);
	MR_r5 = MR_tempr1;
	MR_np_tailcall_ent(fn__assoc_list__map_values_only_2_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module6)
	MR_init_entry1(fn__libs__lp_rational__construct_constraint_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__construct_constraint_3_0);
	MR_init_label10(fn__libs__lp_rational__construct_constraint_3_0,5,8,7,76,14,18,19,20,12,24)
	MR_init_label8(fn__libs__lp_rational__construct_constraint_3_0,28,29,30,32,33,22,35,36)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'construct_constraint'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__libs__lp_rational__construct_constraint_3_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(fn__libs__lp_rational__construct_constraint_3_0_i76);
	}
	if (MR_INT_NE(MR_r2,1)) {
		MR_GOTO_LAB(fn__libs__lp_rational__construct_constraint_3_0_i5);
	}
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r1, 0) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(1, MR_r1, 1) = MR_r3;
	MR_proceed();
MR_def_label(fn__libs__lp_rational__construct_constraint_3_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r2,2)) {
		MR_GOTO_LAB(fn__libs__lp_rational__construct_constraint_3_0_i7);
	}
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_r1 = MR_r3;
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		fn__libs__lp_rational__construct_constraint_3_0_i8);
MR_def_label(fn__libs__lp_rational__construct_constraint_3_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_r2, 1) = MR_r1;
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(5);
MR_def_label(fn__libs__lp_rational__construct_constraint_3_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r1, 0) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_r1, 1) = MR_r3;
	MR_proceed();
MR_def_label(fn__libs__lp_rational__construct_constraint_3_0,76)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	if (MR_INT_NE(MR_r2,1)) {
		MR_GOTO_LAB(fn__libs__lp_rational__construct_constraint_3_0_i12);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r3;
	MR_sv(3) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_sv(4) = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(4);
	MR_np_call_localret_ent(fn__map__init_0_0,
		fn__libs__lp_rational__construct_constraint_3_0_i14);
MR_def_label(fn__libs__lp_rational__construct_constraint_3_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,1,1);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,3,4);
	MR_r4 = MR_sv(1);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__foldl_4_0,
		fn__libs__lp_rational__construct_constraint_3_0_i18);
MR_def_label(fn__libs__lp_rational__construct_constraint_3_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__map__to_assoc_list_1_0,
		fn__libs__lp_rational__construct_constraint_3_0_i19);
MR_def_label(fn__libs__lp_rational__construct_constraint_3_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Integer) 0;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(2);
	}
	MR_np_call_localret_ent(libs__lp_rational__normalize_terms_and_const_5_0,
		fn__libs__lp_rational__construct_constraint_3_0_i20);
MR_def_label(fn__libs__lp_rational__construct_constraint_3_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_r1;
	MR_tfield(1, MR_tempr1, 1) = MR_r2;
	MR_r1 = MR_tempr1;
	MR_decr_sp_and_return(5);
	}
MR_def_label(fn__libs__lp_rational__construct_constraint_3_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r2,2)) {
		MR_GOTO_LAB(fn__libs__lp_rational__construct_constraint_3_0_i22);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r3;
	MR_sv(3) = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_sv(4) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r1 = MR_sv(4);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__map__init_0_0,
		fn__libs__lp_rational__construct_constraint_3_0_i24);
MR_def_label(fn__libs__lp_rational__construct_constraint_3_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,1,1);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,3,5);
	MR_r4 = MR_sv(1);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__foldl_4_0,
		fn__libs__lp_rational__construct_constraint_3_0_i28);
MR_def_label(fn__libs__lp_rational__construct_constraint_3_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__map__to_assoc_list_1_0,
		fn__libs__lp_rational__construct_constraint_3_0_i29);
MR_def_label(fn__libs__lp_rational__construct_constraint_3_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Integer) 1;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(2);
	}
	MR_np_call_localret_ent(libs__lp_rational__normalize_terms_and_const_5_0,
		fn__libs__lp_rational__construct_constraint_3_0_i30);
MR_def_label(fn__libs__lp_rational__construct_constraint_3_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r2 = MR_r1;
	MR_r3 = MR_sv(4);
	MR_r4 = (MR_Word) MR_TAG_COMMON(0,3,6);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__assoc_list__map_values_only_2_0,
		fn__libs__lp_rational__construct_constraint_3_0_i32);
MR_def_label(fn__libs__lp_rational__construct_constraint_3_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		fn__libs__lp_rational__construct_constraint_3_0_i33);
MR_def_label(fn__libs__lp_rational__construct_constraint_3_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_decr_sp_and_return(5);
	}
MR_def_label(fn__libs__lp_rational__construct_constraint_3_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r3;
	MR_np_call_localret_ent(fn__libs__lp_rational__sum_like_terms_1_0,
		fn__libs__lp_rational__construct_constraint_3_0_i35);
MR_def_label(fn__libs__lp_rational__construct_constraint_3_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Integer) 1;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(2);
	}
	MR_np_call_localret_ent(libs__lp_rational__normalize_terms_and_const_5_0,
		fn__libs__lp_rational__construct_constraint_3_0_i36);
MR_def_label(fn__libs__lp_rational__construct_constraint_3_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_r1;
	MR_tfield(0, MR_tempr1, 1) = MR_r2;
	MR_r1 = MR_tempr1;
	MR_decr_sp_and_return(5);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(f_108_105_98_115_95_95_114_97_116_95_95_62_2_0);
MR_decl_entry(f_108_105_98_115_95_95_114_97_116_95_95_60_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module7)
	MR_init_entry1(libs__lp_rational__is_false_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__is_false_1_0);
	MR_init_label7(libs__lp_rational__is_false_1_0,6,7,3,11,9,15,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'is_false'/1 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__libs__lp_rational__is_false_1_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(libs__lp_rational__is_false_1_0_i3);
	}
	MR_r2 = MR_tfield(1, MR_r1, 0);
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__is_false_1_0_i1);
	}
	MR_sv(1) = MR_tfield(1, MR_r1, 1);
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__is_false_1_0_i6);
MR_def_label(libs__lp_rational__is_false_1_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__is_false_1_0_i7);
MR_def_label(libs__lp_rational__is_false_1_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO_LAB(libs__lp_rational__is_false_1_0_i1);
	}
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(libs__lp_rational__is_false_1_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(libs__lp_rational__is_false_1_0_i9);
	}
	MR_r2 = MR_tfield(2, MR_r1, 0);
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__is_false_1_0_i1);
	}
	MR_sv(1) = MR_tfield(2, MR_r1, 1);
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__is_false_1_0_i11);
MR_def_label(libs__lp_rational__is_false_1_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(f_108_105_98_115_95_95_114_97_116_95_95_62_2_0);
	}
MR_def_label(libs__lp_rational__is_false_1_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_tfield(0, MR_r1, 0);
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__is_false_1_0_i1);
	}
	MR_sv(1) = MR_tfield(0, MR_r1, 1);
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__is_false_1_0_i15);
MR_def_label(libs__lp_rational__is_false_1_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(f_108_105_98_115_95_95_114_97_116_95_95_60_2_0);
	}
MR_def_label(libs__lp_rational__is_false_1_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module8)
	MR_init_entry1(fn__libs__lp_rational__construct_non_false_constraint_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__construct_non_false_constraint_3_0);
	MR_init_label3(fn__libs__lp_rational__construct_non_false_constraint_3_0,2,5,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'construct_non_false_constraint'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__libs__lp_rational__construct_non_false_constraint_3_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_np_call_localret_ent(fn__libs__lp_rational__construct_constraint_3_0,
		fn__libs__lp_rational__construct_non_false_constraint_3_0_i2);
MR_def_label(fn__libs__lp_rational__construct_non_false_constraint_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_np_call_localret_ent(libs__lp_rational__is_false_1_0,
		fn__libs__lp_rational__construct_non_false_constraint_3_0_i5);
MR_def_label(fn__libs__lp_rational__construct_non_false_constraint_3_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(fn__libs__lp_rational__construct_non_false_constraint_3_0_i3);
	}
	MR_r1 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r2 = (MR_Word) MR_string_const("non_false_constraints/3: false constraint.", 42);
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(libs__compiler_util__unexpected_2_0);
MR_def_label(fn__libs__lp_rational__construct_non_false_constraint_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(2);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module9)
	MR_init_entry1(libs__lp_rational__deconstruct_constraint_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__deconstruct_constraint_4_0);
	MR_init_label2(libs__lp_rational__deconstruct_constraint_4_0,3,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'deconstruct_constraint'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__libs__lp_rational__deconstruct_constraint_4_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(libs__lp_rational__deconstruct_constraint_4_0_i3);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_tfield(1, MR_r1, 0);
	MR_r2 = (MR_Integer) 1;
	MR_r3 = MR_tfield(1, MR_tempr1, 1);
	MR_proceed();
	}
MR_def_label(libs__lp_rational__deconstruct_constraint_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(libs__lp_rational__deconstruct_constraint_4_0_i4);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_tfield(2, MR_r1, 0);
	MR_r2 = (MR_Integer) 2;
	MR_r3 = MR_tfield(2, MR_tempr1, 1);
	MR_proceed();
	}
MR_def_label(libs__lp_rational__deconstruct_constraint_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_tfield(0, MR_r1, 0);
	MR_r2 = (MR_Integer) 0;
	MR_r3 = MR_tfield(0, MR_tempr1, 1);
	MR_proceed();
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module10)
	MR_init_entry1(libs__lp_rational__deconstruct_non_false_constraint_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__deconstruct_non_false_constraint_4_0);
	MR_init_label5(libs__lp_rational__deconstruct_non_false_constraint_4_0,4,2,7,9,10)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'deconstruct_non_false_constraint'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__libs__lp_rational__deconstruct_non_false_constraint_4_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_np_call_localret_ent(libs__lp_rational__is_false_1_0,
		libs__lp_rational__deconstruct_non_false_constraint_4_0_i4);
MR_def_label(libs__lp_rational__deconstruct_non_false_constraint_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__deconstruct_non_false_constraint_4_0_i2);
	}
	MR_r1 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r2 = (MR_Word) MR_string_const("deconstruct_non_false_constraint/4: false_constraint.", 53);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		libs__lp_rational__deconstruct_non_false_constraint_4_0_i7);
MR_def_label(libs__lp_rational__deconstruct_non_false_constraint_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
MR_def_label(libs__lp_rational__deconstruct_non_false_constraint_4_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(1),1)) {
		MR_GOTO_LAB(libs__lp_rational__deconstruct_non_false_constraint_4_0_i9);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_r1 = MR_tfield(1, MR_tempr1, 0);
	MR_r2 = (MR_Integer) 1;
	MR_r3 = MR_tfield(1, MR_tempr1, 1);
	MR_decr_sp_and_return(2);
	}
MR_def_label(libs__lp_rational__deconstruct_non_false_constraint_4_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(1),0)) {
		MR_GOTO_LAB(libs__lp_rational__deconstruct_non_false_constraint_4_0_i10);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_r1 = MR_tfield(0, MR_tempr1, 0);
	MR_r2 = (MR_Integer) 0;
	MR_r3 = MR_tfield(0, MR_tempr1, 1);
	MR_decr_sp_and_return(2);
	}
MR_def_label(libs__lp_rational__deconstruct_non_false_constraint_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r2 = (MR_Word) MR_string_const("deconstruct_non_false_constraint/4: gte encountered.", 52);
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(libs__compiler_util__unexpected_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module11)
	MR_init_entry1(libs__lp_rational__nonneg_constr_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__nonneg_constr_1_0);
	MR_init_label7(libs__lp_rational__nonneg_constr_1_0,5,6,7,10,19,3,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'nonneg_constr'/1 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__libs__lp_rational__nonneg_constr_1_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(libs__lp_rational__nonneg_constr_1_0_i3);
	}
	MR_r2 = MR_tfield(0, MR_r1, 0);
	if (MR_LTAGS_TEST(MR_r2,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__nonneg_constr_1_0_i1);
	}
	MR_sv(1) = MR_tfield(0, MR_r1, 1);
	MR_sv(2) = MR_tfield(1, MR_r2, 1);
	MR_sv(3) = MR_tfield(0, MR_tfield(1, MR_r2, 0), 1);
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		libs__lp_rational__nonneg_constr_1_0_i5);
MR_def_label(libs__lp_rational__nonneg_constr_1_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		libs__lp_rational__nonneg_constr_1_0_i6);
MR_def_label(libs__lp_rational__nonneg_constr_1_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__nonneg_constr_1_0_i7);
MR_def_label(libs__lp_rational__nonneg_constr_1_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__nonneg_constr_1_0_i1);
	}
	if (MR_LTAGS_TESTR(MR_sv(2),0,0)) {
		MR_GOTO_LAB(libs__lp_rational__nonneg_constr_1_0_i1);
	}
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__nonneg_constr_1_0_i10);
MR_def_label(libs__lp_rational__nonneg_constr_1_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(__Unify___libs__rat__rat_0_0);
	}
MR_def_label(libs__lp_rational__nonneg_constr_1_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(libs__lp_rational__nonneg_constr_1_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(libs__lp_rational__nonneg_constr_1_0_i1);
	}
	MR_r1 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r2 = (MR_Word) MR_string_const("nonneg_constr/1: gte.", 21);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		libs__lp_rational__nonneg_constr_1_0_i19);
MR_def_label(libs__lp_rational__nonneg_constr_1_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module12)
	MR_init_entry1(fn__libs__lp_rational__make_nonneg_constr_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__make_nonneg_constr_1_0);
	MR_init_label3(fn__libs__lp_rational__make_nonneg_constr_1_0,2,3,6)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'make_nonneg_constr'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__libs__lp_rational__make_nonneg_constr_1_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		fn__libs__lp_rational__make_nonneg_constr_1_0_i2);
MR_def_label(fn__libs__lp_rational__make_nonneg_constr_1_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		fn__libs__lp_rational__make_nonneg_constr_1_0_i3);
MR_def_label(fn__libs__lp_rational__make_nonneg_constr_1_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(1);
	MR_tfield(0, MR_r2, 1) = MR_r1;
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_sv(1) = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = MR_r2;
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	}
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		fn__libs__lp_rational__make_nonneg_constr_1_0_i6);
MR_def_label(fn__libs__lp_rational__make_nonneg_constr_1_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Integer) 0;
	MR_r3 = MR_tempr1;
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(fn__libs__lp_rational__construct_constraint_3_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module13)
	MR_init_entry1(fn__libs__lp_rational__make_vars_eq_constraint_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__make_vars_eq_constraint_2_0);
	MR_init_label4(fn__libs__lp_rational__make_vars_eq_constraint_2_0,2,4,5,9)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'make_vars_eq_constraint'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__libs__lp_rational__make_vars_eq_constraint_2_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		fn__libs__lp_rational__make_vars_eq_constraint_2_0_i2);
MR_def_label(fn__libs__lp_rational__make_vars_eq_constraint_2_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(1);
	MR_tfield(0, MR_r2, 1) = MR_r1;
	MR_sv(1) = MR_r2;
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		fn__libs__lp_rational__make_vars_eq_constraint_2_0_i4);
MR_def_label(fn__libs__lp_rational__make_vars_eq_constraint_2_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		fn__libs__lp_rational__make_vars_eq_constraint_2_0_i5);
MR_def_label(fn__libs__lp_rational__make_vars_eq_constraint_2_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(2);
	MR_tfield(0, MR_r2, 1) = MR_r1;
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r1, 0) = MR_r2;
	MR_tfield(1, MR_r1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_sv(1);
	MR_tfield(1, MR_r2, 1) = MR_r1;
	MR_sv(1) = MR_r2;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		fn__libs__lp_rational__make_vars_eq_constraint_2_0_i9);
MR_def_label(fn__libs__lp_rational__make_vars_eq_constraint_2_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Integer) 1;
	MR_r3 = MR_tempr1;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(fn__libs__lp_rational__construct_constraint_3_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module14)
	MR_init_entry1(fn__libs__lp_rational__make_var_const_eq_constraint_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__make_var_const_eq_constraint_2_0);
	MR_init_label1(fn__libs__lp_rational__make_var_const_eq_constraint_2_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'make_var_const_eq_constraint'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__libs__lp_rational__make_var_const_eq_constraint_2_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		fn__libs__lp_rational__make_var_const_eq_constraint_2_0_i2);
MR_def_label(fn__libs__lp_rational__make_var_const_eq_constraint_2_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 1) = MR_r1;
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r1, 0) = MR_tempr1;
	MR_tfield(1, MR_r1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_r2 = (MR_Integer) 1;
	MR_r3 = MR_sv(2);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(fn__libs__lp_rational__construct_constraint_3_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module15)
	MR_init_entry1(fn__libs__lp_rational__make_var_const_gte_constraint_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__make_var_const_gte_constraint_2_0);
	MR_init_label1(fn__libs__lp_rational__make_var_const_gte_constraint_2_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'make_var_const_gte_constraint'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__libs__lp_rational__make_var_const_gte_constraint_2_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		fn__libs__lp_rational__make_var_const_gte_constraint_2_0_i2);
MR_def_label(fn__libs__lp_rational__make_var_const_gte_constraint_2_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 1) = MR_r1;
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r1, 0) = MR_tempr1;
	MR_tfield(1, MR_r1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_r2 = (MR_Integer) 2;
	MR_r3 = MR_sv(2);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(fn__libs__lp_rational__construct_constraint_3_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module16)
	MR_init_entry1(fn__libs__lp_rational__false_constraint_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__false_constraint_0_0);
	MR_init_label1(fn__libs__lp_rational__false_constraint_0_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'false_constraint'/1 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__libs__lp_rational__false_constraint_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(1);
	MR_sv(1) = (MR_Word) MR_succip;
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		fn__libs__lp_rational__false_constraint_0_0_i2);
MR_def_label(fn__libs__lp_rational__false_constraint_0_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(1, MR_r2, 1) = MR_r1;
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(1);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module17)
	MR_init_entry1(fn__libs__lp_rational__true_constraint_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__true_constraint_0_0);
	MR_init_label1(fn__libs__lp_rational__true_constraint_0_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'true_constraint'/1 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__libs__lp_rational__true_constraint_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(1);
	MR_sv(1) = (MR_Word) MR_succip;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		fn__libs__lp_rational__true_constraint_0_0_i2);
MR_def_label(fn__libs__lp_rational__true_constraint_0_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(1, MR_r2, 1) = MR_r1;
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(1);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(f_108_105_98_115_95_95_114_97_116_95_95_61_60_2_0);
MR_decl_entry(f_108_105_98_115_95_95_114_97_116_95_95_62_61_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module18)
	MR_init_entry1(libs__lp_rational__is_true_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__is_true_1_0);
	MR_init_label6(libs__lp_rational__is_true_1_0,5,3,10,8,14,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'is_true'/1 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__libs__lp_rational__is_true_1_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(libs__lp_rational__is_true_1_0_i3);
	}
	MR_r2 = MR_tfield(1, MR_r1, 0);
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__is_true_1_0_i1);
	}
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_tfield(1, MR_r1, 1);
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__is_true_1_0_i5);
MR_def_label(libs__lp_rational__is_true_1_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(__Unify___libs__rat__rat_0_0);
	}
MR_def_label(libs__lp_rational__is_true_1_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(libs__lp_rational__is_true_1_0_i8);
	}
	MR_r2 = MR_tfield(2, MR_r1, 0);
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__is_true_1_0_i1);
	}
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_tfield(2, MR_r1, 1);
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__is_true_1_0_i10);
MR_def_label(libs__lp_rational__is_true_1_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(f_108_105_98_115_95_95_114_97_116_95_95_61_60_2_0);
	}
MR_def_label(libs__lp_rational__is_true_1_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_tfield(0, MR_r1, 0);
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__is_true_1_0_i1);
	}
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_tfield(0, MR_r1, 1);
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__is_true_1_0_i14);
MR_def_label(libs__lp_rational__is_true_1_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(f_108_105_98_115_95_95_114_97_116_95_95_62_61_2_0);
	}
MR_def_label(libs__lp_rational__is_true_1_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(__Unify___list__list_1_0);
MR_decl_entry(fn__f_108_105_115_116_95_95_43_43_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module19)
	MR_init_entry1(libs__lp_rational__check_for_equalities_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__check_for_equalities_5_0);
	MR_init_label10(libs__lp_rational__check_for_equalities_5_0,55,7,8,13,14,16,18,3,4,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'check_for_equalities'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__check_for_equalities_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(9);
	MR_sv(9) = (MR_Word) MR_succip;
MR_def_label(libs__lp_rational__check_for_equalities_5_0,55)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_r2,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__check_for_equalities_5_0_i1);
	}
	MR_sv(3) = MR_tfield(1, MR_r2, 1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r2, 0);
	MR_sv(2) = MR_tempr1;
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(libs__lp_rational__check_for_equalities_5_0_i4);
	}
	if (MR_PTAG_TESTR(MR_tempr1,0)) {
		MR_GOTO_LAB(libs__lp_rational__check_for_equalities_5_0_i4);
	}
	MR_sv(1) = MR_r1;
	MR_sv(4) = MR_r3;
	MR_sv(5) = MR_tfield(0, MR_r1, 0);
	MR_sv(6) = MR_tfield(0, MR_r1, 1);
	MR_sv(7) = MR_tfield(0, MR_tempr1, 0);
	MR_sv(8) = MR_tfield(0, MR_tempr1, 1);
	MR_r1 = MR_sv(6);
	}
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		libs__lp_rational__check_for_equalities_5_0_i7);
MR_def_label(libs__lp_rational__check_for_equalities_5_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(8);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__check_for_equalities_5_0_i8);
MR_def_label(libs__lp_rational__check_for_equalities_5_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__check_for_equalities_5_0_i3);
	}
	MR_sv(8) = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r1 = MR_sv(8);
	MR_r2 = MR_r1;
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,3,7);
	MR_r4 = MR_sv(5);
	MR_np_call_localret_ent(fn__list__map_2_0,
		libs__lp_rational__check_for_equalities_5_0_i13);
MR_def_label(libs__lp_rational__check_for_equalities_5_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(8);
	MR_r2 = MR_sv(7);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___list__list_1_0,
		libs__lp_rational__check_for_equalities_5_0_i14);
MR_def_label(libs__lp_rational__check_for_equalities_5_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__check_for_equalities_5_0_i3);
	}
	MR_r1 = (MR_Integer) 0;
	MR_r2 = MR_sv(5);
	MR_r3 = MR_sv(6);
	MR_np_call_localret_ent(libs__lp_rational__normalize_terms_and_const_5_0,
		libs__lp_rational__check_for_equalities_5_0_i16);
MR_def_label(libs__lp_rational__check_for_equalities_5_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_sv(1) = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = MR_r1;
	MR_tfield(1, MR_tempr1, 1) = MR_r2;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_r2 = MR_sv(4);
	MR_r3 = MR_sv(3);
	}
	MR_np_call_localret_ent(fn__f_108_105_115_116_95_95_43_43_2_0,
		libs__lp_rational__check_for_equalities_5_0_i18);
MR_def_label(libs__lp_rational__check_for_equalities_5_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_r3 = MR_r1;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(9);
MR_def_label(libs__lp_rational__check_for_equalities_5_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r3 = MR_sv(4);
MR_def_label(libs__lp_rational__check_for_equalities_5_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(1, MR_tempr1, 1) = MR_r3;
	MR_r2 = MR_sv(3);
	MR_r3 = MR_tempr1;
	MR_succip_word = MR_sv(9);
	MR_GOTO_LAB(libs__lp_rational__check_for_equalities_5_0_i55);
	}
MR_def_label(libs__lp_rational__check_for_equalities_5_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_decr_sp_and_return(9);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module20)
	MR_init_entry1(libs__lp_rational__restore_equalities_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__restore_equalities_2_0);
	MR_init_label4(libs__lp_rational__restore_equalities_2_0,26,5,4,8)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'restore_equalities'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__libs__lp_rational__restore_equalities_2_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__restore_equalities_2_0_i26);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_proceed();
MR_def_label(libs__lp_rational__restore_equalities_2_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_r2 = MR_tfield(1, MR_r1, 1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r1, 0);
	MR_sv(1) = MR_tempr1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_tempr1;
	MR_r3 = (MR_Word) MR_tbmkword(0, 0);
	}
	MR_np_call_localret_ent(libs__lp_rational__check_for_equalities_5_0,
		libs__lp_rational__restore_equalities_2_0_i5);
MR_def_label(libs__lp_rational__restore_equalities_2_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__restore_equalities_2_0_i4);
	}
	MR_sv(1) = MR_r2;
	MR_r1 = MR_r3;
	MR_np_localcall_lab(libs__lp_rational__restore_equalities_2_0,
		libs__lp_rational__restore_equalities_2_0_i8);
MR_def_label(libs__lp_rational__restore_equalities_2_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_localcall_lab(libs__lp_rational__restore_equalities_2_0,
		libs__lp_rational__restore_equalities_2_0_i8);
MR_def_label(libs__lp_rational__restore_equalities_2_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_sv(1);
	MR_tfield(1, MR_r2, 1) = MR_r1;
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(3);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(list__member_2_0);
MR_decl_entry(fn__map__delete_2_0);
MR_decl_entry(fn__map__set_3_0);

MR_BEGIN_MODULE(libs__lp_rational_module21)
	MR_init_entry1(libs__lp_rational__set_cell_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__set_cell_5_0);
	MR_init_label9(libs__lp_rational__set_cell_5_0,6,8,4,2,11,13,14,12,22)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'set_cell'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__set_cell_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(10);
	MR_sv(10) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_r4;
	MR_sv(9) = MR_tfield(0, MR_tempr2, 5);
	MR_sv(8) = MR_tfield(0, MR_tempr2, 4);
	MR_tempr1 = MR_tfield(0, MR_tempr2, 3);
	MR_sv(6) = MR_tfield(0, MR_tempr2, 2);
	MR_sv(5) = MR_tfield(0, MR_tempr2, 1);
	MR_sv(4) = MR_tfield(0, MR_tempr2, 0);
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_sv(7) = MR_tempr1;
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_sv(1);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__member_2_0,
		libs__lp_rational__set_cell_5_0_i6);
MR_def_label(libs__lp_rational__set_cell_5_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO_LAB(libs__lp_rational__set_cell_5_0_i4);
	}
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(8);
	MR_np_call_localret_ent(list__member_2_0,
		libs__lp_rational__set_cell_5_0_i8);
MR_def_label(libs__lp_rational__set_cell_5_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__set_cell_5_0_i2);
	}
MR_def_label(libs__lp_rational__set_cell_5_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r2 = (MR_Word) MR_string_const("set_cell/5: Attempt to write shunned row/col.", 45);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		libs__lp_rational__set_cell_5_0_i11);
MR_def_label(libs__lp_rational__set_cell_5_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_sv(3);
	MR_tempr2 = MR_sv(7);
	}
MR_def_label(libs__lp_rational__set_cell_5_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__set_cell_5_0_i13);
MR_def_label(libs__lp_rational__set_cell_5_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__set_cell_5_0_i14);
MR_def_label(libs__lp_rational__set_cell_5_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__set_cell_5_0_i12);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(2);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,4);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_sv(9);
	}
	MR_np_call_localret_ent(fn__map__delete_2_0,
		libs__lp_rational__set_cell_5_0_i22);
MR_def_label(libs__lp_rational__set_cell_5_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(2);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,4);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_sv(9);
	MR_r5 = MR_sv(3);
	}
	MR_np_call_localret_ent(fn__map__set_3_0,
		libs__lp_rational__set_cell_5_0_i22);
MR_def_label(libs__lp_rational__set_cell_5_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 6);
	MR_tfield(0, MR_r2, 0) = MR_sv(4);
	MR_tfield(0, MR_r2, 1) = MR_sv(5);
	MR_tfield(0, MR_r2, 2) = MR_sv(6);
	MR_tfield(0, MR_r2, 3) = MR_sv(7);
	MR_tfield(0, MR_r2, 4) = MR_sv(8);
	MR_tfield(0, MR_r2, 5) = MR_r1;
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(10);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__f_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_100_101_116_95_101_108_101_109_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module22)
	MR_init_entry1(libs__lp_rational__insert_terms_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__insert_terms_5_0);
	MR_init_label4(libs__lp_rational__insert_terms_5_0,15,3,5,6)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'insert_terms'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__insert_terms_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
MR_def_label(libs__lp_rational__insert_terms_5_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__insert_terms_5_0_i3);
	}
	MR_r1 = MR_r4;
	MR_decr_sp_and_return(6);
MR_def_label(libs__lp_rational__insert_terms_5_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_r4;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r1, 0);
	MR_sv(4) = MR_tfield(0, MR_tempr1, 1);
	MR_sv(5) = MR_tfield(1, MR_r1, 1);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r3 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r4 = MR_tfield(0, MR_tempr1, 0);
	MR_r5 = MR_sv(2);
	}
	MR_np_call_localret_ent(fn__f_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_100_101_116_95_101_108_101_109_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_2_0,
		libs__lp_rational__insert_terms_5_0_i5);
MR_def_label(libs__lp_rational__insert_terms_5_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(4);
	MR_r4 = MR_sv(3);
	}
	MR_np_call_localret_ent(libs__lp_rational__set_cell_5_0,
		libs__lp_rational__insert_terms_5_0_i6);
MR_def_label(libs__lp_rational__insert_terms_5_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(1);
	MR_r3 = MR_sv(2);
	MR_r4 = MR_tempr1;
	MR_succip_word = MR_sv(6);
	MR_GOTO_LAB(libs__lp_rational__insert_terms_5_0_i15);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__map__elem_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module23)
	MR_init_entry1(fn__libs__lp_rational__elem_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__elem_3_0);
	MR_init_label7(fn__libs__lp_rational__elem_3_0,6,8,4,2,11,15,12)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'elem'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__elem_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_sv(4) = MR_tfield(0, MR_tempr1, 4);
	MR_sv(1) = MR_tempr1;
	MR_sv(2) = MR_r1;
	MR_sv(3) = MR_r2;
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_sv(2);
	MR_r3 = MR_tfield(0, MR_r3, 3);
	}
	MR_np_call_localret_ent(list__member_2_0,
		fn__libs__lp_rational__elem_3_0_i6);
MR_def_label(fn__libs__lp_rational__elem_3_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO_LAB(fn__libs__lp_rational__elem_3_0_i4);
	}
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_sv(3);
	MR_r3 = MR_sv(4);
	MR_np_call_localret_ent(list__member_2_0,
		fn__libs__lp_rational__elem_3_0_i8);
MR_def_label(fn__libs__lp_rational__elem_3_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(fn__libs__lp_rational__elem_3_0_i2);
	}
MR_def_label(fn__libs__lp_rational__elem_3_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r2 = (MR_Word) MR_string_const("get_cell/3: attempt to address shunned row/col.", 47);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		fn__libs__lp_rational__elem_3_0_i11);
MR_def_label(fn__libs__lp_rational__elem_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(3);
	}
MR_def_label(fn__libs__lp_rational__elem_3_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(3);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,4);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r4 = MR_tfield(0, MR_sv(1), 5);
	}
	MR_np_call_localret_ent(fn__map__elem_2_0,
		fn__libs__lp_rational__elem_3_0_i15);
MR_def_label(fn__libs__lp_rational__elem_3_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(fn__libs__lp_rational__elem_3_0_i12);
	}
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(5);
MR_def_label(fn__libs__lp_rational__elem_3_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(fn__libs__rat__zero_0_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(solutions__aggregate_4_3);

MR_BEGIN_MODULE(libs__lp_rational_module24)
	MR_init_entry1(libs__lp_rational__pivot_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__pivot_4_0);
	MR_init_label5(libs__lp_rational__pivot_4_0,2,5,8,11,12)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'pivot'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__pivot_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		libs__lp_rational__pivot_4_0_i2);
MR_def_label(libs__lp_rational__pivot_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 6);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(5,0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__pivot__1182__1_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 3;
	MR_tempr3 = MR_sv(1);
	MR_tfield(0, MR_tempr1, 3) = MR_tempr3;
	MR_tempr4 = MR_sv(2);
	MR_tfield(0, MR_tempr1, 4) = MR_tempr4;
	MR_tfield(0, MR_tempr1, 5) = MR_sv(3);
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 6);
	MR_r4 = MR_tempr2;
	MR_tfield(0, MR_tempr2, 0) = (MR_Word) MR_COMMON(6,0);
	MR_tfield(0, MR_tempr2, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0);
	MR_tfield(0, MR_tempr2, 2) = (MR_Integer) 3;
	MR_tfield(0, MR_tempr2, 3) = MR_tempr3;
	MR_tfield(0, MR_tempr2, 4) = MR_tempr4;
	MR_tfield(0, MR_tempr2, 5) = MR_r1;
	MR_sv(3) = MR_r1;
	MR_sv(4) = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, cell);
	MR_sv(5) = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, tableau);
	MR_r1 = MR_sv(4);
	MR_r2 = MR_sv(5);
	MR_r5 = MR_tfield(0, MR_tempr1, 5);
	}
	MR_np_call_localret_ent(solutions__aggregate_4_3,
		libs__lp_rational__pivot_4_0_i5);
MR_def_label(libs__lp_rational__pivot_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,6);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__pivot__1201__1_3_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 4) = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = MR_sv(5);
	MR_r4 = (MR_Word) MR_TAG_COMMON(0,3,8);
	MR_r5 = MR_tfield(0, MR_tempr1, 4);
	}
	MR_np_call_localret_ent(solutions__aggregate_4_3,
		libs__lp_rational__pivot_4_0_i8);
MR_def_label(libs__lp_rational__pivot_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(4,3);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__all_cols0_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 5);
	MR_r4 = MR_tempr2;
	MR_tfield(0, MR_tempr2, 0) = (MR_Word) MR_COMMON(7,0);
	MR_tfield(0, MR_tempr2, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__pivot__1211__1_5_0);
	MR_tfield(0, MR_tempr2, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr2, 3) = MR_sv(1);
	MR_tfield(0, MR_tempr2, 4) = MR_sv(3);
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_sv(5);
	MR_r5 = MR_tfield(0, MR_tempr1, 3);
	}
	MR_np_call_localret_ent(solutions__aggregate_4_3,
		libs__lp_rational__pivot_4_0_i11);
MR_def_label(libs__lp_rational__pivot_4_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		libs__lp_rational__pivot_4_0_i12);
MR_def_label(libs__lp_rational__pivot_4_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(3);
	MR_succip_word = MR_sv(6);
	MR_decr_sp(6);
	MR_np_tailcall_ent(libs__lp_rational__set_cell_5_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module25)
	MR_init_entry1(libs__lp_rational__simplex_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__simplex_3_0);
	MR_init_label6(libs__lp_rational__simplex_3_0,29,6,8,11,13,32)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'simplex'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__simplex_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
MR_def_label(libs__lp_rational__simplex_3_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(4,4);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__all_cols_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 4);
	MR_r4 = MR_tempr2;
	MR_tfield(0, MR_tempr2, 0) = (MR_Word) MR_COMMON(5,1);
	MR_tfield(0, MR_tempr2, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0);
	MR_tfield(0, MR_tempr2, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr2, 3) = MR_r1;
	MR_sv(2) = MR_r1;
	MR_sv(1) = (MR_Word) MR_INT_CTOR_ADDR;
	MR_sv(3) = (MR_Word) MR_TAG_COMMON(0,0,3);
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(3);
	MR_r5 = (MR_Word) MR_tbmkword(0, 0);
	}
	MR_np_call_localret_ent(solutions__aggregate_4_3,
		libs__lp_rational__simplex_3_0_i6);
MR_def_label(libs__lp_rational__simplex_3_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__simplex_3_0_i8);
	}
	MR_r1 = (MR_Integer) 1;
	MR_r2 = MR_sv(2);
	MR_decr_sp_and_return(4);
MR_def_label(libs__lp_rational__simplex_3_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(4,5);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__all_rows_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tempr3 = MR_sv(2);
	MR_tfield(0, MR_tempr1, 3) = MR_tempr3;
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 5);
	MR_r4 = MR_tempr2;
	MR_tfield(0, MR_tempr2, 0) = (MR_Word) MR_COMMON(7,1);
	MR_tfield(0, MR_tempr2, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0);
	MR_tfield(0, MR_tempr2, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr2, 3) = MR_tfield(0, MR_tfield(1, MR_r1, 0), 0);
	MR_tfield(0, MR_tempr2, 4) = MR_tempr3;
	MR_sv(1) = MR_tfield(0, MR_tempr2, 3);
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_sv(3);
	MR_r5 = (MR_Word) MR_tbmkword(0, 0);
	}
	MR_np_call_localret_ent(solutions__aggregate_4_3,
		libs__lp_rational__simplex_3_0_i11);
MR_def_label(libs__lp_rational__simplex_3_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__simplex_3_0_i13);
	}
	MR_r1 = (MR_Integer) 0;
	MR_r2 = MR_sv(2);
	MR_decr_sp_and_return(4);
MR_def_label(libs__lp_rational__simplex_3_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_tfield(1, MR_r1, 0), 0);
	MR_r2 = MR_sv(1);
	MR_r3 = MR_sv(2);
	MR_np_call_localret_ent(libs__lp_rational__pivot_4_0,
		libs__lp_rational__simplex_3_0_i32);
MR_def_label(libs__lp_rational__simplex_3_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(4);
	MR_GOTO_LAB(libs__lp_rational__simplex_3_0_i29);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__list__foldl_3_0);

MR_BEGIN_MODULE(libs__lp_rational_module26)
	MR_init_entry1(libs__lp_rational__optimize_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__optimize_4_0);
	MR_init_label5(libs__lp_rational__optimize_4_0,2,4,5,9,10)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'optimize'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__optimize_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(libs__lp_rational__simplex_3_0,
		libs__lp_rational__optimize_4_0_i2);
MR_def_label(libs__lp_rational__optimize_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(libs__lp_rational__optimize_4_0_i4);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_decr_sp_and_return(7);
MR_def_label(libs__lp_rational__optimize_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r2;
	MR_r1 = (MR_Integer) 0;
	MR_r2 = MR_tfield(0, MR_r2, 1);
	MR_r3 = MR_sv(3);
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		libs__lp_rational__optimize_4_0_i5);
MR_def_label(libs__lp_rational__optimize_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_sv(4) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(5,2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(fn__libs__lp_rational__extract_obj_var_3_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(3);
	MR_sv(2) = MR_r1;
	MR_sv(5) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_sv(6) = (MR_Word) MR_TAG_COMMON(0,1,1);
	MR_r1 = MR_sv(5);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	}
	MR_np_call_localret_ent(fn__map__init_0_0,
		libs__lp_rational__optimize_4_0_i9);
MR_def_label(libs__lp_rational__optimize_4_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(6);
	MR_r3 = MR_sv(4);
	MR_r4 = MR_sv(1);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__list__foldl_3_0,
		libs__lp_rational__optimize_4_0_i10);
MR_def_label(libs__lp_rational__optimize_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(1, MR_tempr1, 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_sv(3);
	MR_decr_sp_and_return(7);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(f_115_118_115_101_116_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_105_110_115_101_114_116_95_95_91_84_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_3_0);

MR_BEGIN_MODULE(libs__lp_rational_module27)
	MR_init_entry1(libs__lp_rational__get_vars_from_terms_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__get_vars_from_terms_3_0);
	MR_init_label3(libs__lp_rational__get_vars_from_terms_3_0,14,3,5)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'get_vars_from_terms'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__get_vars_from_terms_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
MR_def_label(libs__lp_rational__get_vars_from_terms_3_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__get_vars_from_terms_3_0_i3);
	}
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(2);
MR_def_label(libs__lp_rational__get_vars_from_terms_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_tfield(1, MR_r1, 1);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_tempr2 = MR_r2;
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r3 = MR_tfield(0, MR_tfield(1, MR_tempr1, 0), 0);
	MR_r4 = MR_tempr2;
	}
	MR_np_call_localret_ent(f_115_118_115_101_116_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_105_110_115_101_114_116_95_95_91_84_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_3_0,
		libs__lp_rational__get_vars_from_terms_3_0_i5);
MR_def_label(libs__lp_rational__get_vars_from_terms_3_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(2);
	MR_GOTO_LAB(libs__lp_rational__get_vars_from_terms_3_0_i14);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__set__init_0_0);
MR_decl_entry(fn__set__to_sorted_list_1_0);

MR_BEGIN_MODULE(libs__lp_rational_module28)
	MR_init_entry1(fn__libs__lp_rational__one_phase_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__one_phase_4_0);
	MR_init_label9(fn__libs__lp_rational__one_phase_4_0,2,4,5,6,7,9,10,13,14)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'one_phase'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__one_phase_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = (MR_Integer) 0;
	MR_np_call_localret_ent(libs__lp_rational__insert_terms_5_0,
		fn__libs__lp_rational__one_phase_4_0_i2);
MR_def_label(fn__libs__lp_rational__one_phase_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_sv(3) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(fn__set__init_0_0,
		fn__libs__lp_rational__one_phase_4_0_i4);
MR_def_label(fn__libs__lp_rational__one_phase_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(libs__lp_rational__get_vars_from_terms_3_0,
		fn__libs__lp_rational__one_phase_4_0_i5);
MR_def_label(fn__libs__lp_rational__one_phase_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__set__to_sorted_list_1_0,
		fn__libs__lp_rational__one_phase_4_0_i6);
MR_def_label(fn__libs__lp_rational__one_phase_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(libs__lp_rational__simplex_3_0,
		fn__libs__lp_rational__one_phase_4_0_i7);
MR_def_label(fn__libs__lp_rational__one_phase_4_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(fn__libs__lp_rational__one_phase_4_0_i9);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_decr_sp_and_return(6);
MR_def_label(fn__libs__lp_rational__one_phase_4_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r2;
	MR_r1 = (MR_Integer) 0;
	MR_r2 = MR_tfield(0, MR_r2, 1);
	MR_r3 = MR_sv(2);
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		fn__libs__lp_rational__one_phase_4_0_i10);
MR_def_label(fn__libs__lp_rational__one_phase_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_sv(4) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(5,3);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(fn__libs__lp_rational__extract_obj_var_3_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(2);
	MR_sv(2) = MR_r1;
	MR_sv(5) = (MR_Word) MR_TAG_COMMON(0,1,1);
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	}
	MR_np_call_localret_ent(fn__map__init_0_0,
		fn__libs__lp_rational__one_phase_4_0_i13);
MR_def_label(fn__libs__lp_rational__one_phase_4_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(5);
	MR_r3 = MR_sv(4);
	MR_r4 = MR_sv(1);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__list__foldl_3_0,
		fn__libs__lp_rational__one_phase_4_0_i14);
MR_def_label(fn__libs__lp_rational__one_phase_4_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_sv(2);
	MR_tfield(1, MR_r2, 1) = MR_r1;
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(6);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(solutions__solutions_2_1);

MR_BEGIN_MODULE(libs__lp_rational_module29)
	MR_init_entry1(libs__lp_rational__ensure_zero_obj_coeffs_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__ensure_zero_obj_coeffs_3_0);
	MR_init_label10(libs__lp_rational__ensure_zero_obj_coeffs_3_0,56,3,5,6,8,9,7,14,18,19)
	MR_init_label6(libs__lp_rational__ensure_zero_obj_coeffs_3_0,17,22,23,24,27,16)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'ensure_zero_obj_coeffs'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__ensure_zero_obj_coeffs_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
MR_def_label(libs__lp_rational__ensure_zero_obj_coeffs_3_0,56)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__ensure_zero_obj_coeffs_3_0_i3);
	}
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(6);
MR_def_label(libs__lp_rational__ensure_zero_obj_coeffs_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_tfield(1, MR_r1, 1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r3 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r4 = MR_tfield(1, MR_tempr1, 0);
	MR_r5 = MR_tfield(0, MR_sv(1), 2);
	}
	MR_np_call_localret_ent(fn__f_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_100_101_116_95_101_108_101_109_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_2_0,
		libs__lp_rational__ensure_zero_obj_coeffs_3_0_i5);
MR_def_label(libs__lp_rational__ensure_zero_obj_coeffs_3_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_r1 = (MR_Integer) 0;
	MR_r2 = MR_sv(3);
	MR_r3 = MR_sv(1);
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		libs__lp_rational__ensure_zero_obj_coeffs_3_0_i6);
MR_def_label(libs__lp_rational__ensure_zero_obj_coeffs_3_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__ensure_zero_obj_coeffs_3_0_i8);
MR_def_label(libs__lp_rational__ensure_zero_obj_coeffs_3_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__ensure_zero_obj_coeffs_3_0_i9);
MR_def_label(libs__lp_rational__ensure_zero_obj_coeffs_3_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__ensure_zero_obj_coeffs_3_0_i7);
	}
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(1);
	MR_succip_word = MR_sv(6);
	MR_GOTO_LAB(libs__lp_rational__ensure_zero_obj_coeffs_3_0_i56);
MR_def_label(libs__lp_rational__ensure_zero_obj_coeffs_3_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 5);
	MR_tfield(0, MR_r2, 0) = (MR_Word) MR_COMMON(2,8);
	MR_tfield(0, MR_r2, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__ensure_zero_obj_coeffs__1115__1_3_0);
	MR_tfield(0, MR_r2, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_r2, 3) = MR_sv(1);
	MR_tfield(0, MR_r2, 4) = MR_sv(3);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,6);
	MR_np_call_localret_ent(solutions__solutions_2_1,
		libs__lp_rational__ensure_zero_obj_coeffs_3_0_i14);
MR_def_label(libs__lp_rational__ensure_zero_obj_coeffs_3_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_r1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__ensure_zero_obj_coeffs_3_0_i16);
	}
	MR_r2 = MR_tfield(1, MR_r1, 0);
	MR_sv(5) = MR_tfield(0, MR_r2, 1);
	MR_sv(3) = MR_tfield(0, MR_r2, 0);
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__ensure_zero_obj_coeffs_3_0_i18);
MR_def_label(libs__lp_rational__ensure_zero_obj_coeffs_3_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__ensure_zero_obj_coeffs_3_0_i19);
MR_def_label(libs__lp_rational__ensure_zero_obj_coeffs_3_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__ensure_zero_obj_coeffs_3_0_i17);
	}
	MR_r1 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r2 = (MR_Word) MR_string_const("ensure_zero_obj_coeffs/3: zero divisor.", 39);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		libs__lp_rational__ensure_zero_obj_coeffs_3_0_i22);
MR_def_label(libs__lp_rational__ensure_zero_obj_coeffs_3_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
MR_def_label(libs__lp_rational__ensure_zero_obj_coeffs_3_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		libs__lp_rational__ensure_zero_obj_coeffs_3_0_i23);
MR_def_label(libs__lp_rational__ensure_zero_obj_coeffs_3_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(5);
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_47_2_0,
		libs__lp_rational__ensure_zero_obj_coeffs_3_0_i24);
MR_def_label(libs__lp_rational__ensure_zero_obj_coeffs_3_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(4,6);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__all_cols0_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tempr3 = MR_sv(1);
	MR_tfield(0, MR_tempr1, 3) = MR_tempr3;
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 6);
	MR_r4 = MR_tempr2;
	MR_tfield(0, MR_tempr2, 0) = (MR_Word) MR_COMMON(6,1);
	MR_tfield(0, MR_tempr2, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__row_op__1227__1_6_0);
	MR_tfield(0, MR_tempr2, 2) = (MR_Integer) 3;
	MR_tfield(0, MR_tempr2, 3) = MR_r1;
	MR_tfield(0, MR_tempr2, 4) = MR_sv(3);
	MR_tfield(0, MR_tempr2, 5) = (MR_Integer) 0;
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, tableau);
	MR_r5 = MR_tempr3;
	}
	MR_np_call_localret_ent(solutions__aggregate_4_3,
		libs__lp_rational__ensure_zero_obj_coeffs_3_0_i27);
MR_def_label(libs__lp_rational__ensure_zero_obj_coeffs_3_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(6);
	MR_GOTO_LAB(libs__lp_rational__ensure_zero_obj_coeffs_3_0_i56);
	}
MR_def_label(libs__lp_rational__ensure_zero_obj_coeffs_3_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r2 = (MR_Word) MR_string_const("ensure_zero_obj_coeffs/3: problem with artificial variable.", 59);
	MR_succip_word = MR_sv(6);
	MR_decr_sp(6);
	MR_np_tailcall_ent(libs__compiler_util__unexpected_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module30)
	MR_init_entry1(libs__lp_rational__remove_row_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__remove_row_3_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'remove_row'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__remove_row_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_r1;
	MR_tfield(1, MR_tempr1, 1) = MR_tfield(0, MR_r2, 3);
	MR_tag_alloc_heap(MR_r1, 0, (MR_Integer) 6);
	MR_tfield(0, MR_r1, 0) = MR_tfield(0, MR_r2, 0);
	MR_tfield(0, MR_r1, 1) = MR_tfield(0, MR_r2, 1);
	MR_tfield(0, MR_r1, 2) = MR_tfield(0, MR_r2, 2);
	MR_tfield(0, MR_r1, 3) = MR_tempr1;
	MR_tfield(0, MR_r1, 4) = MR_tfield(0, MR_r2, 4);
	MR_tfield(0, MR_r1, 5) = MR_tfield(0, MR_r2, 5);
	MR_proceed();
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module31)
	MR_init_entry1(libs__lp_rational__remove_col_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__remove_col_3_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'remove_col'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__remove_col_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_r1;
	MR_tfield(1, MR_tempr1, 1) = MR_tfield(0, MR_r2, 4);
	MR_tag_alloc_heap(MR_r1, 0, (MR_Integer) 6);
	MR_tfield(0, MR_r1, 0) = MR_tfield(0, MR_r2, 0);
	MR_tfield(0, MR_r1, 1) = MR_tfield(0, MR_r2, 1);
	MR_tfield(0, MR_r1, 2) = MR_tfield(0, MR_r2, 2);
	MR_tfield(0, MR_r1, 3) = MR_tfield(0, MR_r2, 3);
	MR_tfield(0, MR_r1, 4) = MR_tempr1;
	MR_tfield(0, MR_r1, 5) = MR_tfield(0, MR_r2, 5);
	MR_proceed();
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module32)
	MR_init_entry1(libs__lp_rational__fix_basis_and_rem_cols_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__fix_basis_and_rem_cols_3_0);
	MR_init_label10(libs__lp_rational__fix_basis_and_rem_cols_3_0,62,3,5,10,14,15,19,24,21,25)
	MR_init_label2(libs__lp_rational__fix_basis_and_rem_cols_3_0,12,29)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'fix_basis_and_rem_cols'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__fix_basis_and_rem_cols_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(8);
	MR_sv(8) = (MR_Word) MR_succip;
MR_def_label(libs__lp_rational__fix_basis_and_rem_cols_3_0,62)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__fix_basis_and_rem_cols_3_0_i3);
	}
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(8);
MR_def_label(libs__lp_rational__fix_basis_and_rem_cols_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_tfield(1, MR_r1, 1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r3 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r4 = MR_tfield(1, MR_tempr1, 0);
	MR_r5 = MR_tfield(0, MR_sv(1), 2);
	}
	MR_np_call_localret_ent(fn__f_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_100_101_116_95_101_108_101_109_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_2_0,
		libs__lp_rational__fix_basis_and_rem_cols_3_0_i5);
MR_def_label(libs__lp_rational__fix_basis_and_rem_cols_3_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(7,2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1144__1_5_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tempr3 = MR_sv(1);
	MR_tfield(0, MR_tempr1, 3) = MR_tempr3;
	MR_tfield(0, MR_tempr1, 4) = MR_r1;
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr2;
	MR_tfield(0, MR_tempr2, 0) = (MR_Word) MR_COMMON(4,7);
	MR_tfield(0, MR_tempr2, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__all_rows_2_0);
	MR_tfield(0, MR_tempr2, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr2, 3) = MR_tempr3;
	MR_sv(3) = MR_r1;
	MR_sv(7) = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r1 = MR_sv(7);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,6);
	MR_r5 = (MR_Word) MR_tbmkword(0, 0);
	}
	MR_np_call_localret_ent(solutions__aggregate_4_3,
		libs__lp_rational__fix_basis_and_rem_cols_3_0_i10);
MR_def_label(libs__lp_rational__fix_basis_and_rem_cols_3_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_r1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__fix_basis_and_rem_cols_3_0_i12);
	}
	MR_r2 = MR_tfield(1, MR_r1, 0);
	MR_sv(4) = MR_tfield(0, MR_r2, 1);
	MR_sv(5) = MR_tfield(1, MR_r1, 1);
	MR_sv(6) = MR_tfield(0, MR_r2, 0);
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		libs__lp_rational__fix_basis_and_rem_cols_3_0_i14);
MR_def_label(libs__lp_rational__fix_basis_and_rem_cols_3_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__fix_basis_and_rem_cols_3_0_i15);
MR_def_label(libs__lp_rational__fix_basis_and_rem_cols_3_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__fix_basis_and_rem_cols_3_0_i12);
	}
	if (MR_LTAGS_TESTR(MR_sv(5),0,0)) {
		MR_GOTO_LAB(libs__lp_rational__fix_basis_and_rem_cols_3_0_i12);
	}
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 6);
	MR_tfield(0, MR_r2, 0) = (MR_Word) MR_COMMON(5,4);
	MR_tfield(0, MR_r2, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1152__1_4_0);
	MR_tfield(0, MR_r2, 2) = (MR_Integer) 3;
	MR_tfield(0, MR_r2, 3) = MR_sv(1);
	MR_tfield(0, MR_r2, 4) = MR_sv(3);
	MR_tfield(0, MR_r2, 5) = MR_sv(4);
	MR_r1 = MR_sv(7);
	MR_np_call_localret_ent(solutions__solutions_2_1,
		libs__lp_rational__fix_basis_and_rem_cols_3_0_i19);
MR_def_label(libs__lp_rational__fix_basis_and_rem_cols_3_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__fix_basis_and_rem_cols_3_0_i21);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_sv(3);
	MR_tempr2 = MR_sv(1);
	MR_tfield(1, MR_tempr1, 1) = MR_tfield(0, MR_tempr2, 4);
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 6);
	MR_tfield(0, MR_r2, 0) = MR_tfield(0, MR_tempr2, 0);
	MR_tfield(0, MR_r2, 1) = MR_tfield(0, MR_tempr2, 1);
	MR_tfield(0, MR_r2, 2) = MR_tfield(0, MR_tempr2, 2);
	MR_tfield(0, MR_r2, 3) = MR_tfield(0, MR_tempr2, 3);
	MR_tfield(0, MR_r2, 4) = MR_tempr1;
	MR_tfield(0, MR_r2, 5) = MR_tfield(0, MR_tempr2, 5);
	MR_r1 = MR_sv(4);
	}
	MR_np_call_localret_ent(libs__lp_rational__remove_row_3_0,
		libs__lp_rational__fix_basis_and_rem_cols_3_0_i24);
MR_def_label(libs__lp_rational__fix_basis_and_rem_cols_3_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(libs__lp_rational__remove_col_3_0,
		libs__lp_rational__fix_basis_and_rem_cols_3_0_i29);
MR_def_label(libs__lp_rational__fix_basis_and_rem_cols_3_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = MR_tfield(1, MR_tempr1, 0);
	MR_r3 = MR_sv(1);
	}
	MR_np_call_localret_ent(libs__lp_rational__pivot_4_0,
		libs__lp_rational__fix_basis_and_rem_cols_3_0_i25);
MR_def_label(libs__lp_rational__fix_basis_and_rem_cols_3_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tempr2 = MR_sv(3);
	MR_tfield(1, MR_tempr1, 0) = MR_tempr2;
	MR_tfield(1, MR_tempr1, 1) = MR_tfield(0, MR_r1, 4);
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 6);
	MR_tfield(0, MR_r2, 0) = MR_tfield(0, MR_r1, 0);
	MR_tfield(0, MR_r2, 1) = MR_tfield(0, MR_r1, 1);
	MR_tfield(0, MR_r2, 2) = MR_tfield(0, MR_r1, 2);
	MR_tfield(0, MR_r2, 3) = MR_tfield(0, MR_r1, 3);
	MR_tfield(0, MR_r2, 4) = MR_tempr1;
	MR_tfield(0, MR_r2, 5) = MR_tfield(0, MR_r1, 5);
	MR_r1 = MR_tempr2;
	}
	MR_np_call_localret_ent(libs__lp_rational__remove_col_3_0,
		libs__lp_rational__fix_basis_and_rem_cols_3_0_i29);
MR_def_label(libs__lp_rational__fix_basis_and_rem_cols_3_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(libs__lp_rational__remove_col_3_0,
		libs__lp_rational__fix_basis_and_rem_cols_3_0_i29);
MR_def_label(libs__lp_rational__fix_basis_and_rem_cols_3_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(8);
	MR_GOTO_LAB(libs__lp_rational__fix_basis_and_rem_cols_3_0_i62);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module33)
	MR_init_entry1(fn__libs__lp_rational__get_basis_vars_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__get_basis_vars_1_0);
	MR_init_label1(fn__libs__lp_rational__get_basis_vars_1_0,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'get_basis_vars'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__get_basis_vars_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 4);
	MR_tfield(0, MR_r2, 0) = (MR_Word) MR_COMMON(4,8);
	MR_tfield(0, MR_r2, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1345__1_2_0);
	MR_tfield(0, MR_r2, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_r2, 3) = MR_r1;
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_np_call_localret_ent(solutions__solutions_2_1,
		fn__libs__lp_rational__get_basis_vars_1_0_i3);
MR_def_label(fn__libs__lp_rational__get_basis_vars_1_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 5);
	MR_tfield(0, MR_r2, 0) = (MR_Word) MR_COMMON(2,9);
	MR_tfield(0, MR_r2, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1357__1_3_0);
	MR_tfield(0, MR_r2, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_r2, 3) = MR_sv(1);
	MR_tfield(0, MR_r2, 4) = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(solutions__solutions_2_1);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module34)
	MR_init_entry1(fn__libs__lp_rational__two_phase_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__two_phase_5_0);
	MR_init_label10(fn__libs__lp_rational__two_phase_5_0,5,6,7,8,10,11,14,15,19,20)
	MR_init_label8(fn__libs__lp_rational__two_phase_5_0,17,22,23,24,25,26,27,28)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'two_phase'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__two_phase_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(10);
	MR_sv(10) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_sv(4) = MR_r4;
	MR_sv(5) = MR_r5;
	MR_sv(7) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r1 = MR_sv(7);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,3,9);
	MR_r4 = MR_sv(3);
	MR_np_call_localret_ent(fn__list__map_2_0,
		fn__libs__lp_rational__two_phase_5_0_i5);
MR_def_label(fn__libs__lp_rational__two_phase_5_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Integer) 0;
	MR_r3 = MR_sv(4);
	MR_r4 = MR_sv(5);
	MR_np_call_localret_ent(libs__lp_rational__insert_terms_5_0,
		fn__libs__lp_rational__two_phase_5_0_i6);
MR_def_label(fn__libs__lp_rational__two_phase_5_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(libs__lp_rational__ensure_zero_obj_coeffs_3_0,
		fn__libs__lp_rational__two_phase_5_0_i7);
MR_def_label(fn__libs__lp_rational__two_phase_5_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(libs__lp_rational__simplex_3_0,
		fn__libs__lp_rational__two_phase_5_0_i8);
MR_def_label(fn__libs__lp_rational__two_phase_5_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(fn__libs__lp_rational__two_phase_5_0_i10);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_decr_sp_and_return(10);
MR_def_label(fn__libs__lp_rational__two_phase_5_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(6) = MR_r2;
	MR_r1 = (MR_Integer) 0;
	MR_r2 = MR_tfield(0, MR_r2, 1);
	MR_r3 = MR_sv(6);
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		fn__libs__lp_rational__two_phase_5_0_i11);
MR_def_label(fn__libs__lp_rational__two_phase_5_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_sv(8) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(5,5);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(fn__libs__lp_rational__extract_obj_var_3_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(6);
	MR_sv(5) = MR_r1;
	MR_sv(9) = (MR_Word) MR_TAG_COMMON(0,1,1);
	MR_r1 = MR_sv(7);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	}
	MR_np_call_localret_ent(fn__map__init_0_0,
		fn__libs__lp_rational__two_phase_5_0_i14);
MR_def_label(fn__libs__lp_rational__two_phase_5_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(7);
	MR_r2 = MR_sv(9);
	MR_r3 = MR_sv(8);
	MR_r4 = MR_sv(3);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__list__foldl_3_0,
		fn__libs__lp_rational__two_phase_5_0_i15);
MR_def_label(fn__libs__lp_rational__two_phase_5_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		fn__libs__lp_rational__two_phase_5_0_i19);
MR_def_label(fn__libs__lp_rational__two_phase_5_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		fn__libs__lp_rational__two_phase_5_0_i20);
MR_def_label(fn__libs__lp_rational__two_phase_5_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO_LAB(fn__libs__lp_rational__two_phase_5_0_i17);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 1);
	MR_decr_sp_and_return(10);
MR_def_label(fn__libs__lp_rational__two_phase_5_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(6);
	MR_np_call_localret_ent(libs__lp_rational__fix_basis_and_rem_cols_3_0,
		fn__libs__lp_rational__two_phase_5_0_i22);
MR_def_label(fn__libs__lp_rational__two_phase_5_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = (MR_Integer) 0;
	MR_r3 = MR_sv(4);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(libs__lp_rational__insert_terms_5_0,
		fn__libs__lp_rational__two_phase_5_0_i23);
MR_def_label(fn__libs__lp_rational__two_phase_5_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_np_call_localret_ent(fn__libs__lp_rational__get_basis_vars_1_0,
		fn__libs__lp_rational__two_phase_5_0_i24);
MR_def_label(fn__libs__lp_rational__two_phase_5_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_np_call_localret_ent(libs__lp_rational__ensure_zero_obj_coeffs_3_0,
		fn__libs__lp_rational__two_phase_5_0_i25);
MR_def_label(fn__libs__lp_rational__two_phase_5_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_r1 = MR_sv(7);
	MR_np_call_localret_ent(fn__set__init_0_0,
		fn__libs__lp_rational__two_phase_5_0_i26);
MR_def_label(fn__libs__lp_rational__two_phase_5_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(libs__lp_rational__get_vars_from_terms_3_0,
		fn__libs__lp_rational__two_phase_5_0_i27);
MR_def_label(fn__libs__lp_rational__two_phase_5_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(7);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__set__to_sorted_list_1_0,
		fn__libs__lp_rational__two_phase_5_0_i28);
MR_def_label(fn__libs__lp_rational__two_phase_5_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_succip_word = MR_sv(10);
	MR_decr_sp(10);
	MR_np_tailcall_ent(libs__lp_rational__optimize_4_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module35)
	MR_init_entry1(fn__libs__lp_rational__negate_constraint_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__negate_constraint_1_0);
	MR_init_label8(fn__libs__lp_rational__negate_constraint_1_0,6,7,3,12,13,9,17,18)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'negate_constraint'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__negate_constraint_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(fn__libs__lp_rational__negate_constraint_1_0_i3);
	}
	MR_sv(1) = MR_tfield(1, MR_r1, 1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r2 = MR_r1;
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r4 = (MR_Word) MR_TAG_COMMON(0,3,10);
	MR_r5 = MR_tfield(1, MR_tempr1, 0);
	}
	MR_np_call_localret_ent(fn__assoc_list__map_values_only_2_0,
		fn__libs__lp_rational__negate_constraint_1_0_i6);
MR_def_label(fn__libs__lp_rational__negate_constraint_1_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		fn__libs__lp_rational__negate_constraint_1_0_i7);
MR_def_label(fn__libs__lp_rational__negate_constraint_1_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_sv(1);
	MR_tfield(1, MR_r2, 1) = MR_r1;
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(2);
MR_def_label(fn__libs__lp_rational__negate_constraint_1_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(fn__libs__lp_rational__negate_constraint_1_0_i9);
	}
	MR_sv(1) = MR_tfield(2, MR_r1, 1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r2 = MR_r1;
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r4 = (MR_Word) MR_TAG_COMMON(0,3,11);
	MR_r5 = MR_tfield(2, MR_tempr1, 0);
	}
	MR_np_call_localret_ent(fn__assoc_list__map_values_only_2_0,
		fn__libs__lp_rational__negate_constraint_1_0_i12);
MR_def_label(fn__libs__lp_rational__negate_constraint_1_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		fn__libs__lp_rational__negate_constraint_1_0_i13);
MR_def_label(fn__libs__lp_rational__negate_constraint_1_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_decr_sp_and_return(2);
	}
MR_def_label(fn__libs__lp_rational__negate_constraint_1_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_tfield(0, MR_r1, 1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r2 = MR_r1;
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r4 = (MR_Word) MR_TAG_COMMON(0,3,12);
	MR_r5 = MR_tfield(0, MR_tempr1, 0);
	}
	MR_np_call_localret_ent(fn__assoc_list__map_values_only_2_0,
		fn__libs__lp_rational__negate_constraint_1_0_i17);
MR_def_label(fn__libs__lp_rational__negate_constraint_1_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		fn__libs__lp_rational__negate_constraint_1_0_i18);
MR_def_label(fn__libs__lp_rational__negate_constraint_1_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 2, (MR_Integer) 2);
	MR_tfield(2, MR_tempr1, 0) = MR_sv(1);
	MR_tfield(2, MR_tempr1, 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_decr_sp_and_return(2);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__f_115_101_116_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_108_105_115_116_95_116_111_95_115_101_116_95_95_91_84_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_1_0);

MR_BEGIN_MODULE(libs__lp_rational_module36)
	MR_init_entry1(fn__libs__lp_rational__collect_vars_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__collect_vars_2_0);
	MR_init_label1(fn__libs__lp_rational__collect_vars_2_0,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'collect_vars'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__collect_vars_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,10);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__collect_vars__945__1_3_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_tfield(0, MR_tempr1, 4) = MR_r2;
	MR_sv(1) = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_sv(2) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(solutions__solutions_2_1,
		fn__libs__lp_rational__collect_vars_2_0_i4);
MR_def_label(fn__libs__lp_rational__collect_vars_2_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_tempr1;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(fn__f_115_101_116_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_108_105_115_116_95_116_111_95_115_101_116_95_95_91_84_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(f_115_118_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_95_100_101_116_95_105_110_115_101_114_116_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_4_0);

MR_BEGIN_MODULE(libs__lp_rational_module37)
	MR_init_entry1(libs__lp_rational__number_vars_2_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__number_vars_2_4_0);
	MR_init_label3(libs__lp_rational__number_vars_2_4_0,14,3,5)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'number_vars_2'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__number_vars_2_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
MR_def_label(libs__lp_rational__number_vars_2_4_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__number_vars_2_4_0_i3);
	}
	MR_r1 = MR_r3;
	MR_decr_sp_and_return(3);
MR_def_label(libs__lp_rational__number_vars_2_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_tfield(1, MR_r1, 1);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_tempr2 = MR_r3;
	MR_r3 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r4 = MR_tfield(1, MR_tempr1, 0);
	MR_r5 = MR_sv(1);
	MR_r6 = MR_tempr2;
	}
	MR_np_call_localret_ent(f_115_118_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_95_100_101_116_95_105_110_115_101_114_116_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_4_0,
		libs__lp_rational__number_vars_2_4_0_i5);
MR_def_label(libs__lp_rational__number_vars_2_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = ((MR_Integer) MR_sv(1) + (MR_Integer) 1);
	MR_r3 = MR_tempr1;
	MR_succip_word = MR_sv(3);
	MR_GOTO_LAB(libs__lp_rational__number_vars_2_4_0_i14);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module38)
	MR_init_entry1(libs__lp_rational__insert_constraints_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__insert_constraints_6_0);
	MR_init_label4(libs__lp_rational__insert_constraints_6_0,19,3,7,8)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'insert_constraints'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__insert_constraints_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
MR_def_label(libs__lp_rational__insert_constraints_6_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__insert_constraints_6_0_i3);
	}
	MR_r1 = MR_r5;
	MR_decr_sp_and_return(6);
MR_def_label(libs__lp_rational__insert_constraints_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r1, 0);
	MR_sv(2) = MR_r3;
	MR_r3 = MR_r4;
	MR_r4 = MR_r5;
	MR_sv(4) = MR_tfield(1, MR_r1, 1);
	MR_r1 = MR_mask_field(MR_tempr1, 0);
	MR_sv(5) = MR_mask_field(MR_tempr1, 1);
	MR_sv(1) = MR_r2;
	MR_sv(3) = MR_r3;
	}
	MR_np_call_localret_ent(libs__lp_rational__insert_terms_5_0,
		libs__lp_rational__insert_constraints_6_0_i7);
MR_def_label(libs__lp_rational__insert_constraints_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(libs__lp_rational__set_cell_5_0,
		libs__lp_rational__insert_constraints_6_0_i8);
MR_def_label(libs__lp_rational__insert_constraints_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = ((MR_Integer) MR_sv(1) + (MR_Integer) 1);
	MR_r3 = MR_sv(2);
	MR_r4 = MR_sv(3);
	MR_r5 = MR_tempr1;
	MR_succip_word = MR_sv(6);
	MR_GOTO_LAB(libs__lp_rational__insert_constraints_6_0_i19);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(list__map_foldl_5_1);
MR_decl_entry(fn__list__length_1_0);

MR_BEGIN_MODULE(libs__lp_rational_module39)
	MR_init_entry1(libs__lp_rational__solve_2_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__solve_2_6_0);
	MR_init_label10(libs__lp_rational__solve_2_6_0,3,6,8,5,4,12,13,15,16,17)
	MR_init_label7(libs__lp_rational__solve_2_6_0,18,20,22,24,26,31,27)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'solve_2'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__solve_2_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(10);
	MR_sv(10) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_sv(6) = MR_r3;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_r2 = MR_r1;
	MR_r3 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, lp_info);
	MR_tempr2 = MR_r4;
	MR_r4 = (MR_Word) MR_TAG_COMMON(0,3,13);
	MR_r5 = MR_tempr1;
	MR_r6 = MR_tempr2;
	}
	MR_np_call_localret_ent(list__map_foldl_5_1,
		libs__lp_rational__solve_2_6_0_i3);
MR_def_label(libs__lp_rational__solve_2_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(1),0)) {
		MR_GOTO_LAB(libs__lp_rational__solve_2_6_0_i5);
	}
	MR_sv(7) = MR_r2;
	MR_sv(8) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__solve_2_6_0_i6);
MR_def_label(libs__lp_rational__solve_2_6_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_sv(6);
	MR_tfield(1, MR_r2, 1) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__libs__lp_rational__negate_constraint_1_0,
		libs__lp_rational__solve_2_6_0_i8);
MR_def_label(libs__lp_rational__solve_2_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(8);
	MR_sv(9) = MR_mask_field(MR_r1, 0);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_GOTO_LAB(libs__lp_rational__solve_2_6_0_i4);
MR_def_label(libs__lp_rational__solve_2_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(7) = MR_r2;
	MR_r2 = MR_r1;
	MR_sv(9) = MR_sv(6);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
MR_def_label(libs__lp_rational__solve_2_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(8) = MR_r2;
	MR_np_call_localret_ent(fn__list__length_1_0,
		libs__lp_rational__solve_2_6_0_i12);
MR_def_label(libs__lp_rational__solve_2_6_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_r1 = MR_sv(8);
	MR_r2 = MR_sv(6);
	MR_np_call_localret_ent(fn__libs__lp_rational__collect_vars_2_0,
		libs__lp_rational__solve_2_6_0_i13);
MR_def_label(libs__lp_rational__solve_2_6_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = (MR_Word) MR_TAG_COMMON(0,0,0);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__set__to_sorted_list_1_0,
		libs__lp_rational__solve_2_6_0_i15);
MR_def_label(libs__lp_rational__solve_2_6_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__list__length_1_0,
		libs__lp_rational__solve_2_6_0_i16);
MR_def_label(libs__lp_rational__solve_2_6_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r2 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_np_call_localret_ent(fn__map__init_0_0,
		libs__lp_rational__solve_2_6_0_i17);
MR_def_label(libs__lp_rational__solve_2_6_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Integer) 0;
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(libs__lp_rational__number_vars_2_4_0,
		libs__lp_rational__solve_2_6_0_i18);
MR_def_label(libs__lp_rational__solve_2_6_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_sv(5) = MR_tfield(0, MR_sv(7), 2);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,4);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_np_call_localret_ent(fn__map__init_0_0,
		libs__lp_rational__solve_2_6_0_i20);
MR_def_label(libs__lp_rational__solve_2_6_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 6);
	MR_r5 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(2);
	MR_tempr2 = MR_sv(4);
	MR_tfield(0, MR_tempr1, 1) = MR_tempr2;
	MR_tempr3 = MR_sv(3);
	MR_tfield(0, MR_tempr1, 2) = MR_tempr3;
	MR_tfield(0, MR_tempr1, 3) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr1, 4) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr1, 5) = MR_r1;
	MR_r1 = MR_sv(8);
	MR_r2 = (MR_Integer) 1;
	MR_r3 = MR_tempr2;
	MR_r4 = MR_tempr3;
	}
	MR_np_call_localret_ent(libs__lp_rational__insert_constraints_6_0,
		libs__lp_rational__solve_2_6_0_i22);
MR_def_label(libs__lp_rational__solve_2_6_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(5),0,0)) {
		MR_GOTO_LAB(libs__lp_rational__solve_2_6_0_i24);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(9);
	MR_r3 = MR_sv(3);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__libs__lp_rational__one_phase_4_0,
		libs__lp_rational__solve_2_6_0_i26);
MR_def_label(libs__lp_rational__solve_2_6_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(9);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(3);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__libs__lp_rational__two_phase_5_0,
		libs__lp_rational__solve_2_6_0_i26);
MR_def_label(libs__lp_rational__solve_2_6_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(7);
	if (MR_INT_EQ(MR_sv(1),0)) {
		MR_GOTO_LAB(libs__lp_rational__solve_2_6_0_i27);
	}
	if ((((MR_Integer) MR_r1 == (MR_Integer) MR_tbmkword(0, 1)) || ((MR_Integer) MR_r1 == (MR_Integer) MR_tbmkword(0, 0)))) {
		MR_GOTO_LAB(libs__lp_rational__solve_2_6_0_i27);
	}
	MR_sv(1) = MR_tfield(1, MR_r1, 1);
	MR_r1 = MR_tfield(1, MR_r1, 0);
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		libs__lp_rational__solve_2_6_0_i31);
MR_def_label(libs__lp_rational__solve_2_6_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_r1;
	MR_tfield(1, MR_tempr1, 1) = MR_sv(1);
	MR_r1 = MR_tempr1;
	MR_r2 = MR_sv(7);
	}
MR_def_label(libs__lp_rational__solve_2_6_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(10);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module40)
	MR_init_entry1(fn__libs__lp_rational__solve_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__solve_4_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'solve'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__libs__lp_rational__solve_4_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 3);
	MR_tfield(0, MR_tempr1, 0) = MR_r4;
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Word) MR_tbmkword(0, 0);
	MR_r4 = MR_tempr1;
	MR_np_tailcall_ent(libs__lp_rational__solve_2_6_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module41)
	MR_init_entry1(fn__libs__lp_rational__entailed_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__entailed_3_0);
	MR_init_label10(fn__libs__lp_rational__entailed_3_0,74,5,3,12,14,33,15,17,10,21)
	MR_init_label5(fn__libs__lp_rational__entailed_3_0,23,36,24,26,82)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'entailed'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__libs__lp_rational__entailed_3_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
MR_def_label(fn__libs__lp_rational__entailed_3_0,74)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r3,1)) {
		MR_GOTO_LAB(fn__libs__lp_rational__entailed_3_0_i3);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tempr2 = MR_r3;
	MR_tfield(0, MR_tempr1, 0) = MR_tfield(1, MR_tempr2, 0);
	MR_tfield(0, MR_tempr1, 1) = MR_tfield(1, MR_tempr2, 1);
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_tfield(0, MR_tempr1, 0);
	MR_sv(4) = MR_tfield(0, MR_tempr1, 1);
	MR_r3 = MR_tempr1;
	}
	MR_np_localcall_lab(fn__libs__lp_rational__entailed_3_0,
		fn__libs__lp_rational__entailed_3_0_i5);
MR_def_label(fn__libs__lp_rational__entailed_3_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((((MR_Integer) MR_r1 == (MR_Integer) 2) || ((MR_Integer) MR_r1 == (MR_Integer) 1))) {
		MR_GOTO_LAB(fn__libs__lp_rational__entailed_3_0_i82);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 2, (MR_Integer) 2);
	MR_r3 = MR_tempr1;
	MR_tfield(2, MR_tempr1, 0) = MR_sv(3);
	MR_tfield(2, MR_tempr1, 1) = MR_sv(4);
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_succip_word = MR_sv(5);
	MR_GOTO_LAB(fn__libs__lp_rational__entailed_3_0_i74);
	}
MR_def_label(fn__libs__lp_rational__entailed_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r3,2)) {
		MR_GOTO_LAB(fn__libs__lp_rational__entailed_3_0_i10);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 3);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_r1;
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Word) MR_tbmkword(0, 0);
	MR_sv(1) = MR_tfield(2, MR_r3, 1);
	MR_r1 = MR_r2;
	MR_r2 = (MR_Integer) 1;
	MR_r3 = MR_tfield(2, MR_r3, 0);
	}
	MR_np_call_localret_ent(libs__lp_rational__solve_2_6_0,
		fn__libs__lp_rational__entailed_3_0_i12);
MR_def_label(fn__libs__lp_rational__entailed_3_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,1)) {
		MR_GOTO_LAB(fn__libs__lp_rational__entailed_3_0_i14);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(5);
MR_def_label(fn__libs__lp_rational__entailed_3_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(fn__libs__lp_rational__entailed_3_0_i15);
	}
MR_def_label(fn__libs__lp_rational__entailed_3_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(5);
MR_def_label(fn__libs__lp_rational__entailed_3_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(1, MR_r1, 0);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_62_61_2_0,
		fn__libs__lp_rational__entailed_3_0_i17);
MR_def_label(fn__libs__lp_rational__entailed_3_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(fn__libs__lp_rational__entailed_3_0_i36);
	}
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_and_return(5);
MR_def_label(fn__libs__lp_rational__entailed_3_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 3);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_r1;
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Word) MR_tbmkword(0, 0);
	MR_sv(1) = MR_tfield(0, MR_r3, 1);
	MR_r1 = MR_r2;
	MR_r2 = (MR_Integer) 0;
	MR_r3 = MR_tfield(0, MR_r3, 0);
	}
	MR_np_call_localret_ent(libs__lp_rational__solve_2_6_0,
		fn__libs__lp_rational__entailed_3_0_i21);
MR_def_label(fn__libs__lp_rational__entailed_3_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,1)) {
		MR_GOTO_LAB(fn__libs__lp_rational__entailed_3_0_i23);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(5);
MR_def_label(fn__libs__lp_rational__entailed_3_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(fn__libs__lp_rational__entailed_3_0_i24);
	}
MR_def_label(fn__libs__lp_rational__entailed_3_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(5);
MR_def_label(fn__libs__lp_rational__entailed_3_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(1, MR_r1, 0);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_61_60_2_0,
		fn__libs__lp_rational__entailed_3_0_i26);
MR_def_label(fn__libs__lp_rational__entailed_3_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(fn__libs__lp_rational__entailed_3_0_i33);
	}
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_and_return(5);
MR_def_label(fn__libs__lp_rational__entailed_3_0,82)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(5);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(list__cons_3_0);
MR_decl_entry(list__member_2_1);
MR_decl_entry(fn__pair__snd_1_0);
MR_declare_entry(MR_do_redo);

MR_BEGIN_MODULE(libs__lp_rational_module42)
	MR_init_entry1(libs__lp_rational__remove_some_entailed_constraints_2_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__remove_some_entailed_constraints_2_4_0);
	MR_init_label10(libs__lp_rational__remove_some_entailed_constraints_2_4_0,121,3,6,5,11,12,16,21,23,24)
	MR_init_label10(libs__lp_rational__remove_some_entailed_constraints_2_4_0,25,10,29,30,34,39,41,42,43,40)
	MR_init_label9(libs__lp_rational__remove_some_entailed_constraints_2_4_0,38,7,8,46,47,65,49,51,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'remove_some_entailed_constraints_2'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__remove_some_entailed_constraints_2_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(11);
	MR_sv(11) = (MR_Word) MR_succip;
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,121)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__remove_some_entailed_constraints_2_4_0_i3);
	}
	MR_r2 = MR_r3;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(11);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r4 = MR_tfield(1, MR_r2, 1);
	if (MR_LTAGS_TESTR(MR_r4,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__remove_some_entailed_constraints_2_4_0_i5);
	}
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_r2 = MR_tfield(1, MR_r2, 0);
	MR_np_call_localret_ent(list__cons_3_0,
		libs__lp_rational__remove_some_entailed_constraints_2_4_0_i6);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_r1;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(11);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r2, 0);
	MR_sv(5) = MR_tempr1;
	if (MR_PTAG_TESTR(MR_tempr1,2)) {
		MR_GOTO_LAB(libs__lp_rational__remove_some_entailed_constraints_2_4_0_i10);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r3;
	MR_sv(4) = MR_r4;
	MR_sv(3) = MR_tfield(2, MR_tempr1, 0);
	MR_sv(6) = MR_tfield(2, MR_tempr1, 1);
	}
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__remove_some_entailed_constraints_2_4_0_i11);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_61_60_2_0,
		libs__lp_rational__remove_some_entailed_constraints_2_4_0_i12);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__remove_some_entailed_constraints_2_4_0_i7);
	}
	MR_sv(6) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_sv(7) = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r1 = MR_sv(7);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__list__length_1_0,
		libs__lp_rational__remove_some_entailed_constraints_2_4_0_i16);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_LT(MR_r1,2)) {
		MR_GOTO_LAB(libs__lp_rational__remove_some_entailed_constraints_2_4_0_i7);
	}
	MR_sv(8) = (MR_Word) MR_redoip_slot(MR_maxfr);
	MR_sv(9) = (MR_Word) MR_redofr_slot(MR_maxfr);
	MR_save_maxfr(MR_sv(10));
	MR_redofr_slot_word(MR_maxfr) = (MR_Word) MR_curfr;
	MR_redoip_slot_word(MR_maxfr) = (MR_Word) MR_LABEL_AP(libs__lp_rational__remove_some_entailed_constraints_2_4_0_i38);
	MR_r1 = MR_sv(7);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(list__member_2_1,
		libs__lp_rational__remove_some_entailed_constraints_2_4_0_i21);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__pair__snd_1_0,
		libs__lp_rational__remove_some_entailed_constraints_2_4_0_i23);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__remove_some_entailed_constraints_2_4_0_i24);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_62_2_0,
		libs__lp_rational__remove_some_entailed_constraints_2_4_0_i25);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__remove_some_entailed_constraints_2_4_0_i40);
	}
	MR_GOTO(MR_ENTRY(MR_do_redo));
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(5),0)) {
		MR_GOTO_LAB(libs__lp_rational__remove_some_entailed_constraints_2_4_0_i8);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r3;
	MR_sv(4) = MR_r4;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(5);
	MR_sv(3) = MR_tfield(0, MR_tempr1, 0);
	MR_sv(6) = MR_tfield(0, MR_tempr1, 1);
	}
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__remove_some_entailed_constraints_2_4_0_i29);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_62_61_2_0,
		libs__lp_rational__remove_some_entailed_constraints_2_4_0_i30);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__remove_some_entailed_constraints_2_4_0_i7);
	}
	MR_sv(6) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_sv(7) = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r1 = MR_sv(7);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__list__length_1_0,
		libs__lp_rational__remove_some_entailed_constraints_2_4_0_i34);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_LT(MR_r1,2)) {
		MR_GOTO_LAB(libs__lp_rational__remove_some_entailed_constraints_2_4_0_i7);
	}
	MR_sv(8) = (MR_Word) MR_redoip_slot(MR_maxfr);
	MR_sv(9) = (MR_Word) MR_redofr_slot(MR_maxfr);
	MR_save_maxfr(MR_sv(10));
	MR_redofr_slot_word(MR_maxfr) = (MR_Word) MR_curfr;
	MR_redoip_slot_word(MR_maxfr) = (MR_Word) MR_LABEL_AP(libs__lp_rational__remove_some_entailed_constraints_2_4_0_i38);
	MR_r1 = MR_sv(7);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(list__member_2_1,
		libs__lp_rational__remove_some_entailed_constraints_2_4_0_i39);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__pair__snd_1_0,
		libs__lp_rational__remove_some_entailed_constraints_2_4_0_i41);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,41)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__remove_some_entailed_constraints_2_4_0_i42);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,42)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_60_2_0,
		libs__lp_rational__remove_some_entailed_constraints_2_4_0_i43);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_restore_maxfr(MR_sv(10));
	MR_redoip_slot_word(MR_maxfr) = MR_sv(8);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(9);
	MR_GOTO_LAB(libs__lp_rational__remove_some_entailed_constraints_2_4_0_i7);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,38)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_redoip_slot_word(MR_maxfr) = MR_sv(8);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(9);
	MR_GOTO_LAB(libs__lp_rational__remove_some_entailed_constraints_2_4_0_i65);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r3 = MR_sv(2);
	MR_r4 = MR_sv(4);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r3;
	MR_sv(3) = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r4;
	MR_sv(4) = MR_tempr1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_108_105_115_116_95_95_43_43_2_0,
		libs__lp_rational__remove_some_entailed_constraints_2_4_0_i46);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,46)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(5);
	}
	MR_np_call_localret_ent(fn__libs__lp_rational__entailed_3_0,
		libs__lp_rational__remove_some_entailed_constraints_2_4_0_i47);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,47)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(libs__lp_rational__remove_some_entailed_constraints_2_4_0_i49);
	}
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,65)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r3 = MR_sv(2);
	MR_r2 = MR_sv(4);
	MR_succip_word = MR_sv(11);
	MR_GOTO_LAB(libs__lp_rational__remove_some_entailed_constraints_2_4_0_i121);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,49)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,1)) {
		MR_GOTO_LAB(libs__lp_rational__remove_some_entailed_constraints_2_4_0_i1);
	}
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(5);
	MR_r3 = MR_sv(2);
	MR_np_call_localret_ent(list__cons_3_0,
		libs__lp_rational__remove_some_entailed_constraints_2_4_0_i51);
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,51)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r3 = MR_tempr1;
	MR_r2 = MR_sv(4);
	MR_succip_word = MR_sv(11);
	MR_GOTO_LAB(libs__lp_rational__remove_some_entailed_constraints_2_4_0_i121);
	}
MR_def_label(libs__lp_rational__remove_some_entailed_constraints_2_4_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_decr_sp_and_return(11);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module43)
	MR_init_entry1(libs__lp_rational__remove_some_entailed_constraints_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__remove_some_entailed_constraints_3_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'remove_some_entailed_constraints'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__libs__lp_rational__remove_some_entailed_constraints_3_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = (MR_Word) MR_tbmkword(0, 0);
	MR_np_tailcall_ent(libs__lp_rational__remove_some_entailed_constraints_2_4_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module44)
	MR_init_entry1(libs__lp_rational__inconsistent_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__inconsistent_2_0);
	MR_init_label6(libs__lp_rational__inconsistent_2_0,6,9,13,20,3,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'inconsistent'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__libs__lp_rational__inconsistent_2_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	if (MR_LTAGS_TEST(MR_r2,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__inconsistent_2_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r2, 0);
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r1;
	MR_sv(3) = MR_tempr1;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(libs__lp_rational__is_false_1_0,
		libs__lp_rational__inconsistent_2_0_i6);
MR_def_label(libs__lp_rational__inconsistent_2_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO_LAB(libs__lp_rational__inconsistent_2_0_i3);
	}
	MR_r2 = MR_sv(1);
	MR_r1 = MR_sv(2);
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tempr1 = MR_sv(3);
	MR_r3 = MR_tempr1;
	if (MR_PTAG_TESTR(MR_tempr1,1)) {
		MR_GOTO_LAB(libs__lp_rational__inconsistent_2_0_i9);
	}
	MR_tempr2 = MR_tfield(1, MR_tempr1, 0);
	if (MR_LTAGS_TEST(MR_tempr2,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__inconsistent_2_0_i1);
	}
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 2);
	MR_r3 = MR_tempr3;
	MR_tfield(1, MR_tempr3, 0) = MR_tfield(1, MR_tempr2, 0);
	MR_tfield(1, MR_tempr3, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr4, 0, (MR_Integer) 3);
	MR_r4 = MR_tempr4;
	MR_tfield(0, MR_tempr4, 0) = MR_r1;
	MR_tfield(0, MR_tempr4, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr4, 2) = (MR_Word) MR_tbmkword(0, 0);
	MR_r1 = MR_r2;
	MR_r2 = (MR_Integer) 0;
	}
	MR_np_call_localret_ent(libs__lp_rational__solve_2_6_0,
		libs__lp_rational__inconsistent_2_0_i20);
MR_def_label(libs__lp_rational__inconsistent_2_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r3,2)) {
		MR_GOTO_LAB(libs__lp_rational__inconsistent_2_0_i13);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr1 = MR_tfield(2, MR_r3, 0);
	if (MR_LTAGS_TEST(MR_tempr1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__inconsistent_2_0_i1);
	}
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_r3 = MR_tempr2;
	MR_tfield(1, MR_tempr2, 0) = MR_tfield(1, MR_tempr1, 0);
	MR_tfield(1, MR_tempr2, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr3, 0, (MR_Integer) 3);
	MR_r4 = MR_tempr3;
	MR_tfield(0, MR_tempr3, 0) = MR_r1;
	MR_tfield(0, MR_tempr3, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr3, 2) = (MR_Word) MR_tbmkword(0, 0);
	MR_r1 = MR_r2;
	MR_r2 = (MR_Integer) 0;
	}
	MR_np_call_localret_ent(libs__lp_rational__solve_2_6_0,
		libs__lp_rational__inconsistent_2_0_i20);
MR_def_label(libs__lp_rational__inconsistent_2_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr1 = MR_tfield(0, MR_r3, 0);
	if (MR_LTAGS_TEST(MR_tempr1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__inconsistent_2_0_i1);
	}
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_r3 = MR_tempr2;
	MR_tfield(1, MR_tempr2, 0) = MR_tfield(1, MR_tempr1, 0);
	MR_tfield(1, MR_tempr2, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr3, 0, (MR_Integer) 3);
	MR_r4 = MR_tempr3;
	MR_tfield(0, MR_tempr3, 0) = MR_r1;
	MR_tfield(0, MR_tempr3, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr3, 2) = (MR_Word) MR_tbmkword(0, 0);
	MR_r1 = MR_r2;
	MR_r2 = (MR_Integer) 0;
	}
	MR_np_call_localret_ent(libs__lp_rational__solve_2_6_0,
		libs__lp_rational__inconsistent_2_0_i20);
MR_def_label(libs__lp_rational__inconsistent_2_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = ((MR_Integer) MR_r1 == (MR_Integer) MR_tbmkword(0, 1));
	MR_decr_sp_and_return(4);
MR_def_label(libs__lp_rational__inconsistent_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(libs__lp_rational__inconsistent_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module45)
	MR_init_entry1(fn__libs__lp_rational__remove_trivial_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__remove_trivial_1_0);
	MR_init_label10(fn__libs__lp_rational__remove_trivial_1_0,149,6,8,4,11,16,12,13,23,71)
	MR_init_label10(fn__libs__lp_rational__remove_trivial_1_0,21,27,28,32,37,39,40,41,26,45)
	MR_init_label10(fn__libs__lp_rational__remove_trivial_1_0,46,50,55,57,58,59,56,54,18,19)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'remove_trivial'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__remove_trivial_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(fn__libs__lp_rational__remove_trivial_1_0_i149);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_proceed();
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,149)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(9);
	MR_sv(9) = (MR_Word) MR_succip;
	MR_sv(2) = MR_tfield(1, MR_r1, 1);
	MR_r2 = MR_tfield(1, MR_r1, 0);
	MR_sv(1) = MR_r2;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(libs__lp_rational__is_false_1_0,
		fn__libs__lp_rational__remove_trivial_1_0_i6);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(fn__libs__lp_rational__remove_trivial_1_0_i4);
	}
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		fn__libs__lp_rational__remove_trivial_1_0_i8);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(1, MR_r2, 1) = MR_r1;
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r1, 0) = MR_r2;
	MR_tfield(1, MR_r1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_decr_sp_and_return(9);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_r1 = MR_sv(2);
	MR_np_localcall_lab(fn__libs__lp_rational__remove_trivial_1_0,
		fn__libs__lp_rational__remove_trivial_1_0_i11);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_r1,0,0)) {
		MR_GOTO_LAB(fn__libs__lp_rational__remove_trivial_1_0_i13);
	}
	MR_r2 = MR_tfield(1, MR_r1, 1);
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(fn__libs__lp_rational__remove_trivial_1_0_i13);
	}
	MR_sv(2) = MR_r1;
	MR_r1 = MR_tfield(1, MR_r1, 0);
	MR_np_call_localret_ent(libs__lp_rational__is_false_1_0,
		fn__libs__lp_rational__remove_trivial_1_0_i16);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(fn__libs__lp_rational__remove_trivial_1_0_i12);
	}
	MR_r1 = MR_sv(2);
	MR_decr_sp_and_return(9);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(libs__lp_rational__is_true_1_0,
		fn__libs__lp_rational__remove_trivial_1_0_i23);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(fn__libs__lp_rational__remove_trivial_1_0_i21);
	}
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,71)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_decr_sp_and_return(9);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	if (MR_PTAG_TESTR(MR_sv(1),2)) {
		MR_GOTO_LAB(fn__libs__lp_rational__remove_trivial_1_0_i26);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(3) = MR_tfield(2, MR_tempr1, 0);
	MR_sv(4) = MR_tfield(2, MR_tempr1, 1);
	}
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		fn__libs__lp_rational__remove_trivial_1_0_i27);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_61_60_2_0,
		fn__libs__lp_rational__remove_trivial_1_0_i28);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(fn__libs__lp_rational__remove_trivial_1_0_i18);
	}
	MR_sv(4) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_sv(5) = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__list__length_1_0,
		fn__libs__lp_rational__remove_trivial_1_0_i32);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_LT(MR_r1,2)) {
		MR_GOTO_LAB(fn__libs__lp_rational__remove_trivial_1_0_i18);
	}
	MR_sv(6) = (MR_Word) MR_redoip_slot(MR_maxfr);
	MR_sv(7) = (MR_Word) MR_redofr_slot(MR_maxfr);
	MR_save_maxfr(MR_sv(8));
	MR_redofr_slot_word(MR_maxfr) = (MR_Word) MR_curfr;
	MR_redoip_slot_word(MR_maxfr) = (MR_Word) MR_LABEL_AP(fn__libs__lp_rational__remove_trivial_1_0_i54);
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(list__member_2_1,
		fn__libs__lp_rational__remove_trivial_1_0_i37);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,37)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__pair__snd_1_0,
		fn__libs__lp_rational__remove_trivial_1_0_i39);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		fn__libs__lp_rational__remove_trivial_1_0_i40);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_62_2_0,
		fn__libs__lp_rational__remove_trivial_1_0_i41);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,41)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(fn__libs__lp_rational__remove_trivial_1_0_i56);
	}
	MR_GOTO(MR_ENTRY(MR_do_redo));
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(1),0)) {
		MR_GOTO_LAB(fn__libs__lp_rational__remove_trivial_1_0_i19);
	}
	MR_sv(2) = MR_r1;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(3) = MR_tfield(0, MR_tempr1, 0);
	MR_sv(4) = MR_tfield(0, MR_tempr1, 1);
	}
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		fn__libs__lp_rational__remove_trivial_1_0_i45);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,45)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_62_61_2_0,
		fn__libs__lp_rational__remove_trivial_1_0_i46);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,46)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(fn__libs__lp_rational__remove_trivial_1_0_i18);
	}
	MR_sv(4) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_sv(5) = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__list__length_1_0,
		fn__libs__lp_rational__remove_trivial_1_0_i50);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,50)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_LT(MR_r1,2)) {
		MR_GOTO_LAB(fn__libs__lp_rational__remove_trivial_1_0_i18);
	}
	MR_sv(6) = (MR_Word) MR_redoip_slot(MR_maxfr);
	MR_sv(7) = (MR_Word) MR_redofr_slot(MR_maxfr);
	MR_save_maxfr(MR_sv(8));
	MR_redofr_slot_word(MR_maxfr) = (MR_Word) MR_curfr;
	MR_redoip_slot_word(MR_maxfr) = (MR_Word) MR_LABEL_AP(fn__libs__lp_rational__remove_trivial_1_0_i54);
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(list__member_2_1,
		fn__libs__lp_rational__remove_trivial_1_0_i55);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,55)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__pair__snd_1_0,
		fn__libs__lp_rational__remove_trivial_1_0_i57);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,57)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		fn__libs__lp_rational__remove_trivial_1_0_i58);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,58)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_60_2_0,
		fn__libs__lp_rational__remove_trivial_1_0_i59);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,59)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,56)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_restore_maxfr(MR_sv(8));
	MR_redoip_slot_word(MR_maxfr) = MR_sv(6);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(7);
	MR_GOTO_LAB(fn__libs__lp_rational__remove_trivial_1_0_i18);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,54)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_redoip_slot_word(MR_maxfr) = MR_sv(6);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(7);
	MR_GOTO_LAB(fn__libs__lp_rational__remove_trivial_1_0_i71);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
MR_def_label(fn__libs__lp_rational__remove_trivial_1_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_sv(1);
	MR_tfield(1, MR_r2, 1) = MR_r1;
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(9);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_bool__type_ctor_info_bool_0;
MR_decl_entry(list__foldl2_6_0);

MR_BEGIN_MODULE(libs__lp_rational_module46)
	MR_init_entry1(fn__libs__lp_rational__remove_weaker_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__remove_weaker_1_0);
	MR_init_label4(fn__libs__lp_rational__remove_weaker_1_0,27,6,7,26)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'remove_weaker'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__remove_weaker_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(fn__libs__lp_rational__remove_weaker_1_0_i27);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_proceed();
MR_def_label(fn__libs__lp_rational__remove_weaker_1_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(6,2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__remove_weaker_2_6_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_tfield(1, MR_r1, 0);
	MR_sv(1) = MR_tfield(0, MR_tempr1, 3);
	MR_tempr2 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,10);
	MR_r3 = (MR_Word) MR_BOOL_CTOR_ADDR;
	MR_r5 = MR_tfield(1, MR_tempr2, 1);
	MR_r6 = (MR_Word) MR_tbmkword(0, 0);
	MR_r7 = (MR_Integer) 1;
	}
	MR_np_call_localret_ent(list__foldl2_6_0,
		fn__libs__lp_rational__remove_weaker_1_0_i6);
MR_def_label(fn__libs__lp_rational__remove_weaker_1_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r2;
	MR_np_localcall_lab(fn__libs__lp_rational__remove_weaker_1_0,
		fn__libs__lp_rational__remove_weaker_1_0_i7);
MR_def_label(fn__libs__lp_rational__remove_weaker_1_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_EQ(MR_sv(2),0)) {
		MR_GOTO_LAB(fn__libs__lp_rational__remove_weaker_1_0_i26);
	}
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_sv(1);
	MR_tfield(1, MR_r2, 1) = MR_r1;
	MR_r1 = MR_r2;
MR_def_label(fn__libs__lp_rational__remove_weaker_1_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(3);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module47)
	MR_init_entry1(fn__libs__lp_rational__simplify_constraints_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__simplify_constraints_1_0);
	MR_init_label1(fn__libs__lp_rational__simplify_constraints_1_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'simplify_constraints'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__libs__lp_rational__simplify_constraints_1_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(1);
	MR_sv(1) = (MR_Word) MR_succip;
	MR_np_call_localret_ent(fn__libs__lp_rational__remove_trivial_1_0,
		fn__libs__lp_rational__simplify_constraints_1_0_i2);
MR_def_label(fn__libs__lp_rational__simplify_constraints_1_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(1);
	MR_decr_sp(1);
	MR_np_tailcall_ent(fn__libs__lp_rational__remove_weaker_1_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__map__from_corresponding_lists_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module48)
	MR_init_entry1(fn__libs__lp_rational__substitute_vars_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__substitute_vars_3_0);
	MR_init_label1(fn__libs__lp_rational__substitute_vars_3_0,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'substitute_vars'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__libs__lp_rational__substitute_vars_3_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r3;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_r1;
	MR_r3 = MR_tempr1;
	MR_r4 = MR_tempr2;
	}
	MR_np_call_localret_ent(fn__map__from_corresponding_lists_2_0,
		fn__libs__lp_rational__substitute_vars_3_0_i3);
MR_def_label(fn__libs__lp_rational__substitute_vars_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,11);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(fn__libs__lp_rational__substitute_vars_2_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_r2 = MR_r1;
	MR_r4 = MR_sv(1);
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(fn__list__map_2_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module49)
	MR_init_entry1(fn__libs__lp_rational__substitute_vars_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__substitute_vars_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'substitute_vars'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__libs__lp_rational__substitute_vars_2_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,12);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(fn__libs__lp_rational__substitute_vars_2_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_r1;
	MR_r4 = MR_tempr2;
	MR_np_tailcall_ent(fn__list__map_2_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module50)
	MR_init_entry1(fn__libs__lp_rational__set_vars_to_zero_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__set_vars_to_zero_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'set_vars_to_zero'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__libs__lp_rational__set_vars_to_zero_2_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,13);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(fn__libs__lp_rational__set_vars_to_zero_2_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_r1;
	MR_r4 = MR_tempr2;
	MR_np_tailcall_ent(fn__list__map_2_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module51)
	MR_init_entry1(fn__libs__lp_rational__get_vars_from_constraints_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__get_vars_from_constraints_1_0);
	MR_init_label1(fn__libs__lp_rational__get_vars_from_constraints_1_0,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'get_vars_from_constraints'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__libs__lp_rational__get_vars_from_constraints_1_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(fn__set__init_0_0,
		fn__libs__lp_rational__get_vars_from_constraints_1_0_i3);
MR_def_label(fn__libs__lp_rational__get_vars_from_constraints_1_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,12);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,3,14);
	MR_r4 = MR_sv(1);
	MR_r5 = MR_tempr1;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module52)
	MR_init_entry1(fn__libs__lp_rational__bounding_box_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__bounding_box_2_0);
	MR_init_label2(fn__libs__lp_rational__bounding_box_2_0,3,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'bounding_box'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__libs__lp_rational__bounding_box_2_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__libs__lp_rational__get_vars_from_constraints_1_0,
		fn__libs__lp_rational__bounding_box_2_0_i3);
MR_def_label(fn__libs__lp_rational__bounding_box_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__set__to_sorted_list_1_0,
		fn__libs__lp_rational__bounding_box_2_0_i4);
MR_def_label(fn__libs__lp_rational__bounding_box_2_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(5,7);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(fn__libs__lp_rational__IntroducedFrom__func__bounding_box__726__1_3_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,10);
	MR_r4 = MR_tempr2;
	MR_r5 = MR_sv(2);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(fn__list__foldl_3_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(set__fold_4_0);

MR_BEGIN_MODULE(libs__lp_rational_module53)
	MR_init_entry1(fn__libs__lp_rational__nonneg_box_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__nonneg_box_2_0);
	MR_init_label1(fn__libs__lp_rational__nonneg_box_2_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'nonneg_box'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__libs__lp_rational__nonneg_box_2_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__libs__lp_rational__get_vars_from_constraints_1_0,
		fn__libs__lp_rational__nonneg_box_2_0_i2);
MR_def_label(fn__libs__lp_rational__nonneg_box_2_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(5,8);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__nonneg_box__749__1_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tempr2 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,10);
	MR_r4 = MR_tempr2;
	MR_r5 = (MR_Word) MR_tbmkword(0, 0);
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(set__fold_4_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__libs__compiler_util__unexpected_2_0);
MR_decl_entry(builtin__unify_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module54)
	MR_init_entry1(fn__libs__lp_rational__find_target_equality_2_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__find_target_equality_2_3_0);
	MR_init_label10(fn__libs__lp_rational__find_target_equality_2_3_0,62,3,9,7,4,13,24,25,20,27)
	MR_init_label2(fn__libs__lp_rational__find_target_equality_2_3_0,28,18)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'find_target_equality_2'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__find_target_equality_2_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(10);
	MR_sv(10) = (MR_Word) MR_succip;
MR_def_label(fn__libs__lp_rational__find_target_equality_2_3_0,62)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(fn__libs__lp_rational__find_target_equality_2_3_0_i3);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_decr_sp_and_return(10);
MR_def_label(fn__libs__lp_rational__find_target_equality_2_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_tfield(1, MR_r2, 1);
	MR_sv(3) = MR_tfield(1, MR_r2, 0);
	if (MR_PTAG_TESTR(MR_sv(3),1)) {
		MR_GOTO_LAB(fn__libs__lp_rational__find_target_equality_2_3_0_i9);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r3;
	MR_GOTO_LAB(fn__libs__lp_rational__find_target_equality_2_3_0_i4);
MR_def_label(fn__libs__lp_rational__find_target_equality_2_3_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(3),2)) {
		MR_GOTO_LAB(fn__libs__lp_rational__find_target_equality_2_3_0_i7);
	}
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, lp_operator);
	MR_r2 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_sv(2) = MR_r3;
	MR_r3 = (MR_Word) MR_string_const("operator/1: gte.", 16);
	MR_np_call_localret_ent(fn__libs__compiler_util__unexpected_2_0,
		fn__libs__lp_rational__find_target_equality_2_3_0_i4);
MR_def_label(fn__libs__lp_rational__find_target_equality_2_3_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r2 = (MR_Word) MR_string_const("find_target_equality_2/3: inequality encountered.", 49);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		fn__libs__lp_rational__find_target_equality_2_3_0_i13);
MR_def_label(fn__libs__lp_rational__find_target_equality_2_3_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(2);
	}
MR_def_label(fn__libs__lp_rational__find_target_equality_2_3_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_mask_field(MR_sv(3), 0);
	MR_sv(7) = (MR_Word) MR_redoip_slot(MR_maxfr);
	MR_sv(8) = (MR_Word) MR_redofr_slot(MR_maxfr);
	MR_save_maxfr(MR_sv(9));
	MR_redofr_slot_word(MR_maxfr) = (MR_Word) MR_curfr;
	MR_redoip_slot_word(MR_maxfr) = (MR_Word) MR_LABEL_AP(fn__libs__lp_rational__find_target_equality_2_3_0_i20);
	MR_tag_alloc_heap(MR_sv(5), 0, (MR_Integer) 2);
	MR_tfield(0, MR_sv(5), 0) = MR_sv(1);
	MR_sv(6) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_np_call_localret_ent(list__member_2_1,
		fn__libs__lp_rational__find_target_equality_2_3_0_i24);
MR_def_label(fn__libs__lp_rational__find_target_equality_2_3_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_tfield(0, MR_r1, 1);
	MR_tempr2 = MR_sv(5);
	MR_tfield(0, MR_tempr2, 1) = MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_tfield(0, MR_tempr1, 0);
	MR_r3 = MR_tfield(0, MR_tempr2, 0);
	}
	MR_np_call_localret_ent(builtin__unify_2_0,
		fn__libs__lp_rational__find_target_equality_2_3_0_i25);
MR_def_label(fn__libs__lp_rational__find_target_equality_2_3_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_restore_maxfr(MR_sv(9));
	MR_redoip_slot_word(MR_maxfr) = MR_sv(7);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(8);
	MR_GOTO_LAB(fn__libs__lp_rational__find_target_equality_2_3_0_i27);
MR_def_label(fn__libs__lp_rational__find_target_equality_2_3_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_redoip_slot_word(MR_maxfr) = MR_sv(7);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(8);
	MR_GOTO_LAB(fn__libs__lp_rational__find_target_equality_2_3_0_i18);
MR_def_label(fn__libs__lp_rational__find_target_equality_2_3_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(4);
	MR_np_call_localret_ent(fn__f_108_105_115_116_95_95_43_43_2_0,
		fn__libs__lp_rational__find_target_equality_2_3_0_i28);
MR_def_label(fn__libs__lp_rational__find_target_equality_2_3_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(3);
	MR_tfield(0, MR_r2, 1) = MR_r1;
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 1);
	MR_tfield(1, MR_r1, 0) = MR_r2;
	MR_decr_sp_and_return(10);
MR_def_label(fn__libs__lp_rational__find_target_equality_2_3_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_r3 = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = MR_sv(3);
	MR_tfield(1, MR_tempr1, 1) = MR_sv(2);
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(4);
	MR_succip_word = MR_sv(10);
	MR_GOTO_LAB(fn__libs__lp_rational__find_target_equality_2_3_0_i62);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(__Unify___term__var_1_0);

MR_BEGIN_MODULE(libs__lp_rational_module55)
	MR_init_entry1(libs__lp_rational__fix_coeff_and_const_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__fix_coeff_and_const_5_0);
	MR_init_label6(libs__lp_rational__fix_coeff_and_const_5_0,4,3,5,7,6,9)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'fix_coeff_and_const'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__fix_coeff_and_const_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__fix_coeff_and_const_5_0_i3);
	}
	MR_r1 = MR_r3;
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		libs__lp_rational__fix_coeff_and_const_5_0_i4);
MR_def_label(libs__lp_rational__fix_coeff_and_const_5_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_r2 = MR_tempr1;
	MR_decr_sp_and_return(5);
	}
MR_def_label(libs__lp_rational__fix_coeff_and_const_5_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r2, 0);
	MR_sv(2) = MR_tfield(0, MR_tempr1, 0);
	MR_sv(3) = MR_tfield(0, MR_tempr1, 1);
	MR_r2 = MR_tfield(1, MR_r2, 1);
	}
	MR_np_localcall_lab(libs__lp_rational__fix_coeff_and_const_5_0,
		libs__lp_rational__fix_coeff_and_const_5_0_i5);
MR_def_label(libs__lp_rational__fix_coeff_and_const_5_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r2;
	MR_sv(4) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(2);
	}
	MR_np_call_localret_ent(__Unify___term__var_1_0,
		libs__lp_rational__fix_coeff_and_const_5_0_i7);
MR_def_label(libs__lp_rational__fix_coeff_and_const_5_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__fix_coeff_and_const_5_0_i6);
	}
	MR_r1 = MR_sv(4);
	MR_r2 = MR_sv(1);
	MR_decr_sp_and_return(5);
MR_def_label(libs__lp_rational__fix_coeff_and_const_5_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		libs__lp_rational__fix_coeff_and_const_5_0_i9);
MR_def_label(libs__lp_rational__fix_coeff_and_const_5_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(2);
	MR_tfield(0, MR_r2, 1) = MR_r1;
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r1, 0) = MR_r2;
	MR_tfield(1, MR_r1, 1) = MR_sv(4);
	MR_r2 = MR_sv(1);
	MR_decr_sp_and_return(5);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(assoc_list__search_3_0);
MR_decl_entry(fn__f_108_105_98_115_95_95_114_97_116_95_95_43_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module56)
	MR_init_entry1(libs__lp_rational__substitute_into_constraint_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__substitute_into_constraint_6_0);
	MR_init_label10(libs__lp_rational__substitute_into_constraint_6_0,3,4,2,7,10,11,9,16,17,18)
	MR_init_label10(libs__lp_rational__substitute_into_constraint_6_0,20,21,24,25,5,27,29,31,35,39)
	MR_init_label7(libs__lp_rational__substitute_into_constraint_6_0,41,42,43,44,45,46,34)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'substitute_into_constraint'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__substitute_into_constraint_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(10);
	MR_sv(10) = (MR_Word) MR_succip;
	if (MR_PTAG_TESTR(MR_r4,1)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_into_constraint_6_0_i3);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r4;
	MR_r5 = MR_tempr1;
	MR_r4 = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_r3 = MR_tfield(1, MR_tempr1, 0);
	MR_sv(5) = (MR_Integer) 1;
	MR_sv(6) = MR_tfield(1, MR_tempr1, 1);
	MR_GOTO_LAB(libs__lp_rational__substitute_into_constraint_6_0_i2);
	}
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r4,2)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_into_constraint_6_0_i4);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r4;
	MR_r5 = MR_tempr1;
	MR_r4 = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_r3 = MR_tfield(2, MR_tempr1, 0);
	MR_sv(5) = (MR_Integer) 2;
	MR_sv(6) = MR_tfield(2, MR_tempr1, 1);
	MR_GOTO_LAB(libs__lp_rational__substitute_into_constraint_6_0_i2);
	}
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r4;
	MR_r4 = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_r3 = MR_tfield(0, MR_tempr1, 0);
	MR_sv(5) = (MR_Integer) 0;
	MR_sv(6) = MR_tfield(0, MR_tempr1, 1);
	}
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r4;
	MR_sv(4) = MR_r3;
	MR_sv(8) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r1 = MR_sv(8);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_np_call_localret_ent(assoc_list__search_3_0,
		libs__lp_rational__substitute_into_constraint_6_0_i7);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_into_constraint_6_0_i5);
	}
	MR_sv(7) = MR_r2;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__substitute_into_constraint_6_0_i10);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(7);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__substitute_into_constraint_6_0_i11);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_into_constraint_6_0_i9);
	}
	MR_r1 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r2 = (MR_Word) MR_string_const("normalize_constraint/3: zero coefficient constraint.", 52);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		libs__lp_rational__substitute_into_constraint_6_0_i16);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r1, 0, (MR_Integer) 3);
	MR_tfield(0, MR_r1, 0) = (MR_Word) MR_CTOR_ADDR(pair, pair, 2);
	MR_tfield(0, MR_r1, 1) = MR_sv(8);
	MR_tfield(0, MR_r1, 2) = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,15);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(fn__libs__lp_rational__IntroducedFrom__func__normalize_constraint__2088__1_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(7);
	MR_r4 = MR_sv(4);
	}
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_r1;
	MR_np_call_localret_ent(fn__list__map_2_0,
		libs__lp_rational__substitute_into_constraint_6_0_i17);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(7);
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_47_2_0,
		libs__lp_rational__substitute_into_constraint_6_0_i18);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(6) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__substitute_into_constraint_6_0_i20);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(7);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_60_2_0,
		libs__lp_rational__substitute_into_constraint_6_0_i21);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_into_constraint_6_0_i5);
	}
	if (MR_INT_NE(MR_sv(5),1)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_into_constraint_6_0_i24);
	}
	MR_r1 = (MR_Integer) 1;
	MR_GOTO_LAB(libs__lp_rational__substitute_into_constraint_6_0_i27);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(5),2)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_into_constraint_6_0_i25);
	}
	MR_r1 = (MR_Integer) 0;
	MR_GOTO_LAB(libs__lp_rational__substitute_into_constraint_6_0_i27);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 2;
	MR_GOTO_LAB(libs__lp_rational__substitute_into_constraint_6_0_i27);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(5);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,1)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_into_constraint_6_0_i29);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_sv(7) = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = MR_sv(4);
	MR_tfield(1, MR_tempr1, 1) = MR_sv(6);
	MR_sv(5) = (MR_Integer) 1;
	}
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		libs__lp_rational__substitute_into_constraint_6_0_i35);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,2)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_into_constraint_6_0_i31);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 2, (MR_Integer) 2);
	MR_sv(7) = MR_tempr1;
	MR_tfield(2, MR_tempr1, 0) = MR_sv(4);
	MR_tfield(2, MR_tempr1, 1) = MR_sv(6);
	MR_sv(5) = (MR_Integer) 2;
	}
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		libs__lp_rational__substitute_into_constraint_6_0_i35);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_sv(7) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(4);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(6);
	MR_sv(5) = (MR_Integer) 0;
	}
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		libs__lp_rational__substitute_into_constraint_6_0_i35);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(1);
	MR_tfield(0, MR_r2, 1) = MR_r1;
	MR_sv(8) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_sv(9) = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r1 = MR_sv(9);
	MR_r3 = MR_sv(4);
	MR_np_call_localret_ent(list__member_2_0,
		libs__lp_rational__substitute_into_constraint_6_0_i39);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_into_constraint_6_0_i34);
	}
	MR_r1 = MR_sv(9);
	MR_r2 = MR_sv(4);
	MR_r3 = MR_sv(2);
	MR_np_call_localret_ent(fn__f_108_105_115_116_95_95_43_43_2_0,
		libs__lp_rational__substitute_into_constraint_6_0_i41);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,41)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__libs__lp_rational__lp_terms_to_map_1_0,
		libs__lp_rational__substitute_into_constraint_6_0_i42);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,42)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(8);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(1);
	}
	MR_np_call_localret_ent(fn__map__delete_2_0,
		libs__lp_rational__substitute_into_constraint_6_0_i43);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(8);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__map__to_assoc_list_1_0,
		libs__lp_rational__substitute_into_constraint_6_0_i44);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,44)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_43_2_0,
		libs__lp_rational__substitute_into_constraint_6_0_i45);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,45)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(5);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__libs__lp_rational__construct_constraint_3_0,
		libs__lp_rational__substitute_into_constraint_6_0_i46);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,46)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Integer) 1;
	MR_decr_sp_and_return(10);
MR_def_label(libs__lp_rational__substitute_into_constraint_6_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Integer) 0;
	MR_r1 = MR_sv(7);
	MR_decr_sp_and_return(10);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__bool__or_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module57)
	MR_init_entry1(libs__lp_rational__substitute_into_constraints_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__substitute_into_constraints_6_0);
	MR_init_label8(libs__lp_rational__substitute_into_constraints_6_0,47,4,7,9,13,11,17,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'substitute_into_constraints'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__substitute_into_constraints_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r4,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_into_constraints_6_0_i47);
	}
	MR_r2 = (MR_Word) MR_tbmkword(0, 0);
	MR_r3 = (MR_Integer) 0;
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(libs__lp_rational__substitute_into_constraints_6_0,47)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_sv(4) = MR_tfield(1, MR_r4, 1);
	MR_r4 = MR_tfield(1, MR_r4, 0);
	MR_np_call_localret_ent(libs__lp_rational__substitute_into_constraint_6_0,
		libs__lp_rational__substitute_into_constraints_6_0_i4);
MR_def_label(libs__lp_rational__substitute_into_constraints_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(5) = MR_r1;
	MR_sv(6) = MR_r2;
	MR_np_call_localret_ent(libs__lp_rational__is_false_1_0,
		libs__lp_rational__substitute_into_constraints_6_0_i7);
MR_def_label(libs__lp_rational__substitute_into_constraints_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO_LAB(libs__lp_rational__substitute_into_constraints_6_0_i1);
	}
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(6);
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(3);
	MR_r4 = MR_sv(4);
	MR_np_localcall_lab(libs__lp_rational__substitute_into_constraints_6_0,
		libs__lp_rational__substitute_into_constraints_6_0_i9);
MR_def_label(libs__lp_rational__substitute_into_constraints_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_into_constraints_6_0_i1);
	}
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r3;
	MR_r1 = MR_sv(5);
	MR_np_call_localret_ent(libs__lp_rational__is_true_1_0,
		libs__lp_rational__substitute_into_constraints_6_0_i13);
MR_def_label(libs__lp_rational__substitute_into_constraints_6_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_into_constraints_6_0_i11);
	}
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(2);
	MR_np_call_localret_ent(fn__bool__or_2_0,
		libs__lp_rational__substitute_into_constraints_6_0_i17);
MR_def_label(libs__lp_rational__substitute_into_constraints_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_sv(2);
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_sv(1) = MR_tempr2;
	MR_tfield(1, MR_tempr2, 0) = MR_sv(5);
	MR_tfield(1, MR_tempr2, 1) = MR_r2;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__bool__or_2_0,
		libs__lp_rational__substitute_into_constraints_6_0_i17);
MR_def_label(libs__lp_rational__substitute_into_constraints_6_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_r3 = MR_r1;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(7);
MR_def_label(libs__lp_rational__substitute_into_constraints_6_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_decr_sp_and_return(7);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(libs__compiler_util__expect_3_0);

MR_BEGIN_MODULE(libs__lp_rational_module58)
	MR_init_entry1(libs__lp_rational__substitute_variable_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__substitute_variable_7_0);
	MR_init_label10(libs__lp_rational__substitute_variable_7_0,3,4,2,7,10,11,9,16,17,18)
	MR_init_label10(libs__lp_rational__substitute_variable_7_0,20,21,24,25,5,27,29,31,34,35)
	MR_init_label4(libs__lp_rational__substitute_variable_7_0,36,38,40,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'substitute_variable'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__substitute_variable_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(9);
	MR_sv(9) = (MR_Word) MR_succip;
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_variable_7_0_i3);
	}
	MR_sv(5) = MR_r4;
	MR_r4 = MR_r2;
	MR_sv(4) = MR_r3;
	MR_r3 = MR_tfield(1, MR_r1, 0);
	MR_sv(3) = (MR_Integer) 1;
	MR_sv(6) = MR_tfield(1, MR_r1, 1);
	MR_GOTO_LAB(libs__lp_rational__substitute_variable_7_0_i2);
MR_def_label(libs__lp_rational__substitute_variable_7_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_variable_7_0_i4);
	}
	MR_sv(5) = MR_r4;
	MR_r4 = MR_r2;
	MR_sv(4) = MR_r3;
	MR_r3 = MR_tfield(2, MR_r1, 0);
	MR_sv(3) = (MR_Integer) 2;
	MR_sv(6) = MR_tfield(2, MR_r1, 1);
	MR_GOTO_LAB(libs__lp_rational__substitute_variable_7_0_i2);
MR_def_label(libs__lp_rational__substitute_variable_7_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(5) = MR_r4;
	MR_r4 = MR_r2;
	MR_sv(4) = MR_r3;
	MR_r3 = MR_tfield(0, MR_r1, 0);
	MR_sv(3) = (MR_Integer) 0;
	MR_sv(6) = MR_tfield(0, MR_r1, 1);
MR_def_label(libs__lp_rational__substitute_variable_7_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r4;
	MR_sv(2) = MR_r3;
	MR_sv(8) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r1 = MR_sv(8);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_np_call_localret_ent(assoc_list__search_3_0,
		libs__lp_rational__substitute_variable_7_0_i7);
MR_def_label(libs__lp_rational__substitute_variable_7_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_variable_7_0_i5);
	}
	MR_sv(7) = MR_r2;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__substitute_variable_7_0_i10);
MR_def_label(libs__lp_rational__substitute_variable_7_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(7);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__substitute_variable_7_0_i11);
MR_def_label(libs__lp_rational__substitute_variable_7_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_variable_7_0_i9);
	}
	MR_r1 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r2 = (MR_Word) MR_string_const("normalize_constraint/3: zero coefficient constraint.", 52);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		libs__lp_rational__substitute_variable_7_0_i16);
MR_def_label(libs__lp_rational__substitute_variable_7_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r1, 0, (MR_Integer) 3);
	MR_tfield(0, MR_r1, 0) = (MR_Word) MR_CTOR_ADDR(pair, pair, 2);
	MR_tfield(0, MR_r1, 1) = MR_sv(8);
	MR_tfield(0, MR_r1, 2) = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,16);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(fn__libs__lp_rational__IntroducedFrom__func__normalize_constraint__2088__1_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(7);
	MR_r4 = MR_sv(2);
	}
MR_def_label(libs__lp_rational__substitute_variable_7_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_r1;
	MR_np_call_localret_ent(fn__list__map_2_0,
		libs__lp_rational__substitute_variable_7_0_i17);
MR_def_label(libs__lp_rational__substitute_variable_7_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(7);
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_47_2_0,
		libs__lp_rational__substitute_variable_7_0_i18);
MR_def_label(libs__lp_rational__substitute_variable_7_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(6) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__substitute_variable_7_0_i20);
MR_def_label(libs__lp_rational__substitute_variable_7_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(7);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_60_2_0,
		libs__lp_rational__substitute_variable_7_0_i21);
MR_def_label(libs__lp_rational__substitute_variable_7_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_variable_7_0_i5);
	}
	if (MR_INT_NE(MR_sv(3),1)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_variable_7_0_i24);
	}
	MR_r1 = (MR_Integer) 1;
	MR_GOTO_LAB(libs__lp_rational__substitute_variable_7_0_i27);
MR_def_label(libs__lp_rational__substitute_variable_7_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(3),2)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_variable_7_0_i25);
	}
	MR_r1 = (MR_Integer) 0;
	MR_GOTO_LAB(libs__lp_rational__substitute_variable_7_0_i27);
MR_def_label(libs__lp_rational__substitute_variable_7_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 2;
	MR_GOTO_LAB(libs__lp_rational__substitute_variable_7_0_i27);
MR_def_label(libs__lp_rational__substitute_variable_7_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
MR_def_label(libs__lp_rational__substitute_variable_7_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,1)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_variable_7_0_i29);
	}
	MR_sv(3) = MR_sv(6);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,8,0);
	MR_r2 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r3 = (MR_Word) MR_string_const("substitute_variable/7: inequality encountered.", 46);
	MR_np_call_localret_ent(libs__compiler_util__expect_3_0,
		libs__lp_rational__substitute_variable_7_0_i34);
MR_def_label(libs__lp_rational__substitute_variable_7_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,2)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_variable_7_0_i31);
	}
	MR_sv(3) = MR_sv(6);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,8,1);
	MR_r2 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r3 = (MR_Word) MR_string_const("substitute_variable/7: inequality encountered.", 46);
	MR_np_call_localret_ent(libs__compiler_util__expect_3_0,
		libs__lp_rational__substitute_variable_7_0_i34);
MR_def_label(libs__lp_rational__substitute_variable_7_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_sv(6);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,8,2);
	MR_r2 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r3 = (MR_Word) MR_string_const("substitute_variable/7: inequality encountered.", 46);
	MR_np_call_localret_ent(libs__compiler_util__expect_3_0,
		libs__lp_rational__substitute_variable_7_0_i34);
MR_def_label(libs__lp_rational__substitute_variable_7_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(3);
	MR_np_call_localret_ent(libs__lp_rational__fix_coeff_and_const_5_0,
		libs__lp_rational__substitute_variable_7_0_i35);
MR_def_label(libs__lp_rational__substitute_variable_7_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_sv(3) = MR_r2;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(3);
	MR_r4 = MR_sv(4);
	MR_np_call_localret_ent(libs__lp_rational__substitute_into_constraints_6_0,
		libs__lp_rational__substitute_variable_7_0_i36);
MR_def_label(libs__lp_rational__substitute_variable_7_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_variable_7_0_i1);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r3;
	MR_tempr2 = MR_sv(2);
	MR_sv(2) = MR_r2;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	MR_r3 = MR_sv(3);
	MR_r4 = MR_sv(5);
	}
	MR_np_call_localret_ent(libs__lp_rational__substitute_into_constraints_6_0,
		libs__lp_rational__substitute_variable_7_0_i38);
MR_def_label(libs__lp_rational__substitute_variable_7_0,38)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__substitute_variable_7_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r2;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_r3;
	}
	MR_np_call_localret_ent(fn__bool__or_2_0,
		libs__lp_rational__substitute_variable_7_0_i40);
MR_def_label(libs__lp_rational__substitute_variable_7_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(1);
	MR_r4 = MR_r1;
	MR_succip_word = MR_sv(9);
	MR_decr_sp(9);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(libs__lp_rational__substitute_variable_7_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(9);
	MR_decr_sp(9);
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module59)
	MR_init_entry1(libs__lp_rational__eliminate_equations_2_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__eliminate_equations_2_6_0);
	MR_init_label10(libs__lp_rational__eliminate_equations_2_6_0,56,4,7,9,14,15,12,6,17,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'eliminate_equations_2'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__eliminate_equations_2_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__eliminate_equations_2_6_0_i56);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r2;
	MR_r2 = (MR_Word) MR_tbmkword(0, 0);
	MR_tempr2 = MR_r3;
	MR_r3 = MR_tempr1;
	MR_r4 = MR_tempr2;
	MR_r1 = MR_TRUE;
	MR_proceed();
	}
MR_def_label(libs__lp_rational__eliminate_equations_2_6_0,56)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_tfield(1, MR_r1, 0);
	MR_r1 = MR_tfield(1, MR_r1, 1);
	MR_np_localcall_lab(libs__lp_rational__eliminate_equations_2_6_0,
		libs__lp_rational__eliminate_equations_2_6_0_i4);
MR_def_label(libs__lp_rational__eliminate_equations_2_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__eliminate_equations_2_6_0_i1);
	}
	MR_sv(2) = MR_r2;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_sv(3) = MR_tempr1;
	MR_sv(4) = MR_r4;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_r3 = (MR_Word) MR_tbmkword(0, 0);
	}
	MR_np_call_localret_ent(fn__libs__lp_rational__find_target_equality_2_3_0,
		libs__lp_rational__eliminate_equations_2_6_0_i7);
MR_def_label(libs__lp_rational__eliminate_equations_2_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_r1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__eliminate_equations_2_6_0_i6);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r1, 0);
	MR_sv(3) = MR_tfield(0, MR_tempr1, 0);
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(1);
	MR_r3 = MR_tfield(0, MR_tempr1, 1);
	MR_r4 = MR_sv(4);
	}
	MR_np_call_localret_ent(libs__lp_rational__substitute_variable_7_0,
		libs__lp_rational__eliminate_equations_2_6_0_i9);
MR_def_label(libs__lp_rational__eliminate_equations_2_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__eliminate_equations_2_6_0_i1);
	}
	if (MR_INT_NE(MR_r4,0)) {
		MR_GOTO_LAB(libs__lp_rational__eliminate_equations_2_6_0_i12);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_sv(2);
	MR_sv(2) = MR_r3;
	MR_tempr2 = MR_sv(1);
	MR_sv(1) = MR_r2;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r2 = MR_tempr2;
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__cons_3_0,
		libs__lp_rational__eliminate_equations_2_6_0_i14);
MR_def_label(libs__lp_rational__eliminate_equations_2_6_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_r2 = MR_sv(3);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__cons_3_0,
		libs__lp_rational__eliminate_equations_2_6_0_i15);
MR_def_label(libs__lp_rational__eliminate_equations_2_6_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_r3 = MR_r1;
	MR_r4 = MR_sv(2);
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(5);
MR_def_label(libs__lp_rational__eliminate_equations_2_6_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_sv(2);
	MR_tempr2 = MR_r3;
	MR_r3 = MR_tempr1;
	MR_r4 = MR_tempr2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(5);
	}
MR_def_label(libs__lp_rational__eliminate_equations_2_6_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r2 = MR_sv(1);
	MR_r3 = MR_sv(2);
	MR_np_call_localret_ent(list__cons_3_0,
		libs__lp_rational__eliminate_equations_2_6_0_i17);
MR_def_label(libs__lp_rational__eliminate_equations_2_6_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_r1;
	MR_r3 = MR_sv(3);
	MR_r4 = MR_sv(4);
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(5);
MR_def_label(libs__lp_rational__eliminate_equations_2_6_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_decr_sp_and_return(5);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module60)
	MR_init_entry1(fn__libs__lp_rational__collect_remaining_vars_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__collect_remaining_vars_2_0);
	MR_init_label5(fn__libs__lp_rational__collect_remaining_vars_2_0,24,3,5,4,8)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'collect_remaining_vars'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__collect_remaining_vars_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
MR_def_label(fn__libs__lp_rational__collect_remaining_vars_2_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(fn__libs__lp_rational__collect_remaining_vars_2_0_i3);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_decr_sp_and_return(4);
MR_def_label(fn__libs__lp_rational__collect_remaining_vars_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_tfield(1, MR_r1, 1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(0, MR_tfield(1, MR_r1, 0), 0);
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_tempr1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(1);
	}
	MR_np_call_localret_ent(__Unify___term__var_1_0,
		fn__libs__lp_rational__collect_remaining_vars_2_0_i5);
MR_def_label(fn__libs__lp_rational__collect_remaining_vars_2_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(fn__libs__lp_rational__collect_remaining_vars_2_0_i4);
	}
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(1);
	MR_succip_word = MR_sv(4);
	MR_GOTO_LAB(fn__libs__lp_rational__collect_remaining_vars_2_0_i24);
MR_def_label(fn__libs__lp_rational__collect_remaining_vars_2_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(1);
	MR_np_localcall_lab(fn__libs__lp_rational__collect_remaining_vars_2_0,
		fn__libs__lp_rational__collect_remaining_vars_2_0_i8);
MR_def_label(fn__libs__lp_rational__collect_remaining_vars_2_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_sv(2);
	MR_tfield(1, MR_r2, 1) = MR_r1;
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(4);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module61)
	MR_init_entry1(fn__libs__lp_rational__find_max_2_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__find_max_2_2_0);
	MR_init_label2(fn__libs__lp_rational__find_max_2_2_0,3,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'find_max_2'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__find_max_2_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(fn__libs__lp_rational__find_max_2_2_0_i3);
	}
	MR_r1 = MR_r2;
	MR_proceed();
MR_def_label(fn__libs__lp_rational__find_max_2_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_tfield(1, MR_r1, 1);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_tfield(0, MR_tfield(1, MR_r1, 0), 1);
	MR_tempr2 = MR_tfield(0, MR_r2, 1);
	if (((MR_Integer) MR_tempr1 >= (MR_Integer) MR_tempr2)) {
		MR_GOTO_LAB(fn__libs__lp_rational__find_max_2_2_0_i4);
	}
	MR_tempr1 = MR_r1;
	MR_r1 = MR_r3;
	MR_r2 = MR_tfield(1, MR_tempr1, 0);
	MR_np_localtailcall(fn__libs__lp_rational__find_max_2_2_0);
	}
MR_def_label(fn__libs__lp_rational__find_max_2_2_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r3;
	MR_np_localtailcall(fn__libs__lp_rational__find_max_2_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__f_108_105_115_116_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_115_111_114_116_95_97_110_100_95_114_101_109_111_118_101_95_100_117_112_115_95_95_91_84_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_1_0);
MR_decl_entry(fn__list__filter_2_0);
MR_decl_entry(fn__pair__fst_1_0);

MR_BEGIN_MODULE(libs__lp_rational_module62)
	MR_init_entry1(libs__lp_rational__duffin_heuristic_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__duffin_heuristic_4_0);
	MR_init_label10(libs__lp_rational__duffin_heuristic_4_0,72,6,8,10,12,13,14,18,20,25)
	MR_init_label9(libs__lp_rational__duffin_heuristic_4_0,26,24,23,29,31,28,32,71,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'duffin_heuristic'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__duffin_heuristic_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_r1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__duffin_heuristic_4_0_i71);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r1, 1);
	if (MR_LTAGS_TESTR(MR_tempr1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__duffin_heuristic_4_0_i72);
	}
	MR_r2 = MR_tfield(1, MR_r1, 0);
	MR_r3 = (MR_Word) MR_tbmkword(0, 0);
	MR_r1 = MR_TRUE;
	MR_proceed();
	}
MR_def_label(libs__lp_rational__duffin_heuristic_4_0,72)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_sv(2) = (MR_Word) MR_TAG_COMMON(0,0,0);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_108_105_115_116_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_115_111_114_116_95_97_110_100_95_114_101_109_111_118_101_95_100_117_112_115_95_95_91_84_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_1_0,
		libs__lp_rational__duffin_heuristic_4_0_i6);
MR_def_label(libs__lp_rational__duffin_heuristic_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_sv(4) = (MR_Word) MR_TAG_COMMON(0,1,12);
	MR_r1 = MR_sv(2);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, coeff_info);
	MR_np_call_localret_ent(fn__map__init_0_0,
		libs__lp_rational__duffin_heuristic_4_0_i8);
MR_def_label(libs__lp_rational__duffin_heuristic_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(4);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,3,15);
	MR_r4 = MR_sv(3);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__list__foldl_3_0,
		libs__lp_rational__duffin_heuristic_4_0_i10);
MR_def_label(libs__lp_rational__duffin_heuristic_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, vector);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(4);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,3,16);
	MR_r4 = MR_sv(1);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__list__foldl_3_0,
		libs__lp_rational__duffin_heuristic_4_0_i12);
MR_def_label(libs__lp_rational__duffin_heuristic_4_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, coeff_info);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__map__to_assoc_list_1_0,
		libs__lp_rational__duffin_heuristic_4_0_i13);
MR_def_label(libs__lp_rational__duffin_heuristic_4_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__list__length_1_0,
		libs__lp_rational__duffin_heuristic_4_0_i14);
MR_def_label(libs__lp_rational__duffin_heuristic_4_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,19);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(fn__libs__lp_rational__make_expansion_num_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_tempr2 = MR_sv(1);
	MR_sv(1) = (MR_Word) MR_TAG_COMMON(0,1,15);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,14);
	MR_r2 = MR_sv(1);
	MR_r4 = MR_tempr2;
	}
	MR_np_call_localret_ent(fn__list__map_2_0,
		libs__lp_rational__duffin_heuristic_4_0_i18);
MR_def_label(libs__lp_rational__duffin_heuristic_4_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,3,17);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__list__filter_2_0,
		libs__lp_rational__duffin_heuristic_4_0_i20);
MR_def_label(libs__lp_rational__duffin_heuristic_4_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_r1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__duffin_heuristic_4_0_i1);
	}
	if (MR_LTAGS_TEST(MR_r1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__duffin_heuristic_4_0_i24);
	}
	MR_sv(1) = MR_r1;
	MR_r1 = MR_tfield(1, MR_r1, 1);
	MR_r2 = MR_tfield(1, MR_sv(1), 0);
	MR_np_call_localret_ent(fn__libs__lp_rational__find_max_2_2_0,
		libs__lp_rational__duffin_heuristic_4_0_i25);
MR_def_label(libs__lp_rational__duffin_heuristic_4_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__pair__fst_1_0,
		libs__lp_rational__duffin_heuristic_4_0_i26);
MR_def_label(libs__lp_rational__duffin_heuristic_4_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_r1;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_r2 = MR_tfield(0, MR_tfield(1, MR_tempr1, 0), 0);
	MR_sv(3) = MR_tfield(1, MR_tempr1, 1);
	MR_GOTO_LAB(libs__lp_rational__duffin_heuristic_4_0_i23);
	}
MR_def_label(libs__lp_rational__duffin_heuristic_4_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_r2 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r3 = (MR_Word) MR_string_const("find_max/2: empty list passed as arg.", 37);
	MR_np_call_localret_ent(fn__libs__compiler_util__unexpected_2_0,
		libs__lp_rational__duffin_heuristic_4_0_i23);
MR_def_label(libs__lp_rational__duffin_heuristic_4_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r3;
	MR_sv(2) = MR_r2;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_np_call_localret_ent(__Unify___term__var_1_0,
		libs__lp_rational__duffin_heuristic_4_0_i29);
MR_def_label(libs__lp_rational__duffin_heuristic_4_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__duffin_heuristic_4_0_i28);
	}
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(fn__libs__lp_rational__collect_remaining_vars_2_0,
		libs__lp_rational__duffin_heuristic_4_0_i31);
MR_def_label(libs__lp_rational__duffin_heuristic_4_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_r3 = MR_r1;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(5);
MR_def_label(libs__lp_rational__duffin_heuristic_4_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(fn__libs__lp_rational__collect_remaining_vars_2_0,
		libs__lp_rational__duffin_heuristic_4_0_i32);
MR_def_label(libs__lp_rational__duffin_heuristic_4_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_r3 = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(1, MR_tempr1, 1) = MR_r1;
	MR_r2 = MR_sv(1);
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(5);
	}
MR_def_label(libs__lp_rational__duffin_heuristic_4_0,71)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
MR_def_label(libs__lp_rational__duffin_heuristic_4_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_decr_sp_and_return(5);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module63)
	MR_init_entry1(libs__lp_rational__project_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__project_5_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'project'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__libs__lp_rational__project_5_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_r3;
	MR_r3 = MR_r4;
	MR_np_tailcall_ent(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module64)
	MR_init_entry1(fn__libs__lp_rational__project_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__project_3_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'project'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__libs__lp_rational__project_3_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_r3;
	MR_np_tailcall_ent(fn__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module65)
	MR_init_entry1(libs__lp_rational__project_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__project_4_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'project'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__libs__lp_rational__project_4_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_r3;
	MR_np_tailcall_ent(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_4_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module66)
	MR_init_entry1(libs__lp_rational__entailed_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__entailed_3_0);
	MR_init_label3(libs__lp_rational__entailed_3_0,2,3,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'entailed'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__libs__lp_rational__entailed_3_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(1);
	MR_sv(1) = (MR_Word) MR_succip;
	MR_np_call_localret_ent(fn__libs__lp_rational__entailed_3_0,
		libs__lp_rational__entailed_3_0_i2);
MR_def_label(libs__lp_rational__entailed_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_EQ(MR_r1,0)) {
		MR_GOTO_LAB(libs__lp_rational__entailed_3_0_i3);
	}
	if (MR_INT_NE(MR_r1,2)) {
		MR_GOTO_LAB(libs__lp_rational__entailed_3_0_i1);
	}
	MR_r1 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r2 = (MR_Word) MR_string_const("entailed/3: inconsistent constraint set.", 40);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		libs__lp_rational__entailed_3_0_i3);
MR_def_label(libs__lp_rational__entailed_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(1);
	MR_decr_sp(1);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(libs__lp_rational__entailed_3_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(1);
	MR_decr_sp(1);
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(io__write_char_3_0);
MR_decl_entry(io__write_list_5_0);

MR_BEGIN_MODULE(libs__lp_rational_module67)
	MR_init_entry1(libs__lp_rational__output_constraints_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__output_constraints_4_0);
	MR_init_label2(libs__lp_rational__output_constraints_4_0,2,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_constraints'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__libs__lp_rational__output_constraints_4_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = (MR_Integer) 91;
	MR_np_call_localret_ent(io__write_char_3_0,
		libs__lp_rational__output_constraints_4_0_i2);
MR_def_label(libs__lp_rational__output_constraints_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(5,9);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__output_constraint_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_r2 = MR_sv(2);
	MR_r3 = (MR_Word) MR_string_const(", ", 2);
	}
	MR_np_call_localret_ent(io__write_list_5_0,
		libs__lp_rational__output_constraints_4_0_i4);
MR_def_label(libs__lp_rational__output_constraints_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 93;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(io__write_char_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_io__type_ctor_info_state_0;
MR_decl_entry(list__foldl_4_2);

MR_BEGIN_MODULE(libs__lp_rational_module68)
	MR_init_entry1(libs__lp_rational__write_constraints_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__write_constraints_4_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'write_constraints'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__libs__lp_rational__write_constraints_4_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(5,10);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__write_constraint_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r2;
	MR_tempr2 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_r2 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r3 = MR_tempr1;
	MR_r4 = MR_tempr2;
	MR_np_tailcall_ent(list__foldl_4_2);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__f_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_101_108_101_109_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_2_0);
MR_decl_entry(svmap__delete_3_0);
MR_decl_entry(f_115_118_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_95_115_101_116_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_4_0);

MR_BEGIN_MODULE(libs__lp_rational_module69)
	MR_init_entry1(libs__lp_rational__lp_terms_to_map_2_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__lp_terms_to_map_2_3_0);
	MR_init_label9(libs__lp_rational__lp_terms_to_map_2_3_0,4,6,8,9,7,2,17,18,15)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'lp_terms_to_map_2'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__lp_terms_to_map_2_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	MR_sv(2) = MR_tfield(0, MR_r1, 1);
	MR_r4 = MR_tfield(0, MR_r1, 0);
	MR_sv(1) = MR_r4;
	MR_sv(3) = MR_r2;
	MR_sv(4) = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_sv(5) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r1 = MR_sv(4);
	MR_r2 = MR_sv(5);
	MR_r3 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r5 = MR_sv(3);
	MR_np_call_localret_ent(fn__f_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_101_108_101_109_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_2_0,
		libs__lp_rational__lp_terms_to_map_2_3_0_i4);
MR_def_label(libs__lp_rational__lp_terms_to_map_2_3_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__lp_terms_to_map_2_3_0_i2);
	}
	MR_r1 = MR_r2;
	MR_r2 = MR_sv(2);
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_43_2_0,
		libs__lp_rational__lp_terms_to_map_2_3_0_i6);
MR_def_label(libs__lp_rational__lp_terms_to_map_2_3_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__lp_terms_to_map_2_3_0_i8);
MR_def_label(libs__lp_rational__lp_terms_to_map_2_3_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__lp_terms_to_map_2_3_0_i9);
MR_def_label(libs__lp_rational__lp_terms_to_map_2_3_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__lp_terms_to_map_2_3_0_i7);
	}
	MR_r1 = MR_sv(5);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_sv(1);
	MR_r4 = MR_sv(3);
	MR_succip_word = MR_sv(6);
	MR_decr_sp(6);
	MR_np_tailcall_ent(svmap__delete_3_0);
MR_def_label(libs__lp_rational__lp_terms_to_map_2_3_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_r2 = MR_sv(5);
	MR_r3 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r4 = MR_sv(1);
	MR_r5 = MR_sv(2);
	MR_r6 = MR_sv(3);
	MR_succip_word = MR_sv(6);
	MR_decr_sp(6);
	MR_np_tailcall_ent(f_115_118_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_95_115_101_116_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_4_0);
MR_def_label(libs__lp_rational__lp_terms_to_map_2_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__lp_terms_to_map_2_3_0_i17);
MR_def_label(libs__lp_rational__lp_terms_to_map_2_3_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__lp_terms_to_map_2_3_0_i18);
MR_def_label(libs__lp_rational__lp_terms_to_map_2_3_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO_LAB(libs__lp_rational__lp_terms_to_map_2_3_0_i15);
	}
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r3 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r4 = MR_sv(1);
	MR_r5 = MR_sv(2);
	MR_r6 = MR_sv(3);
	MR_succip_word = MR_sv(6);
	MR_decr_sp(6);
	MR_np_tailcall_ent(f_115_118_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_95_115_101_116_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_4_0);
MR_def_label(libs__lp_rational__lp_terms_to_map_2_3_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(6);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__f_108_105_98_115_95_95_114_97_116_95_95_42_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module70)
	MR_init_entry1(libs__lp_rational__is_stronger_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__is_stronger_2_0);
	MR_init_label10(libs__lp_rational__is_stronger_2_0,10,12,7,14,17,19,5,27,29,24)
	MR_init_label10(libs__lp_rational__is_stronger_2_0,32,35,37,38,31,40,43,45,46,47)
	MR_init_label10(libs__lp_rational__is_stronger_2_0,115,3,56,57,58,62,64,65,66,69)
	MR_init_label7(libs__lp_rational__is_stronger_2_0,70,72,54,76,78,79,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'is_stronger'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__is_stronger_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(8);
	MR_sv(8) = (MR_Word) MR_succip;
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i3);
	}
	if (MR_PTAG_TESTR(MR_r2,2)) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i5);
	}
	MR_r3 = MR_tfield(2, MR_r2, 0);
	MR_sv(3) = MR_tfield(2, MR_r2, 1);
	MR_r2 = MR_tfield(1, MR_r1, 0);
	MR_sv(1) = MR_tfield(1, MR_r1, 1);
	MR_sv(2) = MR_r2;
	MR_sv(4) = MR_r3;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_np_call_localret_ent(__Unify___list__list_1_0,
		libs__lp_rational__is_stronger_2_0_i10);
MR_def_label(libs__lp_rational__is_stronger_2_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i7);
	}
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__is_stronger_2_0_i12);
MR_def_label(libs__lp_rational__is_stronger_2_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i115);
	}
MR_def_label(libs__lp_rational__is_stronger_2_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(fn__libs__lp_rational__negate_lp_terms_1_0,
		libs__lp_rational__is_stronger_2_0_i14);
MR_def_label(libs__lp_rational__is_stronger_2_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = MR_sv(4);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___list__list_1_0,
		libs__lp_rational__is_stronger_2_0_i17);
MR_def_label(libs__lp_rational__is_stronger_2_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i1);
	}
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		libs__lp_rational__is_stronger_2_0_i19);
MR_def_label(libs__lp_rational__is_stronger_2_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_np_tailcall_ent(__Unify___libs__rat__rat_0_0);
	}
MR_def_label(libs__lp_rational__is_stronger_2_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,0)) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i1);
	}
	MR_r3 = MR_tfield(0, MR_r2, 0);
	MR_sv(3) = MR_tfield(0, MR_r2, 1);
	MR_r2 = MR_tfield(1, MR_r1, 0);
	MR_sv(1) = MR_tfield(1, MR_r1, 1);
	MR_sv(2) = MR_r2;
	MR_sv(4) = MR_r3;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_np_call_localret_ent(__Unify___list__list_1_0,
		libs__lp_rational__is_stronger_2_0_i27);
MR_def_label(libs__lp_rational__is_stronger_2_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i24);
	}
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__is_stronger_2_0_i29);
MR_def_label(libs__lp_rational__is_stronger_2_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i115);
	}
MR_def_label(libs__lp_rational__is_stronger_2_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(fn__libs__lp_rational__negate_lp_terms_1_0,
		libs__lp_rational__is_stronger_2_0_i32);
MR_def_label(libs__lp_rational__is_stronger_2_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = MR_sv(4);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___list__list_1_0,
		libs__lp_rational__is_stronger_2_0_i35);
MR_def_label(libs__lp_rational__is_stronger_2_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i31);
	}
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		libs__lp_rational__is_stronger_2_0_i37);
MR_def_label(libs__lp_rational__is_stronger_2_0,37)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__is_stronger_2_0_i38);
MR_def_label(libs__lp_rational__is_stronger_2_0,38)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i115);
	}
MR_def_label(libs__lp_rational__is_stronger_2_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(fn__libs__lp_rational__negate_lp_terms_1_0,
		libs__lp_rational__is_stronger_2_0_i40);
MR_def_label(libs__lp_rational__is_stronger_2_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = MR_sv(4);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___list__list_1_0,
		libs__lp_rational__is_stronger_2_0_i43);
MR_def_label(libs__lp_rational__is_stronger_2_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i1);
	}
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		libs__lp_rational__is_stronger_2_0_i45);
MR_def_label(libs__lp_rational__is_stronger_2_0,45)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		libs__lp_rational__is_stronger_2_0_i46);
MR_def_label(libs__lp_rational__is_stronger_2_0,46)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_42_2_0,
		libs__lp_rational__is_stronger_2_0_i47);
MR_def_label(libs__lp_rational__is_stronger_2_0,47)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_np_tailcall_ent(f_108_105_98_115_95_95_114_97_116_95_95_62_61_2_0);
	}
MR_def_label(libs__lp_rational__is_stronger_2_0,115)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(libs__lp_rational__is_stronger_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i1);
	}
	if (MR_PTAG_TESTR(MR_r2,0)) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i1);
	}
	MR_sv(7) = MR_tfield(0, MR_r2, 0);
	MR_sv(6) = MR_tfield(0, MR_r2, 1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(0, MR_r1, 0);
	MR_sv(5) = MR_tempr1;
	MR_sv(4) = MR_tfield(0, MR_r1, 1);
	if (MR_LTAGS_TEST(MR_tempr1,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i54);
	}
	MR_r1 = MR_tfield(1, MR_tempr1, 0);
	MR_sv(1) = MR_tfield(0, MR_r1, 0);
	MR_sv(2) = MR_tfield(1, MR_tempr1, 1);
	MR_sv(3) = MR_tfield(0, MR_r1, 1);
	}
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		libs__lp_rational__is_stronger_2_0_i56);
MR_def_label(libs__lp_rational__is_stronger_2_0,56)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		libs__lp_rational__is_stronger_2_0_i57);
MR_def_label(libs__lp_rational__is_stronger_2_0,57)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__is_stronger_2_0_i58);
MR_def_label(libs__lp_rational__is_stronger_2_0,58)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i54);
	}
	if (MR_LTAGS_TESTR(MR_sv(2),0,0)) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i54);
	}
	if (MR_LTAGS_TEST(MR_sv(7),0,0)) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i54);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr1 = MR_sv(1);
	MR_tempr3 = MR_sv(7);
	MR_sv(1) = MR_tfield(1, MR_tempr3, 1);
	MR_tempr2 = MR_tfield(1, MR_tempr3, 0);
	MR_sv(2) = MR_tfield(0, MR_tempr2, 1);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tfield(0, MR_tempr2, 0);
	}
	MR_np_call_localret_ent(__Unify___term__var_1_0,
		libs__lp_rational__is_stronger_2_0_i62);
MR_def_label(libs__lp_rational__is_stronger_2_0,62)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i54);
	}
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		libs__lp_rational__is_stronger_2_0_i64);
MR_def_label(libs__lp_rational__is_stronger_2_0,64)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		libs__lp_rational__is_stronger_2_0_i65);
MR_def_label(libs__lp_rational__is_stronger_2_0,65)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__is_stronger_2_0_i66);
MR_def_label(libs__lp_rational__is_stronger_2_0,66)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i54);
	}
	if (MR_LTAGS_TESTR(MR_sv(1),0,0)) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i54);
	}
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__is_stronger_2_0_i69);
MR_def_label(libs__lp_rational__is_stronger_2_0,69)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_61_60_2_0,
		libs__lp_rational__is_stronger_2_0_i70);
MR_def_label(libs__lp_rational__is_stronger_2_0,70)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i54);
	}
	MR_r1 = MR_sv(4);
	MR_r2 = MR_sv(6);
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_61_60_2_0,
		libs__lp_rational__is_stronger_2_0_i72);
MR_def_label(libs__lp_rational__is_stronger_2_0,72)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i115);
	}
MR_def_label(libs__lp_rational__is_stronger_2_0,54)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = MR_sv(5);
	MR_r3 = MR_sv(7);
	MR_np_call_localret_ent(__Unify___list__list_1_0,
		libs__lp_rational__is_stronger_2_0_i76);
MR_def_label(libs__lp_rational__is_stronger_2_0,76)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i1);
	}
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__is_stronger_2_0_i78);
MR_def_label(libs__lp_rational__is_stronger_2_0,78)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_61_60_2_0,
		libs__lp_rational__is_stronger_2_0_i79);
MR_def_label(libs__lp_rational__is_stronger_2_0,79)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__is_stronger_2_0_i1);
	}
	MR_r1 = MR_sv(4);
	MR_r2 = MR_sv(6);
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_np_tailcall_ent(f_108_105_98_115_95_95_114_97_116_95_95_61_60_2_0);
MR_def_label(libs__lp_rational__is_stronger_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module71)
	MR_init_entry1(libs__lp_rational__remove_weaker_2_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__remove_weaker_2_6_0);
	MR_init_label6(libs__lp_rational__remove_weaker_2_6_0,4,2,8,10,6,11)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'remove_weaker_2'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__remove_weaker_2_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_sv(4) = MR_r4;
	MR_np_call_localret_ent(libs__lp_rational__is_stronger_2_0,
		libs__lp_rational__remove_weaker_2_6_0_i4);
MR_def_label(libs__lp_rational__remove_weaker_2_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__remove_weaker_2_6_0_i2);
	}
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(4);
	MR_decr_sp_and_return(5);
MR_def_label(libs__lp_rational__remove_weaker_2_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr1 = MR_sv(3);
	MR_tempr2 = MR_sv(4);
	MR_tempr3 = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = MR_tempr3;
	}
	MR_np_call_localret_ent(libs__lp_rational__is_stronger_2_0,
		libs__lp_rational__remove_weaker_2_6_0_i8);
MR_def_label(libs__lp_rational__remove_weaker_2_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__remove_weaker_2_6_0_i6);
	}
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(3);
	MR_np_call_localret_ent(list__cons_3_0,
		libs__lp_rational__remove_weaker_2_6_0_i10);
MR_def_label(libs__lp_rational__remove_weaker_2_6_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Integer) 0;
	MR_decr_sp_and_return(5);
MR_def_label(libs__lp_rational__remove_weaker_2_6_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(3);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(4);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	}
	MR_np_call_localret_ent(list__cons_3_0,
		libs__lp_rational__remove_weaker_2_6_0_i11);
MR_def_label(libs__lp_rational__remove_weaker_2_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(4);
	MR_decr_sp_and_return(5);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module72)
	MR_init_entry1(fn__libs__lp_rational__substitute_vars_2_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__substitute_vars_2_2_0);
	MR_init_label10(fn__libs__lp_rational__substitute_vars_2_2_0,7,8,11,12,3,18,19,22,23,14)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'substitute_vars_2'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__substitute_vars_2_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,1)) {
		MR_GOTO_LAB(fn__libs__lp_rational__substitute_vars_2_2_0_i3);
	}
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,20);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(fn__libs__lp_rational__substitute_term_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_sv(1) = MR_tfield(1, MR_r2, 1);
	MR_sv(3) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_sv(5) = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r1 = MR_sv(5);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_r1;
	MR_r4 = MR_tfield(1, MR_tempr2, 0);
	}
	MR_np_call_localret_ent(fn__list__map_2_0,
		fn__libs__lp_rational__substitute_vars_2_2_0_i7);
MR_def_label(fn__libs__lp_rational__substitute_vars_2_2_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_sv(4) = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(4);
	MR_np_call_localret_ent(fn__map__init_0_0,
		fn__libs__lp_rational__substitute_vars_2_2_0_i8);
MR_def_label(fn__libs__lp_rational__substitute_vars_2_2_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,1,1);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,3,18);
	MR_r4 = MR_sv(2);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__foldl_4_0,
		fn__libs__lp_rational__substitute_vars_2_2_0_i11);
MR_def_label(fn__libs__lp_rational__substitute_vars_2_2_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__map__to_assoc_list_1_0,
		fn__libs__lp_rational__substitute_vars_2_2_0_i12);
MR_def_label(fn__libs__lp_rational__substitute_vars_2_2_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_r1;
	MR_tfield(1, MR_r2, 1) = MR_sv(1);
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(6);
MR_def_label(fn__libs__lp_rational__substitute_vars_2_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,0)) {
		MR_GOTO_LAB(fn__libs__lp_rational__substitute_vars_2_2_0_i14);
	}
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,22);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(fn__libs__lp_rational__substitute_term_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_sv(1) = MR_tfield(0, MR_r2, 1);
	MR_sv(3) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_sv(5) = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r1 = MR_sv(5);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_r1;
	MR_r4 = MR_tfield(0, MR_tempr2, 0);
	}
	MR_np_call_localret_ent(fn__list__map_2_0,
		fn__libs__lp_rational__substitute_vars_2_2_0_i18);
MR_def_label(fn__libs__lp_rational__substitute_vars_2_2_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_sv(4) = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(4);
	MR_np_call_localret_ent(fn__map__init_0_0,
		fn__libs__lp_rational__substitute_vars_2_2_0_i19);
MR_def_label(fn__libs__lp_rational__substitute_vars_2_2_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,1,1);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,3,19);
	MR_r4 = MR_sv(2);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__foldl_4_0,
		fn__libs__lp_rational__substitute_vars_2_2_0_i22);
MR_def_label(fn__libs__lp_rational__substitute_vars_2_2_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__map__to_assoc_list_1_0,
		fn__libs__lp_rational__substitute_vars_2_2_0_i23);
MR_def_label(fn__libs__lp_rational__substitute_vars_2_2_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_r1;
	MR_tfield(0, MR_tempr1, 1) = MR_sv(1);
	MR_r1 = MR_tempr1;
	MR_decr_sp_and_return(6);
	}
MR_def_label(fn__libs__lp_rational__substitute_vars_2_2_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_r2 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r3 = (MR_Word) MR_string_const("substitute_vars_2/2: gte.", 25);
	MR_np_tailcall_ent(fn__libs__compiler_util__unexpected_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module73)
	MR_init_entry1(fn__libs__lp_rational__substitute_term_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__substitute_term_2_0);
	MR_init_label1(fn__libs__lp_rational__substitute_term_2_0,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'substitute_term'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__substitute_term_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_tfield(0, MR_r2, 1);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_tempr2 = MR_r2;
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r3 = MR_r2;
	MR_r4 = MR_tfield(0, MR_tempr2, 0);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_100_101_116_95_101_108_101_109_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_2_0,
		fn__libs__lp_rational__substitute_term_2_0_i3);
MR_def_label(fn__libs__lp_rational__substitute_term_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_r1;
	MR_tfield(0, MR_r2, 1) = MR_sv(1);
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(2);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module74)
	MR_init_entry1(fn__libs__lp_rational__set_vars_to_zero_2_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__set_vars_to_zero_2_2_0);
	MR_init_label5(fn__libs__lp_rational__set_vars_to_zero_2_2_0,7,3,13,9,18)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'set_vars_to_zero_2'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__set_vars_to_zero_2_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	if (MR_PTAG_TESTR(MR_r2,1)) {
		MR_GOTO_LAB(fn__libs__lp_rational__set_vars_to_zero_2_2_0_i3);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(4,16);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__set_terms_to_zero__713__1_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_sv(1) = MR_tfield(1, MR_r2, 1);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tfield(1, MR_tempr2, 0);
	}
	MR_np_call_localret_ent(fn__list__filter_2_0,
		fn__libs__lp_rational__set_vars_to_zero_2_2_0_i7);
MR_def_label(fn__libs__lp_rational__set_vars_to_zero_2_2_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_r1;
	MR_tfield(1, MR_r2, 1) = MR_sv(1);
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(2);
MR_def_label(fn__libs__lp_rational__set_vars_to_zero_2_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,2)) {
		MR_GOTO_LAB(fn__libs__lp_rational__set_vars_to_zero_2_2_0_i9);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(4,17);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__set_terms_to_zero__713__1_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_sv(1) = MR_tfield(2, MR_r2, 1);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tfield(2, MR_tempr2, 0);
	}
	MR_np_call_localret_ent(fn__list__filter_2_0,
		fn__libs__lp_rational__set_vars_to_zero_2_2_0_i13);
MR_def_label(fn__libs__lp_rational__set_vars_to_zero_2_2_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 2, (MR_Integer) 2);
	MR_tfield(2, MR_tempr1, 0) = MR_r1;
	MR_tfield(2, MR_tempr1, 1) = MR_sv(1);
	MR_r1 = MR_tempr1;
	MR_decr_sp_and_return(2);
	}
MR_def_label(fn__libs__lp_rational__set_vars_to_zero_2_2_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(4,18);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__set_terms_to_zero__713__1_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_sv(1) = MR_tfield(0, MR_r2, 1);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tfield(0, MR_tempr2, 0);
	}
	MR_np_call_localret_ent(fn__list__filter_2_0,
		fn__libs__lp_rational__set_vars_to_zero_2_2_0_i18);
MR_def_label(fn__libs__lp_rational__set_vars_to_zero_2_2_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_r1;
	MR_tfield(0, MR_tempr1, 1) = MR_sv(1);
	MR_r1 = MR_tempr1;
	MR_decr_sp_and_return(2);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(varset__new_var_3_0);

MR_BEGIN_MODULE(libs__lp_rational_module75)
	MR_init_entry1(libs__lp_rational__new_slack_var_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__new_slack_var_3_0);
	MR_init_label1(libs__lp_rational__new_slack_var_3_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'new_slack_var'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__new_slack_var_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = MR_tfield(0, MR_sv(1), 0);
	MR_np_call_localret_ent(varset__new_var_3_0,
		libs__lp_rational__new_slack_var_3_0_i2);
MR_def_label(libs__lp_rational__new_slack_var_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_r1;
	MR_tempr3 = MR_sv(1);
	MR_tfield(1, MR_tempr1, 1) = MR_tfield(0, MR_tempr3, 1);
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 3);
	MR_tfield(0, MR_tempr2, 0) = MR_r2;
	MR_tfield(0, MR_tempr2, 1) = MR_tempr1;
	MR_tfield(0, MR_tempr2, 2) = MR_tfield(0, MR_tempr3, 2);
	MR_r2 = MR_tempr2;
	MR_decr_sp_and_return(2);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module76)
	MR_init_entry1(libs__lp_rational__new_art_var_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__new_art_var_3_0);
	MR_init_label1(libs__lp_rational__new_art_var_3_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'new_art_var'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__new_art_var_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = MR_tfield(0, MR_sv(1), 0);
	MR_np_call_localret_ent(varset__new_var_3_0,
		libs__lp_rational__new_art_var_3_0_i2);
MR_def_label(libs__lp_rational__new_art_var_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_r1;
	MR_tempr3 = MR_sv(1);
	MR_tfield(1, MR_tempr1, 1) = MR_tfield(0, MR_tempr3, 2);
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 3);
	MR_tfield(0, MR_tempr2, 0) = MR_r2;
	MR_tfield(0, MR_tempr2, 1) = MR_tfield(0, MR_tempr3, 1);
	MR_tfield(0, MR_tempr2, 2) = MR_tempr1;
	MR_r2 = MR_tempr2;
	MR_decr_sp_and_return(2);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module77)
	MR_init_entry1(libs__lp_rational__lp_standardize_constraint_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__lp_standardize_constraint_4_0);
	MR_init_label10(libs__lp_rational__lp_standardize_constraint_4_0,74,5,6,4,10,13,3,20,21,19)
	MR_init_label10(libs__lp_rational__lp_standardize_constraint_4_0,25,26,27,29,30,18,37,38,40,36)
	MR_init_label2(libs__lp_rational__lp_standardize_constraint_4_0,42,43)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'lp_standardize_constraint'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__lp_standardize_constraint_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,74)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(libs__lp_rational__lp_standardize_constraint_4_0_i3);
	}
	MR_sv(4) = MR_tfield(1, MR_r1, 1);
	MR_sv(3) = MR_tfield(1, MR_r1, 0);
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__lp_standardize_constraint_4_0_i5);
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_60_2_0,
		libs__lp_rational__lp_standardize_constraint_4_0_i6);
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__lp_standardize_constraint_4_0_i4);
	}
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(fn__libs__lp_rational__negate_constraint_1_0,
		libs__lp_rational__lp_standardize_constraint_4_0_i40);
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = MR_tfield(0, MR_sv(2), 0);
	MR_np_call_localret_ent(varset__new_var_3_0,
		libs__lp_rational__lp_standardize_constraint_4_0_i10);
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_r1;
	MR_tempr3 = MR_sv(2);
	MR_tfield(1, MR_tempr1, 1) = MR_tfield(0, MR_tempr3, 2);
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 3);
	MR_sv(1) = MR_tempr2;
	MR_tfield(0, MR_tempr2, 0) = MR_r2;
	MR_tfield(0, MR_tempr2, 1) = MR_tfield(0, MR_tempr3, 1);
	MR_tfield(0, MR_tempr2, 2) = MR_tempr1;
	MR_sv(2) = MR_r1;
	}
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		libs__lp_rational__lp_standardize_constraint_4_0_i13);
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 1) = MR_r1;
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr1;
	MR_tfield(1, MR_tempr2, 1) = MR_sv(3);
	MR_tag_alloc_heap(MR_r1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r1, 0) = MR_tempr2;
	MR_tfield(0, MR_r1, 1) = MR_sv(4);
	MR_r2 = MR_sv(1);
	MR_decr_sp_and_return(6);
	}
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(libs__lp_rational__lp_standardize_constraint_4_0_i18);
	}
	MR_sv(4) = MR_tfield(2, MR_r1, 1);
	MR_sv(3) = MR_tfield(2, MR_r1, 0);
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__lp_standardize_constraint_4_0_i20);
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_60_2_0,
		libs__lp_rational__lp_standardize_constraint_4_0_i21);
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__lp_standardize_constraint_4_0_i19);
	}
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(fn__libs__lp_rational__negate_constraint_1_0,
		libs__lp_rational__lp_standardize_constraint_4_0_i40);
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(libs__lp_rational__new_slack_var_3_0,
		libs__lp_rational__lp_standardize_constraint_4_0_i25);
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(libs__lp_rational__new_art_var_3_0,
		libs__lp_rational__lp_standardize_constraint_4_0_i26);
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	MR_sv(5) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		libs__lp_rational__lp_standardize_constraint_4_0_i27);
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(5);
	MR_tfield(0, MR_r2, 1) = MR_r1;
	MR_sv(5) = MR_r2;
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		libs__lp_rational__lp_standardize_constraint_4_0_i29);
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		libs__lp_rational__lp_standardize_constraint_4_0_i30);
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(2);
	MR_tfield(0, MR_r2, 1) = MR_r1;
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r1, 0) = MR_r2;
	MR_tfield(1, MR_r1, 1) = MR_sv(3);
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_sv(5);
	MR_tfield(1, MR_r2, 1) = MR_r1;
	MR_tag_alloc_heap(MR_r1, 2, (MR_Integer) 2);
	MR_tfield(2, MR_r1, 0) = MR_r2;
	MR_tfield(2, MR_r1, 1) = MR_sv(4);
	MR_r2 = MR_sv(1);
	MR_decr_sp_and_return(6);
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_tfield(0, MR_r1, 1);
	MR_sv(3) = MR_tfield(0, MR_r1, 0);
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__lp_standardize_constraint_4_0_i37);
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,37)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_60_2_0,
		libs__lp_rational__lp_standardize_constraint_4_0_i38);
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,38)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__lp_standardize_constraint_4_0_i36);
	}
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(fn__libs__lp_rational__negate_constraint_1_0,
		libs__lp_rational__lp_standardize_constraint_4_0_i40);
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_succip_word = MR_sv(6);
	MR_GOTO_LAB(libs__lp_rational__lp_standardize_constraint_4_0_i74);
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(libs__lp_rational__new_slack_var_3_0,
		libs__lp_rational__lp_standardize_constraint_4_0_i42);
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,42)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		libs__lp_rational__lp_standardize_constraint_4_0_i43);
MR_def_label(libs__lp_rational__lp_standardize_constraint_4_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(2);
	MR_tfield(0, MR_r2, 1) = MR_r1;
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r1, 0) = MR_r2;
	MR_tfield(1, MR_r1, 1) = MR_sv(3);
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_r1;
	MR_tfield(0, MR_r2, 1) = MR_sv(4);
	MR_r1 = MR_r2;
	MR_r2 = MR_sv(1);
	MR_decr_sp_and_return(6);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__f_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_101_108_101_109_32_58_61_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_3_0);

MR_BEGIN_MODULE(libs__lp_rational_module78)
	MR_init_entry1(fn__libs__lp_rational__extract_obj_var_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__extract_obj_var_3_0);
	MR_init_label4(fn__libs__lp_rational__extract_obj_var_3_0,3,5,6,9)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'extract_obj_var'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__extract_obj_var_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_sv(4) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = MR_sv(4);
	MR_r3 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r4 = MR_sv(2);
	MR_r5 = MR_tfield(0, MR_sv(1), 2);
	MR_np_call_localret_ent(fn__f_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_100_101_116_95_101_108_101_109_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_2_0,
		fn__libs__lp_rational__extract_obj_var_3_0_i3);
MR_def_label(fn__libs__lp_rational__extract_obj_var_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 5);
	MR_tfield(0, MR_r2, 0) = (MR_Word) MR_COMMON(2,24);
	MR_tfield(0, MR_r2, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__extract_obj_var2__1024__1_3_0);
	MR_tfield(0, MR_r2, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_r2, 3) = MR_sv(1);
	MR_tfield(0, MR_r2, 4) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_np_call_localret_ent(solutions__solutions_2_1,
		fn__libs__lp_rational__extract_obj_var_3_0_i5);
MR_def_label(fn__libs__lp_rational__extract_obj_var_3_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_r1,0,0)) {
		MR_GOTO_LAB(fn__libs__lp_rational__extract_obj_var_3_0_i6);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r1, 1);
	if (MR_LTAGS_TESTR(MR_tempr1,0,0)) {
		MR_GOTO_LAB(fn__libs__lp_rational__extract_obj_var_3_0_i6);
	}
	MR_r4 = MR_sv(2);
	MR_r5 = MR_sv(3);
	MR_r6 = MR_tfield(1, MR_r1, 0);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = MR_sv(4);
	MR_r3 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(fn__f_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_101_108_101_109_32_58_61_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_3_0);
	}
MR_def_label(fn__libs__lp_rational__extract_obj_var_3_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		fn__libs__lp_rational__extract_obj_var_3_0_i9);
MR_def_label(fn__libs__lp_rational__extract_obj_var_3_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r4 = MR_sv(2);
	MR_r5 = MR_sv(3);
	MR_r6 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = MR_sv(4);
	MR_r3 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(fn__f_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_101_108_101_109_32_58_61_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module79)
	MR_init_entry1(fn__libs__lp_rational__rhs_col_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__rhs_col_1_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'rhs_col'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__rhs_col_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_r1, 1);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_declare_entry(MR_do_fail);

MR_BEGIN_MODULE(libs__lp_rational_module80)
	MR_init_entry1(libs__lp_rational__between_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__between_3_0);
	MR_init_label2(libs__lp_rational__between_3_0,4,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'between'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__between_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_mkframe_no_redoip("pred libs.lp_rational.between/3-0", 2);
MR_def_label(libs__lp_rational__between_3_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_redoip_slot_word(MR_curfr) = (MR_Word) MR_ENTRY(MR_do_fail);
	if (((MR_Integer) MR_r1 > (MR_Integer) MR_r2)) {
		MR_GOTO(MR_ENTRY(MR_do_fail));
	}
	MR_redoip_slot_word(MR_maxfr) = (MR_Word) MR_LABEL_AP(libs__lp_rational__between_3_0_i2);
	MR_fv(1) = MR_r1;
	MR_fv(2) = MR_r2;
	MR_succeed();
MR_def_label(libs__lp_rational__between_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_redoip_slot_word(MR_curfr) = (MR_Word) MR_ENTRY(MR_do_fail);
	MR_r1 = ((MR_Integer) MR_fv(1) + (MR_Integer) 1);
	MR_r2 = MR_fv(2);
	MR_GOTO_LAB(libs__lp_rational__between_3_0_i4);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module81)
	MR_init_entry1(libs__lp_rational__all_rows0_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__all_rows0_2_0);
	MR_init_label2(libs__lp_rational__all_rows0_2_0,1,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'all_rows0'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__all_rows0_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_mkframe("pred libs.lp_rational.all_rows0/2-0", 2,
		MR_ENTRY(MR_do_fail));
	MR_fv(1) = MR_r1;
	MR_r1 = (MR_Integer) 0;
	MR_r2 = MR_tfield(0, MR_fv(1), 0);
	MR_np_call_localret_ent(libs__lp_rational__between_3_0,
		libs__lp_rational__all_rows0_2_0_i1);
MR_def_label(libs__lp_rational__all_rows0_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_fv(2) = MR_r1;
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_fv(2);
	MR_r3 = MR_tfield(0, MR_fv(1), 3);
	MR_np_call_localret_ent(list__member_2_0,
		libs__lp_rational__all_rows0_2_0_i3);
MR_def_label(libs__lp_rational__all_rows0_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_r1 = MR_fv(2);
	MR_succeed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module82)
	MR_init_entry1(libs__lp_rational__all_rows_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__all_rows_2_0);
	MR_init_label2(libs__lp_rational__all_rows_2_0,1,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'all_rows'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__all_rows_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_mkframe("pred libs.lp_rational.all_rows/2-0", 2,
		MR_ENTRY(MR_do_fail));
	MR_fv(1) = MR_r1;
	MR_r1 = (MR_Integer) 1;
	MR_r2 = MR_tfield(0, MR_fv(1), 0);
	MR_np_call_localret_ent(libs__lp_rational__between_3_0,
		libs__lp_rational__all_rows_2_0_i1);
MR_def_label(libs__lp_rational__all_rows_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_fv(2) = MR_r1;
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_fv(2);
	MR_r3 = MR_tfield(0, MR_fv(1), 3);
	MR_np_call_localret_ent(list__member_2_0,
		libs__lp_rational__all_rows_2_0_i3);
MR_def_label(libs__lp_rational__all_rows_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_r1 = MR_fv(2);
	MR_succeed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module83)
	MR_init_entry1(libs__lp_rational__all_cols0_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__all_cols0_2_0);
	MR_init_label2(libs__lp_rational__all_cols0_2_0,1,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'all_cols0'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__all_cols0_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_mkframe("pred libs.lp_rational.all_cols0/2-0", 2,
		MR_ENTRY(MR_do_fail));
	MR_fv(1) = MR_r1;
	MR_r1 = (MR_Integer) 0;
	MR_r2 = MR_tfield(0, MR_fv(1), 1);
	MR_np_call_localret_ent(libs__lp_rational__between_3_0,
		libs__lp_rational__all_cols0_2_0_i1);
MR_def_label(libs__lp_rational__all_cols0_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_fv(2) = MR_r1;
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_fv(2);
	MR_r3 = MR_tfield(0, MR_fv(1), 4);
	MR_np_call_localret_ent(list__member_2_0,
		libs__lp_rational__all_cols0_2_0_i3);
MR_def_label(libs__lp_rational__all_cols0_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_r1 = MR_fv(2);
	MR_succeed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module84)
	MR_init_entry1(libs__lp_rational__all_cols_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__all_cols_2_0);
	MR_init_label2(libs__lp_rational__all_cols_2_0,1,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'all_cols'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__all_cols_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_mkframe("pred libs.lp_rational.all_cols/2-0", 2,
		MR_ENTRY(MR_do_fail));
	MR_fv(1) = MR_r1;
	MR_r1 = (MR_Integer) 0;
	MR_r2 = ((MR_Integer) MR_tfield(0, MR_fv(1), 1) - (MR_Integer) 1);
	MR_np_call_localret_ent(libs__lp_rational__between_3_0,
		libs__lp_rational__all_cols_2_0_i1);
MR_def_label(libs__lp_rational__all_cols_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_fv(2) = MR_r1;
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_fv(2);
	MR_r3 = MR_tfield(0, MR_fv(1), 4);
	MR_np_call_localret_ent(list__member_2_0,
		libs__lp_rational__all_cols_2_0_i3);
MR_def_label(libs__lp_rational__all_cols_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_r1 = MR_fv(2);
	MR_succeed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(set__singleton_set_2_1);

MR_BEGIN_MODULE(libs__lp_rational_module85)
	MR_init_entry1(libs__lp_rational__make_label_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__make_label_3_0);
	MR_init_label1(libs__lp_rational__make_label_3_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'make_label'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__make_label_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = ((MR_Integer) MR_r1 + (MR_Integer) 1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(set__singleton_set_2_1,
		libs__lp_rational__make_label_3_0_i2);
MR_def_label(libs__lp_rational__make_label_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_decr_sp_and_return(2);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(list__append_3_1);

MR_BEGIN_MODULE(libs__lp_rational_module86)
	MR_init_entry1(libs__lp_rational__fm_standardize_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__fm_standardize_5_0);
	MR_init_label10(libs__lp_rational__fm_standardize_5_0,4,5,7,11,14,15,16,3,22,23)
	MR_init_label6(libs__lp_rational__fm_standardize_5_0,24,25,21,28,29,31)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'fm_standardize'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__fm_standardize_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(9);
	MR_sv(9) = (MR_Word) MR_succip;
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(libs__lp_rational__fm_standardize_5_0_i3);
	}
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_tfield(1, MR_r1, 0);
	MR_sv(4) = MR_tfield(1, MR_r1, 1);
	MR_sv(1) = ((MR_Integer) MR_r2 + (MR_Integer) 1);
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_np_call_localret_ent(set__singleton_set_2_1,
		libs__lp_rational__fm_standardize_5_0_i4);
MR_def_label(libs__lp_rational__fm_standardize_5_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = ((MR_Integer) MR_tempr1 + (MR_Integer) 1);
	MR_sv(5) = MR_r1;
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(set__singleton_set_2_1,
		libs__lp_rational__fm_standardize_5_0_i5);
MR_def_label(libs__lp_rational__fm_standardize_5_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(6) = MR_r1;
	MR_sv(7) = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_sv(8) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r1 = MR_sv(8);
	MR_r2 = MR_sv(7);
	MR_np_call_localret_ent(fn__map__init_0_0,
		libs__lp_rational__fm_standardize_5_0_i7);
MR_def_label(libs__lp_rational__fm_standardize_5_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,1,1);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,3,20);
	MR_r4 = MR_sv(3);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__foldl_4_0,
		libs__lp_rational__fm_standardize_5_0_i11);
MR_def_label(libs__lp_rational__fm_standardize_5_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 3);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(5);
	MR_tfield(0, MR_tempr1, 1) = MR_r1;
	MR_tfield(0, MR_tempr1, 2) = MR_sv(4);
	MR_tempr2 = MR_sv(3);
	MR_sv(3) = MR_tempr1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r2 = MR_r1;
	MR_r3 = MR_sv(8);
	MR_r4 = (MR_Word) MR_TAG_COMMON(0,3,21);
	MR_r5 = MR_tempr2;
	}
	MR_np_call_localret_ent(fn__assoc_list__map_values_only_2_0,
		libs__lp_rational__fm_standardize_5_0_i14);
MR_def_label(libs__lp_rational__fm_standardize_5_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__libs__lp_rational__lp_terms_to_map_1_0,
		libs__lp_rational__fm_standardize_5_0_i15);
MR_def_label(libs__lp_rational__fm_standardize_5_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_r1 = MR_tfield(0, MR_sv(3), 2);
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		libs__lp_rational__fm_standardize_5_0_i16);
MR_def_label(libs__lp_rational__fm_standardize_5_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 3);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(6);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(4);
	MR_tfield(0, MR_tempr1, 2) = MR_r1;
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr1;
	MR_tfield(1, MR_tempr2, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_sv(3);
	MR_tfield(1, MR_r2, 1) = MR_tempr2;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, vector);
	MR_r3 = MR_sv(2);
	}
	MR_np_call_localret_ent(list__append_3_1,
		libs__lp_rational__fm_standardize_5_0_i31);
MR_def_label(libs__lp_rational__fm_standardize_5_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(libs__lp_rational__fm_standardize_5_0_i21);
	}
	MR_sv(2) = MR_r3;
	MR_sv(1) = MR_tfield(2, MR_r1, 0);
	MR_sv(3) = MR_tfield(2, MR_r1, 1);
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(libs__lp_rational__make_label_3_0,
		libs__lp_rational__fm_standardize_5_0_i22);
MR_def_label(libs__lp_rational__fm_standardize_5_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r2;
	MR_sv(4) = MR_r1;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__libs__lp_rational__negate_lp_terms_1_0,
		libs__lp_rational__fm_standardize_5_0_i23);
MR_def_label(libs__lp_rational__fm_standardize_5_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__libs__lp_rational__lp_terms_to_map_1_0,
		libs__lp_rational__fm_standardize_5_0_i24);
MR_def_label(libs__lp_rational__fm_standardize_5_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_sv(3) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		libs__lp_rational__fm_standardize_5_0_i25);
MR_def_label(libs__lp_rational__fm_standardize_5_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 3);
	MR_tfield(0, MR_r2, 0) = MR_sv(4);
	MR_tfield(0, MR_r2, 1) = MR_sv(3);
	MR_tfield(0, MR_r2, 2) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, vector);
	MR_r3 = MR_sv(2);
	MR_np_call_localret_ent(list__cons_3_0,
		libs__lp_rational__fm_standardize_5_0_i31);
MR_def_label(libs__lp_rational__fm_standardize_5_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_tfield(0, MR_r1, 1);
	MR_r1 = MR_tfield(0, MR_r1, 0);
	MR_np_call_localret_ent(fn__libs__lp_rational__lp_terms_to_map_1_0,
		libs__lp_rational__fm_standardize_5_0_i28);
MR_def_label(libs__lp_rational__fm_standardize_5_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(libs__lp_rational__make_label_3_0,
		libs__lp_rational__fm_standardize_5_0_i29);
MR_def_label(libs__lp_rational__fm_standardize_5_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 3);
	MR_tfield(0, MR_tempr1, 0) = MR_r1;
	MR_tfield(0, MR_tempr1, 1) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 2) = MR_sv(3);
	MR_sv(1) = MR_r2;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, vector);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(2);
	}
	MR_np_call_localret_ent(list__cons_3_0,
		libs__lp_rational__fm_standardize_5_0_i31);
MR_def_label(libs__lp_rational__fm_standardize_5_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_decr_sp_and_return(9);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module87)
	MR_init_entry1(fn__libs__lp_rational__vector_to_constraint_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__vector_to_constraint_1_0);
	MR_init_label2(fn__libs__lp_rational__vector_to_constraint_1_0,3,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'vector_to_constraint'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__vector_to_constraint_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_tfield(0, MR_r1, 2);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_tfield(0, MR_tempr1, 1);
	}
	MR_np_call_localret_ent(fn__map__to_assoc_list_1_0,
		fn__libs__lp_rational__vector_to_constraint_1_0_i3);
MR_def_label(fn__libs__lp_rational__vector_to_constraint_1_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Integer) 1;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(1);
	}
	MR_np_call_localret_ent(libs__lp_rational__normalize_terms_and_const_5_0,
		fn__libs__lp_rational__vector_to_constraint_1_0_i4);
MR_def_label(fn__libs__lp_rational__vector_to_constraint_1_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_r1;
	MR_tfield(0, MR_tempr1, 1) = MR_r2;
	MR_r1 = MR_tempr1;
	MR_decr_sp_and_return(2);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__map__map_values_only_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module88)
	MR_init_entry1(libs__lp_rational__classify_vector_10_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__classify_vector_10_0);
	MR_init_label10(libs__lp_rational__classify_vector_10_0,4,7,10,11,9,14,15,17,18,20)
	MR_init_label7(libs__lp_rational__classify_vector_10_0,22,23,25,21,26,2,28)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'classify_vector'/10 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__classify_vector_10_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(11);
	MR_sv(11) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(6) = MR_r3;
	MR_sv(7) = MR_r4;
	MR_sv(8) = MR_r5;
	MR_sv(9) = MR_r6;
	MR_sv(3) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = MR_sv(3);
	MR_r3 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r4 = MR_sv(1);
	MR_r5 = MR_tfield(0, MR_sv(2), 1);
	MR_np_call_localret_ent(fn__f_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_101_108_101_109_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_2_0,
		libs__lp_rational__classify_vector_10_0_i4);
MR_def_label(libs__lp_rational__classify_vector_10_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__classify_vector_10_0_i2);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r2;
	MR_tempr2 = MR_sv(2);
	MR_sv(3) = MR_tfield(0, MR_tempr2, 0);
	MR_sv(4) = MR_tfield(0, MR_tempr2, 1);
	MR_sv(5) = MR_tfield(0, MR_tempr2, 2);
	MR_sv(10) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = MR_sv(10);
	MR_r3 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r4 = MR_tempr1;
	MR_r5 = MR_sv(4);
	}
	MR_np_call_localret_ent(fn__f_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_101_108_101_109_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_2_0,
		libs__lp_rational__classify_vector_10_0_i7);
MR_def_label(libs__lp_rational__classify_vector_10_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__classify_vector_10_0_i20);
	}
	MR_sv(2) = MR_r2;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__classify_vector_10_0_i10);
MR_def_label(libs__lp_rational__classify_vector_10_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__classify_vector_10_0_i11);
MR_def_label(libs__lp_rational__classify_vector_10_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__classify_vector_10_0_i9);
	}
	MR_r1 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r2 = (MR_Word) MR_string_const("normalize_vector/5: zero coefficient in vector.", 47);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		libs__lp_rational__classify_vector_10_0_i14);
MR_def_label(libs__lp_rational__classify_vector_10_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
MR_def_label(libs__lp_rational__classify_vector_10_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__libs__rat__abs_1_0,
		libs__lp_rational__classify_vector_10_0_i15);
MR_def_label(libs__lp_rational__classify_vector_10_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,26);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(fn__libs__lp_rational__IntroducedFrom__func__normalize_vector__2062__1_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_sv(2) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r2 = MR_r1;
	MR_r3 = MR_sv(10);
	MR_r5 = MR_sv(4);
	}
	MR_np_call_localret_ent(fn__map__map_values_only_2_0,
		libs__lp_rational__classify_vector_10_0_i17);
MR_def_label(libs__lp_rational__classify_vector_10_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(2);
	MR_sv(2) = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_47_2_0,
		libs__lp_rational__classify_vector_10_0_i18);
MR_def_label(libs__lp_rational__classify_vector_10_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 3);
	MR_tfield(0, MR_r2, 0) = MR_sv(3);
	MR_tfield(0, MR_r2, 1) = MR_sv(2);
	MR_tfield(0, MR_r2, 2) = MR_r1;
	MR_sv(2) = MR_r2;
MR_def_label(libs__lp_rational__classify_vector_10_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__classify_vector_10_0_i22);
MR_def_label(libs__lp_rational__classify_vector_10_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_62_2_0,
		libs__lp_rational__classify_vector_10_0_i23);
MR_def_label(libs__lp_rational__classify_vector_10_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__classify_vector_10_0_i21);
	}
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, vector);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(6);
	MR_np_call_localret_ent(list__cons_3_0,
		libs__lp_rational__classify_vector_10_0_i25);
MR_def_label(libs__lp_rational__classify_vector_10_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(7);
	MR_r3 = MR_sv(8);
	MR_r4 = MR_sv(9);
	MR_decr_sp_and_return(11);
MR_def_label(libs__lp_rational__classify_vector_10_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, vector);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(7);
	MR_np_call_localret_ent(list__cons_3_0,
		libs__lp_rational__classify_vector_10_0_i26);
MR_def_label(libs__lp_rational__classify_vector_10_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(8);
	MR_r4 = MR_sv(9);
	MR_decr_sp_and_return(11);
	}
MR_def_label(libs__lp_rational__classify_vector_10_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, vector);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(8);
	MR_np_call_localret_ent(list__cons_3_0,
		libs__lp_rational__classify_vector_10_0_i28);
MR_def_label(libs__lp_rational__classify_vector_10_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(7);
	MR_r3 = MR_tempr1;
	MR_r4 = ((MR_Integer) MR_sv(9) + (MR_Integer) 1);
	MR_decr_sp_and_return(11);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(list__foldl2_6_4);

MR_BEGIN_MODULE(libs__lp_rational_module89)
	MR_init_entry1(libs__lp_rational__eliminate_var_8_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__eliminate_var_8_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'eliminate_var'/8 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__eliminate_var_8_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 6);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(11,0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__combine_vectors_8_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 3;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_tfield(0, MR_tempr1, 4) = MR_r2;
	MR_tfield(0, MR_tempr1, 5) = MR_r4;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, vector);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,17);
	MR_tempr2 = MR_r3;
	MR_r3 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r4 = MR_tempr1;
	MR_tempr3 = MR_r5;
	MR_r5 = MR_tempr2;
	MR_tempr4 = MR_r6;
	MR_r6 = MR_tempr3;
	MR_r7 = MR_tempr4;
	MR_np_tailcall_ent(list__foldl2_6_4);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(map__member_3_0);

MR_BEGIN_MODULE(libs__lp_rational_module90)
	MR_init_entry1(libs__lp_rational__quasi_syntactic_redundant_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__quasi_syntactic_redundant_2_0);
	MR_init_label10(libs__lp_rational__quasi_syntactic_redundant_2_0,2,12,17,18,20,10,27,32,33,35)
	MR_init_label3(libs__lp_rational__quasi_syntactic_redundant_2_0,31,25,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'quasi_syntactic_redundant'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__quasi_syntactic_redundant_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(14);
	MR_sv(14) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_tfield(0, MR_r2, 2);
	MR_r2 = MR_tfield(0, MR_sv(1), 2);
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_60_2_0,
		libs__lp_rational__quasi_syntactic_redundant_2_0_i2);
MR_def_label(libs__lp_rational__quasi_syntactic_redundant_2_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__quasi_syntactic_redundant_2_0_i1);
	}
	MR_sv(8) = (MR_Word) MR_redoip_slot(MR_maxfr);
	MR_sv(9) = (MR_Word) MR_redofr_slot(MR_maxfr);
	MR_save_maxfr(MR_sv(10));
	MR_redofr_slot_word(MR_maxfr) = (MR_Word) MR_curfr;
	MR_redoip_slot_word(MR_maxfr) = (MR_Word) MR_LABEL_AP(libs__lp_rational__quasi_syntactic_redundant_2_0_i10);
	MR_sv(5) = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_sv(6) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r1 = MR_sv(6);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_tfield(0, MR_sv(1), 1);
	MR_np_call_localret_ent(map__member_3_0,
		libs__lp_rational__quasi_syntactic_redundant_2_0_i12);
MR_def_label(libs__lp_rational__quasi_syntactic_redundant_2_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(11) = (MR_Word) MR_redoip_slot(MR_maxfr);
	MR_sv(12) = (MR_Word) MR_redofr_slot(MR_maxfr);
	MR_save_maxfr(MR_sv(13));
	MR_redofr_slot_word(MR_maxfr) = (MR_Word) MR_curfr;
	MR_redoip_slot_word(MR_maxfr) = (MR_Word) MR_LABEL_AP(libs__lp_rational__quasi_syntactic_redundant_2_0_i31);
	MR_sv(3) = MR_r1;
	MR_sv(4) = MR_r2;
	MR_r1 = MR_sv(6);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_tfield(0, MR_sv(2), 1);
	MR_np_call_localret_ent(map__member_3_0,
		libs__lp_rational__quasi_syntactic_redundant_2_0_i17);
MR_def_label(libs__lp_rational__quasi_syntactic_redundant_2_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(7) = MR_r2;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(3);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___term__var_1_0,
		libs__lp_rational__quasi_syntactic_redundant_2_0_i18);
MR_def_label(libs__lp_rational__quasi_syntactic_redundant_2_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_r1 = MR_sv(4);
	MR_r2 = MR_sv(7);
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__quasi_syntactic_redundant_2_0_i20);
MR_def_label(libs__lp_rational__quasi_syntactic_redundant_2_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_restore_maxfr(MR_sv(13));
	MR_redoip_slot_word(MR_maxfr) = MR_sv(11);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(12);
	MR_GOTO(MR_ENTRY(MR_do_redo));
MR_def_label(libs__lp_rational__quasi_syntactic_redundant_2_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_redoip_slot_word(MR_maxfr) = MR_sv(8);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(9);
	MR_sv(8) = (MR_Word) MR_redoip_slot(MR_maxfr);
	MR_sv(9) = (MR_Word) MR_redofr_slot(MR_maxfr);
	MR_save_maxfr(MR_sv(10));
	MR_redofr_slot_word(MR_maxfr) = (MR_Word) MR_curfr;
	MR_redoip_slot_word(MR_maxfr) = (MR_Word) MR_LABEL_AP(libs__lp_rational__quasi_syntactic_redundant_2_0_i25);
	MR_sv(3) = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_sv(4) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r1 = MR_sv(4);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_tfield(0, MR_sv(2), 1);
	MR_np_call_localret_ent(map__member_3_0,
		libs__lp_rational__quasi_syntactic_redundant_2_0_i27);
MR_def_label(libs__lp_rational__quasi_syntactic_redundant_2_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(11) = (MR_Word) MR_redoip_slot(MR_maxfr);
	MR_sv(12) = (MR_Word) MR_redofr_slot(MR_maxfr);
	MR_save_maxfr(MR_sv(13));
	MR_redofr_slot_word(MR_maxfr) = (MR_Word) MR_curfr;
	MR_redoip_slot_word(MR_maxfr) = (MR_Word) MR_LABEL_AP(libs__lp_rational__quasi_syntactic_redundant_2_0_i31);
	MR_sv(2) = MR_r2;
	MR_sv(5) = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_tfield(0, MR_sv(1), 1);
	MR_np_call_localret_ent(map__member_3_0,
		libs__lp_rational__quasi_syntactic_redundant_2_0_i32);
MR_def_label(libs__lp_rational__quasi_syntactic_redundant_2_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(6) = MR_r2;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(5);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___term__var_1_0,
		libs__lp_rational__quasi_syntactic_redundant_2_0_i33);
MR_def_label(libs__lp_rational__quasi_syntactic_redundant_2_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(6);
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__quasi_syntactic_redundant_2_0_i35);
MR_def_label(libs__lp_rational__quasi_syntactic_redundant_2_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_restore_maxfr(MR_sv(13));
	MR_redoip_slot_word(MR_maxfr) = MR_sv(11);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(12);
	MR_GOTO(MR_ENTRY(MR_do_redo));
MR_def_label(libs__lp_rational__quasi_syntactic_redundant_2_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_redoip_slot_word(MR_maxfr) = MR_sv(11);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(12);
	MR_restore_maxfr(MR_sv(10));
	MR_redoip_slot_word(MR_maxfr) = MR_sv(8);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(9);
	MR_succip_word = MR_sv(14);
	MR_decr_sp(14);
	MR_r1 = MR_FALSE;
	MR_proceed();
MR_def_label(libs__lp_rational__quasi_syntactic_redundant_2_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_redoip_slot_word(MR_maxfr) = MR_sv(8);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(9);
	MR_succip_word = MR_sv(14);
	MR_decr_sp(14);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(libs__lp_rational__quasi_syntactic_redundant_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(14);
	MR_decr_sp(14);
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module91)
	MR_init_entry1(libs__lp_rational__add_vectors_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__add_vectors_6_0);
	MR_init_label2(libs__lp_rational__add_vectors_6_0,2,7)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'add_vectors'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__add_vectors_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r3;
	MR_r1 = MR_r2;
	MR_r2 = MR_r4;
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_43_2_0,
		libs__lp_rational__add_vectors_6_0_i2);
MR_def_label(libs__lp_rational__add_vectors_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(4,20);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__add_vectors__2108__1_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tempr3 = MR_sv(1);
	MR_tfield(0, MR_tempr1, 3) = MR_tempr3;
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 4);
	MR_r4 = MR_tempr2;
	MR_tfield(0, MR_tempr2, 0) = (MR_Word) MR_COMMON(5,11);
	MR_tfield(0, MR_tempr2, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0);
	MR_tfield(0, MR_tempr2, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr2, 3) = MR_tempr3;
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,1,1);
	MR_r5 = MR_sv(2);
	}
	MR_np_call_localret_ent(solutions__aggregate_4_3,
		libs__lp_rational__add_vectors_6_0_i7);
MR_def_label(libs__lp_rational__add_vectors_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_decr_sp_and_return(3);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__set__union_2_0);
MR_decl_entry(fn__set__count_1_0);
MR_decl_entry(map__is_empty_1_0);
MR_decl_entry(set__subset_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module92)
	MR_init_entry1(libs__lp_rational__combine_vectors_8_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__combine_vectors_8_0);
	MR_init_label10(libs__lp_rational__combine_vectors_8_0,2,4,5,12,14,15,41,10,19,20)
	MR_init_label10(libs__lp_rational__combine_vectors_8_0,18,23,28,29,26,31,25,32,33,36)
	MR_init_label2(libs__lp_rational__combine_vectors_8_0,37,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'combine_vectors'/8 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__combine_vectors_8_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(13);
	MR_sv(13) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r3;
	MR_sv(3) = MR_tfield(0, MR_tempr1, 1);
	MR_sv(4) = MR_tfield(0, MR_tempr1, 2);
	MR_tempr2 = MR_r4;
	MR_sv(5) = MR_tfield(0, MR_tempr2, 1);
	MR_sv(6) = MR_tfield(0, MR_tempr2, 2);
	MR_sv(8) = MR_r5;
	MR_sv(9) = MR_r6;
	MR_sv(7) = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r1 = MR_sv(7);
	MR_r2 = MR_tfield(0, MR_tempr1, 0);
	MR_r3 = MR_tfield(0, MR_tempr2, 0);
	}
	MR_np_call_localret_ent(fn__set__union_2_0,
		libs__lp_rational__combine_vectors_8_0_i2);
MR_def_label(libs__lp_rational__combine_vectors_8_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(7) = MR_r1;
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_sv(7);
	MR_np_call_localret_ent(fn__set__count_1_0,
		libs__lp_rational__combine_vectors_8_0_i4);
MR_def_label(libs__lp_rational__combine_vectors_8_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = ((MR_Integer) MR_sv(1) + (MR_Integer) 2);
	if (((MR_Integer) MR_r1 >= (MR_Integer) MR_tempr1)) {
		MR_GOTO_LAB(libs__lp_rational__combine_vectors_8_0_i41);
	}
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(4);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(6);
	}
	MR_np_call_localret_ent(libs__lp_rational__add_vectors_6_0,
		libs__lp_rational__combine_vectors_8_0_i5);
MR_def_label(libs__lp_rational__combine_vectors_8_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 3);
	MR_sv(3) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(7);
	MR_tfield(0, MR_tempr1, 1) = MR_r1;
	MR_tfield(0, MR_tempr1, 2) = MR_r2;
	MR_sv(1) = MR_r2;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_tfield(0, MR_tempr1, 1);
	}
	MR_np_call_localret_ent(map__is_empty_1_0,
		libs__lp_rational__combine_vectors_8_0_i12);
MR_def_label(libs__lp_rational__combine_vectors_8_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__combine_vectors_8_0_i10);
	}
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__combine_vectors_8_0_i14);
MR_def_label(libs__lp_rational__combine_vectors_8_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_62_61_2_0,
		libs__lp_rational__combine_vectors_8_0_i15);
MR_def_label(libs__lp_rational__combine_vectors_8_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__combine_vectors_8_0_i10);
	}
MR_def_label(libs__lp_rational__combine_vectors_8_0,41)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(8);
	MR_r3 = MR_sv(9);
	MR_GOTO_LAB(libs__lp_rational__combine_vectors_8_0_i36);
MR_def_label(libs__lp_rational__combine_vectors_8_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(10) = (MR_Word) MR_redoip_slot(MR_maxfr);
	MR_sv(11) = (MR_Word) MR_redofr_slot(MR_maxfr);
	MR_save_maxfr(MR_sv(12));
	MR_redofr_slot_word(MR_maxfr) = (MR_Word) MR_curfr;
	MR_redoip_slot_word(MR_maxfr) = (MR_Word) MR_LABEL_AP(libs__lp_rational__combine_vectors_8_0_i18);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, vector);
	MR_r2 = MR_sv(8);
	MR_np_call_localret_ent(list__member_2_1,
		libs__lp_rational__combine_vectors_8_0_i19);
MR_def_label(libs__lp_rational__combine_vectors_8_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(libs__lp_rational__quasi_syntactic_redundant_2_0,
		libs__lp_rational__combine_vectors_8_0_i20);
MR_def_label(libs__lp_rational__combine_vectors_8_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_restore_maxfr(MR_sv(12));
	MR_redoip_slot_word(MR_maxfr) = MR_sv(10);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(11);
	MR_GOTO_LAB(libs__lp_rational__combine_vectors_8_0_i41);
MR_def_label(libs__lp_rational__combine_vectors_8_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_redoip_slot_word(MR_maxfr) = MR_sv(10);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(11);
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(8);
	MR_r3 = (MR_Word) MR_tbmkword(0, 0);
	MR_r4 = (MR_Integer) 0;
	MR_np_call_localret_ent(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_50_95_95_91_50_93_95_48_6_0,
		libs__lp_rational__combine_vectors_8_0_i23);
MR_def_label(libs__lp_rational__combine_vectors_8_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(10) = (MR_Word) MR_redoip_slot(MR_maxfr);
	MR_sv(11) = (MR_Word) MR_redofr_slot(MR_maxfr);
	MR_save_maxfr(MR_sv(12));
	MR_redofr_slot_word(MR_maxfr) = (MR_Word) MR_curfr;
	MR_redoip_slot_word(MR_maxfr) = (MR_Word) MR_LABEL_AP(libs__lp_rational__combine_vectors_8_0_i26);
	MR_sv(1) = MR_r1;
	MR_sv(4) = MR_r2;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, vector);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(list__member_2_1,
		libs__lp_rational__combine_vectors_8_0_i28);
MR_def_label(libs__lp_rational__combine_vectors_8_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_tfield(0, MR_tempr1, 0);
	MR_r3 = MR_tfield(0, MR_sv(3), 0);
	}
	MR_np_call_localret_ent(set__subset_2_0,
		libs__lp_rational__combine_vectors_8_0_i29);
MR_def_label(libs__lp_rational__combine_vectors_8_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_restore_maxfr(MR_sv(12));
	MR_redoip_slot_word(MR_maxfr) = MR_sv(10);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(11);
	MR_GOTO_LAB(libs__lp_rational__combine_vectors_8_0_i31);
MR_def_label(libs__lp_rational__combine_vectors_8_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_redoip_slot_word(MR_maxfr) = MR_sv(10);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(11);
	MR_GOTO_LAB(libs__lp_rational__combine_vectors_8_0_i25);
MR_def_label(libs__lp_rational__combine_vectors_8_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_r3 = MR_sv(4);
	MR_GOTO_LAB(libs__lp_rational__combine_vectors_8_0_i36);
MR_def_label(libs__lp_rational__combine_vectors_8_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tempr1;
	MR_r3 = (MR_Word) MR_tbmkword(0, 0);
	MR_r4 = (MR_Integer) 0;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_49_95_95_91_50_93_95_48_6_0,
		libs__lp_rational__combine_vectors_8_0_i32);
MR_def_label(libs__lp_rational__combine_vectors_8_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, vector);
	MR_r2 = MR_sv(3);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__cons_3_0,
		libs__lp_rational__combine_vectors_8_0_i33);
MR_def_label(libs__lp_rational__combine_vectors_8_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_r1;
	MR_r3 = ((MR_Integer) MR_sv(1) + (MR_Integer) 1);
MR_def_label(libs__lp_rational__combine_vectors_8_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_sv(2),0,0)) {
		MR_GOTO_LAB(libs__lp_rational__combine_vectors_8_0_i37);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_sv(2), 0);
	if (((MR_Integer) MR_r3 > (MR_Integer) MR_tempr1)) {
		MR_GOTO_LAB(libs__lp_rational__combine_vectors_8_0_i1);
	}
	}
MR_def_label(libs__lp_rational__combine_vectors_8_0,37)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(13);
	MR_decr_sp(13);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(libs__lp_rational__combine_vectors_8_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(13);
	MR_decr_sp(13);
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module93)
	MR_init_entry1(libs__lp_rational__relevant_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__relevant_1_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'relevant'/1 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__relevant_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_tfield(0, MR_r1, 1);
	MR_r1 = ((MR_Integer) MR_r2 != (MR_Integer) 0);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module94)
	MR_init_entry1(fn__libs__lp_rational__make_expansion_num_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__make_expansion_num_2_0);
	MR_init_label1(fn__libs__lp_rational__make_expansion_num_2_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'make_expansion_num'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__make_expansion_num_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(0, MR_r2, 1);
	MR_r4 = MR_tempr1;
	MR_r3 = ((MR_Integer) MR_tfield(0, MR_tempr1, 0) + (MR_Integer) MR_tfield(0, MR_tempr1, 1));
	MR_r5 = MR_tfield(0, MR_tempr1, 1);
	MR_r6 = MR_tfield(0, MR_tempr1, 0);
	MR_r4 = MR_tfield(0, MR_r2, 0);
	if (MR_INT_NE(MR_r3,0)) {
		MR_GOTO_LAB(fn__libs__lp_rational__make_expansion_num_2_0_i2);
	}
	MR_tag_alloc_heap(MR_r1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r1, 0) = MR_r4;
	MR_tfield(0, MR_r1, 1) = (MR_Integer) 0;
	MR_proceed();
	}
MR_def_label(fn__libs__lp_rational__make_expansion_num_2_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_r4;
	MR_tfield(0, MR_r2, 1) = (((MR_Integer) MR_r6 * (MR_Integer) MR_r5) + ((MR_Integer) MR_r1 - (MR_Integer) MR_r3));
	MR_r1 = MR_r2;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module95)
	MR_init_entry1(fn__libs__lp_rational__count_coeffs_in_vector_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__count_coeffs_in_vector_2_0);
	MR_init_label1(fn__libs__lp_rational__count_coeffs_in_vector_2_0,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'count_coeffs_in_vector'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__count_coeffs_in_vector_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_sv(2) = (MR_Word) MR_TAG_COMMON(0,0,0);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_tfield(0, MR_tempr1, 1);
	}
	MR_np_call_localret_ent(fn__map__to_assoc_list_1_0,
		fn__libs__lp_rational__count_coeffs_in_vector_2_0_i3);
MR_def_label(fn__libs__lp_rational__count_coeffs_in_vector_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,1,12);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,3,22);
	MR_r4 = MR_tempr1;
	MR_r5 = MR_sv(1);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(f_115_118_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_95_100_101_116_95_117_112_100_97_116_101_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_4_0);

MR_BEGIN_MODULE(libs__lp_rational_module96)
	MR_init_entry1(libs__lp_rational__count_coeff_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__count_coeff_3_0);
	MR_init_label9(libs__lp_rational__count_coeff_3_0,4,7,8,6,12,13,11,18,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'count_coeff'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__count_coeff_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(8);
	MR_sv(8) = (MR_Word) MR_succip;
	MR_sv(1) = MR_tfield(0, MR_r1, 0);
	MR_sv(2) = MR_tfield(0, MR_r1, 1);
	MR_sv(5) = MR_r2;
	MR_sv(6) = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_sv(7) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(7);
	MR_r3 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, coeff_info);
	MR_r4 = MR_sv(1);
	MR_r5 = MR_sv(5);
	MR_np_call_localret_ent(fn__f_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_101_108_101_109_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_2_0,
		libs__lp_rational__count_coeff_3_0_i4);
MR_def_label(libs__lp_rational__count_coeff_3_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__count_coeff_3_0_i2);
	}
	MR_sv(4) = MR_tfield(0, MR_r2, 1);
	MR_sv(3) = MR_tfield(0, MR_r2, 0);
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__count_coeff_3_0_i7);
MR_def_label(libs__lp_rational__count_coeff_3_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_62_2_0,
		libs__lp_rational__count_coeff_3_0_i8);
MR_def_label(libs__lp_rational__count_coeff_3_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__count_coeff_3_0_i6);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_r5 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = ((MR_Integer) MR_sv(3) + (MR_Integer) 1);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(4);
	MR_r4 = MR_sv(1);
	MR_r6 = MR_sv(5);
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(7);
	MR_r3 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, coeff_info);
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_np_tailcall_ent(f_115_118_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_95_100_101_116_95_117_112_100_97_116_101_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_4_0);
	}
MR_def_label(libs__lp_rational__count_coeff_3_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__count_coeff_3_0_i12);
MR_def_label(libs__lp_rational__count_coeff_3_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_60_2_0,
		libs__lp_rational__count_coeff_3_0_i13);
MR_def_label(libs__lp_rational__count_coeff_3_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__count_coeff_3_0_i11);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_r5 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(3);
	MR_tfield(0, MR_tempr1, 1) = ((MR_Integer) MR_sv(4) + (MR_Integer) 1);
	MR_r4 = MR_sv(1);
	MR_r6 = MR_sv(5);
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(7);
	MR_r3 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, coeff_info);
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_np_tailcall_ent(f_115_118_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_95_100_101_116_95_117_112_100_97_116_101_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_4_0);
	}
MR_def_label(libs__lp_rational__count_coeff_3_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r2 = (MR_Word) MR_string_const("count_coeff/3: zero coefficient encountered.", 44);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		libs__lp_rational__count_coeff_3_0_i18);
MR_def_label(libs__lp_rational__count_coeff_3_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_np_tailcall_ent(f_115_118_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_95_100_101_116_95_117_112_100_97_116_101_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_4_0);
MR_def_label(libs__lp_rational__count_coeff_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(5);
	MR_decr_sp_and_return(8);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module97)
	MR_init_entry1(libs__lp_rational__get_vars_from_constraint_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__get_vars_from_constraint_3_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'get_vars_from_constraint'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__get_vars_from_constraint_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_mask_field(MR_r1, 0);
	MR_np_tailcall_ent(libs__lp_rational__get_vars_from_terms_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__libs__rat__to_string_1_0);
MR_decl_entry(fn__f_115_116_114_105_110_103_95_95_43_43_2_0);
MR_decl_entry(io__write_string_3_0);

MR_BEGIN_MODULE(libs__lp_rational_module98)
	MR_init_entry1(libs__lp_rational__write_constraint_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__write_constraint_4_0);
	MR_init_label8(libs__lp_rational__write_constraint_4_0,2,7,8,9,10,11,12,13)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'write_constraint'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__write_constraint_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = (MR_Integer) 9;
	MR_np_call_localret_ent(io__write_char_3_0,
		libs__lp_rational__write_constraint_4_0_i2);
MR_def_label(libs__lp_rational__write_constraint_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(5,12);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__write_constr_term_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(libs__lp_rational__write_constraint_4_0_i7);
	}
	MR_tempr2 = MR_sv(2);
	MR_r4 = MR_tfield(1, MR_tempr2, 0);
	MR_sv(1) = MR_tfield(1, MR_tempr2, 1);
	MR_sv(2) = (MR_Word) MR_string_const("=", 1);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = (MR_Word) MR_IO_CTOR_ADDR;
	}
	MR_np_call_localret_ent(list__foldl_4_2,
		libs__lp_rational__write_constraint_4_0_i9);
MR_def_label(libs__lp_rational__write_constraint_4_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),2)) {
		MR_GOTO_LAB(libs__lp_rational__write_constraint_4_0_i8);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(2);
	MR_r4 = MR_tfield(2, MR_tempr1, 0);
	MR_sv(1) = MR_tfield(2, MR_tempr1, 1);
	MR_sv(2) = (MR_Word) MR_string_const(">=", 2);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = (MR_Word) MR_IO_CTOR_ADDR;
	}
	MR_np_call_localret_ent(list__foldl_4_2,
		libs__lp_rational__write_constraint_4_0_i9);
MR_def_label(libs__lp_rational__write_constraint_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(2);
	MR_r4 = MR_tfield(0, MR_tempr1, 0);
	MR_sv(1) = MR_tfield(0, MR_tempr1, 1);
	MR_sv(2) = (MR_Word) MR_string_const("=<", 2);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = (MR_Word) MR_IO_CTOR_ADDR;
	}
	MR_np_call_localret_ent(list__foldl_4_2,
		libs__lp_rational__write_constraint_4_0_i9);
MR_def_label(libs__lp_rational__write_constraint_4_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(fn__libs__rat__to_string_1_0,
		libs__lp_rational__write_constraint_4_0_i10);
MR_def_label(libs__lp_rational__write_constraint_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_string_const("\n", 1);
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		libs__lp_rational__write_constraint_4_0_i11);
MR_def_label(libs__lp_rational__write_constraint_4_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" ", 1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		libs__lp_rational__write_constraint_4_0_i12);
MR_def_label(libs__lp_rational__write_constraint_4_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		libs__lp_rational__write_constraint_4_0_i13);
MR_def_label(libs__lp_rational__write_constraint_4_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(io__write_string_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__varset__lookup_name_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module99)
	MR_init_entry1(libs__lp_rational__write_constr_term_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__write_constr_term_4_0);
	MR_init_label4(libs__lp_rational__write_constr_term_4_0,2,3,4,5)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'write_constr_term'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__write_constr_term_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_tfield(0, MR_r2, 1);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tfield(0, MR_tempr2, 0);
	}
	MR_np_call_localret_ent(fn__varset__lookup_name_2_0,
		libs__lp_rational__write_constr_term_4_0_i2);
MR_def_label(libs__lp_rational__write_constr_term_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__libs__rat__to_string_1_0,
		libs__lp_rational__write_constr_term_4_0_i3);
MR_def_label(libs__lp_rational__write_constr_term_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Word) MR_string_const(" ", 1);
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		libs__lp_rational__write_constr_term_4_0_i4);
MR_def_label(libs__lp_rational__write_constr_term_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		libs__lp_rational__write_constr_term_4_0_i5);
MR_def_label(libs__lp_rational__write_constr_term_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__write_string_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(libs__rat__write_rat_3_0);

MR_BEGIN_MODULE(libs__lp_rational_module100)
	MR_init_entry1(libs__lp_rational__output_constraint_2_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__output_constraint_2_5_0);
	MR_init_label5(libs__lp_rational__output_constraint_2_5_0,2,6,7,8,9)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_constraint_2'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__output_constraint_2_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_r1 = (MR_Integer) 91;
	MR_np_call_localret_ent(io__write_char_3_0,
		libs__lp_rational__output_constraint_2_5_0_i2);
MR_def_label(libs__lp_rational__output_constraint_2_5_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(5,13);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__output_term_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = MR_sv(2);
	MR_r3 = (MR_Word) MR_string_const(", ", 2);
	}
	MR_np_call_localret_ent(io__write_list_5_0,
		libs__lp_rational__output_constraint_2_5_0_i6);
MR_def_label(libs__lp_rational__output_constraint_2_5_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 93;
	MR_np_call_localret_ent(io__write_char_3_0,
		libs__lp_rational__output_constraint_2_5_0_i7);
MR_def_label(libs__lp_rational__output_constraint_2_5_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		libs__lp_rational__output_constraint_2_5_0_i8);
MR_def_label(libs__lp_rational__output_constraint_2_5_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(libs__rat__write_rat_3_0,
		libs__lp_rational__output_constraint_2_5_0_i9);
MR_def_label(libs__lp_rational__output_constraint_2_5_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 41;
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(io__write_char_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module101)
	MR_init_entry1(libs__lp_rational__output_constraint_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__output_constraint_4_0);
	MR_init_label9(libs__lp_rational__output_constraint_4_0,4,5,9,10,11,12,3,15,14)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_constraint'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__output_constraint_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,1)) {
		MR_GOTO_LAB(libs__lp_rational__output_constraint_4_0_i3);
	}
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(1, MR_r2, 0);
	MR_sv(3) = MR_tfield(1, MR_r2, 1);
	MR_r1 = (MR_Word) MR_string_const("eq(", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		libs__lp_rational__output_constraint_4_0_i4);
MR_def_label(libs__lp_rational__output_constraint_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 91;
	MR_np_call_localret_ent(io__write_char_3_0,
		libs__lp_rational__output_constraint_4_0_i5);
MR_def_label(libs__lp_rational__output_constraint_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(5,14);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__output_term_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = MR_sv(2);
	MR_r3 = (MR_Word) MR_string_const(", ", 2);
	}
	MR_np_call_localret_ent(io__write_list_5_0,
		libs__lp_rational__output_constraint_4_0_i9);
MR_def_label(libs__lp_rational__output_constraint_4_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 93;
	MR_np_call_localret_ent(io__write_char_3_0,
		libs__lp_rational__output_constraint_4_0_i10);
MR_def_label(libs__lp_rational__output_constraint_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		libs__lp_rational__output_constraint_4_0_i11);
MR_def_label(libs__lp_rational__output_constraint_4_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(libs__rat__write_rat_3_0,
		libs__lp_rational__output_constraint_4_0_i12);
MR_def_label(libs__lp_rational__output_constraint_4_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 41;
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(io__write_char_3_0);
MR_def_label(libs__lp_rational__output_constraint_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,0)) {
		MR_GOTO_LAB(libs__lp_rational__output_constraint_4_0_i14);
	}
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(0, MR_r2, 0);
	MR_sv(3) = MR_tfield(0, MR_r2, 1);
	MR_r1 = (MR_Word) MR_string_const("le(", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		libs__lp_rational__output_constraint_4_0_i15);
MR_def_label(libs__lp_rational__output_constraint_4_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(3);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(libs__lp_rational__output_constraint_2_5_0);
MR_def_label(libs__lp_rational__output_constraint_4_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r2 = (MR_Word) MR_string_const("output_constraint/3: gte encountered.", 37);
	MR_np_tailcall_ent(libs__compiler_util__unexpected_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_declare_entry(mercury__do_call_closure_1);

MR_BEGIN_MODULE(libs__lp_rational_module102)
	MR_init_entry1(libs__lp_rational__output_term_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__output_term_4_0);
	MR_init_label5(libs__lp_rational__output_term_4_0,2,3,4,5,6)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_term'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__output_term_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_tfield(0, MR_r2, 1);
	MR_r2 = MR_tfield(0, MR_r2, 0);
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(libs__lp_rational__output_term_4_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_closure_1),
		mercury__libs__lp_rational__output_term_4_0_i2);
MR_def_label(libs__lp_rational__output_term_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_string_const(", ", 2);
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		libs__lp_rational__output_term_4_0_i3);
MR_def_label(libs__lp_rational__output_term_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("term(", 5);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		libs__lp_rational__output_term_4_0_i4);
MR_def_label(libs__lp_rational__output_term_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		libs__lp_rational__output_term_4_0_i5);
MR_def_label(libs__lp_rational__output_term_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(libs__rat__write_rat_3_0,
		libs__lp_rational__output_term_4_0_i6);
MR_def_label(libs__lp_rational__output_term_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 41;
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__write_char_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(__Unify___tree234__tree234_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module103)
	MR_init_entry1(__Unify___libs__lp_rational__cc_map_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__cc_map_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Unify___libs__lp_rational__cc_map_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_tempr2 = MR_r2;
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, coeff_info);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_tempr2;
	MR_np_tailcall_ent(__Unify___tree234__tree234_2_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(__Compare___tree234__tree234_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module104)
	MR_init_entry1(__Compare___libs__lp_rational__cc_map_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__cc_map_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Compare___libs__lp_rational__cc_map_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_tempr2 = MR_r2;
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, coeff_info);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_tempr2;
	MR_np_tailcall_ent(__Compare___tree234__tree234_2_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module105)
	MR_init_entry1(__Unify___libs__lp_rational__cell_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__cell_0_0);
	MR_init_label2(__Unify___libs__lp_rational__cell_0_0,4,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Unify___libs__lp_rational__cell_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__cell_0_0_i4);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_sv(1) = MR_tempr1;
	MR_tempr2 = MR_r2;
	MR_sv(2) = MR_tempr2;
	MR_r1 = MR_tfield(0, MR_tempr1, 0);
	MR_r2 = MR_tfield(0, MR_tempr2, 0);
	if ((MR_r1 != MR_r2)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__cell_0_0_i1);
	}
	MR_r1 = MR_tfield(0, MR_tempr1, 1);
	MR_r2 = MR_tfield(0, MR_tempr2, 1);
	MR_r1 = (MR_r1 == MR_r2);
	MR_decr_sp(2);
	MR_proceed();
	}
MR_def_label(__Unify___libs__lp_rational__cell_0_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp(2);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(__Unify___libs__lp_rational__cell_0_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp(2);
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(private_builtin__builtin_compare_int_3_0);

MR_BEGIN_MODULE(libs__lp_rational_module106)
	MR_init_entry1(__Compare___libs__lp_rational__cell_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__cell_0_0);
	MR_init_label4(__Compare___libs__lp_rational__cell_0_0,3,2,5,21)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Compare___libs__lp_rational__cell_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__cell_0_0_i3);
	}
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_GOTO_LAB(__Compare___libs__lp_rational__cell_0_0_i2);
MR_def_label(__Compare___libs__lp_rational__cell_0_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_def_label(__Compare___libs__lp_rational__cell_0_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6;
	MR_tempr5 = MR_sv(2);
	MR_tempr1 = MR_tfield(0, MR_tempr5, 1);
	MR_tempr6 = MR_sv(1);
	MR_tempr2 = MR_tfield(0, MR_tempr6, 1);
	MR_tempr3 = MR_tempr6;
	MR_sv(1) = MR_tempr2;
	MR_tempr4 = MR_tempr5;
	MR_sv(2) = MR_tempr1;
	MR_r1 = MR_tfield(0, MR_tempr3, 0);
	MR_r2 = MR_tfield(0, MR_tempr4, 0);
	}
	MR_np_call_localret_ent(private_builtin__builtin_compare_int_3_0,
		__Compare___libs__lp_rational__cell_0_0_i5);
MR_def_label(__Compare___libs__lp_rational__cell_0_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__cell_0_0_i21);
	}
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(private_builtin__builtin_compare_int_3_0);
MR_def_label(__Compare___libs__lp_rational__cell_0_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(3);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module107)
	MR_init_entry1(__Unify___libs__lp_rational__coeff_info_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__coeff_info_0_0);
	MR_init_label2(__Unify___libs__lp_rational__coeff_info_0_0,4,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Unify___libs__lp_rational__coeff_info_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__coeff_info_0_0_i4);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_sv(1) = MR_tempr1;
	MR_tempr2 = MR_r2;
	MR_sv(2) = MR_tempr2;
	MR_r1 = MR_tfield(0, MR_tempr1, 0);
	MR_r2 = MR_tfield(0, MR_tempr2, 0);
	if ((MR_r1 != MR_r2)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__coeff_info_0_0_i1);
	}
	MR_r1 = MR_tfield(0, MR_tempr1, 1);
	MR_r2 = MR_tfield(0, MR_tempr2, 1);
	MR_r1 = (MR_r1 == MR_r2);
	MR_decr_sp(2);
	MR_proceed();
	}
MR_def_label(__Unify___libs__lp_rational__coeff_info_0_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp(2);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(__Unify___libs__lp_rational__coeff_info_0_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp(2);
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module108)
	MR_init_entry1(__Compare___libs__lp_rational__coeff_info_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__coeff_info_0_0);
	MR_init_label4(__Compare___libs__lp_rational__coeff_info_0_0,3,2,5,21)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Compare___libs__lp_rational__coeff_info_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__coeff_info_0_0_i3);
	}
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_GOTO_LAB(__Compare___libs__lp_rational__coeff_info_0_0_i2);
MR_def_label(__Compare___libs__lp_rational__coeff_info_0_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_def_label(__Compare___libs__lp_rational__coeff_info_0_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6;
	MR_tempr5 = MR_sv(2);
	MR_tempr1 = MR_tfield(0, MR_tempr5, 1);
	MR_tempr6 = MR_sv(1);
	MR_tempr2 = MR_tfield(0, MR_tempr6, 1);
	MR_tempr3 = MR_tempr6;
	MR_sv(1) = MR_tempr2;
	MR_tempr4 = MR_tempr5;
	MR_sv(2) = MR_tempr1;
	MR_r1 = MR_tfield(0, MR_tempr3, 0);
	MR_r2 = MR_tfield(0, MR_tempr4, 0);
	}
	MR_np_call_localret_ent(private_builtin__builtin_compare_int_3_0,
		__Compare___libs__lp_rational__coeff_info_0_0_i5);
MR_def_label(__Compare___libs__lp_rational__coeff_info_0_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__coeff_info_0_0_i21);
	}
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(private_builtin__builtin_compare_int_3_0);
MR_def_label(__Compare___libs__lp_rational__coeff_info_0_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(3);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module109)
	MR_init_entry1(__Unify___libs__lp_rational__coefficient_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__coefficient_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___libs__lp_rational__coefficient_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(__Unify___libs__rat__rat_0_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(__Compare___libs__rat__rat_0_0);

MR_BEGIN_MODULE(libs__lp_rational_module110)
	MR_init_entry1(__Compare___libs__lp_rational__coefficient_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__coefficient_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___libs__lp_rational__coefficient_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(__Compare___libs__rat__rat_0_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module111)
	MR_init_entry1(__Unify___libs__lp_rational__constant_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__constant_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___libs__lp_rational__constant_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(__Unify___libs__rat__rat_0_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module112)
	MR_init_entry1(__Compare___libs__lp_rational__constant_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__constant_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___libs__lp_rational__constant_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(__Compare___libs__rat__rat_0_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module113)
	MR_init_entry1(__Unify___libs__lp_rational__constraint_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__constraint_0_0);
	MR_init_label7(__Unify___libs__lp_rational__constraint_0_0,9,5,17,37,13,24,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___libs__lp_rational__constraint_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__constraint_0_0_i37);
	}
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tempr1 = MR_r1;
	MR_sv(1) = MR_tempr1;
	MR_tempr2 = MR_r2;
	MR_sv(2) = MR_tempr2;
	if (MR_PTAG_TESTR(MR_tempr1,1)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__constraint_0_0_i5);
	}
	if (MR_PTAG_TESTR(MR_tempr2,1)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__constraint_0_0_i1);
	}
	MR_tempr3 = MR_tempr1;
	MR_sv(1) = MR_tfield(1, MR_tempr3, 1);
	MR_tempr4 = MR_tempr2;
	MR_sv(2) = MR_tfield(1, MR_tempr4, 1);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = MR_tfield(1, MR_tempr3, 0);
	MR_r3 = MR_tfield(1, MR_tempr4, 0);
	}
	MR_np_call_localret_ent(__Unify___list__list_1_0,
		__Unify___libs__lp_rational__constraint_0_0_i9);
MR_def_label(__Unify___libs__lp_rational__constraint_0_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__constraint_0_0_i1);
	}
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(__Unify___libs__rat__rat_0_0);
MR_def_label(__Unify___libs__lp_rational__constraint_0_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(1),2)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__constraint_0_0_i13);
	}
	if (MR_PTAG_TESTR(MR_sv(2),2)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__constraint_0_0_i1);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_tfield(2, MR_tempr1, 1);
	MR_tempr2 = MR_sv(2);
	MR_sv(2) = MR_tfield(2, MR_tempr2, 1);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = MR_tfield(2, MR_tempr1, 0);
	MR_r3 = MR_tfield(2, MR_tempr2, 0);
	}
	MR_np_call_localret_ent(__Unify___list__list_1_0,
		__Unify___libs__lp_rational__constraint_0_0_i17);
MR_def_label(__Unify___libs__lp_rational__constraint_0_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__constraint_0_0_i1);
	}
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(__Unify___libs__rat__rat_0_0);
MR_def_label(__Unify___libs__lp_rational__constraint_0_0,37)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(__Unify___libs__lp_rational__constraint_0_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),0)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__constraint_0_0_i1);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_tfield(0, MR_tempr1, 1);
	MR_tempr2 = MR_sv(2);
	MR_sv(2) = MR_tfield(0, MR_tempr2, 1);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = MR_tfield(0, MR_tempr1, 0);
	MR_r3 = MR_tfield(0, MR_tempr2, 0);
	}
	MR_np_call_localret_ent(__Unify___list__list_1_0,
		__Unify___libs__lp_rational__constraint_0_0_i24);
MR_def_label(__Unify___libs__lp_rational__constraint_0_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__constraint_0_0_i1);
	}
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(__Unify___libs__rat__rat_0_0);
MR_def_label(__Unify___libs__lp_rational__constraint_0_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_decr_sp_and_return(3);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(__Compare___list__list_1_0);

MR_BEGIN_MODULE(libs__lp_rational_module114)
	MR_init_entry1(__Compare___libs__lp_rational__constraint_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__constraint_0_0);
	MR_init_label10(__Compare___libs__lp_rational__constraint_0_0,3,2,11,7,5,59,19,24,17,30)
	MR_init_label3(__Compare___libs__lp_rational__constraint_0_0,31,35,119)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___libs__lp_rational__constraint_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__constraint_0_0_i3);
	}
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_GOTO_LAB(__Compare___libs__lp_rational__constraint_0_0_i2);
MR_def_label(__Compare___libs__lp_rational__constraint_0_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_def_label(__Compare___libs__lp_rational__constraint_0_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(1),1)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__constraint_0_0_i5);
	}
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__constraint_0_0_i7);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6;
	MR_tempr5 = MR_sv(1);
	MR_tempr1 = MR_tfield(1, MR_tempr5, 1);
	MR_tempr6 = MR_sv(2);
	MR_tempr2 = MR_tfield(1, MR_tempr6, 1);
	MR_tempr3 = MR_tempr5;
	MR_sv(1) = MR_tempr2;
	MR_tempr4 = MR_tempr6;
	MR_sv(2) = MR_tempr1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = MR_tfield(1, MR_tempr3, 0);
	MR_r3 = MR_tfield(1, MR_tempr4, 0);
	}
	MR_np_call_localret_ent(__Compare___list__list_1_0,
		__Compare___libs__lp_rational__constraint_0_0_i11);
MR_def_label(__Compare___libs__lp_rational__constraint_0_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__constraint_0_0_i119);
	}
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(1);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(__Compare___libs__rat__rat_0_0);
MR_def_label(__Compare___libs__lp_rational__constraint_0_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),2)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__constraint_0_0_i59);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___libs__lp_rational__constraint_0_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(1),2)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__constraint_0_0_i17);
	}
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__constraint_0_0_i19);
	}
MR_def_label(__Compare___libs__lp_rational__constraint_0_0,59)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___libs__lp_rational__constraint_0_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),2)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__constraint_0_0_i59);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6;
	MR_tempr5 = MR_sv(1);
	MR_tempr1 = MR_tfield(2, MR_tempr5, 1);
	MR_tempr6 = MR_sv(2);
	MR_tempr2 = MR_tfield(2, MR_tempr6, 1);
	MR_tempr3 = MR_tempr5;
	MR_sv(1) = MR_tempr2;
	MR_tempr4 = MR_tempr6;
	MR_sv(2) = MR_tempr1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = MR_tfield(2, MR_tempr3, 0);
	MR_r3 = MR_tfield(2, MR_tempr4, 0);
	}
	MR_np_call_localret_ent(__Compare___list__list_1_0,
		__Compare___libs__lp_rational__constraint_0_0_i24);
MR_def_label(__Compare___libs__lp_rational__constraint_0_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__constraint_0_0_i119);
	}
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(1);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(__Compare___libs__rat__rat_0_0);
MR_def_label(__Compare___libs__lp_rational__constraint_0_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__constraint_0_0_i30);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___libs__lp_rational__constraint_0_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),2)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__constraint_0_0_i31);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___libs__lp_rational__constraint_0_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6;
	MR_tempr5 = MR_sv(1);
	MR_tempr1 = MR_tfield(0, MR_tempr5, 1);
	MR_tempr6 = MR_sv(2);
	MR_tempr2 = MR_tfield(0, MR_tempr6, 1);
	MR_tempr3 = MR_tempr5;
	MR_sv(1) = MR_tempr2;
	MR_tempr4 = MR_tempr6;
	MR_sv(2) = MR_tempr1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = MR_tfield(0, MR_tempr3, 0);
	MR_r3 = MR_tfield(0, MR_tempr4, 0);
	}
	MR_np_call_localret_ent(__Compare___list__list_1_0,
		__Compare___libs__lp_rational__constraint_0_0_i35);
MR_def_label(__Compare___libs__lp_rational__constraint_0_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__constraint_0_0_i119);
	}
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(1);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(__Compare___libs__rat__rat_0_0);
MR_def_label(__Compare___libs__lp_rational__constraint_0_0,119)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(3);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module115)
	MR_init_entry1(__Unify___libs__lp_rational__constraints_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__constraints_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___libs__lp_rational__constraints_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tempr2;
	MR_np_tailcall_ent(__Unify___list__list_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module116)
	MR_init_entry1(__Compare___libs__lp_rational__constraints_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__constraints_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___libs__lp_rational__constraints_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tempr2;
	MR_np_tailcall_ent(__Compare___list__list_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module117)
	MR_init_entry1(__Unify___libs__lp_rational__direction_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__direction_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___libs__lp_rational__direction_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_r1 == MR_r2);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module118)
	MR_init_entry1(__Compare___libs__lp_rational__direction_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__direction_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___libs__lp_rational__direction_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(private_builtin__builtin_compare_int_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module119)
	MR_init_entry1(__Unify___libs__lp_rational__entailment_result_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__entailment_result_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___libs__lp_rational__entailment_result_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_r1 == MR_r2);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module120)
	MR_init_entry1(__Compare___libs__lp_rational__entailment_result_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__entailment_result_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___libs__lp_rational__entailment_result_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(private_builtin__builtin_compare_int_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(__Unify___varset__varset_1_0);

MR_BEGIN_MODULE(libs__lp_rational_module121)
	MR_init_entry1(__Unify___libs__lp_rational__lp_info_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__lp_info_0_0);
	MR_init_label4(__Unify___libs__lp_rational__lp_info_0_0,4,7,11,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Unify___libs__lp_rational__lp_info_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__lp_info_0_0_i11);
	}
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_tfield(0, MR_tempr1, 1);
	MR_tempr2 = MR_sv(2);
	MR_sv(2) = MR_tfield(0, MR_tempr1, 2);
	MR_sv(3) = MR_tfield(0, MR_tempr2, 1);
	MR_sv(4) = MR_tfield(0, MR_tempr2, 2);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = MR_tfield(0, MR_tempr1, 0);
	MR_r3 = MR_tfield(0, MR_tempr2, 0);
	}
	MR_np_call_localret_ent(__Unify___varset__varset_1_0,
		__Unify___libs__lp_rational__lp_info_0_0_i4);
MR_def_label(__Unify___libs__lp_rational__lp_info_0_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__lp_info_0_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(3);
	}
	MR_np_call_localret_ent(__Unify___list__list_1_0,
		__Unify___libs__lp_rational__lp_info_0_0_i7);
MR_def_label(__Unify___libs__lp_rational__lp_info_0_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__lp_info_0_0_i1);
	}
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(4);
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(__Unify___list__list_1_0);
MR_def_label(__Unify___libs__lp_rational__lp_info_0_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(__Unify___libs__lp_rational__lp_info_0_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_decr_sp_and_return(5);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(__Compare___varset__varset_1_0);

MR_BEGIN_MODULE(libs__lp_rational_module122)
	MR_init_entry1(__Compare___libs__lp_rational__lp_info_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__lp_info_0_0);
	MR_init_label5(__Compare___libs__lp_rational__lp_info_0_0,3,2,5,10,40)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Compare___libs__lp_rational__lp_info_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__lp_info_0_0_i3);
	}
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_GOTO_LAB(__Compare___libs__lp_rational__lp_info_0_0_i2);
MR_def_label(__Compare___libs__lp_rational__lp_info_0_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_def_label(__Compare___libs__lp_rational__lp_info_0_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6;
	MR_tempr5 = MR_sv(2);
	MR_sv(4) = MR_tfield(0, MR_tempr5, 2);
	MR_sv(3) = MR_tfield(0, MR_tempr5, 1);
	MR_tempr6 = MR_sv(1);
	MR_tempr1 = MR_tfield(0, MR_tempr6, 2);
	MR_tempr2 = MR_tfield(0, MR_tempr6, 1);
	MR_tempr3 = MR_tempr6;
	MR_sv(1) = MR_tempr2;
	MR_tempr4 = MR_tempr5;
	MR_sv(2) = MR_tempr1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = MR_tfield(0, MR_tempr3, 0);
	MR_r3 = MR_tfield(0, MR_tempr4, 0);
	}
	MR_np_call_localret_ent(__Compare___varset__varset_1_0,
		__Compare___libs__lp_rational__lp_info_0_0_i5);
MR_def_label(__Compare___libs__lp_rational__lp_info_0_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__lp_info_0_0_i40);
	}
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r2 = MR_sv(1);
	MR_r3 = MR_sv(3);
	MR_np_call_localret_ent(__Compare___list__list_1_0,
		__Compare___libs__lp_rational__lp_info_0_0_i10);
MR_def_label(__Compare___libs__lp_rational__lp_info_0_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__lp_info_0_0_i40);
	}
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(4);
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(__Compare___list__list_1_0);
MR_def_label(__Compare___libs__lp_rational__lp_info_0_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(5);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module123)
	MR_init_entry1(__Unify___libs__lp_rational__lp_operator_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__lp_operator_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___libs__lp_rational__lp_operator_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_r1 == MR_r2);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module124)
	MR_init_entry1(__Compare___libs__lp_rational__lp_operator_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__lp_operator_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___libs__lp_rational__lp_operator_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(private_builtin__builtin_compare_int_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module125)
	MR_init_entry1(__Unify___libs__lp_rational__lp_result_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__lp_result_0_0);
	MR_init_label5(__Unify___libs__lp_rational__lp_result_0_0,5,18,6,8,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___libs__lp_rational__lp_result_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__lp_result_0_0_i18);
	}
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_sv(1) = MR_tempr1;
	MR_sv(2) = MR_r2;
	if (MR_LTAGS_TESTR(MR_tempr1,0,1)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__lp_result_0_0_i5);
	}
	MR_r1 = (MR_sv(2) == MR_tempr1);
	MR_decr_sp(3);
	MR_proceed();
	}
MR_def_label(__Unify___libs__lp_rational__lp_result_0_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,0)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__lp_result_0_0_i6);
	}
	MR_r1 = (MR_sv(2) == MR_sv(1));
	MR_decr_sp_and_return(3);
MR_def_label(__Unify___libs__lp_rational__lp_result_0_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(__Unify___libs__lp_rational__lp_result_0_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__lp_result_0_0_i1);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_tfield(1, MR_tempr1, 1);
	MR_tempr2 = MR_sv(2);
	MR_sv(2) = MR_tfield(1, MR_tempr2, 1);
	MR_r1 = MR_tfield(1, MR_tempr1, 0);
	MR_r2 = MR_tfield(1, MR_tempr2, 0);
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		__Unify___libs__lp_rational__lp_result_0_0_i8);
MR_def_label(__Unify___libs__lp_rational__lp_result_0_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__lp_result_0_0_i1);
	}
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_sv(1);
	MR_r4 = MR_sv(2);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(__Unify___tree234__tree234_2_0);
MR_def_label(__Unify___libs__lp_rational__lp_result_0_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_decr_sp_and_return(3);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module126)
	MR_init_entry1(__Compare___libs__lp_rational__lp_result_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__lp_result_0_0);
	MR_init_label10(__Compare___libs__lp_rational__lp_result_0_0,7,5,39,11,40,9,14,15,17,23)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___libs__lp_rational__lp_result_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__lp_result_0_0_i40);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	if (MR_LTAGS_TESTR(MR_sv(1),0,1)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__lp_result_0_0_i5);
	}
	if (MR_LTAGS_TESTR(MR_sv(2),0,1)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__lp_result_0_0_i7);
	}
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp(3);
	MR_proceed();
MR_def_label(__Compare___libs__lp_rational__lp_result_0_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__lp_result_0_0_i39);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___libs__lp_rational__lp_result_0_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__lp_result_0_0_i9);
	}
	if (MR_LTAGS_TESTR(MR_sv(2),0,1)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__lp_result_0_0_i11);
	}
MR_def_label(__Compare___libs__lp_rational__lp_result_0_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___libs__lp_rational__lp_result_0_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__lp_result_0_0_i39);
	}
MR_def_label(__Compare___libs__lp_rational__lp_result_0_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___libs__lp_rational__lp_result_0_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,1)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__lp_result_0_0_i14);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___libs__lp_rational__lp_result_0_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__lp_result_0_0_i15);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___libs__lp_rational__lp_result_0_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6;
	MR_tempr5 = MR_sv(1);
	MR_tempr1 = MR_tfield(1, MR_tempr5, 1);
	MR_tempr6 = MR_sv(2);
	MR_tempr2 = MR_tfield(1, MR_tempr6, 1);
	MR_tempr3 = MR_tempr5;
	MR_sv(1) = MR_tempr2;
	MR_tempr4 = MR_tempr6;
	MR_sv(2) = MR_tempr1;
	MR_r1 = MR_tfield(1, MR_tempr3, 0);
	MR_r2 = MR_tfield(1, MR_tempr4, 0);
	}
	MR_np_call_localret_ent(__Compare___libs__rat__rat_0_0,
		__Compare___libs__lp_rational__lp_result_0_0_i17);
MR_def_label(__Compare___libs__lp_rational__lp_result_0_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__lp_result_0_0_i23);
	}
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_sv(2);
	MR_r4 = MR_sv(1);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(__Compare___tree234__tree234_2_0);
MR_def_label(__Compare___libs__lp_rational__lp_result_0_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(3);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(__Unify___pair__pair_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module127)
	MR_init_entry1(__Unify___libs__lp_rational__lp_term_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__lp_term_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___libs__lp_rational__lp_term_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_tempr2 = MR_r2;
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_tempr2;
	MR_np_tailcall_ent(__Unify___pair__pair_2_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(__Compare___pair__pair_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module128)
	MR_init_entry1(__Compare___libs__lp_rational__lp_term_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__lp_term_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___libs__lp_rational__lp_term_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_tempr2 = MR_r2;
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_tempr2;
	MR_np_tailcall_ent(__Compare___pair__pair_2_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module129)
	MR_init_entry1(__Unify___libs__lp_rational__lp_terms_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__lp_terms_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___libs__lp_rational__lp_terms_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tempr2;
	MR_np_tailcall_ent(__Unify___list__list_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module130)
	MR_init_entry1(__Compare___libs__lp_rational__lp_terms_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__lp_terms_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___libs__lp_rational__lp_terms_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tempr2;
	MR_np_tailcall_ent(__Compare___list__list_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module131)
	MR_init_entry1(__Unify___libs__lp_rational__lp_var_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__lp_var_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___libs__lp_rational__lp_var_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tempr2;
	MR_np_tailcall_ent(__Unify___term__var_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(__Compare___term__var_1_0);

MR_BEGIN_MODULE(libs__lp_rational_module132)
	MR_init_entry1(__Compare___libs__lp_rational__lp_var_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__lp_var_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___libs__lp_rational__lp_var_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tempr2;
	MR_np_tailcall_ent(__Compare___term__var_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module133)
	MR_init_entry1(__Unify___libs__lp_rational__lp_vars_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__lp_vars_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___libs__lp_rational__lp_vars_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tempr2;
	MR_np_tailcall_ent(__Unify___list__list_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module134)
	MR_init_entry1(__Compare___libs__lp_rational__lp_vars_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__lp_vars_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___libs__lp_rational__lp_vars_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tempr2;
	MR_np_tailcall_ent(__Compare___list__list_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module135)
	MR_init_entry1(__Unify___libs__lp_rational__lp_varset_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__lp_varset_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___libs__lp_rational__lp_varset_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tempr2;
	MR_np_tailcall_ent(__Unify___varset__varset_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module136)
	MR_init_entry1(__Compare___libs__lp_rational__lp_varset_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__lp_varset_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___libs__lp_rational__lp_varset_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tempr2;
	MR_np_tailcall_ent(__Compare___varset__varset_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module137)
	MR_init_entry1(__Unify___libs__lp_rational__matrix_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__matrix_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Unify___libs__lp_rational__matrix_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, vector);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tempr2;
	MR_np_tailcall_ent(__Unify___list__list_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module138)
	MR_init_entry1(__Compare___libs__lp_rational__matrix_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__matrix_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Compare___libs__lp_rational__matrix_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, vector);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tempr2;
	MR_np_tailcall_ent(__Compare___list__list_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module139)
	MR_init_entry1(__Unify___libs__lp_rational__objective_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__objective_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___libs__lp_rational__objective_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tempr2;
	MR_np_tailcall_ent(__Unify___list__list_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module140)
	MR_init_entry1(__Compare___libs__lp_rational__objective_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__objective_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___libs__lp_rational__objective_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tempr2;
	MR_np_tailcall_ent(__Compare___list__list_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(private_builtin__builtin_unify_pred_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module141)
	MR_init_entry1(__Unify___libs__lp_rational__output_var_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__output_var_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___libs__lp_rational__output_var_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(private_builtin__builtin_unify_pred_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(private_builtin__builtin_compare_pred_3_0);

MR_BEGIN_MODULE(libs__lp_rational_module142)
	MR_init_entry1(__Compare___libs__lp_rational__output_var_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__output_var_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___libs__lp_rational__output_var_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(private_builtin__builtin_compare_pred_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module143)
	MR_init_entry1(__Unify___libs__lp_rational__projection_result_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__projection_result_0_0);
	MR_init_label4(__Unify___libs__lp_rational__projection_result_0_0,5,15,6,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___libs__lp_rational__projection_result_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__projection_result_0_0_i15);
	}
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_sv(1) = MR_tempr1;
	MR_sv(2) = MR_r2;
	if (MR_LTAGS_TESTR(MR_tempr1,0,1)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__projection_result_0_0_i5);
	}
	MR_r1 = (MR_sv(2) == MR_tempr1);
	MR_decr_sp(3);
	MR_proceed();
	}
MR_def_label(__Unify___libs__lp_rational__projection_result_0_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,0)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__projection_result_0_0_i6);
	}
	MR_r1 = (MR_sv(2) == MR_sv(1));
	MR_decr_sp_and_return(3);
MR_def_label(__Unify___libs__lp_rational__projection_result_0_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(__Unify___libs__lp_rational__projection_result_0_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__projection_result_0_0_i1);
	}
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_r2 = MR_tfield(1, MR_sv(1), 0);
	MR_r3 = MR_tfield(1, MR_sv(2), 0);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(__Unify___list__list_1_0);
MR_def_label(__Unify___libs__lp_rational__projection_result_0_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_decr_sp_and_return(3);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module144)
	MR_init_entry1(__Compare___libs__lp_rational__projection_result_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__projection_result_0_0);
	MR_init_label7(__Compare___libs__lp_rational__projection_result_0_0,30,5,11,33,9,14,15)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___libs__lp_rational__projection_result_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__projection_result_0_0_i33);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	if (MR_LTAGS_TESTR(MR_sv(1),0,1)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__projection_result_0_0_i5);
	}
	if (MR_LTAGS_TESTR(MR_sv(2),0,1)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__projection_result_0_0_i30);
	}
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp(3);
	MR_proceed();
MR_def_label(__Compare___libs__lp_rational__projection_result_0_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___libs__lp_rational__projection_result_0_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__projection_result_0_0_i9);
	}
	if (MR_LTAGS_TESTR(MR_sv(2),0,1)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__projection_result_0_0_i11);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___libs__lp_rational__projection_result_0_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__projection_result_0_0_i30);
	}
MR_def_label(__Compare___libs__lp_rational__projection_result_0_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___libs__lp_rational__projection_result_0_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,1)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__projection_result_0_0_i14);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___libs__lp_rational__projection_result_0_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__projection_result_0_0_i15);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___libs__lp_rational__projection_result_0_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_r2 = MR_tfield(1, MR_sv(1), 0);
	MR_r3 = MR_tfield(1, MR_sv(2), 0);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(__Compare___list__list_1_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module145)
	MR_init_entry1(__Unify___libs__lp_rational__tableau_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__tableau_0_0);
	MR_init_label5(__Unify___libs__lp_rational__tableau_0_0,5,7,9,14,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Unify___libs__lp_rational__tableau_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__tableau_0_0_i14);
	}
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tempr1 = MR_r1;
	MR_sv(1) = MR_tempr1;
	MR_tempr2 = MR_r2;
	MR_sv(2) = MR_tempr2;
	MR_tempr3 = MR_tfield(0, MR_tempr1, 0);
	MR_tempr4 = MR_tfield(0, MR_tempr2, 0);
	if ((MR_tempr3 != MR_tempr4)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__tableau_0_0_i1);
	}
	MR_tempr3 = MR_tfield(0, MR_tempr1, 1);
	MR_tempr4 = MR_tfield(0, MR_tempr2, 1);
	if ((MR_tempr3 != MR_tempr4)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__tableau_0_0_i1);
	}
	MR_tempr3 = MR_tempr1;
	MR_sv(1) = MR_tfield(0, MR_tempr3, 3);
	MR_tempr4 = MR_tempr2;
	MR_sv(2) = MR_tfield(0, MR_tempr3, 4);
	MR_sv(3) = MR_tfield(0, MR_tempr3, 5);
	MR_sv(4) = MR_tfield(0, MR_tempr4, 3);
	MR_sv(5) = MR_tfield(0, MR_tempr4, 4);
	MR_sv(6) = MR_tfield(0, MR_tempr4, 5);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r2 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r3 = MR_tfield(0, MR_tempr3, 2);
	MR_r4 = MR_tfield(0, MR_tempr4, 2);
	}
	MR_np_call_localret_ent(__Unify___tree234__tree234_2_0,
		__Unify___libs__lp_rational__tableau_0_0_i5);
MR_def_label(__Unify___libs__lp_rational__tableau_0_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__tableau_0_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(4);
	}
	MR_np_call_localret_ent(__Unify___list__list_1_0,
		__Unify___libs__lp_rational__tableau_0_0_i7);
MR_def_label(__Unify___libs__lp_rational__tableau_0_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__tableau_0_0_i1);
	}
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(5);
	MR_np_call_localret_ent(__Unify___list__list_1_0,
		__Unify___libs__lp_rational__tableau_0_0_i9);
MR_def_label(__Unify___libs__lp_rational__tableau_0_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__tableau_0_0_i1);
	}
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,4);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_sv(3);
	MR_r4 = MR_sv(6);
	MR_succip_word = MR_sv(7);
	MR_decr_sp(7);
	MR_np_tailcall_ent(__Unify___tree234__tree234_2_0);
MR_def_label(__Unify___libs__lp_rational__tableau_0_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(__Unify___libs__lp_rational__tableau_0_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_decr_sp_and_return(7);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module146)
	MR_init_entry1(__Compare___libs__lp_rational__tableau_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__tableau_0_0);
	MR_init_label8(__Compare___libs__lp_rational__tableau_0_0,3,2,5,9,14,18,22,73)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Compare___libs__lp_rational__tableau_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__tableau_0_0_i3);
	}
	MR_incr_sp(11);
	MR_sv(11) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_GOTO_LAB(__Compare___libs__lp_rational__tableau_0_0_i2);
MR_def_label(__Compare___libs__lp_rational__tableau_0_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_def_label(__Compare___libs__lp_rational__tableau_0_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6;
	MR_tempr5 = MR_sv(2);
	MR_sv(10) = MR_tfield(0, MR_tempr5, 5);
	MR_sv(9) = MR_tfield(0, MR_tempr5, 4);
	MR_sv(8) = MR_tfield(0, MR_tempr5, 3);
	MR_sv(7) = MR_tfield(0, MR_tempr5, 2);
	MR_sv(6) = MR_tfield(0, MR_tempr5, 1);
	MR_tempr6 = MR_sv(1);
	MR_sv(5) = MR_tfield(0, MR_tempr6, 5);
	MR_sv(4) = MR_tfield(0, MR_tempr6, 4);
	MR_sv(3) = MR_tfield(0, MR_tempr6, 3);
	MR_tempr1 = MR_tfield(0, MR_tempr6, 2);
	MR_tempr2 = MR_tfield(0, MR_tempr6, 1);
	MR_tempr3 = MR_tempr6;
	MR_sv(1) = MR_tempr2;
	MR_tempr4 = MR_tempr5;
	MR_sv(2) = MR_tempr1;
	MR_r1 = MR_tfield(0, MR_tempr3, 0);
	MR_r2 = MR_tfield(0, MR_tempr4, 0);
	}
	MR_np_call_localret_ent(private_builtin__builtin_compare_int_3_0,
		__Compare___libs__lp_rational__tableau_0_0_i5);
MR_def_label(__Compare___libs__lp_rational__tableau_0_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__tableau_0_0_i73);
	}
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(6);
	MR_np_call_localret_ent(private_builtin__builtin_compare_int_3_0,
		__Compare___libs__lp_rational__tableau_0_0_i9);
MR_def_label(__Compare___libs__lp_rational__tableau_0_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__tableau_0_0_i73);
	}
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r2 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r3 = MR_sv(2);
	MR_r4 = MR_sv(7);
	MR_np_call_localret_ent(__Compare___tree234__tree234_2_0,
		__Compare___libs__lp_rational__tableau_0_0_i14);
MR_def_label(__Compare___libs__lp_rational__tableau_0_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__tableau_0_0_i73);
	}
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_sv(3);
	MR_r3 = MR_sv(8);
	MR_np_call_localret_ent(__Compare___list__list_1_0,
		__Compare___libs__lp_rational__tableau_0_0_i18);
MR_def_label(__Compare___libs__lp_rational__tableau_0_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__tableau_0_0_i73);
	}
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_sv(4);
	MR_r3 = MR_sv(9);
	MR_np_call_localret_ent(__Compare___list__list_1_0,
		__Compare___libs__lp_rational__tableau_0_0_i22);
MR_def_label(__Compare___libs__lp_rational__tableau_0_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__tableau_0_0_i73);
	}
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,4);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(10);
	MR_succip_word = MR_sv(11);
	MR_decr_sp(11);
	MR_np_tailcall_ent(__Compare___tree234__tree234_2_0);
MR_def_label(__Compare___libs__lp_rational__tableau_0_0,73)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(11);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module147)
	MR_init_entry1(__Unify___libs__lp_rational__var_num_map_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__var_num_map_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Unify___libs__lp_rational__var_num_map_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_tempr2 = MR_r2;
	MR_r2 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r3 = MR_tempr1;
	MR_r4 = MR_tempr2;
	MR_np_tailcall_ent(__Unify___tree234__tree234_2_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module148)
	MR_init_entry1(__Compare___libs__lp_rational__var_num_map_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__var_num_map_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Compare___libs__lp_rational__var_num_map_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_tempr2 = MR_r2;
	MR_r2 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r3 = MR_tempr1;
	MR_r4 = MR_tempr2;
	MR_np_tailcall_ent(__Compare___tree234__tree234_2_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(__Unify___set_ordlist__set_ordlist_1_0);

MR_BEGIN_MODULE(libs__lp_rational_module149)
	MR_init_entry1(__Unify___libs__lp_rational__vector_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___libs__lp_rational__vector_0_0);
	MR_init_label4(__Unify___libs__lp_rational__vector_0_0,4,7,11,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Unify___libs__lp_rational__vector_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__vector_0_0_i11);
	}
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_tfield(0, MR_tempr1, 1);
	MR_tempr2 = MR_sv(2);
	MR_sv(2) = MR_tfield(0, MR_tempr1, 2);
	MR_sv(3) = MR_tfield(0, MR_tempr2, 1);
	MR_sv(4) = MR_tfield(0, MR_tempr2, 2);
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_tfield(0, MR_tempr1, 0);
	MR_r3 = MR_tfield(0, MR_tempr2, 0);
	}
	MR_np_call_localret_ent(__Unify___set_ordlist__set_ordlist_1_0,
		__Unify___libs__lp_rational__vector_0_0_i4);
MR_def_label(__Unify___libs__lp_rational__vector_0_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__vector_0_0_i1);
	}
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_sv(1);
	MR_r4 = MR_sv(3);
	MR_np_call_localret_ent(__Unify___tree234__tree234_2_0,
		__Unify___libs__lp_rational__vector_0_0_i7);
MR_def_label(__Unify___libs__lp_rational__vector_0_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(__Unify___libs__lp_rational__vector_0_0_i1);
	}
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(4);
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(__Unify___libs__rat__rat_0_0);
MR_def_label(__Unify___libs__lp_rational__vector_0_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(__Unify___libs__lp_rational__vector_0_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_decr_sp_and_return(5);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(__Compare___set_ordlist__set_ordlist_1_0);

MR_BEGIN_MODULE(libs__lp_rational_module150)
	MR_init_entry1(__Compare___libs__lp_rational__vector_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___libs__lp_rational__vector_0_0);
	MR_init_label5(__Compare___libs__lp_rational__vector_0_0,3,2,5,10,39)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Compare___libs__lp_rational__vector_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__vector_0_0_i3);
	}
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_GOTO_LAB(__Compare___libs__lp_rational__vector_0_0_i2);
MR_def_label(__Compare___libs__lp_rational__vector_0_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_def_label(__Compare___libs__lp_rational__vector_0_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6;
	MR_tempr5 = MR_sv(2);
	MR_sv(4) = MR_tfield(0, MR_tempr5, 2);
	MR_sv(3) = MR_tfield(0, MR_tempr5, 1);
	MR_tempr6 = MR_sv(1);
	MR_tempr1 = MR_tfield(0, MR_tempr6, 2);
	MR_tempr2 = MR_tfield(0, MR_tempr6, 1);
	MR_tempr3 = MR_tempr6;
	MR_sv(1) = MR_tempr2;
	MR_tempr4 = MR_tempr5;
	MR_sv(2) = MR_tempr1;
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_tfield(0, MR_tempr3, 0);
	MR_r3 = MR_tfield(0, MR_tempr4, 0);
	}
	MR_np_call_localret_ent(__Compare___set_ordlist__set_ordlist_1_0,
		__Compare___libs__lp_rational__vector_0_0_i5);
MR_def_label(__Compare___libs__lp_rational__vector_0_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__vector_0_0_i39);
	}
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_sv(1);
	MR_r4 = MR_sv(3);
	MR_np_call_localret_ent(__Compare___tree234__tree234_2_0,
		__Compare___libs__lp_rational__vector_0_0_i10);
MR_def_label(__Compare___libs__lp_rational__vector_0_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___libs__lp_rational__vector_0_0_i39);
	}
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(4);
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(__Compare___libs__rat__rat_0_0);
MR_def_label(__Compare___libs__lp_rational__vector_0_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(5);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module151)
	MR_init_entry1(fn__libs__lp_rational__IntroducedFrom__func__bounding_box__726__1_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__IntroducedFrom__func__bounding_box__726__1_3_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__func__bounding_box__726__1'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__IntroducedFrom__func__bounding_box__726__1_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_np_tailcall_ent(fn__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_73_110_116_114_111_100_117_99_101_100_70_114_111_109_95_95_102_117_110_99_95_95_98_111_117_110_100_105_110_103_95_98_111_120_95_95_55_50_54_95_95_49_95_95_91_49_93_95_48_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(f_108_105_115_116_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_95_109_101_109_98_101_114_95_95_91_84_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module152)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__nonneg_box__749__1_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__nonneg_box__749__1_4_0);
	MR_init_label3(libs__lp_rational__IntroducedFrom__pred__nonneg_box__749__1_4_0,4,2,6)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__nonneg_box__749__1'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__nonneg_box__749__1_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r3;
	MR_sv(2) = MR_r2;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r3 = MR_sv(2);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_115_116_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_95_109_101_109_98_101_114_95_95_91_84_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_2_0,
		libs__lp_rational__IntroducedFrom__pred__nonneg_box__749__1_4_0_i4);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__nonneg_box__749__1_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__IntroducedFrom__pred__nonneg_box__749__1_4_0_i2);
	}
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(3);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__nonneg_box__749__1_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(fn__libs__lp_rational__make_nonneg_constr_1_0,
		libs__lp_rational__IntroducedFrom__pred__nonneg_box__749__1_4_0_i6);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__nonneg_box__749__1_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(1);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(list__cons_3_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module153)
	MR_init_entry1(fn__libs__lp_rational__IntroducedFrom__func__normalize_terms_and_const__562__1_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__IntroducedFrom__func__normalize_terms_and_const__562__1_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__func__normalize_terms_and_const__562__1'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__IntroducedFrom__func__normalize_terms_and_const__562__1_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tfield(0, MR_tempr1, 0);
	MR_r3 = MR_tfield(0, MR_tempr2, 0);
	MR_np_tailcall_ent(__Compare___term__var_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module154)
	MR_init_entry1(fn__libs__lp_rational__IntroducedFrom__func__normalize_terms_and_const__580__1_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__IntroducedFrom__func__normalize_terms_and_const__580__1_2_0);
	MR_init_label1(fn__libs__lp_rational__IntroducedFrom__func__normalize_terms_and_const__580__1_2_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__func__normalize_terms_and_const__580__1'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__IntroducedFrom__func__normalize_terms_and_const__580__1_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_tfield(0, MR_r2, 0);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_tfield(0, MR_r2, 1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_47_2_0,
		fn__libs__lp_rational__IntroducedFrom__func__normalize_terms_and_const__580__1_2_0_i2);
MR_def_label(fn__libs__lp_rational__IntroducedFrom__func__normalize_terms_and_const__580__1_2_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(1);
	MR_tfield(0, MR_r2, 1) = MR_r1;
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(2);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(f_115_101_116_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_95_109_101_109_98_101_114_95_95_91_84_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module155)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__set_terms_to_zero__713__1_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__set_terms_to_zero__713__1_2_0);
	MR_init_label2(libs__lp_rational__IntroducedFrom__pred__set_terms_to_zero__713__1_2_0,4,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__set_terms_to_zero__713__1'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__set_terms_to_zero__713__1_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(1);
	MR_sv(1) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_tempr2 = MR_r2;
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r3 = MR_tfield(0, MR_tempr2, 0);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_115_101_116_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_95_109_101_109_98_101_114_95_95_91_84_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_2_0,
		libs__lp_rational__IntroducedFrom__pred__set_terms_to_zero__713__1_2_0_i4);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__set_terms_to_zero__713__1_2_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO_LAB(libs__lp_rational__IntroducedFrom__pred__set_terms_to_zero__713__1_2_0_i1);
	}
	MR_succip_word = MR_sv(1);
	MR_decr_sp(1);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(libs__lp_rational__IntroducedFrom__pred__set_terms_to_zero__713__1_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(1);
	MR_decr_sp(1);
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module156)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__collect_vars__945__1_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__collect_vars__945__1_3_0);
	MR_init_label5(libs__lp_rational__IntroducedFrom__pred__collect_vars__945__1_3_0,3,13,2,17,18)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__collect_vars__945__1'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__collect_vars__945__1_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_mkframe("pred libs.lp_rational.IntroducedFrom__pred__collect_vars__945__1/3-0", 2,
		MR_LABEL_AP(libs__lp_rational__IntroducedFrom__pred__collect_vars__945__1_3_0_i2));
	MR_fv(1) = MR_r2;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__member_2_1,
		libs__lp_rational__IntroducedFrom__pred__collect_vars__945__1_3_0_i3);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__collect_vars__945__1_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_mask_field(MR_r1, 0);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_np_call_localret_ent(list__member_2_1,
		libs__lp_rational__IntroducedFrom__pred__collect_vars__945__1_3_0_i13);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__collect_vars__945__1_3_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_np_call_localret_ent(fn__pair__fst_1_0,
		libs__lp_rational__IntroducedFrom__pred__collect_vars__945__1_3_0_i18);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__collect_vars__945__1_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_redoip_slot_word(MR_curfr) = (MR_Word) MR_ENTRY(MR_do_fail);
	MR_fv(2) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r2 = MR_fv(1);
	MR_np_call_localret_ent(list__member_2_1,
		libs__lp_rational__IntroducedFrom__pred__collect_vars__945__1_3_0_i17);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__collect_vars__945__1_3_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_r1;
	MR_r1 = MR_fv(2);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_np_call_localret_ent(fn__pair__fst_1_0,
		libs__lp_rational__IntroducedFrom__pred__collect_vars__945__1_3_0_i18);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__collect_vars__945__1_3_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succeed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module157)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__extract_obj_var2__1024__1_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__extract_obj_var2__1024__1_3_0);
	MR_init_label6(libs__lp_rational__IntroducedFrom__pred__extract_obj_var2__1024__1_3_0,1,3,5,6,7,9)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__extract_obj_var2__1024__1'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__extract_obj_var2__1024__1_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_mkframe("pred libs.lp_rational.IntroducedFrom__pred__extract_obj_var2__1024__1/3-0", 4,
		MR_ENTRY(MR_do_fail));
	MR_fv(1) = MR_r1;
	MR_fv(2) = MR_r2;
	MR_r1 = (MR_Integer) 1;
	MR_r2 = MR_tfield(0, MR_fv(1), 0);
	MR_np_call_localret_ent(libs__lp_rational__between_3_0,
		libs__lp_rational__IntroducedFrom__pred__extract_obj_var2__1024__1_3_0_i1);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__extract_obj_var2__1024__1_3_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_fv(3) = MR_r1;
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_fv(3);
	MR_r3 = MR_tfield(0, MR_fv(1), 3);
	MR_np_call_localret_ent(list__member_2_0,
		libs__lp_rational__IntroducedFrom__pred__extract_obj_var2__1024__1_3_0_i3);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__extract_obj_var2__1024__1_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		libs__lp_rational__IntroducedFrom__pred__extract_obj_var2__1024__1_3_0_i5);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__extract_obj_var2__1024__1_3_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_fv(4) = MR_r1;
	MR_r1 = MR_fv(3);
	MR_r2 = MR_fv(2);
	MR_r3 = MR_fv(1);
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		libs__lp_rational__IntroducedFrom__pred__extract_obj_var2__1024__1_3_0_i6);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__extract_obj_var2__1024__1_3_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_fv(4);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__IntroducedFrom__pred__extract_obj_var2__1024__1_3_0_i7);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__extract_obj_var2__1024__1_3_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_r1 = MR_fv(3);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_fv(1);
	MR_r2 = MR_tfield(0, MR_tempr1, 1);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		libs__lp_rational__IntroducedFrom__pred__extract_obj_var2__1024__1_3_0_i9);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__extract_obj_var2__1024__1_3_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succeed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module158)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0);
	MR_init_label8(libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0,4,6,7,5,3,12,15,14)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__simplex__1041__1'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	if (MR_LTAGS_TESTR(MR_r3,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0_i3);
	}
	MR_sv(3) = MR_r2;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Integer) 0;
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0_i4);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0_i6);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_60_2_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0_i7);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0_i5);
	}
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(3);
	MR_tfield(0, MR_r2, 1) = MR_sv(1);
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 1);
	MR_tfield(1, MR_r1, 0) = MR_r2;
	MR_decr_sp_and_return(4);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_decr_sp_and_return(4);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_r3;
	MR_sv(1) = MR_tfield(0, MR_tfield(1, MR_tempr2, 0), 1);
	MR_sv(2) = MR_tempr2;
	MR_sv(3) = MR_r2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Integer) 0;
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0_i12);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_60_2_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0_i15);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0_i14);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(3);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(1);
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 1);
	MR_tfield(1, MR_r1, 0) = MR_tempr1;
	MR_decr_sp_and_return(4);
	}
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1041__1_4_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_decr_sp_and_return(4);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module159)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0);
	MR_init_label10(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,4,6,7,9,11,12,14,10,16,17)
	MR_init_label10(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,5,3,21,22,23,25,26,53,24,29)
	MR_init_label6(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,30,32,28,34,35,38)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__simplex__1072__1'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	if (MR_LTAGS_TESTR(MR_r4,0,0)) {
		MR_GOTO_LAB(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i3);
	}
	MR_sv(2) = MR_r2;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_r3;
	MR_sv(4) = MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_tempr2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(2);
	}
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i4);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i6);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_62_2_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i7);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i5);
	}
	MR_r1 = MR_sv(4);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(2);
	MR_r2 = MR_tfield(0, MR_tempr1, 1);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i9);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i11);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i12);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i10);
	}
	MR_np_call_localret_ent(fn__libs__lp_rational__this_file_0_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i14);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_string_const("simplex/3: zero divisor.", 24);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i16);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_r1 = MR_sv(2);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_47_2_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i17);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(4);
	MR_tfield(0, MR_r2, 1) = MR_r1;
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 1);
	MR_tfield(1, MR_r1, 0) = MR_r2;
	MR_decr_sp_and_return(6);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_decr_sp_and_return(6);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr2 = MR_r4;
	MR_sv(1) = MR_tfield(0, MR_tfield(1, MR_tempr2, 0), 1);
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_tempr2;
	MR_tempr3 = MR_r3;
	MR_sv(4) = MR_tempr3;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_tempr3;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(2);
	}
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i21);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(5) = MR_r1;
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(fn__libs__lp_rational__rhs_col_1_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i22);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(2);
	}
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i23);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i25);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_61_60_2_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i26);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i24);
	}
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,53)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(6);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i29);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i30);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i28);
	}
	MR_np_call_localret_ent(fn__libs__lp_rational__this_file_0_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i32);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_string_const("simplex/3: zero divisor.", 24);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i34);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(5);
	MR_r1 = MR_sv(2);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_47_2_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i35);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_114_97_116_95_95_61_60_2_0,
		libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i38);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0,38)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__IntroducedFrom__pred__simplex__1072__1_5_0_i53);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(4);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(1);
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 1);
	MR_tfield(1, MR_r1, 0) = MR_tempr1;
	MR_decr_sp_and_return(6);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module160)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__ensure_zero_obj_coeffs__1115__1_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__ensure_zero_obj_coeffs__1115__1_3_0);
	MR_init_label5(libs__lp_rational__IntroducedFrom__pred__ensure_zero_obj_coeffs__1115__1_3_0,1,3,5,7,8)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__ensure_zero_obj_coeffs__1115__1'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__ensure_zero_obj_coeffs__1115__1_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_mkframe("pred libs.lp_rational.IntroducedFrom__pred__ensure_zero_obj_coeffs__1115__1/3-0", 4,
		MR_ENTRY(MR_do_fail));
	MR_fv(1) = MR_r1;
	MR_fv(2) = MR_r2;
	MR_r1 = (MR_Integer) 1;
	MR_r2 = MR_tfield(0, MR_fv(1), 0);
	MR_np_call_localret_ent(libs__lp_rational__between_3_0,
		libs__lp_rational__IntroducedFrom__pred__ensure_zero_obj_coeffs__1115__1_3_0_i1);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__ensure_zero_obj_coeffs__1115__1_3_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_fv(3) = MR_r1;
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_fv(3);
	MR_r3 = MR_tfield(0, MR_fv(1), 3);
	MR_np_call_localret_ent(list__member_2_0,
		libs__lp_rational__IntroducedFrom__pred__ensure_zero_obj_coeffs__1115__1_3_0_i3);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__ensure_zero_obj_coeffs__1115__1_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_r1 = MR_fv(3);
	MR_r2 = MR_fv(2);
	MR_r3 = MR_fv(1);
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		libs__lp_rational__IntroducedFrom__pred__ensure_zero_obj_coeffs__1115__1_3_0_i5);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__ensure_zero_obj_coeffs__1115__1_3_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_fv(4) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__IntroducedFrom__pred__ensure_zero_obj_coeffs__1115__1_3_0_i7);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__ensure_zero_obj_coeffs__1115__1_3_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_fv(4);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__IntroducedFrom__pred__ensure_zero_obj_coeffs__1115__1_3_0_i8);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__ensure_zero_obj_coeffs__1115__1_3_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_tag_alloc_heap(MR_r1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r1, 0) = MR_fv(3);
	MR_tfield(0, MR_r1, 1) = MR_fv(4);
	MR_succeed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module161)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1144__1_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1144__1_5_0);
	MR_init_label4(libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1144__1_5_0,2,4,5,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__fix_basis_and_rem_cols__1144__1'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1144__1_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(2) = MR_r4;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_r3;
	MR_sv(3) = MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_tempr2;
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1144__1_5_0_i2);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1144__1_5_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1144__1_5_0_i4);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1144__1_5_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1144__1_5_0_i5);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1144__1_5_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1144__1_5_0_i3);
	}
	MR_r1 = MR_sv(2);
	MR_decr_sp_and_return(4);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1144__1_5_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(1);
	MR_tfield(0, MR_r2, 1) = MR_sv(3);
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r1, 0) = MR_r2;
	MR_tfield(1, MR_r1, 1) = MR_sv(2);
	MR_decr_sp_and_return(4);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module162)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1152__1_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1152__1_4_0);
	MR_init_label4(libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1152__1_4_0,1,3,5,6)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__fix_basis_and_rem_cols__1152__1'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1152__1_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_mkframe("pred libs.lp_rational.IntroducedFrom__pred__fix_basis_and_rem_cols__1152__1/4-0", 5,
		MR_ENTRY(MR_do_fail));
	MR_fv(1) = MR_r1;
	MR_fv(2) = MR_r2;
	MR_fv(3) = MR_r3;
	MR_np_call_localret_ent(libs__lp_rational__all_cols_2_0,
		libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1152__1_4_0_i1);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1152__1_4_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_fv(2) == MR_r1)) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_fv(5) = MR_r1;
	MR_r1 = MR_fv(3);
	MR_r2 = MR_fv(5);
	MR_r3 = MR_fv(1);
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1152__1_4_0_i3);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1152__1_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_fv(4) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1152__1_4_0_i5);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1152__1_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_fv(4);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1152__1_4_0_i6);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__fix_basis_and_rem_cols__1152__1_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_r1 = MR_fv(5);
	MR_succeed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module163)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__pivot__1182__1_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__pivot__1182__1_4_0);
	MR_init_label2(libs__lp_rational__IntroducedFrom__pred__pivot__1182__1_4_0,1,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__pivot__1182__1'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__pivot__1182__1_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_mkframe("pred libs.lp_rational.IntroducedFrom__pred__pivot__1182__1/4-0", 4,
		MR_ENTRY(MR_do_fail));
	MR_fv(1) = MR_r1;
	MR_fv(2) = MR_r2;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_fv(4) = MR_tempr1;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(libs__lp_rational__all_rows0_2_0,
		libs__lp_rational__IntroducedFrom__pred__pivot__1182__1_4_0_i1);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__pivot__1182__1_4_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r1 == MR_fv(1))) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_fv(3) = MR_r1;
	MR_r1 = MR_fv(4);
	MR_np_call_localret_ent(libs__lp_rational__all_cols0_2_0,
		libs__lp_rational__IntroducedFrom__pred__pivot__1182__1_4_0_i3);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__pivot__1182__1_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r1 == MR_fv(2))) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_fv(3);
	MR_tfield(0, MR_r2, 1) = MR_r1;
	MR_r1 = MR_r2;
	MR_succeed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_2_0);

MR_BEGIN_MODULE(libs__lp_rational_module164)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0);
	MR_init_label10(libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0,2,3,4,6,7,5,10,11,12,13)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__pivot__1189__1'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(8);
	MR_sv(8) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r5;
	MR_sv(5) = MR_tempr1;
	MR_tempr2 = MR_r4;
	MR_sv(6) = MR_tfield(0, MR_tempr2, 0);
	MR_sv(7) = MR_tfield(0, MR_tempr2, 1);
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(7);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0_i2);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(2);
	MR_sv(2) = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(5);
	}
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0_i3);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_sv(7);
	MR_r3 = MR_sv(5);
	}
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0_i4);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0_i6);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0_i7);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0_i5);
	}
	MR_r1 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r2 = (MR_Word) MR_string_const("pivot/4 - ScaleCell: zero divisor.", 34);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0_i10);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_r1 = MR_sv(4);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_42_2_0,
		libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0_i11);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_47_2_0,
		libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0_i12);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_2_0,
		libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0_i13);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__pivot__1189__1_6_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(7);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(5);
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_np_tailcall_ent(libs__lp_rational__set_cell_5_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module165)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__pivot__1201__1_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__pivot__1201__1_3_0);
	MR_init_label1(libs__lp_rational__IntroducedFrom__pred__pivot__1201__1_3_0,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__pivot__1201__1'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__pivot__1201__1_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_mkframe("pred libs.lp_rational.IntroducedFrom__pred__pivot__1201__1/3-0", 1,
		MR_ENTRY(MR_do_fail));
	MR_fv(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(libs__lp_rational__all_rows0_2_0,
		libs__lp_rational__IntroducedFrom__pred__pivot__1201__1_3_0_i1);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__pivot__1201__1_3_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_r1;
	MR_tfield(0, MR_r2, 1) = MR_fv(1);
	MR_r1 = MR_r2;
	MR_succeed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module166)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__pivot__1205__1_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__pivot__1205__1_3_0);
	MR_init_label1(libs__lp_rational__IntroducedFrom__pred__pivot__1205__1_3_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__pivot__1205__1'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__pivot__1205__1_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_tfield(0, MR_r1, 0);
	MR_sv(3) = MR_tfield(0, MR_r1, 1);
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__IntroducedFrom__pred__pivot__1205__1_3_0_i2);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__pivot__1205__1_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(3);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(1);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(libs__lp_rational__set_cell_5_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module167)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__pivot__1211__1_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__pivot__1211__1_5_0);
	MR_init_label6(libs__lp_rational__IntroducedFrom__pred__pivot__1211__1_5_0,2,4,5,3,8,9)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__pivot__1211__1'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__pivot__1211__1_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r4;
	MR_sv(3) = MR_tempr1;
	MR_tempr2 = MR_r3;
	MR_sv(4) = MR_tempr2;
	MR_r2 = MR_tempr2;
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		libs__lp_rational__IntroducedFrom__pred__pivot__1211__1_5_0_i2);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__pivot__1211__1_5_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(5) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__IntroducedFrom__pred__pivot__1211__1_5_0_i4);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__pivot__1211__1_5_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__IntroducedFrom__pred__pivot__1211__1_5_0_i5);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__pivot__1211__1_5_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__IntroducedFrom__pred__pivot__1211__1_5_0_i3);
	}
	MR_r1 = (MR_Word) MR_string_const("lp_rational.m", 13);
	MR_r2 = (MR_Word) MR_string_const("pivot/4 - ScaleRow: zero divisor.", 33);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		libs__lp_rational__IntroducedFrom__pred__pivot__1211__1_5_0_i8);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__pivot__1211__1_5_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_r1 = MR_sv(5);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__pivot__1211__1_5_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_47_2_0,
		libs__lp_rational__IntroducedFrom__pred__pivot__1211__1_5_0_i9);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__pivot__1211__1_5_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(4);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(3);
	MR_succip_word = MR_sv(6);
	MR_decr_sp(6);
	MR_np_tailcall_ent(libs__lp_rational__set_cell_5_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module168)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__row_op__1227__1_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__row_op__1227__1_6_0);
	MR_init_label4(libs__lp_rational__IntroducedFrom__pred__row_op__1227__1_6_0,2,3,4,5)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__row_op__1227__1'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__row_op__1227__1_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r3;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r5;
	MR_sv(4) = MR_tempr1;
	MR_tempr2 = MR_r4;
	MR_sv(5) = MR_tempr2;
	MR_r1 = MR_r2;
	MR_r2 = MR_tempr2;
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		libs__lp_rational__IntroducedFrom__pred__row_op__1227__1_6_0_i2);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__row_op__1227__1_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(5);
	MR_r3 = MR_sv(4);
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		libs__lp_rational__IntroducedFrom__pred__row_op__1227__1_6_0_i3);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__row_op__1227__1_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_sv(3);
	}
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_42_2_0,
		libs__lp_rational__IntroducedFrom__pred__row_op__1227__1_6_0_i4);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__row_op__1227__1_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_43_2_0,
		libs__lp_rational__IntroducedFrom__pred__row_op__1227__1_6_0_i5);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__row_op__1227__1_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(5);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(4);
	MR_succip_word = MR_sv(6);
	MR_decr_sp(6);
	MR_np_tailcall_ent(libs__lp_rational__set_cell_5_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module169)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1347__1_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1347__1_3_0);
	MR_init_label5(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1347__1_3_0,1,3,5,7,8)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__get_basis_vars__1347__1'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1347__1_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_mkframe("pred libs.lp_rational.IntroducedFrom__pred__get_basis_vars__1347__1/3-0", 4,
		MR_ENTRY(MR_do_fail));
	MR_fv(1) = MR_r1;
	MR_fv(4) = MR_r2;
	MR_r1 = (MR_Integer) 1;
	MR_r2 = MR_tfield(0, MR_fv(1), 0);
	MR_np_call_localret_ent(libs__lp_rational__between_3_0,
		libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1347__1_3_0_i1);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1347__1_3_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_fv(2) = MR_r1;
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_fv(2);
	MR_r3 = MR_tfield(0, MR_fv(1), 3);
	MR_np_call_localret_ent(list__member_2_0,
		libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1347__1_3_0_i3);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1347__1_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_r1 = MR_fv(2);
	MR_r2 = MR_fv(4);
	MR_r3 = MR_fv(1);
	MR_np_call_localret_ent(fn__libs__lp_rational__elem_3_0,
		libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1347__1_3_0_i5);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1347__1_3_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_fv(3) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1347__1_3_0_i7);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1347__1_3_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_fv(3);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1347__1_3_0_i8);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1347__1_3_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_tag_alloc_heap(MR_r1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r1, 0) = MR_fv(2);
	MR_tfield(0, MR_r1, 1) = MR_fv(3);
	MR_succeed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module170)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1345__1_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1345__1_2_0);
	MR_init_label4(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1345__1_2_0,1,4,6,7)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__get_basis_vars__1345__1'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1345__1_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_mkframe("pred libs.lp_rational.IntroducedFrom__pred__get_basis_vars__1345__1/2-0", 4,
		MR_ENTRY(MR_do_fail));
	MR_fv(1) = MR_r1;
	MR_np_call_localret_ent(libs__lp_rational__all_cols_2_0,
		libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1345__1_2_0_i1);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1345__1_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 5);
	MR_tfield(0, MR_r2, 0) = (MR_Word) MR_COMMON(2,28);
	MR_tfield(0, MR_r2, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1347__1_3_0);
	MR_tfield(0, MR_r2, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_r2, 3) = MR_fv(1);
	MR_tfield(0, MR_r2, 4) = MR_r1;
	MR_fv(2) = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,6);
	MR_np_call_localret_ent(solutions__solutions_2_1,
		libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1345__1_2_0_i4);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1345__1_2_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_r1,0,0)) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_fv(3) = MR_tfield(1, MR_r1, 1);
	MR_fv(4) = MR_tfield(0, MR_tfield(1, MR_r1, 0), 1);
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1345__1_2_0_i6);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1345__1_2_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_fv(4);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1345__1_2_0_i7);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1345__1_2_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	if (MR_LTAGS_TESTR(MR_fv(3),0,0)) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_r1 = MR_fv(2);
	MR_succeed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module171)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1357__1_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1357__1_3_0);
	MR_init_label2(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1357__1_3_0,1,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__get_basis_vars__1357__1'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1357__1_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_mkframe("pred libs.lp_rational.IntroducedFrom__pred__get_basis_vars__1357__1/3-0", 3,
		MR_ENTRY(MR_do_fail));
	MR_fv(1) = MR_r1;
	MR_fv(3) = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r1 = MR_fv(3);
	MR_np_call_localret_ent(list__member_2_1,
		libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1357__1_3_0_i1);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1357__1_3_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_fv(2) = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r2 = MR_fv(3);
	MR_r3 = MR_tfield(0, MR_fv(1), 2);
	MR_np_call_localret_ent(map__member_3_0,
		libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1357__1_3_0_i3);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__get_basis_vars__1357__1_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_fv(2) != MR_r2)) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_succeed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module172)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__eliminate_equations__1557__1_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__eliminate_equations__1557__1_1_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__eliminate_equations__1557__1'/1 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__eliminate_equations__1557__1_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_tag(MR_r1) == MR_mktag((MR_Integer) 1));
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module173)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__substitute_variable__1635__1_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__substitute_variable__1635__1_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__substitute_variable__1635__1'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__substitute_variable__1635__1_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_r1 == MR_r2);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module174)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__combine_vectors__1846__1_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__combine_vectors__1846__1_2_0);
	MR_init_label2(libs__lp_rational__IntroducedFrom__pred__combine_vectors__1846__1_2_0,3,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__combine_vectors__1846__1'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__combine_vectors__1846__1_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(1);
	MR_sv(1) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tfield(0, MR_tempr1, 0);
	MR_r3 = MR_tfield(0, MR_tempr2, 0);
	}
	MR_np_call_localret_ent(set__subset_2_0,
		libs__lp_rational__IntroducedFrom__pred__combine_vectors__1846__1_2_0_i3);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__combine_vectors__1846__1_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO_LAB(libs__lp_rational__IntroducedFrom__pred__combine_vectors__1846__1_2_0_i1);
	}
	MR_succip_word = MR_sv(1);
	MR_decr_sp(1);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(libs__lp_rational__IntroducedFrom__pred__combine_vectors__1846__1_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(1);
	MR_decr_sp(1);
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__map__det_insert_3_0);

MR_BEGIN_MODULE(libs__lp_rational_module175)
	MR_init_entry1(fn__libs__lp_rational__IntroducedFrom__func__init_cc_map__2037__1_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__IntroducedFrom__func__init_cc_map__2037__1_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__func__init_cc_map__2037__1'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__IntroducedFrom__func__init_cc_map__2037__1_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_tempr2 = MR_r2;
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, coeff_info);
	MR_r3 = MR_tempr2;
	MR_r4 = MR_tempr1;
	MR_r5 = (MR_Word) MR_TAG_COMMON(0,12,0);
	MR_np_tailcall_ent(fn__map__det_insert_3_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module176)
	MR_init_entry1(fn__libs__lp_rational__IntroducedFrom__func__normalize_vector__2062__1_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__IntroducedFrom__func__normalize_vector__2062__1_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__func__normalize_vector__2062__1'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__IntroducedFrom__func__normalize_vector__2062__1_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_np_tailcall_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_47_2_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module177)
	MR_init_entry1(fn__libs__lp_rational__IntroducedFrom__func__normalize_constraint__2088__1_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__IntroducedFrom__func__normalize_constraint__2088__1_2_0);
	MR_init_label1(fn__libs__lp_rational__IntroducedFrom__func__normalize_constraint__2088__1_2_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__func__normalize_constraint__2088__1'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__IntroducedFrom__func__normalize_constraint__2088__1_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_tfield(0, MR_r2, 0);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_tfield(0, MR_r2, 1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_47_2_0,
		fn__libs__lp_rational__IntroducedFrom__func__normalize_constraint__2088__1_2_0_i2);
MR_def_label(fn__libs__lp_rational__IntroducedFrom__func__normalize_constraint__2088__1_2_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(1);
	MR_tfield(0, MR_r2, 1) = MR_r1;
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(2);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module178)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__add_vectors__2108__1_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__add_vectors__2108__1_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__add_vectors__2108__1'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__add_vectors__2108__1_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	MR_r3 = MR_tempr1;
	MR_np_tailcall_ent(map__member_3_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__map__det_update_3_0);

MR_BEGIN_MODULE(libs__lp_rational_module179)
	MR_init_entry1(libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0);
	MR_init_label8(libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0,3,6,9,10,11,8,14,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__add_vectors__2111__1'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(8);
	MR_sv(8) = (MR_Word) MR_succip;
	MR_sv(3) = MR_r3;
	MR_sv(4) = MR_r2;
	MR_sv(1) = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_sv(6) = (MR_Word) MR_TAG_COMMON(0,0,0);
	MR_sv(7) = (MR_Word) MR_CTOR0_ADDR(libs__rat, rat);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(6);
	MR_r3 = MR_sv(7);
	MR_r4 = MR_sv(4);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_100_101_116_95_101_108_101_109_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_2_0,
		libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0_i3);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(term, generic);
	MR_r2 = MR_sv(6);
	MR_r3 = MR_sv(7);
	MR_r4 = MR_sv(4);
	MR_r5 = MR_sv(3);
	MR_np_call_localret_ent(fn__f_109_97_112_95_95_84_121_112_101_83_112_101_99_79_102_95_95_112_114_101_100_95_111_114_95_102_117_110_99_95_95_101_108_101_109_95_95_91_75_32_61_32_118_97_114_40_86_95_50_41_93_95_48_95_49_2_0,
		libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0_i6);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0_i4);
	}
	MR_sv(2) = MR_r2;
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_43_2_0,
		libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0_i9);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(5) = MR_r1;
	MR_np_call_localret_ent(fn__libs__rat__zero_0_0,
		libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0_i10);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___libs__rat__rat_0_0,
		libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0_i11);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0_i8);
	}
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(7);
	MR_r3 = MR_sv(3);
	MR_r4 = MR_sv(4);
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_np_tailcall_ent(fn__map__delete_2_0);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_43_2_0,
		libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0_i14);
MR_def_label(libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(7);
	MR_r3 = MR_sv(3);
	MR_r4 = MR_sv(4);
	MR_r5 = MR_tempr1;
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_np_tailcall_ent(fn__map__det_update_3_0);
	}
MR_def_label(libs__lp_rational__IntroducedFrom__pred__add_vectors__2111__1_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(7);
	MR_r3 = MR_sv(3);
	MR_r4 = MR_sv(4);
	MR_r5 = MR_tempr1;
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_np_tailcall_ent(fn__map__det_insert_3_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module180)
	MR_init_entry1(fn__libs__lp_rational__IntroducedFrom__func__opposing_inequalities__2198__1_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__libs__lp_rational__IntroducedFrom__func__opposing_inequalities__2198__1_1_0);
	MR_init_label1(fn__libs__lp_rational__IntroducedFrom__func__opposing_inequalities__2198__1_1_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__func__opposing_inequalities__2198__1'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__libs__lp_rational__IntroducedFrom__func__opposing_inequalities__2198__1_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_tfield(0, MR_r1, 0);
	MR_r1 = MR_tfield(0, MR_r1, 1);
	MR_np_call_localret_ent(fn__f_108_105_98_115_95_95_114_97_116_95_95_45_1_0,
		fn__libs__lp_rational__IntroducedFrom__func__opposing_inequalities__2198__1_1_0_i2);
MR_def_label(fn__libs__lp_rational__IntroducedFrom__func__opposing_inequalities__2198__1_1_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(1);
	MR_tfield(0, MR_r2, 1) = MR_r1;
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(2);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module181)
	MR_init_entry1(fn__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_3_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__func__project__[2]_0'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_3_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = (MR_Word) MR_tbmkword(0, 0);
	MR_r3 = MR_tempr1;
	MR_np_tailcall_ent(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module182)
	MR_init_entry1(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_4_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__project__[2]_0'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_4_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = (MR_Word) MR_tbmkword(0, 0);
	MR_r3 = MR_tempr1;
	MR_np_tailcall_ent(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(list__filter_4_0);

MR_BEGIN_MODULE(libs__lp_rational_module183)
	MR_init_entry1(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0);
	MR_init_label10(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0,57,5,6,8,10,12,15,18,19,21)
	MR_init_label2(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0,23,9)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__project__[2]_0'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0_i57);
	}
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 1);
	MR_tfield(1, MR_r1, 0) = MR_r3;
	MR_proceed();
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0,57)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_r3;
	MR_np_call_localret_ent(fn__libs__lp_rational__remove_trivial_1_0,
		f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0_i5);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__libs__lp_rational__remove_weaker_1_0,
		f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0_i6);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,3,23);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__filter_4_0,
		f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0_i8);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tempr2;
	}
	MR_np_call_localret_ent(libs__lp_rational__eliminate_equations_2_6_0,
		f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0_i10);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0_i9);
	}
	MR_sv(1) = MR_r2;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_r3;
	MR_r3 = MR_r4;
	MR_np_call_localret_ent(fn__f_108_105_115_116_95_95_43_43_2_0,
		f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0_i12);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 1);
	MR_tfield(1, MR_r2, 0) = MR_r1;
	if (MR_LTAGS_TESTR(MR_sv(1),0,0)) {
		MR_GOTO_LAB(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0_i15);
	}
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(4);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r2, 0);
	MR_r2 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,0,17);
	MR_r4 = (MR_Word) MR_TAG_COMMON(0,3,24);
	MR_r5 = MR_tempr1;
	MR_r6 = (MR_Integer) 0;
	MR_r7 = (MR_Word) MR_tbmkword(0, 0);
	}
	MR_np_call_localret_ent(list__foldl2_6_0,
		f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0_i18);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_sv(2);
	MR_r3 = (MR_Integer) 0;
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0,
		f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0_i19);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0_i21);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 1);
	MR_decr_sp_and_return(4);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, vector);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, constraint);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,3,25);
	MR_r4 = MR_tfield(1, MR_tempr1, 0);
	}
	MR_np_call_localret_ent(fn__list__map_2_0,
		f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0_i23);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 1);
	MR_tfield(1, MR_r2, 0) = MR_r1;
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(4);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_decr_sp_and_return(4);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(list__foldl4_10_0);

MR_BEGIN_MODULE(libs__lp_rational_module184)
	MR_init_entry1(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0);
	MR_init_label9(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0,57,3,7,5,13,14,20,18,15)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__fourier_elimination__[2]_0'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0,57)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0_i3);
	}
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 1);
	MR_tfield(1, MR_r1, 0) = MR_r4;
	MR_decr_sp_and_return(6);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(5) = MR_tfield(1, MR_r1, 1);
	MR_sv(4) = MR_tfield(1, MR_r1, 0);
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r3;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r4;
	MR_sv(3) = MR_tempr1;
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(libs__lp_rational__duffin_heuristic_4_0,
		f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0_i7);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0_i5);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r6 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(13,0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__classify_vector_10_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r2;
	MR_r7 = MR_sv(3);
	MR_sv(3) = MR_r3;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, vector);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,17);
	MR_r5 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r8 = (MR_Word) MR_tbmkword(0, 0);
	MR_r9 = (MR_Word) MR_tbmkword(0, 0);
	MR_r10 = (MR_Word) MR_tbmkword(0, 0);
	MR_r11 = (MR_Integer) 0;
	MR_GOTO_LAB(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0_i13);
	}
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr1 = MR_sv(2);
	MR_tempr2 = MR_sv(3);
	MR_tag_alloc_heap(MR_tempr3, 0, (MR_Integer) 4);
	MR_r6 = MR_tempr3;
	MR_tfield(0, MR_tempr3, 0) = (MR_Word) MR_COMMON(13,1);
	MR_tfield(0, MR_tempr3, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__classify_vector_10_0);
	MR_tfield(0, MR_tempr3, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr3, 3) = MR_sv(4);
	MR_r7 = MR_tempr2;
	MR_sv(3) = MR_sv(5);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, vector);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,17);
	MR_r5 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r8 = (MR_Word) MR_tbmkword(0, 0);
	MR_r9 = (MR_Word) MR_tbmkword(0, 0);
	MR_r10 = (MR_Word) MR_tbmkword(0, 0);
	MR_r11 = (MR_Integer) 0;
	}
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r2;
	MR_r3 = MR_r2;
	MR_r4 = MR_r2;
	MR_np_call_localret_ent(list__foldl4_10_0,
		f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0_i14);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_r1,0,0)) {
		MR_GOTO_LAB(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0_i15);
	}
	if (MR_LTAGS_TEST(MR_r2,0,0)) {
		MR_GOTO_LAB(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0_i15);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 6);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(11,1);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(libs__lp_rational__eliminate_var_8_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 3;
	MR_tfield(0, MR_tempr1, 3) = ((MR_Integer) MR_sv(2) + (MR_Integer) 1);
	MR_tfield(0, MR_tempr1, 4) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 5) = MR_r2;
	MR_sv(2) = MR_tfield(0, MR_tempr1, 3);
	MR_tempr2 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, vector);
	MR_r2 = MR_sv(4);
	MR_tempr3 = MR_r3;
	MR_r3 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_tempr4 = MR_r4;
	MR_r4 = MR_tempr1;
	MR_r5 = MR_tempr2;
	MR_r6 = MR_tempr3;
	MR_r7 = MR_tempr4;
	}
	MR_np_call_localret_ent(list__foldl2_6_4,
		f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0_i20);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0_i18);
	}
	MR_r1 = MR_sv(3);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_sv(1);
	MR_r3 = MR_sv(2);
	MR_r4 = MR_tempr1;
	MR_succip_word = MR_sv(6);
	MR_GOTO_LAB(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0_i57);
	}
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_decr_sp_and_return(6);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_r3 = MR_sv(2);
	MR_r4 = MR_tempr1;
	MR_succip_word = MR_sv(6);
	MR_GOTO_LAB(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_111_117_114_105_101_114_95_101_108_105_109_105_110_97_116_105_111_110_95_95_91_50_93_95_48_6_0_i57);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module185)
	MR_init_entry1(fn__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_73_110_116_114_111_100_117_99_101_100_70_114_111_109_95_95_102_117_110_99_95_95_98_111_117_110_100_105_110_103_95_98_111_120_95_95_55_50_54_95_95_49_95_95_91_49_93_95_48_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_73_110_116_114_111_100_117_99_101_100_70_114_111_109_95_95_102_117_110_99_95_95_98_111_117_110_100_105_110_103_95_98_111_120_95_95_55_50_54_95_95_49_95_95_91_49_93_95_48_3_0);
	MR_init_label4(fn__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_73_110_116_114_111_100_117_99_101_100_70_114_111_109_95_95_102_117_110_99_95_95_98_111_117_110_100_105_110_103_95_98_111_120_95_95_55_50_54_95_95_49_95_95_91_49_93_95_48_3_0,3,5,7,6)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__func__IntroducedFrom__func__bounding_box__726__1__[1]_0'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_73_110_116_114_111_100_117_99_101_100_70_114_111_109_95_95_102_117_110_99_95_95_98_111_117_110_100_105_110_103_95_98_111_120_95_95_55_50_54_95_95_49_95_95_91_49_93_95_48_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(1);
	MR_sv(1) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_r1;
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_r1 = MR_tempr1;
	MR_tempr2 = MR_r2;
	MR_r2 = (MR_Word) MR_tbmkword(0, 0);
	MR_r3 = MR_tempr2;
	}
	MR_np_call_localret_ent(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_106_101_99_116_95_95_91_50_93_95_48_5_0,
		fn__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_73_110_116_114_111_100_117_99_101_100_70_114_111_109_95_95_102_117_110_99_95_95_98_111_117_110_100_105_110_103_95_98_111_120_95_95_55_50_54_95_95_49_95_95_91_49_93_95_48_3_0_i3);
MR_def_label(fn__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_73_110_116_114_111_100_117_99_101_100_70_114_111_109_95_95_102_117_110_99_95_95_98_111_117_110_100_105_110_103_95_98_111_120_95_95_55_50_54_95_95_49_95_95_91_49_93_95_48_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,1)) {
		MR_GOTO_LAB(fn__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_73_110_116_114_111_100_117_99_101_100_70_114_111_109_95_95_102_117_110_99_95_95_98_111_117_110_100_105_110_103_95_98_111_120_95_95_55_50_54_95_95_49_95_95_91_49_93_95_48_3_0_i5);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_decr_sp_and_return(1);
MR_def_label(fn__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_73_110_116_114_111_100_117_99_101_100_70_114_111_109_95_95_102_117_110_99_95_95_98_111_117_110_100_105_110_103_95_98_111_120_95_95_55_50_54_95_95_49_95_95_91_49_93_95_48_3_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(fn__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_73_110_116_114_111_100_117_99_101_100_70_114_111_109_95_95_102_117_110_99_95_95_98_111_117_110_100_105_110_103_95_98_111_120_95_95_55_50_54_95_95_49_95_95_91_49_93_95_48_3_0_i6);
	}
	MR_np_call_localret_ent(fn__libs__rat__one_0_0,
		fn__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_73_110_116_114_111_100_117_99_101_100_70_114_111_109_95_95_102_117_110_99_95_95_98_111_117_110_100_105_110_103_95_98_111_120_95_95_55_50_54_95_95_49_95_95_91_49_93_95_48_3_0_i7);
MR_def_label(fn__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_73_110_116_114_111_100_117_99_101_100_70_114_111_109_95_95_102_117_110_99_95_95_98_111_117_110_100_105_110_103_95_98_111_120_95_95_55_50_54_95_95_49_95_95_91_49_93_95_48_3_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(1, MR_r2, 1) = MR_r1;
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r1, 0) = MR_r2;
	MR_tfield(1, MR_r1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_decr_sp_and_return(1);
MR_def_label(fn__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_73_110_116_114_111_100_117_99_101_100_70_114_111_109_95_95_102_117_110_99_95_95_98_111_117_110_100_105_110_103_95_98_111_120_95_95_55_50_54_95_95_49_95_95_91_49_93_95_48_3_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(1, MR_r1, 0);
	MR_decr_sp_and_return(1);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module186)
	MR_init_entry1(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_49_95_95_91_50_93_95_48_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_49_95_95_91_50_93_95_48_6_0);
	MR_init_label5(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_49_95_95_91_50_93_95_48_6_0,20,3,6,8,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__filter_and_count__ho1__[2]_0'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_49_95_95_91_50_93_95_48_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_49_95_95_91_50_93_95_48_6_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_49_95_95_91_50_93_95_48_6_0_i3);
	}
	MR_r1 = MR_r3;
	MR_r2 = MR_r4;
	MR_decr_sp_and_return(6);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_49_95_95_91_50_93_95_48_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_tfield(1, MR_r2, 1);
	MR_sv(1) = MR_r3;
	MR_sv(2) = MR_r4;
	MR_sv(3) = MR_tfield(1, MR_r2, 0);
	MR_sv(5) = MR_r1;
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(libs__lp_rational__IntroducedFrom__pred__combine_vectors__1846__1_2_0,
		f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_49_95_95_91_50_93_95_48_6_0_i6);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_49_95_95_91_50_93_95_48_6_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_49_95_95_91_50_93_95_48_6_0_i4);
	}
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, vector);
	MR_r2 = MR_sv(3);
	MR_r3 = MR_sv(1);
	MR_np_call_localret_ent(list__cons_3_0,
		f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_49_95_95_91_50_93_95_48_6_0_i8);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_49_95_95_91_50_93_95_48_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(4);
	MR_r3 = MR_r1;
	MR_r4 = ((MR_Integer) MR_sv(2) + (MR_Integer) 1);
	MR_r1 = MR_sv(5);
	MR_succip_word = MR_sv(6);
	MR_GOTO_LAB(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_49_95_95_91_50_93_95_48_6_0_i20);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_49_95_95_91_50_93_95_48_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_sv(1);
	MR_r4 = MR_sv(2);
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(4);
	MR_succip_word = MR_sv(6);
	MR_GOTO_LAB(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_49_95_95_91_50_93_95_48_6_0_i20);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(libs__lp_rational_module187)
	MR_init_entry1(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_50_95_95_91_50_93_95_48_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_50_95_95_91_50_93_95_48_6_0);
	MR_init_label5(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_50_95_95_91_50_93_95_48_6_0,22,3,8,10,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__filter_and_count__ho2__[2]_0'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_50_95_95_91_50_93_95_48_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_50_95_95_91_50_93_95_48_6_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_50_95_95_91_50_93_95_48_6_0_i3);
	}
	MR_r1 = MR_r3;
	MR_r2 = MR_r4;
	MR_decr_sp_and_return(6);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_50_95_95_91_50_93_95_48_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_tfield(1, MR_r2, 1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r2, 0);
	MR_sv(1) = MR_r3;
	MR_sv(2) = MR_r4;
	MR_sv(3) = MR_tempr1;
	MR_sv(5) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_sv(5);
	}
	MR_np_call_localret_ent(libs__lp_rational__quasi_syntactic_redundant_2_0,
		f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_50_95_95_91_50_93_95_48_6_0_i8);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_50_95_95_91_50_93_95_48_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO_LAB(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_50_95_95_91_50_93_95_48_6_0_i4);
	}
	MR_r3 = MR_sv(1);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_sv(2);
	MR_tempr2 = MR_sv(3);
	MR_r1 = MR_sv(5);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(libs__lp_rational, vector);
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(list__cons_3_0,
		f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_50_95_95_91_50_93_95_48_6_0_i10);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_50_95_95_91_50_93_95_48_6_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(4);
	MR_r3 = MR_r1;
	MR_r4 = ((MR_Integer) MR_sv(2) + (MR_Integer) 1);
	MR_r1 = MR_sv(5);
	MR_succip_word = MR_sv(6);
	MR_GOTO_LAB(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_50_95_95_91_50_93_95_48_6_0_i22);
MR_def_label(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_50_95_95_91_50_93_95_48_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_sv(1);
	MR_r4 = MR_sv(2);
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(4);
	MR_succip_word = MR_sv(6);
	MR_GOTO_LAB(f_108_105_98_115_95_95_108_112_95_114_97_116_105_111_110_97_108_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_105_108_116_101_114_95_97_110_100_95_99_111_117_110_116_95_95_104_111_50_95_95_91_50_93_95_48_6_0_i22);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

static void mercury__libs__lp_rational_maybe_bunch_0(void)
{
	libs__lp_rational_module0();
	libs__lp_rational_module1();
	libs__lp_rational_module2();
	libs__lp_rational_module3();
	libs__lp_rational_module4();
	libs__lp_rational_module5();
	libs__lp_rational_module6();
	libs__lp_rational_module7();
	libs__lp_rational_module8();
	libs__lp_rational_module9();
	libs__lp_rational_module10();
	libs__lp_rational_module11();
	libs__lp_rational_module12();
	libs__lp_rational_module13();
	libs__lp_rational_module14();
	libs__lp_rational_module15();
	libs__lp_rational_module16();
	libs__lp_rational_module17();
	libs__lp_rational_module18();
	libs__lp_rational_module19();
	libs__lp_rational_module20();
	libs__lp_rational_module21();
	libs__lp_rational_module22();
	libs__lp_rational_module23();
	libs__lp_rational_module24();
	libs__lp_rational_module25();
	libs__lp_rational_module26();
	libs__lp_rational_module27();
	libs__lp_rational_module28();
	libs__lp_rational_module29();
	libs__lp_rational_module30();
	libs__lp_rational_module31();
	libs__lp_rational_module32();
	libs__lp_rational_module33();
	libs__lp_rational_module34();
	libs__lp_rational_module35();
	libs__lp_rational_module36();
	libs__lp_rational_module37();
	libs__lp_rational_module38();
	libs__lp_rational_module39();
}

static void mercury__libs__lp_rational_maybe_bunch_1(void)
{
	libs__lp_rational_module40();
	libs__lp_rational_module41();
	libs__lp_rational_module42();
	libs__lp_rational_module43();
	libs__lp_rational_module44();
	libs__lp_rational_module45();
	libs__lp_rational_module46();
	libs__lp_rational_module47();
	libs__lp_rational_module48();
	libs__lp_rational_module49();
	libs__lp_rational_module50();
	libs__lp_rational_module51();
	libs__lp_rational_module52();
	libs__lp_rational_module53();
	libs__lp_rational_module54();
	libs__lp_rational_module55();
	libs__lp_rational_module56();
	libs__lp_rational_module57();
	libs__lp_rational_module58();
	libs__lp_rational_module59();
	libs__lp_rational_module60();
	libs__lp_rational_module61();
	libs__lp_rational_module62();
	libs__lp_rational_module63();
	libs__lp_rational_module64();
	libs__lp_rational_module65();
	libs__lp_rational_module66();
	libs__lp_rational_module67();
	libs__lp_rational_module68();
	libs__lp_rational_module69();
	libs__lp_rational_module70();
	libs__lp_rational_module71();
	libs__lp_rational_module72();
	libs__lp_rational_module73();
	libs__lp_rational_module74();
	libs__lp_rational_module75();
	libs__lp_rational_module76();
	libs__lp_rational_module77();
	libs__lp_rational_module78();
	libs__lp_rational_module79();
}

static void mercury__libs__lp_rational_maybe_bunch_2(void)
{
	libs__lp_rational_module80();
	libs__lp_rational_module81();
	libs__lp_rational_module82();
	libs__lp_rational_module83();
	libs__lp_rational_module84();
	libs__lp_rational_module85();
	libs__lp_rational_module86();
	libs__lp_rational_module87();
	libs__lp_rational_module88();
	libs__lp_rational_module89();
	libs__lp_rational_module90();
	libs__lp_rational_module91();
	libs__lp_rational_module92();
	libs__lp_rational_module93();
	libs__lp_rational_module94();
	libs__lp_rational_module95();
	libs__lp_rational_module96();
	libs__lp_rational_module97();
	libs__lp_rational_module98();
	libs__lp_rational_module99();
	libs__lp_rational_module100();
	libs__lp_rational_module101();
	libs__lp_rational_module102();
	libs__lp_rational_module103();
	libs__lp_rational_module104();
	libs__lp_rational_module105();
	libs__lp_rational_module106();
	libs__lp_rational_module107();
	libs__lp_rational_module108();
	libs__lp_rational_module109();
	libs__lp_rational_module110();
	libs__lp_rational_module111();
	libs__lp_rational_module112();
	libs__lp_rational_module113();
	libs__lp_rational_module114();
	libs__lp_rational_module115();
	libs__lp_rational_module116();
	libs__lp_rational_module117();
	libs__lp_rational_module118();
	libs__lp_rational_module119();
}

static void mercury__libs__lp_rational_maybe_bunch_3(void)
{
	libs__lp_rational_module120();
	libs__lp_rational_module121();
	libs__lp_rational_module122();
	libs__lp_rational_module123();
	libs__lp_rational_module124();
	libs__lp_rational_module125();
	libs__lp_rational_module126();
	libs__lp_rational_module127();
	libs__lp_rational_module128();
	libs__lp_rational_module129();
	libs__lp_rational_module130();
	libs__lp_rational_module131();
	libs__lp_rational_module132();
	libs__lp_rational_module133();
	libs__lp_rational_module134();
	libs__lp_rational_module135();
	libs__lp_rational_module136();
	libs__lp_rational_module137();
	libs__lp_rational_module138();
	libs__lp_rational_module139();
	libs__lp_rational_module140();
	libs__lp_rational_module141();
	libs__lp_rational_module142();
	libs__lp_rational_module143();
	libs__lp_rational_module144();
	libs__lp_rational_module145();
	libs__lp_rational_module146();
	libs__lp_rational_module147();
	libs__lp_rational_module148();
	libs__lp_rational_module149();
	libs__lp_rational_module150();
	libs__lp_rational_module151();
	libs__lp_rational_module152();
	libs__lp_rational_module153();
	libs__lp_rational_module154();
	libs__lp_rational_module155();
	libs__lp_rational_module156();
	libs__lp_rational_module157();
	libs__lp_rational_module158();
	libs__lp_rational_module159();
}

static void mercury__libs__lp_rational_maybe_bunch_4(void)
{
	libs__lp_rational_module160();
	libs__lp_rational_module161();
	libs__lp_rational_module162();
	libs__lp_rational_module163();
	libs__lp_rational_module164();
	libs__lp_rational_module165();
	libs__lp_rational_module166();
	libs__lp_rational_module167();
	libs__lp_rational_module168();
	libs__lp_rational_module169();
	libs__lp_rational_module170();
	libs__lp_rational_module171();
	libs__lp_rational_module172();
	libs__lp_rational_module173();
	libs__lp_rational_module174();
	libs__lp_rational_module175();
	libs__lp_rational_module176();
	libs__lp_rational_module177();
	libs__lp_rational_module178();
	libs__lp_rational_module179();
	libs__lp_rational_module180();
	libs__lp_rational_module181();
	libs__lp_rational_module182();
	libs__lp_rational_module183();
	libs__lp_rational_module184();
	libs__lp_rational_module185();
	libs__lp_rational_module186();
	libs__lp_rational_module187();
}

/* suppress gcc -Wmissing-decls warnings */
void mercury__libs__lp_rational__init(void);
void mercury__libs__lp_rational__init_type_tables(void);
void mercury__libs__lp_rational__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__libs__lp_rational__write_out_proc_statics(FILE *deep_fp, FILE *procrep_fp);
#endif
#ifdef MR_RECORD_TERM_SIZES
void mercury__libs__lp_rational__init_complexity_procs(void);
#endif

void mercury__libs__lp_rational__init(void)
{
	static MR_bool done = MR_FALSE;
	if (done) {
		return;
	}
	done = MR_TRUE;
	mercury__libs__lp_rational_maybe_bunch_0();
	mercury__libs__lp_rational_maybe_bunch_1();
	mercury__libs__lp_rational_maybe_bunch_2();
	mercury__libs__lp_rational_maybe_bunch_3();
	mercury__libs__lp_rational_maybe_bunch_4();
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_cc_map_0,
		libs__lp_rational__cc_map_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_cell_0,
		libs__lp_rational__cell_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_coeff_info_0,
		libs__lp_rational__coeff_info_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_coefficient_0,
		libs__lp_rational__coefficient_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_constant_0,
		libs__lp_rational__constant_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_constraint_0,
		libs__lp_rational__constraint_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_constraints_0,
		libs__lp_rational__constraints_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_direction_0,
		libs__lp_rational__direction_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_entailment_result_0,
		libs__lp_rational__entailment_result_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_lp_info_0,
		libs__lp_rational__lp_info_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_lp_operator_0,
		libs__lp_rational__lp_operator_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_lp_result_0,
		libs__lp_rational__lp_result_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_lp_term_0,
		libs__lp_rational__lp_term_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_lp_terms_0,
		libs__lp_rational__lp_terms_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_lp_var_0,
		libs__lp_rational__lp_var_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_lp_vars_0,
		libs__lp_rational__lp_vars_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_lp_varset_0,
		libs__lp_rational__lp_varset_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_matrix_0,
		libs__lp_rational__matrix_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_objective_0,
		libs__lp_rational__objective_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_output_var_0,
		libs__lp_rational__output_var_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_projection_result_0,
		libs__lp_rational__projection_result_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_tableau_0,
		libs__lp_rational__tableau_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_var_num_map_0,
		libs__lp_rational__var_num_map_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_libs__lp_rational__type_ctor_info_vector_0,
		libs__lp_rational__vector_0_0);
	mercury__libs__lp_rational__init_debugger();
}

void mercury__libs__lp_rational__init_type_tables(void)
{
	static MR_bool done = MR_FALSE;
	if (done) {
		return;
	}
	done = MR_TRUE;
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_cc_map_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_cell_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_coeff_info_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_coefficient_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_constant_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_constraint_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_constraints_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_direction_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_entailment_result_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_lp_info_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_lp_operator_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_lp_result_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_lp_term_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_lp_terms_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_lp_var_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_lp_vars_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_lp_varset_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_matrix_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_objective_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_output_var_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_projection_result_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_tableau_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_var_num_map_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_libs__lp_rational__type_ctor_info_vector_0);
	}
}


void mercury__libs__lp_rational__init_debugger(void)
{
	static MR_bool done = MR_FALSE;
	if (done) {
		return;
	}
	done = MR_TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__libs__lp_rational__write_out_proc_statics(FILE *deep_fp, FILE *procrep_fp)
{
	MR_write_out_module_proc_reps_start(procrep_fp, &mercury_data__module_common_layout__libs__lp_rational);
	MR_write_out_module_proc_reps_end(procrep_fp);
}

#endif

#ifdef MR_RECORD_TERM_SIZES

void mercury__libs__lp_rational__init_complexity_procs(void)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
