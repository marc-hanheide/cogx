/*
** Automatically generated from `unused_imports.m'
** by the Mercury compiler,
** version 10.04.2, configured for x86_64-unknown-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
** HIGHLEVEL_CODE=no
**
** END_OF_C_GRADE_INFO
*/

/*
INIT mercury__check_hlds__unused_imports__init
ENDINIT
*/

#define MR_ALLOW_RESET
#include "mercury_imp.h"
#line 539 "../library/io.int"
#include "io.mh"

#line 28 "check_hlds.unused_imports.c"
#line 547 "../library/io.int"
#include "string.mh"

#line 32 "check_hlds.unused_imports.c"
#line 29 "../library/bitmap.int2"
#include "bitmap.mh"

#line 36 "check_hlds.unused_imports.c"
#line 28 "../library/time.int2"
#include "time.mh"

#line 40 "check_hlds.unused_imports.c"
#line 31 "../library/array.int2"
#include "array.mh"

#line 44 "check_hlds.unused_imports.c"
#line 33 "../mdbcomp/mdbcomp.rtti_access.int2"
#include "mdbcomp.rtti_access.mh"

#line 48 "check_hlds.unused_imports.c"
#line 49 "check_hlds.unused_imports.c"
#include "check_hlds.unused_imports.mh"

#line 52 "check_hlds.unused_imports.c"
#line 53 "check_hlds.unused_imports.c"
#ifndef CHECK_HLDS__UNUSED_IMPORTS_DECL_GUARD
#define CHECK_HLDS__UNUSED_IMPORTS_DECL_GUARD

#line 57 "check_hlds.unused_imports.c"
#line 58 "check_hlds.unused_imports.c"

#endif
#line 61 "check_hlds.unused_imports.c"

#ifdef _MSC_VER
#define MR_STATIC_LINKAGE extern
#else
#define MR_STATIC_LINKAGE static
#endif

struct mercury_type_0 {
	MR_Word * f1;
	MR_Word * f2;
	MR_Integer f3;
	MR_Word * f4;
	MR_Word * f5;
};
MR_STATIC_LINKAGE const struct mercury_type_0 mercury_common_0[];

struct mercury_type_1 {
	MR_Word * f1;
	MR_Code * f2;
	MR_Integer f3;
};
MR_STATIC_LINKAGE const struct mercury_type_1 mercury_common_1[];

struct mercury_type_2 {
	MR_Integer f1;
	MR_String f2;
};
MR_STATIC_LINKAGE const struct mercury_type_2 mercury_common_2[];

struct mercury_type_3 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[4];
};
MR_STATIC_LINKAGE const struct mercury_type_3 mercury_common_3[];

struct mercury_type_4 {
	MR_Word * f1[2];
};
MR_STATIC_LINKAGE const struct mercury_type_4 mercury_common_4[];

struct mercury_type_5 {
	MR_Word * f1;
	MR_Code * f2;
	MR_Integer f3;
	MR_Integer f4;
};
MR_STATIC_LINKAGE const struct mercury_type_5 mercury_common_5[];

struct mercury_type_6 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[3];
};
MR_STATIC_LINKAGE const struct mercury_type_6 mercury_common_6[];

struct mercury_type_7 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[5];
};
MR_STATIC_LINKAGE const struct mercury_type_7 mercury_common_7[];
MR_decl_label10(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0, 2,3,5,7,6,9,10,12,13,15)
MR_decl_label6(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0, 16,17,19,20,21,22)
MR_decl_label2(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_99_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_50_93_95_48_5_0, 2,4)
MR_decl_label9(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0, 2,3,4,6,8,7,10,12,5)
MR_decl_label6(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_105_110_115_116_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0, 2,4,6,5,8,3)
MR_decl_label1(check_hlds__unused_imports__bound_inst_info_used_modules_4_0, 2)
MR_decl_label2(check_hlds__unused_imports__case_used_modules_3_0, 2,4)
MR_decl_label6(check_hlds__unused_imports__class_used_modules_4_0, 2,4,6,5,8,9)
MR_decl_label10(check_hlds__unused_imports__cons_id_used_modules_4_0, 3,4,6,7,9,10,11,12,13,14)
MR_decl_label4(check_hlds__unused_imports__cons_id_used_modules_4_0, 15,16,17,18)
MR_decl_label1(check_hlds__unused_imports__ctor_used_modules_4_0, 3)
MR_decl_label10(check_hlds__unused_imports__hlds_goal_used_modules_3_0, 127,5,7,6,3,10,12,47,14,15)
MR_decl_label10(check_hlds__unused_imports__hlds_goal_used_modules_3_0, 18,22,23,21,25,27,32,31,36,35)
MR_decl_label1(check_hlds__unused_imports__hlds_goal_used_modules_3_0, 29)
MR_decl_label1(check_hlds__unused_imports__ho_inst_info_used_modules_4_0, 3)
MR_decl_label10(check_hlds__unused_imports__inst_name_used_modules_4_0, 66,3,7,6,10,9,13,15,17,19)
MR_decl_label2(check_hlds__unused_imports__inst_name_used_modules_4_0, 21,23)
MR_decl_label7(check_hlds__unused_imports__instance_used_modules_2_4_0, 2,4,6,5,8,9,11)
MR_decl_label10(check_hlds__unused_imports__mer_inst_used_modules_4_0, 65,3,32,4,5,7,10,9,13,16)
MR_decl_label1(check_hlds__unused_imports__mer_inst_used_modules_4_0, 18)
MR_decl_label3(check_hlds__unused_imports__mer_mode_used_modules_4_0, 4,3,6)
MR_decl_label10(check_hlds__unused_imports__mer_type_used_modules_2_4_0, 51,3,5,4,8,9,14,12,18,59)
MR_decl_label6(check_hlds__unused_imports__mode_used_modules_4_0, 2,4,6,5,8,9)
MR_decl_label1(check_hlds__unused_imports__prog_constraint_used_module_4_0, 2)
MR_decl_label2(check_hlds__unused_imports__unify_rhs_used_modules_3_0, 3,5)
MR_decl_label10(check_hlds__unused_imports__unused_imports_4_0, 2,3,4,5,6,8,9,10,11,12)
MR_decl_label10(check_hlds__unused_imports__unused_imports_4_0, 13,14,16,17,15,19,20,21,22,24)
MR_decl_label1(check_hlds__unused_imports__unused_imports_4_0, 25)
MR_decl_label10(check_hlds__unused_imports__used_modules_3_0, 2,4,5,6,7,9,10,11,13,14)
MR_decl_label4(check_hlds__unused_imports__used_modules_3_0, 16,17,20,21)
MR_decl_label10(fn__check_hlds__unused_imports__generate_warning_4_0, 2,3,4,5,8,10,11,12,13,25)
MR_decl_label5(fn__check_hlds__unused_imports__generate_warning_4_0, 29,30,31,38,39)
MR_decl_static(fn__check_hlds__unused_imports__generate_warning_4_0)
MR_decl_static(check_hlds__unused_imports__used_modules_3_0)
MR_def_extern_entry(check_hlds__unused_imports__unused_imports_4_0)
MR_decl_static(fn__check_hlds__unused_imports__wrap_module_name_1_0)
MR_decl_static(check_hlds__unused_imports__mer_type_used_modules_4_0)
MR_decl_static(check_hlds__unused_imports__mer_type_used_modules_2_4_0)
MR_decl_static(check_hlds__unused_imports__type_used_modules_4_0)
MR_decl_static(check_hlds__unused_imports__ctor_used_modules_4_0)
MR_decl_static(check_hlds__unused_imports__prog_constraint_used_module_4_0)
MR_decl_static(check_hlds__unused_imports__ho_inst_info_used_modules_4_0)
MR_decl_static(check_hlds__unused_imports__mer_inst_used_modules_4_0)
MR_decl_static(check_hlds__unused_imports__inst_name_used_modules_4_0)
MR_decl_static(check_hlds__unused_imports__user_inst_used_modules_4_0)
MR_decl_static(check_hlds__unused_imports__mer_mode_used_modules_4_0)
MR_decl_static(check_hlds__unused_imports__mode_used_modules_4_0)
MR_decl_static(check_hlds__unused_imports__class_used_modules_4_0)
MR_decl_static(check_hlds__unused_imports__instance_used_modules_4_0)
MR_decl_static(check_hlds__unused_imports__instance_used_modules_2_4_0)
MR_decl_static(check_hlds__unused_imports__pred_info_used_modules_4_0)
MR_decl_static(check_hlds__unused_imports__proc_info_used_modules_5_0)
MR_decl_static(check_hlds__unused_imports__cons_id_used_modules_4_0)
MR_decl_static(check_hlds__unused_imports__hlds_goal_used_modules_3_0)
MR_decl_static(check_hlds__unused_imports__unify_rhs_used_modules_3_0)
MR_decl_static(check_hlds__unused_imports__clause_used_modules_3_0)
MR_decl_static(check_hlds__unused_imports__case_used_modules_3_0)
MR_decl_static(check_hlds__unused_imports__bound_inst_info_used_modules_4_0)
MR_decl_static(check_hlds__unused_imports__IntroducedFrom__pred__ctor_used_modules__225__1_4_0)
MR_decl_static(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0)
MR_decl_static(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_105_110_115_116_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0)
MR_decl_static(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0)
MR_decl_static(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_99_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_50_93_95_48_5_0)

static const MR_UserClosureId
mercury_data__closure_layout__fn__check_hlds__unused_imports__generate_warning_4_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_mdbcomp__prim_data__type_ctor_info_sym_name_0;
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__error_util__type_ctor_info_format_component_0;
static const MR_UserClosureId
mercury_data__closure_layout__fn__check_hlds__unused_imports__generate_warning_4_0_2;
static const struct mercury_type_0 mercury_common_0[2] =
{
{
(MR_Word *) &mercury_data__closure_layout__fn__check_hlds__unused_imports__generate_warning_4_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name),
MR_CTOR0_ADDR(parse_tree__error_util, format_component)
},
{
(MR_Word *) &mercury_data__closure_layout__fn__check_hlds__unused_imports__generate_warning_4_0_2,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name),
MR_CTOR0_ADDR(parse_tree__error_util, format_component)
},
};

static const struct mercury_type_1 mercury_common_1[13] =
{
{
MR_COMMON(0,0),
MR_ENTRY_AP(fn__check_hlds__unused_imports__wrap_module_name_1_0),
0
},
{
MR_COMMON(0,1),
MR_ENTRY_AP(fn__check_hlds__unused_imports__wrap_module_name_1_0),
0
},
{
MR_COMMON(3,0),
MR_ENTRY_AP(check_hlds__unused_imports__type_used_modules_4_0),
0
},
{
MR_COMMON(3,1),
MR_ENTRY_AP(check_hlds__unused_imports__user_inst_used_modules_4_0),
0
},
{
MR_COMMON(3,2),
MR_ENTRY_AP(check_hlds__unused_imports__mode_used_modules_4_0),
0
},
{
MR_COMMON(3,3),
MR_ENTRY_AP(check_hlds__unused_imports__class_used_modules_4_0),
0
},
{
MR_COMMON(3,4),
MR_ENTRY_AP(check_hlds__unused_imports__instance_used_modules_4_0),
0
},
{
MR_COMMON(3,5),
MR_ENTRY_AP(check_hlds__unused_imports__pred_info_used_modules_4_0),
0
},
{
MR_COMMON(6,0),
MR_ENTRY_AP(check_hlds__unused_imports__hlds_goal_used_modules_3_0),
0
},
{
MR_COMMON(6,1),
MR_ENTRY_AP(check_hlds__unused_imports__hlds_goal_used_modules_3_0),
0
},
{
MR_COMMON(6,2),
MR_ENTRY_AP(check_hlds__unused_imports__hlds_goal_used_modules_3_0),
0
},
{
MR_COMMON(6,3),
MR_ENTRY_AP(check_hlds__unused_imports__case_used_modules_3_0),
0
},
{
MR_COMMON(6,4),
MR_ENTRY_AP(check_hlds__unused_imports__clause_used_modules_3_0),
0
},
};

static const struct mercury_type_2 mercury_common_2[4] =
{
{
3,
MR_string_const(":", 1)
},
{
4,
MR_string_const("warning:", 8)
},
{
4,
MR_string_const("imported, ", 10)
},
{
4,
MR_string_const("but", 3)
},
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__used_modules_3_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_type_ctor_0;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_data__type_ctor_info_hlds_type_defn_0;
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_used_modules_0;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__used_modules_3_0_2;
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_inst_id_0;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_data__type_ctor_info_hlds_inst_defn_0;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__used_modules_3_0_3;
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_mode_id_0;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_data__type_ctor_info_hlds_mode_defn_0;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__used_modules_3_0_4;
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_class_id_0;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_data__type_ctor_info_hlds_class_defn_0;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__used_modules_3_0_5;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__used_modules_3_0_6;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_int_0;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_pred__type_ctor_info_pred_info_0;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__unused_imports_4_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_item_visibility_0;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__mer_type_used_modules_2_4_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_mer_type_0;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__mer_type_used_modules_2_4_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__mer_type_used_modules_2_4_0_3;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__mer_type_used_modules_2_4_0_4;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__ctor_used_modules_4_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_prog_constraint_0;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__ctor_used_modules_4_0_2;
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_constructor_arg_0;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__prog_constraint_used_module_4_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__ho_inst_info_used_modules_4_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_mer_mode_0;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__mer_inst_used_modules_4_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_mer_inst_0;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__mer_inst_used_modules_4_0_2;
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_bound_inst_0;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__inst_name_used_modules_4_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__mer_mode_used_modules_4_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__class_used_modules_4_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__instance_used_modules_4_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_data__type_ctor_info_hlds_instance_defn_0;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__instance_used_modules_2_4_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__instance_used_modules_2_4_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__case_used_modules_3_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_cons_id_0;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__bound_inst_info_used_modules_4_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_constructor_0;
static const MR_UserClosureId
mercury_data__closure_layout__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_99_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_50_93_95_48_5_0_1;
static const struct mercury_type_3 mercury_common_3[29] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__used_modules_3_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, type_ctor),
MR_CTOR0_ADDR(hlds__hlds_data, hlds_type_defn),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__used_modules_3_0_2,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, inst_id),
MR_CTOR0_ADDR(hlds__hlds_data, hlds_inst_defn),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__used_modules_3_0_3,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, mode_id),
MR_CTOR0_ADDR(hlds__hlds_data, hlds_mode_defn),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__used_modules_3_0_4,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, class_id),
MR_CTOR0_ADDR(hlds__hlds_data, hlds_class_defn),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__used_modules_3_0_5,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, class_id),
MR_COMMON(4,1),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__used_modules_3_0_6,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(hlds__hlds_pred, pred_info),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__unused_imports_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__mer_type_used_modules_2_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(parse_tree__prog_data, mer_type),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__mer_type_used_modules_2_4_0_2,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(parse_tree__prog_data, mer_type),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__mer_type_used_modules_2_4_0_3,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(parse_tree__prog_data, mer_type),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__mer_type_used_modules_2_4_0_4,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(parse_tree__prog_data, mer_type),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__ctor_used_modules_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(parse_tree__prog_data, prog_constraint),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__ctor_used_modules_4_0_2,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(parse_tree__prog_data, constructor_arg),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__prog_constraint_used_module_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(parse_tree__prog_data, mer_type),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__ho_inst_info_used_modules_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(parse_tree__prog_data, mer_mode),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__mer_inst_used_modules_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(parse_tree__prog_data, mer_inst),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__mer_inst_used_modules_4_0_2,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(parse_tree__prog_data, bound_inst),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__inst_name_used_modules_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(parse_tree__prog_data, mer_inst),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__mer_mode_used_modules_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(parse_tree__prog_data, mer_inst),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__class_used_modules_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(parse_tree__prog_data, prog_constraint),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__instance_used_modules_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, class_id),
MR_CTOR0_ADDR(hlds__hlds_data, hlds_instance_defn),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__instance_used_modules_2_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(parse_tree__prog_data, prog_constraint),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__instance_used_modules_2_4_0_2,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(parse_tree__prog_data, mer_type),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__case_used_modules_3_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(parse_tree__prog_data, cons_id),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__bound_inst_info_used_modules_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(parse_tree__prog_data, mer_inst),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(parse_tree__prog_data, constructor),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(parse_tree__prog_data, mer_type),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_2,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(parse_tree__prog_data, prog_constraint),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_99_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_50_93_95_48_5_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_CTOR0_ADDR(parse_tree__prog_data, mer_mode),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
};

extern const MR_TypeCtorInfo_Struct mercury_data_list__type_ctor_info_list_1;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_data__type_ctor_info_hlds_instance_defn_0;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_data__type_ctor_info_hlds_instance_defn_0;
static const struct mercury_type_4 mercury_common_4[2] =
{
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(hlds__hlds_data, hlds_instance_defn)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(hlds__hlds_data, hlds_instance_defn)
}
},
};

MR_decl_entry(parse_tree__prog_data__add_all_modules_4_0);
static const struct mercury_type_5 mercury_common_5[2] =
{
{
MR_COMMON(3,6),
MR_ENTRY_AP(parse_tree__prog_data__add_all_modules_4_0),
1,
0
},
{
MR_COMMON(3,23),
MR_ENTRY_AP(check_hlds__unused_imports__cons_id_used_modules_4_0),
1,
1
},
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__hlds_goal_used_modules_3_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_goal__type_ctor_info_hlds_goal_0;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__hlds_goal_used_modules_3_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__hlds_goal_used_modules_3_0_3;
static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__hlds_goal_used_modules_3_0_4;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_goal__type_ctor_info_case_0;
static const MR_UserClosureId
mercury_data__closure_layout__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_4;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_clauses__type_ctor_info_clause_0;
static const struct mercury_type_6 mercury_common_6[5] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__hlds_goal_used_modules_3_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(hlds__hlds_goal, hlds_goal),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__hlds_goal_used_modules_3_0_2,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(hlds__hlds_goal, hlds_goal),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__hlds_goal_used_modules_3_0_3,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(hlds__hlds_goal, hlds_goal),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__check_hlds__unused_imports__hlds_goal_used_modules_3_0_4,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(hlds__hlds_goal, case),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_4,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(hlds__hlds_clauses, clause),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_3;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_pred__type_ctor_info_proc_info_0;
static const struct mercury_type_7 mercury_common_7[1] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_3,
(MR_Word *) (MR_Integer) 0
},
5,
{
MR_CTOR0_ADDR(parse_tree__prog_data, item_visibility),
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(hlds__hlds_pred, proc_info),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules),
MR_CTOR0_ADDR(parse_tree__prog_data, used_modules)
}
},
};


static const MR_UserClosureId
mercury_data__closure_layout__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_99_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_50_93_95_48_5_0_1 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"mer_mode_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
369,
"d1;c7;d1;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_4 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"clause_used_modules",
3,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
380,
"d1;c6;"
};

static const MR_UserClosureId
mercury_data__closure_layout__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_3 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"proc_info_used_modules",
5,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
354,
"d1;c7;d1;c13;"
};

static const MR_UserClosureId
mercury_data__closure_layout__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_2 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"prog_constraint_used_module",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
348,
"d1;c7;d1;c8;"
};

static const MR_UserClosureId
mercury_data__closure_layout__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_1 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"mer_type_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
344,
"d1;c7;d1;c4;"
};

static const MR_UserClosureId
mercury_data__closure_layout__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_1 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"ctor_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
204,
"d1;c8;d1;c3;d1;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__bound_inst_info_used_modules_4_0_1 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"mer_inst_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
586,
"d1;c6;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__case_used_modules_3_0_1 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"cons_id_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
460,
"d1;c7;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__hlds_goal_used_modules_3_0_4 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"case_used_modules",
3,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
425,
"d1;c5;d6;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__hlds_goal_used_modules_3_0_3 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"hlds_goal_used_modules",
3,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
447,
"d1;c5;d9;c2;d2;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__hlds_goal_used_modules_3_0_2 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"hlds_goal_used_modules",
3,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
422,
"d1;c5;d5;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__hlds_goal_used_modules_3_0_1 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"hlds_goal_used_modules",
3,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
422,
"d1;c5;d5;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__instance_used_modules_2_4_0_2 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"mer_type_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
324,
"d1;c7;d1;c7;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__instance_used_modules_2_4_0_1 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"prog_constraint_used_module",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
322,
"d1;c7;d1;c4;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__instance_used_modules_4_0_1 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"instance_used_modules_2",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
307,
"d1;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__class_used_modules_4_0_1 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"prog_constraint_used_module",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
294,
"d1;c7;d1;c4;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__mer_mode_used_modules_4_0_1 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"mer_inst_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
549,
"d2;c6;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__inst_name_used_modules_4_0_1 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"mer_inst_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
603,
"d1;c6;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__mer_inst_used_modules_4_0_2 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"bound_inst_info_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
563,
"d4;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__mer_inst_used_modules_4_0_1 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"mer_inst_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
576,
"d10;c6;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__ho_inst_info_used_modules_4_0_1 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"mer_mode_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
593,
"d1;c6;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__prog_constraint_used_module_4_0_1 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"mer_type_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
236,
"d1;c6;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__ctor_used_modules_4_0_2 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"lambda_unused_imports_m_225",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
225,
"d1;c7;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__ctor_used_modules_4_0_1 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"prog_constraint_used_module",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
223,
"d1;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__mer_type_used_modules_2_4_0_4 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"mer_type_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
531,
"d5;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__mer_type_used_modules_2_4_0_3 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"mer_type_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
523,
"d4;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__mer_type_used_modules_2_4_0_2 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"mer_type_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
533,
"d6;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__mer_type_used_modules_2_4_0_1 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"mer_type_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
519,
"d2;c6;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__unused_imports_4_0_1 = {
{
MR_PREDICATE,
"parse_tree.prog_data",
"parse_tree.prog_data",
"add_all_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
88,
"d1;c13;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__used_modules_3_0_6 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"pred_info_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
186,
"d1;c23;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__used_modules_3_0_5 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"instance_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
183,
"d1;c20;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__used_modules_3_0_4 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"class_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
180,
"d1;c17;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__used_modules_3_0_3 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"mode_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
177,
"d1;c14;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__used_modules_3_0_2 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"user_inst_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
173,
"d1;c10;"
};

static const MR_UserClosureId
mercury_data__closure_layout__check_hlds__unused_imports__used_modules_3_0_1 = {
{
MR_PREDICATE,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"type_used_modules",
4,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
168,
"d1;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__check_hlds__unused_imports__generate_warning_4_0_2 = {
{
MR_FUNCTION,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"wrap_module_name",
2,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
139,
"d1;c14;"
};

static const MR_UserClosureId
mercury_data__closure_layout__fn__check_hlds__unused_imports__generate_warning_4_0_1 = {
{
MR_FUNCTION,
"check_hlds.unused_imports",
"check_hlds.unused_imports",
"wrap_module_name",
2,
0
},
"check_hlds.unused_imports",
"unused_imports.m",
139,
"d1;c14;"
};


MR_decl_entry(term__context_init_3_0);
extern const MR_TypeCtorInfo_Struct mercury_data_mdbcomp__prim_data__type_ctor_info_sym_name_0;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_string_0;
MR_decl_entry(fn__parse_tree__error_util__choose_number_3_0);
MR_decl_entry(fn__parse_tree__error_util__is_or_are_1_0);
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__error_util__type_ctor_info_format_component_0;
MR_decl_entry(fn__f_115_116_114_105_110_103_95_95_43_43_2_0);
MR_decl_entry(fn__list__map_2_0);
MR_decl_entry(fn__parse_tree__error_util__component_list_to_pieces_1_0);
MR_decl_entry(fn__f_108_105_115_116_95_95_43_43_2_0);

MR_BEGIN_MODULE(check_hlds__unused_imports_module0)
	MR_init_entry1(fn__check_hlds__unused_imports__generate_warning_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__check_hlds__unused_imports__generate_warning_4_0);
	MR_init_label10(fn__check_hlds__unused_imports__generate_warning_4_0,2,3,4,5,8,10,11,12,13,25)
	MR_init_label5(fn__check_hlds__unused_imports__generate_warning_4_0,29,30,31,38,39)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'generate_warning'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__check_hlds__unused_imports__generate_warning_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(9);
	MR_sv(9) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = (MR_Integer) 1;
	MR_np_call_localret_ent(term__context_init_3_0,
		fn__check_hlds__unused_imports__generate_warning_4_0_i2);
MR_def_label(fn__check_hlds__unused_imports__generate_warning_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_sv(7) = (MR_Word) MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name);
	MR_r1 = MR_sv(7);
	MR_r2 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r3 = MR_sv(2);
	MR_r4 = (MR_Word) MR_string_const("module", 6);
	MR_r5 = (MR_Word) MR_string_const("modules", 7);
	MR_np_call_localret_ent(fn__parse_tree__error_util__choose_number_3_0,
		fn__check_hlds__unused_imports__generate_warning_4_0_i3);
MR_def_label(fn__check_hlds__unused_imports__generate_warning_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(5) = MR_r1;
	MR_r1 = MR_sv(7);
	MR_r2 = MR_sv(2);
	MR_np_call_localret_ent(fn__parse_tree__error_util__is_or_are_1_0,
		fn__check_hlds__unused_imports__generate_warning_4_0_i4);
MR_def_label(fn__check_hlds__unused_imports__generate_warning_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(3), MR_string_const("", 0)) != 0)) {
		MR_GOTO_LAB(fn__check_hlds__unused_imports__generate_warning_4_0_i5);
	}
	MR_r4 = MR_sv(2);
	MR_sv(6) = MR_r1;
	MR_sv(2) = (MR_Word) MR_string_const("", 0);
	MR_sv(7) = (MR_Word) MR_string_const("", 0);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,1,0);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__error_util, format_component);
	MR_GOTO_LAB(fn__check_hlds__unused_imports__generate_warning_4_0_i10);
MR_def_label(fn__check_hlds__unused_imports__generate_warning_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(6) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_string_const(" of", 3);
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		fn__check_hlds__unused_imports__generate_warning_4_0_i8);
MR_def_label(fn__check_hlds__unused_imports__generate_warning_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r4 = MR_sv(2);
	MR_sv(2) = (MR_Word) MR_string_const(" in the", 7);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(7);
	MR_sv(7) = MR_r1;
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,1,1);
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__error_util, format_component);
	}
MR_def_label(fn__check_hlds__unused_imports__generate_warning_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(8) = MR_r2;
	MR_np_call_localret_ent(fn__list__map_2_0,
		fn__check_hlds__unused_imports__generate_warning_4_0_i11);
MR_def_label(fn__check_hlds__unused_imports__generate_warning_4_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(7);
	MR_sv(7) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Word) MR_string_const(" module", 7);
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		fn__check_hlds__unused_imports__generate_warning_4_0_i12);
MR_def_label(fn__check_hlds__unused_imports__generate_warning_4_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("In ", 3);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		fn__check_hlds__unused_imports__generate_warning_4_0_i13);
MR_def_label(fn__check_hlds__unused_imports__generate_warning_4_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 3, (MR_Integer) 2);
	MR_tfield(3, MR_r2, 0) = (MR_Integer) 4;
	MR_tfield(3, MR_r2, 1) = MR_r1;
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 5;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(1);
	MR_tag_alloc_heap(MR_tempr2, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr2, 0) = (MR_Integer) 4;
	MR_tfield(3, MR_tempr2, 1) = MR_sv(5);
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr3, 0) = MR_tempr2;
	MR_tfield(1, MR_tempr3, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = (MR_Word) MR_TAG_COMMON(3,2,1);
	MR_tfield(1, MR_tempr2, 1) = MR_tempr3;
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr3, 0) = (MR_Word) MR_tbmkword(0, 1);
	MR_tfield(1, MR_tempr3, 1) = MR_tempr2;
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = (MR_Word) MR_TAG_COMMON(3,2,0);
	MR_tfield(1, MR_tempr2, 1) = MR_tempr3;
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr3, 0) = MR_tempr1;
	MR_tfield(1, MR_tempr3, 1) = MR_tempr2;
	MR_tag_alloc_heap(MR_tempr4, 1, (MR_Integer) 2);
	MR_sv(1) = MR_tempr4;
	MR_tfield(1, MR_tempr4, 0) = MR_r2;
	MR_tfield(1, MR_tempr4, 1) = MR_tempr3;
	MR_r1 = MR_sv(7);
	}
	MR_np_call_localret_ent(fn__parse_tree__error_util__component_list_to_pieces_1_0,
		fn__check_hlds__unused_imports__generate_warning_4_0_i25);
MR_def_label(fn__check_hlds__unused_imports__generate_warning_4_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_sv(5), 1, (MR_Integer) 1);
	MR_tfield(1, MR_sv(5), 0) = MR_sv(6);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(3);
	MR_sv(3) = MR_r1;
	MR_sv(6) = (MR_Word) MR_TAG_COMMON(3,2,2);
	MR_sv(7) = (MR_Word) MR_TAG_COMMON(3,2,3);
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Word) MR_string_const(".", 1);
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		fn__check_hlds__unused_imports__generate_warning_4_0_i29);
MR_def_label(fn__check_hlds__unused_imports__generate_warning_4_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		fn__check_hlds__unused_imports__generate_warning_4_0_i30);
MR_def_label(fn__check_hlds__unused_imports__generate_warning_4_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("not used", 8);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		fn__check_hlds__unused_imports__generate_warning_4_0_i31);
MR_def_label(fn__check_hlds__unused_imports__generate_warning_4_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 4;
	MR_tfield(3, MR_tempr1, 1) = MR_r1;
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr1;
	MR_tfield(1, MR_tempr2, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tempr5 = MR_sv(5);
	MR_tfield(1, MR_tempr1, 0) = MR_tempr5;
	MR_tfield(1, MR_tempr1, 1) = MR_tempr2;
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = MR_sv(7);
	MR_tfield(1, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr3, 0) = MR_sv(6);
	MR_tfield(1, MR_tempr3, 1) = MR_tempr2;
	MR_tag_alloc_heap(MR_tempr4, 1, (MR_Integer) 2);
	MR_r3 = MR_tempr4;
	MR_tfield(1, MR_tempr4, 0) = MR_tempr5;
	MR_tfield(1, MR_tempr4, 1) = MR_tempr3;
	MR_r1 = MR_sv(8);
	MR_r2 = MR_sv(3);
	}
	MR_np_call_localret_ent(fn__f_108_105_115_116_95_95_43_43_2_0,
		fn__check_hlds__unused_imports__generate_warning_4_0_i38);
MR_def_label(fn__check_hlds__unused_imports__generate_warning_4_0,38)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(8);
	MR_r2 = MR_sv(1);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_108_105_115_116_95_95_43_43_2_0,
		fn__check_hlds__unused_imports__generate_warning_4_0_i39);
MR_def_label(fn__check_hlds__unused_imports__generate_warning_4_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 1);
	MR_tfield(0, MR_r2, 0) = MR_r1;
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_r2;
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(4);
	MR_tfield(0, MR_r2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_r2;
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_r1, 0, (MR_Integer) 3);
	MR_tfield(0, MR_r1, 0) = (MR_Word) MR_tbmkword(0, 1);
	MR_tfield(0, MR_r1, 1) = (MR_Word) MR_tbmkword(0, 12);
	MR_tfield(0, MR_r1, 2) = MR_tempr1;
	MR_decr_sp_and_return(9);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(hlds__hlds_module__module_info_get_type_table_2_0);
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_used_modules_0;
MR_decl_entry(hlds__hlds_data__foldl_over_type_ctor_defns_4_0);
MR_decl_entry(hlds__hlds_module__module_info_get_inst_table_2_0);
MR_decl_entry(hlds__hlds_data__inst_table_get_user_insts_2_0);
MR_decl_entry(hlds__hlds_data__user_inst_table_get_inst_defns_2_0);
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_inst_id_0;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_data__type_ctor_info_hlds_inst_defn_0;
MR_decl_entry(map__foldl_4_0);
MR_decl_entry(hlds__hlds_module__module_info_get_mode_table_2_0);
MR_decl_entry(hlds__hlds_data__mode_table_get_mode_defns_2_0);
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_mode_id_0;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_data__type_ctor_info_hlds_mode_defn_0;
MR_decl_entry(hlds__hlds_module__module_info_get_class_table_2_0);
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_class_id_0;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_data__type_ctor_info_hlds_class_defn_0;
MR_decl_entry(hlds__hlds_module__module_info_get_instance_table_2_0);
MR_decl_entry(hlds__hlds_module__module_info_preds_2_0);
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_pred__type_ctor_info_pred_id_0;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_pred__type_ctor_info_pred_info_0;

MR_BEGIN_MODULE(check_hlds__unused_imports_module1)
	MR_init_entry1(check_hlds__unused_imports__used_modules_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__used_modules_3_0);
	MR_init_label10(check_hlds__unused_imports__used_modules_3_0,2,4,5,6,7,9,10,11,13,14)
	MR_init_label4(check_hlds__unused_imports__used_modules_3_0,16,17,20,21)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'used_modules'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__used_modules_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_np_call_localret_ent(hlds__hlds_module__module_info_get_type_table_2_0,
		check_hlds__unused_imports__used_modules_3_0_i2);
MR_def_label(check_hlds__unused_imports__used_modules_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,1,2);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(2);
	}
	MR_np_call_localret_ent(hlds__hlds_data__foldl_over_type_ctor_defns_4_0,
		check_hlds__unused_imports__used_modules_3_0_i4);
MR_def_label(check_hlds__unused_imports__used_modules_3_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(hlds__hlds_module__module_info_get_inst_table_2_0,
		check_hlds__unused_imports__used_modules_3_0_i5);
MR_def_label(check_hlds__unused_imports__used_modules_3_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(hlds__hlds_data__inst_table_get_user_insts_2_0,
		check_hlds__unused_imports__used_modules_3_0_i6);
MR_def_label(check_hlds__unused_imports__used_modules_3_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(hlds__hlds_data__user_inst_table_get_inst_defns_2_0,
		check_hlds__unused_imports__used_modules_3_0_i7);
MR_def_label(check_hlds__unused_imports__used_modules_3_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, inst_id);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_data, hlds_inst_defn);
	MR_r3 = MR_sv(3);
	MR_r4 = (MR_Word) MR_TAG_COMMON(0,1,3);
	MR_r5 = MR_tempr1;
	MR_r6 = MR_sv(2);
	}
	MR_np_call_localret_ent(map__foldl_4_0,
		check_hlds__unused_imports__used_modules_3_0_i9);
MR_def_label(check_hlds__unused_imports__used_modules_3_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(hlds__hlds_module__module_info_get_mode_table_2_0,
		check_hlds__unused_imports__used_modules_3_0_i10);
MR_def_label(check_hlds__unused_imports__used_modules_3_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(hlds__hlds_data__mode_table_get_mode_defns_2_0,
		check_hlds__unused_imports__used_modules_3_0_i11);
MR_def_label(check_hlds__unused_imports__used_modules_3_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, mode_id);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_data, hlds_mode_defn);
	MR_r3 = MR_sv(3);
	MR_r4 = (MR_Word) MR_TAG_COMMON(0,1,4);
	MR_r5 = MR_tempr1;
	MR_r6 = MR_sv(2);
	}
	MR_np_call_localret_ent(map__foldl_4_0,
		check_hlds__unused_imports__used_modules_3_0_i13);
MR_def_label(check_hlds__unused_imports__used_modules_3_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(hlds__hlds_module__module_info_get_class_table_2_0,
		check_hlds__unused_imports__used_modules_3_0_i14);
MR_def_label(check_hlds__unused_imports__used_modules_3_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, class_id);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_data, hlds_class_defn);
	MR_r3 = MR_sv(3);
	MR_r4 = (MR_Word) MR_TAG_COMMON(0,1,5);
	MR_r5 = MR_tempr1;
	MR_r6 = MR_sv(2);
	}
	MR_np_call_localret_ent(map__foldl_4_0,
		check_hlds__unused_imports__used_modules_3_0_i16);
MR_def_label(check_hlds__unused_imports__used_modules_3_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(hlds__hlds_module__module_info_get_instance_table_2_0,
		check_hlds__unused_imports__used_modules_3_0_i17);
MR_def_label(check_hlds__unused_imports__used_modules_3_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,4,0);
	MR_r3 = MR_sv(3);
	MR_r4 = (MR_Word) MR_TAG_COMMON(0,1,6);
	MR_r5 = MR_tempr1;
	MR_r6 = MR_sv(2);
	}
	MR_np_call_localret_ent(map__foldl_4_0,
		check_hlds__unused_imports__used_modules_3_0_i20);
MR_def_label(check_hlds__unused_imports__used_modules_3_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(hlds__hlds_module__module_info_preds_2_0,
		check_hlds__unused_imports__used_modules_3_0_i21);
MR_def_label(check_hlds__unused_imports__used_modules_3_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_pred, pred_id);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_pred, pred_info);
	MR_r3 = MR_sv(3);
	MR_r4 = (MR_Word) MR_TAG_COMMON(0,1,7);
	MR_r5 = MR_tempr1;
	MR_r6 = MR_sv(1);
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(map__foldl_4_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(hlds__hlds_module__module_info_get_globals_2_0);
MR_decl_entry(hlds__hlds_module__module_info_get_name_2_0);
MR_decl_entry(parse_tree__file_names__module_name_to_file_name_7_0);
MR_decl_entry(fn__mdbcomp__prim_data__all_builtin_modules_0_0);
MR_decl_entry(hlds__hlds_module__module_info_get_used_modules_2_0);
MR_decl_entry(list__foldl_4_0);
MR_decl_entry(hlds__hlds_module__module_info_get_imported_module_specifiers_2_0);
MR_decl_entry(hlds__hlds_module__module_info_get_interface_module_specifiers_2_0);
MR_decl_entry(fn__set__union_2_0);
MR_decl_entry(fn__set__difference_2_0);
MR_decl_entry(fn__set__to_sorted_list_1_0);
MR_decl_entry(fn__set__set_1_0);

MR_BEGIN_MODULE(check_hlds__unused_imports_module2)
	MR_init_entry1(check_hlds__unused_imports__unused_imports_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__unused_imports_4_0);
	MR_init_label10(check_hlds__unused_imports__unused_imports_4_0,2,3,4,5,6,8,9,10,11,12)
	MR_init_label10(check_hlds__unused_imports__unused_imports_4_0,13,14,16,17,15,19,20,21,22,24)
	MR_init_label1(check_hlds__unused_imports__unused_imports_4_0,25)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'unused_imports'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__check_hlds__unused_imports__unused_imports_4_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_np_call_localret_ent(hlds__hlds_module__module_info_get_globals_2_0,
		check_hlds__unused_imports__unused_imports_4_0_i2);
MR_def_label(check_hlds__unused_imports__unused_imports_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(hlds__hlds_module__module_info_get_name_2_0,
		check_hlds__unused_imports__unused_imports_4_0_i3);
MR_def_label(check_hlds__unused_imports__unused_imports_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(2);
	MR_sv(2) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_sv(2);
	MR_r3 = (MR_Word) MR_string_const(".m", 2);
	MR_r4 = (MR_Integer) 1;
	}
	MR_np_call_localret_ent(parse_tree__file_names__module_name_to_file_name_7_0,
		check_hlds__unused_imports__unused_imports_4_0_i4);
MR_def_label(check_hlds__unused_imports__unused_imports_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_np_call_localret_ent(fn__mdbcomp__prim_data__all_builtin_modules_0_0,
		check_hlds__unused_imports__unused_imports_4_0_i5);
MR_def_label(check_hlds__unused_imports__unused_imports_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(hlds__hlds_module__module_info_get_used_modules_2_0,
		check_hlds__unused_imports__unused_imports_4_0_i6);
MR_def_label(check_hlds__unused_imports__unused_imports_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(6) = (MR_Word) MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,5,0);
	MR_r4 = MR_sv(4);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__foldl_4_0,
		check_hlds__unused_imports__unused_imports_4_0_i8);
MR_def_label(check_hlds__unused_imports__unused_imports_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(check_hlds__unused_imports__used_modules_3_0,
		check_hlds__unused_imports__unused_imports_4_0_i9);
MR_def_label(check_hlds__unused_imports__unused_imports_4_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(hlds__hlds_module__module_info_get_imported_module_specifiers_2_0,
		check_hlds__unused_imports__unused_imports_4_0_i10);
MR_def_label(check_hlds__unused_imports__unused_imports_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_sv(5) = MR_tfield(0, MR_sv(4), 1);
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(hlds__hlds_module__module_info_get_interface_module_specifiers_2_0,
		check_hlds__unused_imports__unused_imports_4_0_i11);
MR_def_label(check_hlds__unused_imports__unused_imports_4_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_tfield(0, MR_sv(4), 0);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(5);
	MR_sv(5) = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(4);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__set__union_2_0,
		check_hlds__unused_imports__unused_imports_4_0_i12);
MR_def_label(check_hlds__unused_imports__unused_imports_4_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(1);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__set__difference_2_0,
		check_hlds__unused_imports__unused_imports_4_0_i13);
MR_def_label(check_hlds__unused_imports__unused_imports_4_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__set__to_sorted_list_1_0,
		check_hlds__unused_imports__unused_imports_4_0_i14);
MR_def_label(check_hlds__unused_imports__unused_imports_4_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(check_hlds__unused_imports__unused_imports_4_0_i16);
	}
	MR_sv(1) = MR_r1;
	MR_r3 = MR_sv(4);
	MR_r2 = MR_sv(5);
	MR_sv(4) = (MR_Word) MR_tbmkword(0, 0);
	MR_r1 = MR_sv(6);
	MR_GOTO_LAB(check_hlds__unused_imports__unused_imports_4_0_i15);
MR_def_label(check_hlds__unused_imports__unused_imports_4_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(3);
	MR_r3 = MR_sv(1);
	MR_r4 = (MR_Word) MR_string_const("", 0);
	MR_np_call_localret_ent(fn__check_hlds__unused_imports__generate_warning_4_0,
		check_hlds__unused_imports__unused_imports_4_0_i17);
MR_def_label(check_hlds__unused_imports__unused_imports_4_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_r1;
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_r3 = MR_sv(4);
	MR_r2 = MR_sv(5);
	MR_sv(4) = MR_tempr1;
	MR_r1 = MR_sv(6);
	}
MR_def_label(check_hlds__unused_imports__unused_imports_4_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(6) = MR_r1;
	MR_np_call_localret_ent(fn__set__difference_2_0,
		check_hlds__unused_imports__unused_imports_4_0_i19);
MR_def_label(check_hlds__unused_imports__unused_imports_4_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__set__set_1_0,
		check_hlds__unused_imports__unused_imports_4_0_i20);
MR_def_label(check_hlds__unused_imports__unused_imports_4_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(1);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__set__difference_2_0,
		check_hlds__unused_imports__unused_imports_4_0_i21);
MR_def_label(check_hlds__unused_imports__unused_imports_4_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__set__to_sorted_list_1_0,
		check_hlds__unused_imports__unused_imports_4_0_i22);
MR_def_label(check_hlds__unused_imports__unused_imports_4_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(check_hlds__unused_imports__unused_imports_4_0_i24);
	}
	MR_r1 = MR_sv(4);
	MR_decr_sp_and_return(7);
MR_def_label(check_hlds__unused_imports__unused_imports_4_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(3);
	MR_r3 = MR_tempr1;
	MR_r4 = (MR_Word) MR_string_const(" interface", 10);
	}
	MR_np_call_localret_ent(fn__check_hlds__unused_imports__generate_warning_4_0,
		check_hlds__unused_imports__unused_imports_4_0_i25);
MR_def_label(check_hlds__unused_imports__unused_imports_4_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_r1;
	MR_tfield(1, MR_tempr1, 1) = MR_sv(4);
	MR_r1 = MR_tempr1;
	MR_decr_sp_and_return(7);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(check_hlds__unused_imports_module3)
	MR_init_entry1(fn__check_hlds__unused_imports__wrap_module_name_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__check_hlds__unused_imports__wrap_module_name_1_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'wrap_module_name'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__check_hlds__unused_imports__wrap_module_name_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 3, (MR_Integer) 2);
	MR_tfield(3, MR_r2, 0) = (MR_Integer) 5;
	MR_tfield(3, MR_r2, 1) = MR_r1;
	MR_r1 = MR_r2;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(check_hlds__unused_imports_module4)
	MR_init_entry1(check_hlds__unused_imports__mer_type_used_modules_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__mer_type_used_modules_4_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'mer_type_used_modules'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__mer_type_used_modules_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(check_hlds__unused_imports__mer_type_used_modules_2_4_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(parse_tree__prog_data__add_sym_name_module_4_0);
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_mer_type_0;

MR_BEGIN_MODULE(check_hlds__unused_imports_module5)
	MR_init_entry1(check_hlds__unused_imports__mer_type_used_modules_2_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__mer_type_used_modules_2_4_0);
	MR_init_label10(check_hlds__unused_imports__mer_type_used_modules_2_4_0,51,3,5,4,8,9,14,12,18,59)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'mer_type_used_modules_2'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__mer_type_used_modules_2_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
MR_def_label(check_hlds__unused_imports__mer_type_used_modules_2_4_0,51)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,2)) {
		MR_GOTO_LAB(check_hlds__unused_imports__mer_type_used_modules_2_4_0_i3);
	}
	MR_r1 = MR_r3;
	MR_decr_sp_and_return(3);
MR_def_label(check_hlds__unused_imports__mer_type_used_modules_2_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,1)) {
		MR_GOTO_LAB(check_hlds__unused_imports__mer_type_used_modules_2_4_0_i4);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(1, MR_r2, 1);
	MR_r2 = MR_tfield(1, MR_r2, 0);
	MR_np_call_localret_ent(parse_tree__prog_data__add_sym_name_module_4_0,
		check_hlds__unused_imports__mer_type_used_modules_2_4_0_i5);
MR_def_label(check_hlds__unused_imports__mer_type_used_modules_2_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,7);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__mer_type_used_modules_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tempr2 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, mer_type);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_r4 = MR_sv(2);
	MR_r5 = MR_tempr2;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
MR_def_label(check_hlds__unused_imports__mer_type_used_modules_2_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,0)) {
		MR_GOTO_LAB(check_hlds__unused_imports__mer_type_used_modules_2_4_0_i8);
	}
	MR_r1 = MR_r3;
	MR_decr_sp_and_return(3);
MR_def_label(check_hlds__unused_imports__mer_type_used_modules_2_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,2)) {
		MR_GOTO_LAB(check_hlds__unused_imports__mer_type_used_modules_2_4_0_i9);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,8);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__mer_type_used_modules_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, mer_type);
	MR_tempr2 = MR_r2;
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_tempr3 = MR_r3;
	MR_r3 = MR_tempr1;
	MR_r4 = MR_tfield(3, MR_tempr2, 2);
	MR_r5 = MR_tempr3;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
MR_def_label(check_hlds__unused_imports__mer_type_used_modules_2_4_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,1)) {
		MR_GOTO_LAB(check_hlds__unused_imports__mer_type_used_modules_2_4_0_i12);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,9);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__mer_type_used_modules_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(3, MR_r2, 2);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, mer_type);
	MR_tempr2 = MR_r2;
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_tempr3 = MR_r3;
	MR_r3 = MR_tempr1;
	MR_r4 = MR_tfield(3, MR_tempr2, 1);
	MR_r5 = MR_tempr3;
	}
	MR_np_call_localret_ent(list__foldl_4_0,
		check_hlds__unused_imports__mer_type_used_modules_2_4_0_i14);
MR_def_label(check_hlds__unused_imports__mer_type_used_modules_2_4_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_sv(2),0,0)) {
		MR_GOTO_LAB(check_hlds__unused_imports__mer_type_used_modules_2_4_0_i59);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tfield(1, MR_sv(2), 0);
	MR_r3 = MR_tempr1;
	MR_succip_word = MR_sv(3);
	MR_GOTO_LAB(check_hlds__unused_imports__mer_type_used_modules_2_4_0_i51);
	}
MR_def_label(check_hlds__unused_imports__mer_type_used_modules_2_4_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,3)) {
		MR_GOTO_LAB(check_hlds__unused_imports__mer_type_used_modules_2_4_0_i18);
	}
	MR_r2 = MR_tfield(3, MR_r2, 1);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(check_hlds__unused_imports__mer_type_used_modules_4_0);
MR_def_label(check_hlds__unused_imports__mer_type_used_modules_2_4_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,10);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__mer_type_used_modules_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, mer_type);
	MR_tempr2 = MR_r2;
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_tempr3 = MR_r3;
	MR_r3 = MR_tempr1;
	MR_r4 = MR_tfield(3, MR_tempr2, 1);
	MR_r5 = MR_tempr3;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
MR_def_label(check_hlds__unused_imports__mer_type_used_modules_2_4_0,59)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(3);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(check_hlds__unused_imports_module6)
	MR_init_entry1(check_hlds__unused_imports__type_used_modules_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__type_used_modules_4_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'type_used_modules'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__type_used_modules_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_np_tailcall_ent(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_prog_constraint_0;
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_constructor_arg_0;

MR_BEGIN_MODULE(check_hlds__unused_imports_module7)
	MR_init_entry1(check_hlds__unused_imports__ctor_used_modules_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__ctor_used_modules_4_0);
	MR_init_label1(check_hlds__unused_imports__ctor_used_modules_4_0,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'ctor_used_modules'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__ctor_used_modules_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,11);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__prog_constraint_used_module_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(0, MR_r2, 3);
	MR_sv(3) = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, prog_constraint);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_sv(3);
	MR_tempr3 = MR_r3;
	MR_r3 = MR_tempr1;
	MR_r4 = MR_tfield(0, MR_tempr2, 1);
	MR_r5 = MR_tempr3;
	}
	MR_np_call_localret_ent(list__foldl_4_0,
		check_hlds__unused_imports__ctor_used_modules_4_0_i3);
MR_def_label(check_hlds__unused_imports__ctor_used_modules_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,12);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__IntroducedFrom__pred__ctor_used_modules__225__1_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tempr2 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, constructor_arg);
	MR_r2 = MR_sv(3);
	MR_r4 = MR_sv(2);
	MR_r5 = MR_tempr2;
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(check_hlds__unused_imports_module8)
	MR_init_entry1(check_hlds__unused_imports__prog_constraint_used_module_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__prog_constraint_used_module_4_0);
	MR_init_label1(check_hlds__unused_imports__prog_constraint_used_module_4_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'prog_constraint_used_module'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__prog_constraint_used_module_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(0, MR_r2, 1);
	MR_r2 = MR_tfield(0, MR_r2, 0);
	MR_np_call_localret_ent(parse_tree__prog_data__add_sym_name_module_4_0,
		check_hlds__unused_imports__prog_constraint_used_module_4_0_i2);
MR_def_label(check_hlds__unused_imports__prog_constraint_used_module_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,13);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__mer_type_used_modules_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tempr2 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, mer_type);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_r4 = MR_sv(2);
	MR_r5 = MR_tempr2;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_mer_mode_0;

MR_BEGIN_MODULE(check_hlds__unused_imports_module9)
	MR_init_entry1(check_hlds__unused_imports__ho_inst_info_used_modules_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__ho_inst_info_used_modules_4_0);
	MR_init_label1(check_hlds__unused_imports__ho_inst_info_used_modules_4_0,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'ho_inst_info_used_modules'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__ho_inst_info_used_modules_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(check_hlds__unused_imports__ho_inst_info_used_modules_4_0_i3);
	}
	MR_r1 = MR_r3;
	MR_proceed();
MR_def_label(check_hlds__unused_imports__ho_inst_info_used_modules_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,14);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__mer_mode_used_modules_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, mer_mode);
	MR_tempr2 = MR_r2;
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_tempr3 = MR_r3;
	MR_r3 = MR_tempr1;
	MR_r4 = MR_tfield(0, MR_tfield(1, MR_tempr2, 0), 1);
	MR_r5 = MR_tempr3;
	MR_np_tailcall_ent(list__foldl_4_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_mer_inst_0;
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_bound_inst_0;

MR_BEGIN_MODULE(check_hlds__unused_imports_module10)
	MR_init_entry1(check_hlds__unused_imports__mer_inst_used_modules_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__mer_inst_used_modules_4_0);
	MR_init_label10(check_hlds__unused_imports__mer_inst_used_modules_4_0,65,3,32,4,5,7,10,9,13,16)
	MR_init_label1(check_hlds__unused_imports__mer_inst_used_modules_4_0,18)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'mer_inst_used_modules'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__mer_inst_used_modules_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
MR_def_label(check_hlds__unused_imports__mer_inst_used_modules_4_0,65)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(check_hlds__unused_imports__mer_inst_used_modules_4_0_i3);
	}
	MR_r1 = MR_r3;
	MR_decr_sp_and_return(3);
MR_def_label(check_hlds__unused_imports__mer_inst_used_modules_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,1)) {
		MR_GOTO_LAB(check_hlds__unused_imports__mer_inst_used_modules_4_0_i4);
	}
MR_def_label(check_hlds__unused_imports__mer_inst_used_modules_4_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r3;
	MR_decr_sp_and_return(3);
MR_def_label(check_hlds__unused_imports__mer_inst_used_modules_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,2)) {
		MR_GOTO_LAB(check_hlds__unused_imports__mer_inst_used_modules_4_0_i5);
	}
	MR_r2 = MR_tfield(2, MR_r2, 1);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(check_hlds__unused_imports__ho_inst_info_used_modules_4_0);
MR_def_label(check_hlds__unused_imports__mer_inst_used_modules_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,1)) {
		MR_GOTO_LAB(check_hlds__unused_imports__mer_inst_used_modules_4_0_i7);
	}
	MR_r2 = MR_tfield(1, MR_r2, 0);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(check_hlds__unused_imports__mer_type_used_modules_2_4_0);
MR_def_label(check_hlds__unused_imports__mer_inst_used_modules_4_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,5)) {
		MR_GOTO_LAB(check_hlds__unused_imports__mer_inst_used_modules_4_0_i9);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(3, MR_r2, 2);
	MR_r2 = MR_tfield(3, MR_r2, 1);
	MR_np_call_localret_ent(parse_tree__prog_data__add_sym_name_module_4_0,
		check_hlds__unused_imports__mer_inst_used_modules_4_0_i10);
MR_def_label(check_hlds__unused_imports__mer_inst_used_modules_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,15);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__mer_inst_used_modules_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tempr2 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, mer_inst);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_r4 = MR_sv(2);
	MR_r5 = MR_tempr2;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
MR_def_label(check_hlds__unused_imports__mer_inst_used_modules_4_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,0)) {
		MR_GOTO_LAB(check_hlds__unused_imports__mer_inst_used_modules_4_0_i13);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,16);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__bound_inst_info_used_modules_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, bound_inst);
	MR_tempr2 = MR_r2;
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_tempr3 = MR_r3;
	MR_r3 = MR_tempr1;
	MR_r4 = MR_tfield(3, MR_tempr2, 2);
	MR_r5 = MR_tempr3;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
MR_def_label(check_hlds__unused_imports__mer_inst_used_modules_4_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,3)) {
		MR_GOTO_LAB(check_hlds__unused_imports__mer_inst_used_modules_4_0_i16);
	}
	MR_r2 = MR_tfield(3, MR_r2, 2);
	MR_succip_word = MR_sv(3);
	MR_GOTO_LAB(check_hlds__unused_imports__mer_inst_used_modules_4_0_i65);
MR_def_label(check_hlds__unused_imports__mer_inst_used_modules_4_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,4)) {
		MR_GOTO_LAB(check_hlds__unused_imports__mer_inst_used_modules_4_0_i18);
	}
	MR_r2 = MR_tfield(3, MR_r2, 1);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(check_hlds__unused_imports__inst_name_used_modules_4_0);
MR_def_label(check_hlds__unused_imports__mer_inst_used_modules_4_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,1)) {
		MR_GOTO_LAB(check_hlds__unused_imports__mer_inst_used_modules_4_0_i32);
	}
	MR_r2 = MR_tfield(3, MR_r2, 2);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(check_hlds__unused_imports__ho_inst_info_used_modules_4_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(check_hlds__unused_imports_module11)
	MR_init_entry1(check_hlds__unused_imports__inst_name_used_modules_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__inst_name_used_modules_4_0);
	MR_init_label10(check_hlds__unused_imports__inst_name_used_modules_4_0,66,3,7,6,10,9,13,15,17,19)
	MR_init_label2(check_hlds__unused_imports__inst_name_used_modules_4_0,21,23)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'inst_name_used_modules'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__inst_name_used_modules_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
MR_def_label(check_hlds__unused_imports__inst_name_used_modules_4_0,66)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,1)) {
		MR_GOTO_LAB(check_hlds__unused_imports__inst_name_used_modules_4_0_i3);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(1, MR_r2, 1);
	MR_r2 = MR_tfield(1, MR_r2, 0);
	MR_np_call_localret_ent(check_hlds__unused_imports__mer_inst_used_modules_4_0,
		check_hlds__unused_imports__inst_name_used_modules_4_0_i7);
MR_def_label(check_hlds__unused_imports__inst_name_used_modules_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,2)) {
		MR_GOTO_LAB(check_hlds__unused_imports__inst_name_used_modules_4_0_i6);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(2, MR_r2, 2);
	MR_r2 = MR_tfield(2, MR_r2, 1);
	MR_np_call_localret_ent(check_hlds__unused_imports__mer_inst_used_modules_4_0,
		check_hlds__unused_imports__inst_name_used_modules_4_0_i7);
MR_def_label(check_hlds__unused_imports__inst_name_used_modules_4_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_tempr1;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(check_hlds__unused_imports__mer_inst_used_modules_4_0);
	}
MR_def_label(check_hlds__unused_imports__inst_name_used_modules_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,0)) {
		MR_GOTO_LAB(check_hlds__unused_imports__inst_name_used_modules_4_0_i9);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(0, MR_r2, 1);
	MR_r2 = MR_tfield(0, MR_r2, 0);
	MR_np_call_localret_ent(parse_tree__prog_data__add_sym_name_module_4_0,
		check_hlds__unused_imports__inst_name_used_modules_4_0_i10);
MR_def_label(check_hlds__unused_imports__inst_name_used_modules_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,17);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__mer_inst_used_modules_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tempr2 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, mer_inst);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_r4 = MR_sv(2);
	MR_r5 = MR_tempr2;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
MR_def_label(check_hlds__unused_imports__inst_name_used_modules_4_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,1)) {
		MR_GOTO_LAB(check_hlds__unused_imports__inst_name_used_modules_4_0_i13);
	}
	MR_r2 = MR_tfield(3, MR_r2, 1);
	MR_succip_word = MR_sv(3);
	MR_GOTO_LAB(check_hlds__unused_imports__inst_name_used_modules_4_0_i66);
MR_def_label(check_hlds__unused_imports__inst_name_used_modules_4_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,0)) {
		MR_GOTO_LAB(check_hlds__unused_imports__inst_name_used_modules_4_0_i15);
	}
	MR_r2 = MR_tfield(3, MR_r2, 1);
	MR_succip_word = MR_sv(3);
	MR_GOTO_LAB(check_hlds__unused_imports__inst_name_used_modules_4_0_i66);
MR_def_label(check_hlds__unused_imports__inst_name_used_modules_4_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,3)) {
		MR_GOTO_LAB(check_hlds__unused_imports__inst_name_used_modules_4_0_i17);
	}
	MR_r2 = MR_tfield(3, MR_r2, 1);
	MR_succip_word = MR_sv(3);
	MR_GOTO_LAB(check_hlds__unused_imports__inst_name_used_modules_4_0_i66);
MR_def_label(check_hlds__unused_imports__inst_name_used_modules_4_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,2)) {
		MR_GOTO_LAB(check_hlds__unused_imports__inst_name_used_modules_4_0_i19);
	}
	MR_r2 = MR_tfield(3, MR_r2, 1);
	MR_succip_word = MR_sv(3);
	MR_GOTO_LAB(check_hlds__unused_imports__inst_name_used_modules_4_0_i66);
MR_def_label(check_hlds__unused_imports__inst_name_used_modules_4_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,4)) {
		MR_GOTO_LAB(check_hlds__unused_imports__inst_name_used_modules_4_0_i21);
	}
	MR_r2 = MR_tfield(3, MR_r2, 2);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(check_hlds__unused_imports__mer_type_used_modules_4_0);
MR_def_label(check_hlds__unused_imports__inst_name_used_modules_4_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(3, MR_r2, 2);
	MR_r2 = MR_tfield(3, MR_r2, 1);
	MR_np_call_localret_ent(check_hlds__unused_imports__mer_type_used_modules_4_0,
		check_hlds__unused_imports__inst_name_used_modules_4_0_i23);
MR_def_label(check_hlds__unused_imports__inst_name_used_modules_4_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_tempr1;
	MR_succip_word = MR_sv(3);
	MR_GOTO_LAB(check_hlds__unused_imports__inst_name_used_modules_4_0_i66);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(check_hlds__unused_imports_module12)
	MR_init_entry1(check_hlds__unused_imports__user_inst_used_modules_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__user_inst_used_modules_4_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'user_inst_used_modules'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__user_inst_used_modules_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_np_tailcall_ent(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_105_110_115_116_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(check_hlds__unused_imports_module13)
	MR_init_entry1(check_hlds__unused_imports__mer_mode_used_modules_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__mer_mode_used_modules_4_0);
	MR_init_label3(check_hlds__unused_imports__mer_mode_used_modules_4_0,4,3,6)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'mer_mode_used_modules'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__mer_mode_used_modules_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	if (MR_PTAG_TESTR(MR_r2,0)) {
		MR_GOTO_LAB(check_hlds__unused_imports__mer_mode_used_modules_4_0_i3);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(0, MR_r2, 1);
	MR_r2 = MR_tfield(0, MR_r2, 0);
	MR_np_call_localret_ent(check_hlds__unused_imports__mer_inst_used_modules_4_0,
		check_hlds__unused_imports__mer_mode_used_modules_4_0_i4);
MR_def_label(check_hlds__unused_imports__mer_mode_used_modules_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_tempr1;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(check_hlds__unused_imports__mer_inst_used_modules_4_0);
	}
MR_def_label(check_hlds__unused_imports__mer_mode_used_modules_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(1, MR_r2, 1);
	MR_r2 = MR_tfield(1, MR_r2, 0);
	MR_np_call_localret_ent(parse_tree__prog_data__add_sym_name_module_4_0,
		check_hlds__unused_imports__mer_mode_used_modules_4_0_i6);
MR_def_label(check_hlds__unused_imports__mer_mode_used_modules_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,18);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__mer_inst_used_modules_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tempr2 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, mer_inst);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_r4 = MR_sv(2);
	MR_r5 = MR_tempr2;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__hlds__hlds_pred__status_defined_in_this_module_1_0);
MR_decl_entry(fn__hlds__hlds_pred__status_is_exported_to_non_submodules_1_0);

MR_BEGIN_MODULE(check_hlds__unused_imports_module14)
	MR_init_entry1(check_hlds__unused_imports__mode_used_modules_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__mode_used_modules_4_0);
	MR_init_label6(check_hlds__unused_imports__mode_used_modules_4_0,2,4,6,5,8,9)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'mode_used_modules'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__mode_used_modules_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_tfield(0, MR_r1, 0);
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_tfield(0, MR_r2, 4);
	MR_sv(4) = MR_r3;
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(fn__hlds__hlds_pred__status_defined_in_this_module_1_0,
		check_hlds__unused_imports__mode_used_modules_4_0_i2);
MR_def_label(check_hlds__unused_imports__mode_used_modules_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(check_hlds__unused_imports__mode_used_modules_4_0_i4);
	}
	MR_r1 = MR_sv(4);
	MR_decr_sp_and_return(5);
MR_def_label(check_hlds__unused_imports__mode_used_modules_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(fn__hlds__hlds_pred__status_is_exported_to_non_submodules_1_0,
		check_hlds__unused_imports__mode_used_modules_4_0_i6);
MR_def_label(check_hlds__unused_imports__mode_used_modules_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,1)) {
		MR_GOTO_LAB(check_hlds__unused_imports__mode_used_modules_4_0_i5);
	}
	MR_r2 = MR_sv(1);
	MR_r1 = (MR_Integer) 0;
	MR_r3 = MR_sv(4);
	MR_GOTO_LAB(check_hlds__unused_imports__mode_used_modules_4_0_i8);
MR_def_label(check_hlds__unused_imports__mode_used_modules_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_r1 = (MR_Integer) 1;
	MR_r3 = MR_sv(4);
MR_def_label(check_hlds__unused_imports__mode_used_modules_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_np_call_localret_ent(parse_tree__prog_data__add_sym_name_module_4_0,
		check_hlds__unused_imports__mode_used_modules_4_0_i9);
MR_def_label(check_hlds__unused_imports__mode_used_modules_4_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tfield(0, MR_sv(2), 2);
	MR_r3 = MR_tempr1;
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(check_hlds__unused_imports__mer_mode_used_modules_4_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(check_hlds__unused_imports_module15)
	MR_init_entry1(check_hlds__unused_imports__class_used_modules_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__class_used_modules_4_0);
	MR_init_label6(check_hlds__unused_imports__class_used_modules_4_0,2,4,6,5,8,9)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'class_used_modules'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__class_used_modules_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_tfield(0, MR_r1, 0);
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_tfield(0, MR_r2, 0);
	MR_sv(4) = MR_r3;
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(fn__hlds__hlds_pred__status_defined_in_this_module_1_0,
		check_hlds__unused_imports__class_used_modules_4_0_i2);
MR_def_label(check_hlds__unused_imports__class_used_modules_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(check_hlds__unused_imports__class_used_modules_4_0_i4);
	}
	MR_r1 = MR_sv(4);
	MR_decr_sp_and_return(5);
MR_def_label(check_hlds__unused_imports__class_used_modules_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(fn__hlds__hlds_pred__status_is_exported_to_non_submodules_1_0,
		check_hlds__unused_imports__class_used_modules_4_0_i6);
MR_def_label(check_hlds__unused_imports__class_used_modules_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,1)) {
		MR_GOTO_LAB(check_hlds__unused_imports__class_used_modules_4_0_i5);
	}
	MR_r2 = MR_sv(1);
	MR_r1 = (MR_Integer) 0;
	MR_r3 = MR_sv(4);
	MR_GOTO_LAB(check_hlds__unused_imports__class_used_modules_4_0_i8);
MR_def_label(check_hlds__unused_imports__class_used_modules_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_r1 = (MR_Integer) 1;
	MR_r3 = MR_sv(4);
MR_def_label(check_hlds__unused_imports__class_used_modules_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_np_call_localret_ent(parse_tree__prog_data__add_sym_name_module_4_0,
		check_hlds__unused_imports__class_used_modules_4_0_i9);
MR_def_label(check_hlds__unused_imports__class_used_modules_4_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,19);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__prog_constraint_used_module_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tempr2 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, prog_constraint);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_r4 = MR_tfield(0, MR_sv(2), 1);
	MR_r5 = MR_tempr2;
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(check_hlds__unused_imports_module16)
	MR_init_entry1(check_hlds__unused_imports__instance_used_modules_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__instance_used_modules_4_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'instance_used_modules'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__instance_used_modules_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,20);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__instance_used_modules_2_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_data, hlds_instance_defn);
	MR_tempr2 = MR_r2;
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_tempr3 = MR_r3;
	MR_r3 = MR_tempr1;
	MR_r4 = MR_tempr2;
	MR_r5 = MR_tempr3;
	MR_np_tailcall_ent(list__foldl_4_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(check_hlds__unused_imports_module17)
	MR_init_entry1(check_hlds__unused_imports__instance_used_modules_2_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__instance_used_modules_2_4_0);
	MR_init_label7(check_hlds__unused_imports__instance_used_modules_2_4_0,2,4,6,5,8,9,11)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'instance_used_modules_2'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__instance_used_modules_2_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_tfield(0, MR_r1, 0);
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_tfield(0, MR_r2, 1);
	MR_sv(4) = MR_r3;
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(fn__hlds__hlds_pred__status_defined_in_this_module_1_0,
		check_hlds__unused_imports__instance_used_modules_2_4_0_i2);
MR_def_label(check_hlds__unused_imports__instance_used_modules_2_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(check_hlds__unused_imports__instance_used_modules_2_4_0_i4);
	}
	MR_r1 = MR_sv(4);
	MR_decr_sp_and_return(5);
MR_def_label(check_hlds__unused_imports__instance_used_modules_2_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(fn__hlds__hlds_pred__status_is_exported_to_non_submodules_1_0,
		check_hlds__unused_imports__instance_used_modules_2_4_0_i6);
MR_def_label(check_hlds__unused_imports__instance_used_modules_2_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,1)) {
		MR_GOTO_LAB(check_hlds__unused_imports__instance_used_modules_2_4_0_i5);
	}
	MR_r2 = MR_sv(1);
	MR_r1 = (MR_Integer) 0;
	MR_r3 = MR_sv(4);
	MR_GOTO_LAB(check_hlds__unused_imports__instance_used_modules_2_4_0_i8);
MR_def_label(check_hlds__unused_imports__instance_used_modules_2_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_r1 = (MR_Integer) 1;
	MR_r3 = MR_sv(4);
MR_def_label(check_hlds__unused_imports__instance_used_modules_2_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_np_call_localret_ent(parse_tree__prog_data__add_sym_name_module_4_0,
		check_hlds__unused_imports__instance_used_modules_2_4_0_i9);
MR_def_label(check_hlds__unused_imports__instance_used_modules_2_4_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,21);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__prog_constraint_used_module_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_sv(3) = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_tempr2 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, prog_constraint);
	MR_r2 = MR_sv(3);
	MR_r4 = MR_tfield(0, MR_sv(2), 3);
	MR_r5 = MR_tempr2;
	}
	MR_np_call_localret_ent(list__foldl_4_0,
		check_hlds__unused_imports__instance_used_modules_2_4_0_i11);
MR_def_label(check_hlds__unused_imports__instance_used_modules_2_4_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,22);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__mer_type_used_modules_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tempr2 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, mer_type);
	MR_r2 = MR_sv(3);
	MR_r4 = MR_tfield(0, MR_sv(2), 4);
	MR_r5 = MR_tempr2;
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(check_hlds__unused_imports_module18)
	MR_init_entry1(check_hlds__unused_imports__pred_info_used_modules_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__pred_info_used_modules_4_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'pred_info_used_modules'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__pred_info_used_modules_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_np_tailcall_ent(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(check_hlds__unused_imports_module19)
	MR_init_entry1(check_hlds__unused_imports__proc_info_used_modules_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__proc_info_used_modules_5_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'proc_info_used_modules'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__proc_info_used_modules_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_r3;
	MR_r3 = MR_r4;
	MR_np_tailcall_ent(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_99_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_50_93_95_48_5_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(check_hlds__unused_imports_module20)
	MR_init_entry1(check_hlds__unused_imports__cons_id_used_modules_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__cons_id_used_modules_4_0);
	MR_init_label10(check_hlds__unused_imports__cons_id_used_modules_4_0,3,4,6,7,9,10,11,12,13,14)
	MR_init_label4(check_hlds__unused_imports__cons_id_used_modules_4_0,15,16,17,18)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'cons_id_used_modules'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__cons_id_used_modules_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(check_hlds__unused_imports__cons_id_used_modules_4_0_i3);
	}
	MR_r1 = MR_r3;
	MR_proceed();
MR_def_label(check_hlds__unused_imports__cons_id_used_modules_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,1)) {
		MR_GOTO_LAB(check_hlds__unused_imports__cons_id_used_modules_4_0_i4);
	}
	MR_r2 = MR_tfield(1, MR_r2, 0);
	MR_np_tailcall_ent(parse_tree__prog_data__add_sym_name_module_4_0);
MR_def_label(check_hlds__unused_imports__cons_id_used_modules_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,2)) {
		MR_GOTO_LAB(check_hlds__unused_imports__cons_id_used_modules_4_0_i6);
	}
	MR_r1 = MR_r3;
	MR_proceed();
MR_def_label(check_hlds__unused_imports__cons_id_used_modules_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,7)) {
		MR_GOTO_LAB(check_hlds__unused_imports__cons_id_used_modules_4_0_i7);
	}
	MR_r2 = MR_tfield(3, MR_r2, 1);
	MR_np_tailcall_ent(parse_tree__prog_data__add_all_modules_4_0);
MR_def_label(check_hlds__unused_imports__cons_id_used_modules_4_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,3)) {
		MR_GOTO_LAB(check_hlds__unused_imports__cons_id_used_modules_4_0_i9);
	}
	MR_r1 = MR_r3;
	MR_proceed();
MR_def_label(check_hlds__unused_imports__cons_id_used_modules_4_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,0)) {
		MR_GOTO_LAB(check_hlds__unused_imports__cons_id_used_modules_4_0_i10);
	}
	MR_r1 = MR_r3;
	MR_proceed();
MR_def_label(check_hlds__unused_imports__cons_id_used_modules_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,11)) {
		MR_GOTO_LAB(check_hlds__unused_imports__cons_id_used_modules_4_0_i11);
	}
	MR_r1 = MR_r3;
	MR_proceed();
MR_def_label(check_hlds__unused_imports__cons_id_used_modules_4_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,2)) {
		MR_GOTO_LAB(check_hlds__unused_imports__cons_id_used_modules_4_0_i12);
	}
	MR_r1 = MR_r3;
	MR_proceed();
MR_def_label(check_hlds__unused_imports__cons_id_used_modules_4_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,5)) {
		MR_GOTO_LAB(check_hlds__unused_imports__cons_id_used_modules_4_0_i13);
	}
	MR_r1 = MR_r3;
	MR_proceed();
MR_def_label(check_hlds__unused_imports__cons_id_used_modules_4_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,1)) {
		MR_GOTO_LAB(check_hlds__unused_imports__cons_id_used_modules_4_0_i14);
	}
	MR_r1 = MR_r3;
	MR_proceed();
MR_def_label(check_hlds__unused_imports__cons_id_used_modules_4_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,4)) {
		MR_GOTO_LAB(check_hlds__unused_imports__cons_id_used_modules_4_0_i15);
	}
	MR_r1 = MR_r3;
	MR_proceed();
MR_def_label(check_hlds__unused_imports__cons_id_used_modules_4_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,10)) {
		MR_GOTO_LAB(check_hlds__unused_imports__cons_id_used_modules_4_0_i16);
	}
	MR_r1 = MR_r3;
	MR_proceed();
MR_def_label(check_hlds__unused_imports__cons_id_used_modules_4_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,9)) {
		MR_GOTO_LAB(check_hlds__unused_imports__cons_id_used_modules_4_0_i17);
	}
	MR_r1 = MR_r3;
	MR_proceed();
MR_def_label(check_hlds__unused_imports__cons_id_used_modules_4_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,6)) {
		MR_GOTO_LAB(check_hlds__unused_imports__cons_id_used_modules_4_0_i18);
	}
	MR_r2 = MR_tfield(3, MR_r2, 1);
	MR_np_tailcall_ent(parse_tree__prog_data__add_all_modules_4_0);
MR_def_label(check_hlds__unused_imports__cons_id_used_modules_4_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_tfield(0, MR_tfield(3, MR_r2, 1), 0);
	MR_np_tailcall_ent(parse_tree__prog_data__add_sym_name_module_4_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_goal__type_ctor_info_hlds_goal_0;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_goal__type_ctor_info_case_0;

MR_BEGIN_MODULE(check_hlds__unused_imports_module21)
	MR_init_entry1(check_hlds__unused_imports__hlds_goal_used_modules_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__hlds_goal_used_modules_3_0);
	MR_init_label10(check_hlds__unused_imports__hlds_goal_used_modules_3_0,127,5,7,6,3,10,12,47,14,15)
	MR_init_label10(check_hlds__unused_imports__hlds_goal_used_modules_3_0,18,22,23,21,25,27,32,31,36,35)
	MR_init_label1(check_hlds__unused_imports__hlds_goal_used_modules_3_0,29)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'hlds_goal_used_modules'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__hlds_goal_used_modules_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
MR_def_label(check_hlds__unused_imports__hlds_goal_used_modules_3_0,127)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(0, MR_r1, 0);
	MR_r3 = MR_tempr1;
	if (MR_PTAG_TESTR(MR_tempr1,2)) {
		MR_GOTO_LAB(check_hlds__unused_imports__hlds_goal_used_modules_3_0_i3);
	}
	MR_r6 = MR_tfield(2, MR_tempr1, 0);
	if (MR_PTAG_TESTR(MR_r6,3)) {
		MR_GOTO_LAB(check_hlds__unused_imports__hlds_goal_used_modules_3_0_i5);
	}
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(3);
	}
MR_def_label(check_hlds__unused_imports__hlds_goal_used_modules_3_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r6,1)) {
		MR_GOTO_LAB(check_hlds__unused_imports__hlds_goal_used_modules_3_0_i6);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_r6;
	MR_sv(1) = MR_tfield(1, MR_tempr2, 3);
	MR_r1 = (MR_Integer) 1;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_tfield(0, MR_tfield(1, MR_tempr2, 2), 0);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(parse_tree__prog_data__add_sym_name_module_4_0,
		check_hlds__unused_imports__hlds_goal_used_modules_3_0_i7);
MR_def_label(check_hlds__unused_imports__hlds_goal_used_modules_3_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Integer) 1;
	MR_r2 = MR_tfield(0, MR_sv(1), 1);
	MR_r3 = MR_tempr1;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(parse_tree__prog_data__add_sym_name_module_4_0);
	}
MR_def_label(check_hlds__unused_imports__hlds_goal_used_modules_3_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r6,2)) {
		MR_GOTO_LAB(check_hlds__unused_imports__hlds_goal_used_modules_3_0_i47);
	}
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(3);
MR_def_label(check_hlds__unused_imports__hlds_goal_used_modules_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r3,1)) {
		MR_GOTO_LAB(check_hlds__unused_imports__hlds_goal_used_modules_3_0_i10);
	}
	MR_r1 = (MR_Integer) 1;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_tfield(1, MR_r3, 5);
	MR_r3 = MR_tempr1;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(parse_tree__prog_data__add_sym_name_module_4_0);
	}
MR_def_label(check_hlds__unused_imports__hlds_goal_used_modules_3_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r3,0)) {
		MR_GOTO_LAB(check_hlds__unused_imports__hlds_goal_used_modules_3_0_i12);
	}
	MR_r1 = MR_tfield(0, MR_r3, 1);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(check_hlds__unused_imports__unify_rhs_used_modules_3_0);
MR_def_label(check_hlds__unused_imports__hlds_goal_used_modules_3_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r3,3,0)) {
		MR_GOTO_LAB(check_hlds__unused_imports__hlds_goal_used_modules_3_0_i14);
	}
MR_def_label(check_hlds__unused_imports__hlds_goal_used_modules_3_0,47)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(3);
MR_def_label(check_hlds__unused_imports__hlds_goal_used_modules_3_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r3,3,1)) {
		MR_GOTO_LAB(check_hlds__unused_imports__hlds_goal_used_modules_3_0_i15);
	}
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_goal, hlds_goal);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r2;
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_tempr2 = MR_r3;
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,1,8);
	MR_r4 = MR_tfield(3, MR_tempr2, 2);
	MR_r5 = MR_tempr1;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
MR_def_label(check_hlds__unused_imports__hlds_goal_used_modules_3_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r3,3,2)) {
		MR_GOTO_LAB(check_hlds__unused_imports__hlds_goal_used_modules_3_0_i18);
	}
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_goal, hlds_goal);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r2;
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_tempr2 = MR_r3;
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,1,9);
	MR_r4 = MR_tfield(3, MR_tempr2, 1);
	MR_r5 = MR_tempr1;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
MR_def_label(check_hlds__unused_imports__hlds_goal_used_modules_3_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r3,3,6)) {
		MR_GOTO_LAB(check_hlds__unused_imports__hlds_goal_used_modules_3_0_i21);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_sv(1) = MR_tfield(3, MR_tempr1, 3);
	MR_sv(2) = MR_tfield(3, MR_tempr1, 4);
	MR_r1 = MR_tfield(3, MR_tempr1, 2);
	}
	MR_np_localcall_lab(check_hlds__unused_imports__hlds_goal_used_modules_3_0,
		check_hlds__unused_imports__hlds_goal_used_modules_3_0_i22);
MR_def_label(check_hlds__unused_imports__hlds_goal_used_modules_3_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	}
	MR_np_localcall_lab(check_hlds__unused_imports__hlds_goal_used_modules_3_0,
		check_hlds__unused_imports__hlds_goal_used_modules_3_0_i23);
MR_def_label(check_hlds__unused_imports__hlds_goal_used_modules_3_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(3);
	MR_GOTO_LAB(check_hlds__unused_imports__hlds_goal_used_modules_3_0_i127);
	}
MR_def_label(check_hlds__unused_imports__hlds_goal_used_modules_3_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r3,3,4)) {
		MR_GOTO_LAB(check_hlds__unused_imports__hlds_goal_used_modules_3_0_i25);
	}
	MR_r1 = MR_tfield(3, MR_r3, 1);
	MR_succip_word = MR_sv(3);
	MR_GOTO_LAB(check_hlds__unused_imports__hlds_goal_used_modules_3_0_i127);
MR_def_label(check_hlds__unused_imports__hlds_goal_used_modules_3_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r3,3,5)) {
		MR_GOTO_LAB(check_hlds__unused_imports__hlds_goal_used_modules_3_0_i27);
	}
	MR_r1 = MR_tfield(3, MR_r3, 2);
	MR_succip_word = MR_sv(3);
	MR_GOTO_LAB(check_hlds__unused_imports__hlds_goal_used_modules_3_0_i127);
MR_def_label(check_hlds__unused_imports__hlds_goal_used_modules_3_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r3,3,7)) {
		MR_GOTO_LAB(check_hlds__unused_imports__hlds_goal_used_modules_3_0_i29);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(3, MR_r3, 1);
	MR_r4 = MR_tempr1;
	if (MR_PTAG_TESTR(MR_tempr1,1)) {
		MR_GOTO_LAB(check_hlds__unused_imports__hlds_goal_used_modules_3_0_i31);
	}
	MR_sv(1) = MR_tfield(1, MR_tempr1, 5);
	MR_r1 = MR_tfield(1, MR_tempr1, 4);
	}
	MR_np_localcall_lab(check_hlds__unused_imports__hlds_goal_used_modules_3_0,
		check_hlds__unused_imports__hlds_goal_used_modules_3_0_i32);
MR_def_label(check_hlds__unused_imports__hlds_goal_used_modules_3_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_goal, hlds_goal);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,1,10);
	MR_r4 = MR_sv(1);
	MR_r5 = MR_tempr1;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
MR_def_label(check_hlds__unused_imports__hlds_goal_used_modules_3_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r4,0)) {
		MR_GOTO_LAB(check_hlds__unused_imports__hlds_goal_used_modules_3_0_i35);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r4;
	MR_sv(1) = MR_tfield(0, MR_tempr1, 1);
	MR_r1 = MR_tfield(0, MR_tempr1, 0);
	}
	MR_np_localcall_lab(check_hlds__unused_imports__hlds_goal_used_modules_3_0,
		check_hlds__unused_imports__hlds_goal_used_modules_3_0_i36);
MR_def_label(check_hlds__unused_imports__hlds_goal_used_modules_3_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(3);
	MR_GOTO_LAB(check_hlds__unused_imports__hlds_goal_used_modules_3_0_i127);
	}
MR_def_label(check_hlds__unused_imports__hlds_goal_used_modules_3_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(2, MR_r4, 2);
	MR_succip_word = MR_sv(3);
	MR_GOTO_LAB(check_hlds__unused_imports__hlds_goal_used_modules_3_0_i127);
MR_def_label(check_hlds__unused_imports__hlds_goal_used_modules_3_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_goal, case);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r2;
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_tempr2 = MR_r3;
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,1,11);
	MR_r4 = MR_tfield(3, MR_tempr2, 3);
	MR_r5 = MR_tempr1;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(check_hlds__unused_imports_module22)
	MR_init_entry1(check_hlds__unused_imports__unify_rhs_used_modules_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__unify_rhs_used_modules_3_0);
	MR_init_label2(check_hlds__unused_imports__unify_rhs_used_modules_3_0,3,5)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'unify_rhs_used_modules'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__unify_rhs_used_modules_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(check_hlds__unused_imports__unify_rhs_used_modules_3_0_i3);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Integer) 1;
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tfield(1, MR_tempr1, 0);
	MR_r3 = MR_tempr2;
	MR_np_tailcall_ent(check_hlds__unused_imports__cons_id_used_modules_4_0);
	}
MR_def_label(check_hlds__unused_imports__unify_rhs_used_modules_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(check_hlds__unused_imports__unify_rhs_used_modules_3_0_i5);
	}
	MR_r1 = MR_tfield(2, MR_r1, 8);
	MR_np_tailcall_ent(check_hlds__unused_imports__hlds_goal_used_modules_3_0);
MR_def_label(check_hlds__unused_imports__unify_rhs_used_modules_3_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(check_hlds__unused_imports_module23)
	MR_init_entry1(check_hlds__unused_imports__clause_used_modules_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__clause_used_modules_3_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'clause_used_modules'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__clause_used_modules_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_r1, 1);
	MR_np_tailcall_ent(check_hlds__unused_imports__hlds_goal_used_modules_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_cons_id_0;

MR_BEGIN_MODULE(check_hlds__unused_imports_module24)
	MR_init_entry1(check_hlds__unused_imports__case_used_modules_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__case_used_modules_3_0);
	MR_init_label2(check_hlds__unused_imports__case_used_modules_3_0,2,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'case_used_modules'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__case_used_modules_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_tfield(0, MR_r1, 1);
	MR_sv(2) = MR_tfield(0, MR_r1, 2);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Integer) 1;
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tfield(0, MR_tempr1, 0);
	MR_r3 = MR_tempr2;
	}
	MR_np_call_localret_ent(check_hlds__unused_imports__cons_id_used_modules_4_0,
		check_hlds__unused_imports__case_used_modules_3_0_i2);
MR_def_label(check_hlds__unused_imports__case_used_modules_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, cons_id);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,5,1);
	MR_r4 = MR_sv(1);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__foldl_4_0,
		check_hlds__unused_imports__case_used_modules_3_0_i4);
MR_def_label(check_hlds__unused_imports__case_used_modules_3_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(check_hlds__unused_imports__hlds_goal_used_modules_3_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(check_hlds__unused_imports_module25)
	MR_init_entry1(check_hlds__unused_imports__bound_inst_info_used_modules_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__bound_inst_info_used_modules_4_0);
	MR_init_label1(check_hlds__unused_imports__bound_inst_info_used_modules_4_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'bound_inst_info_used_modules'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__bound_inst_info_used_modules_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(0, MR_r2, 1);
	MR_r2 = MR_tfield(0, MR_r2, 0);
	MR_np_call_localret_ent(check_hlds__unused_imports__cons_id_used_modules_4_0,
		check_hlds__unused_imports__bound_inst_info_used_modules_4_0_i2);
MR_def_label(check_hlds__unused_imports__bound_inst_info_used_modules_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,24);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__mer_inst_used_modules_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tempr2 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, mer_inst);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_r4 = MR_sv(2);
	MR_r5 = MR_tempr2;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(check_hlds__unused_imports_module26)
	MR_init_entry1(check_hlds__unused_imports__IntroducedFrom__pred__ctor_used_modules__225__1_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__check_hlds__unused_imports__IntroducedFrom__pred__ctor_used_modules__225__1_4_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__ctor_used_modules__225__1'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(check_hlds__unused_imports__IntroducedFrom__pred__ctor_used_modules__225__1_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_tfield(0, MR_r2, 1);
	MR_np_tailcall_ent(check_hlds__unused_imports__mer_type_used_modules_2_4_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(hlds__hlds_data__get_type_defn_status_2_0);
MR_decl_entry(hlds__hlds_data__get_type_defn_body_2_0);
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_constructor_0;

MR_BEGIN_MODULE(check_hlds__unused_imports_module27)
	MR_init_entry1(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0);
	MR_init_label9(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,2,3,4,6,8,7,10,12,5)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__type_used_modules__[1]_0'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(3) = MR_r2;
	MR_np_call_localret_ent(hlds__hlds_data__get_type_defn_status_2_0,
		f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i2);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(hlds__hlds_data__get_type_defn_body_2_0,
		f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i3);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(fn__hlds__hlds_pred__status_defined_in_this_module_1_0,
		f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i4);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i6);
	}
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(4);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(fn__hlds__hlds_pred__status_is_exported_to_non_submodules_1_0,
		f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i8);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,1)) {
		MR_GOTO_LAB(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i7);
	}
	MR_r2 = (MR_Integer) 0;
	MR_r1 = MR_sv(3);
	MR_GOTO_LAB(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i10);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Integer) 1;
	MR_r1 = MR_sv(3);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),0)) {
		MR_GOTO_LAB(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i12);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,25);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__ctor_used_modules_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r2;
	MR_tempr2 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, constructor);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_r4 = MR_tfield(0, MR_sv(2), 0);
	MR_r5 = MR_tempr2;
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i5);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = MR_tfield(1, MR_sv(2), 0);
	MR_r3 = MR_tempr1;
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(check_hlds__unused_imports__mer_type_used_modules_2_4_0);
	}
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_116_121_112_101_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(4);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(check_hlds__unused_imports_module28)
	MR_init_entry1(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_105_110_115_116_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_105_110_115_116_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0);
	MR_init_label6(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_105_110_115_116_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,2,4,6,5,8,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__user_inst_used_modules__[1]_0'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_105_110_115_116_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(0, MR_r1, 4);
	MR_sv(3) = MR_r2;
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(fn__hlds__hlds_pred__status_defined_in_this_module_1_0,
		f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_105_110_115_116_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i2);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_105_110_115_116_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_105_110_115_116_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i4);
	}
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(4);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_105_110_115_116_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(fn__hlds__hlds_pred__status_is_exported_to_non_submodules_1_0,
		f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_105_110_115_116_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i6);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_105_110_115_116_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,1)) {
		MR_GOTO_LAB(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_105_110_115_116_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i5);
	}
	MR_r2 = (MR_Integer) 0;
	MR_r3 = MR_tfield(0, MR_sv(1), 2);
	MR_r1 = MR_sv(3);
	MR_GOTO_LAB(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_105_110_115_116_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i8);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_105_110_115_116_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Integer) 1;
	MR_r3 = MR_tfield(0, MR_sv(1), 2);
	MR_r1 = MR_sv(3);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_105_110_115_116_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_r3,0,0)) {
		MR_GOTO_LAB(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_105_110_115_116_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i3);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = MR_tfield(1, MR_r3, 0);
	MR_r3 = MR_tempr1;
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(check_hlds__unused_imports__mer_inst_used_modules_4_0);
	}
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_105_110_115_116_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(4);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(hlds__hlds_pred__pred_info_get_import_status_2_0);
MR_decl_entry(hlds__hlds_pred__pred_info_get_arg_types_2_0);
MR_decl_entry(hlds__hlds_pred__pred_info_get_class_context_2_0);
MR_decl_entry(hlds__hlds_pred__pred_info_get_procedures_2_0);
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_pred__type_ctor_info_proc_id_0;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_pred__type_ctor_info_proc_info_0;
MR_decl_entry(hlds__hlds_pred__pred_info_get_clauses_info_2_0);
MR_decl_entry(hlds__hlds_clauses__clauses_info_get_clauses_rep_3_0);
MR_decl_entry(hlds__hlds_clauses__get_clause_list_2_0);
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_clauses__type_ctor_info_clause_0;

MR_BEGIN_MODULE(check_hlds__unused_imports_module29)
	MR_init_entry1(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0);
	MR_init_label10(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,2,3,5,7,6,9,10,12,13,15)
	MR_init_label6(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,16,17,19,20,21,22)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__pred_info_used_modules__[1]_0'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(3) = MR_r2;
	MR_np_call_localret_ent(hlds__hlds_pred__pred_info_get_import_status_2_0,
		f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i2);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_np_call_localret_ent(fn__hlds__hlds_pred__status_defined_in_this_module_1_0,
		f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i3);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i5);
	}
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(7);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(fn__hlds__hlds_pred__status_is_exported_to_non_submodules_1_0,
		f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i7);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,1)) {
		MR_GOTO_LAB(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i6);
	}
	MR_r1 = MR_sv(1);
	MR_sv(2) = (MR_Integer) 0;
	MR_GOTO_LAB(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i9);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_sv(2) = (MR_Integer) 1;
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_np_call_localret_ent(hlds__hlds_pred__pred_info_get_arg_types_2_0,
		f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i10);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,26);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__mer_type_used_modules_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(2);
	MR_sv(5) = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_tempr2 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, mer_type);
	MR_r2 = MR_sv(5);
	MR_r4 = MR_tempr2;
	MR_r5 = MR_sv(3);
	}
	MR_np_call_localret_ent(list__foldl_4_0,
		f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i12);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(hlds__hlds_pred__pred_info_get_class_context_2_0,
		f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i13);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,27);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__prog_constraint_used_module_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(2);
	MR_tempr2 = MR_sv(3);
	MR_sv(3) = MR_tfield(0, MR_r1, 1);
	MR_sv(4) = MR_tempr1;
	MR_sv(6) = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, prog_constraint);
	MR_tempr3 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(5);
	MR_r4 = MR_tfield(0, MR_tempr3, 0);
	MR_r5 = MR_tempr2;
	}
	MR_np_call_localret_ent(list__foldl_4_0,
		f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i15);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(5);
	MR_r3 = MR_sv(4);
	MR_r4 = MR_sv(3);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__foldl_4_0,
		f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i16);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(hlds__hlds_pred__pred_info_get_procedures_2_0,
		f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i17);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(7,0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__proc_info_used_modules_5_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(2);
	MR_tempr2 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_pred, proc_id);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_pred, proc_info);
	MR_r3 = MR_sv(5);
	MR_r5 = MR_tempr2;
	MR_r6 = MR_sv(3);
	}
	MR_np_call_localret_ent(map__foldl_4_0,
		f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i19);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(hlds__hlds_pred__pred_info_get_clauses_info_2_0,
		f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i20);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(hlds__hlds_clauses__clauses_info_get_clauses_rep_3_0,
		f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i21);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(hlds__hlds_clauses__get_clause_list_2_0,
		f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0_i22);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_101_100_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_49_93_95_48_4_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_clauses, clause);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,1,12);
	MR_r4 = MR_tempr1;
	MR_r5 = MR_sv(1);
	MR_succip_word = MR_sv(7);
	MR_decr_sp(7);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(hlds__hlds_pred__proc_info_get_maybe_declared_argmodes_2_0);

MR_BEGIN_MODULE(check_hlds__unused_imports_module30)
	MR_init_entry1(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_99_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_50_93_95_48_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_99_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_50_93_95_48_5_0);
	MR_init_label2(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_99_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_50_93_95_48_5_0,2,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__proc_info_used_modules__[2]_0'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_99_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_50_93_95_48_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r3;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(hlds__hlds_pred__proc_info_get_maybe_declared_argmodes_2_0,
		f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_99_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_50_93_95_48_5_0_i2);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_99_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_50_93_95_48_5_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_99_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_50_93_95_48_5_0_i4);
	}
	MR_r1 = MR_sv(2);
	MR_decr_sp_and_return(3);
MR_def_label(f_99_104_101_99_107_95_104_108_100_115_95_95_117_110_117_115_101_100_95_105_109_112_111_114_116_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_112_114_111_99_95_105_110_102_111_95_117_115_101_100_95_109_111_100_117_108_101_115_95_95_91_50_93_95_48_5_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,28);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(check_hlds__unused_imports__mer_mode_used_modules_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tempr2 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, mer_mode);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, used_modules);
	MR_r4 = MR_tfield(1, MR_tempr2, 0);
	MR_r5 = MR_sv(2);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(list__foldl_4_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

static void mercury__check_hlds__unused_imports_maybe_bunch_0(void)
{
	check_hlds__unused_imports_module0();
	check_hlds__unused_imports_module1();
	check_hlds__unused_imports_module2();
	check_hlds__unused_imports_module3();
	check_hlds__unused_imports_module4();
	check_hlds__unused_imports_module5();
	check_hlds__unused_imports_module6();
	check_hlds__unused_imports_module7();
	check_hlds__unused_imports_module8();
	check_hlds__unused_imports_module9();
	check_hlds__unused_imports_module10();
	check_hlds__unused_imports_module11();
	check_hlds__unused_imports_module12();
	check_hlds__unused_imports_module13();
	check_hlds__unused_imports_module14();
	check_hlds__unused_imports_module15();
	check_hlds__unused_imports_module16();
	check_hlds__unused_imports_module17();
	check_hlds__unused_imports_module18();
	check_hlds__unused_imports_module19();
	check_hlds__unused_imports_module20();
	check_hlds__unused_imports_module21();
	check_hlds__unused_imports_module22();
	check_hlds__unused_imports_module23();
	check_hlds__unused_imports_module24();
	check_hlds__unused_imports_module25();
	check_hlds__unused_imports_module26();
	check_hlds__unused_imports_module27();
	check_hlds__unused_imports_module28();
	check_hlds__unused_imports_module29();
	check_hlds__unused_imports_module30();
}

/* suppress gcc -Wmissing-decls warnings */
void mercury__check_hlds__unused_imports__init(void);
void mercury__check_hlds__unused_imports__init_type_tables(void);
void mercury__check_hlds__unused_imports__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__check_hlds__unused_imports__write_out_proc_statics(FILE *deep_fp, FILE *procrep_fp);
#endif
#ifdef MR_RECORD_TERM_SIZES
void mercury__check_hlds__unused_imports__init_complexity_procs(void);
#endif

void mercury__check_hlds__unused_imports__init(void)
{
	static MR_bool done = MR_FALSE;
	if (done) {
		return;
	}
	done = MR_TRUE;
	mercury__check_hlds__unused_imports_maybe_bunch_0();
	mercury__check_hlds__unused_imports__init_debugger();
}

void mercury__check_hlds__unused_imports__init_type_tables(void)
{
	static MR_bool done = MR_FALSE;
	if (done) {
		return;
	}
	done = MR_TRUE;
}


void mercury__check_hlds__unused_imports__init_debugger(void)
{
	static MR_bool done = MR_FALSE;
	if (done) {
		return;
	}
	done = MR_TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__check_hlds__unused_imports__write_out_proc_statics(FILE *deep_fp, FILE *procrep_fp)
{
	MR_write_out_module_proc_reps_start(procrep_fp, &mercury_data__module_common_layout__check_hlds__unused_imports);
	MR_write_out_module_proc_reps_end(procrep_fp);
}

#endif

#ifdef MR_RECORD_TERM_SIZES

void mercury__check_hlds__unused_imports__init_complexity_procs(void)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
