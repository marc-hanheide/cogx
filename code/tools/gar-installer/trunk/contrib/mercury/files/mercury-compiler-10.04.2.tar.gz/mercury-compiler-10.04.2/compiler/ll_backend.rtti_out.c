/*
** Automatically generated from `rtti_out.m'
** by the Mercury compiler,
** version 10.04.2, configured for x86_64-unknown-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
** HIGHLEVEL_CODE=no
**
** END_OF_C_GRADE_INFO
*/

/*
INIT mercury__ll_backend__rtti_out__init
ENDINIT
*/

#define MR_ALLOW_RESET
#include "mercury_imp.h"
#line 539 "../library/io.int"
#include "io.mh"

#line 28 "ll_backend.rtti_out.c"
#line 547 "../library/io.int"
#include "string.mh"

#line 32 "ll_backend.rtti_out.c"
#line 29 "../library/bitmap.int2"
#include "bitmap.mh"

#line 36 "ll_backend.rtti_out.c"
#line 28 "../library/time.int2"
#include "time.mh"

#line 40 "ll_backend.rtti_out.c"
#line 33 "../mdbcomp/mdbcomp.rtti_access.int2"
#include "mdbcomp.rtti_access.mh"

#line 44 "ll_backend.rtti_out.c"
#line 31 "../library/array.int2"
#include "array.mh"

#line 48 "ll_backend.rtti_out.c"
#line 49 "ll_backend.rtti_out.c"
#include "ll_backend.rtti_out.mh"

#line 52 "ll_backend.rtti_out.c"
#line 53 "ll_backend.rtti_out.c"
#ifndef LL_BACKEND__RTTI_OUT_DECL_GUARD
#define LL_BACKEND__RTTI_OUT_DECL_GUARD

#line 57 "ll_backend.rtti_out.c"
#line 58 "ll_backend.rtti_out.c"

#endif
#line 61 "ll_backend.rtti_out.c"

#ifdef _MSC_VER
#define MR_STATIC_LINKAGE extern
#else
#define MR_STATIC_LINKAGE static
#endif

struct mercury_type_0 {
	MR_Word * f1[2];
};
MR_STATIC_LINKAGE const struct mercury_type_0 mercury_common_0[];

struct mercury_type_1 {
	MR_Word * f1[3];
};
MR_STATIC_LINKAGE const struct mercury_type_1 mercury_common_1[];

struct mercury_type_2 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[6];
};
MR_STATIC_LINKAGE const struct mercury_type_2 mercury_common_2[];

struct mercury_type_3 {
	MR_Word * f1;
	MR_Word * f2;
	MR_Integer f3;
	MR_Word * f4;
	MR_Word * f5;
};
MR_STATIC_LINKAGE const struct mercury_type_3 mercury_common_3[];

struct mercury_type_4 {
	MR_Word * f1;
	MR_Code * f2;
	MR_Integer f3;
};
MR_STATIC_LINKAGE const struct mercury_type_4 mercury_common_4[];

struct mercury_type_5 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[3];
};
MR_STATIC_LINKAGE const struct mercury_type_5 mercury_common_5[];

struct mercury_type_6 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[4];
};
MR_STATIC_LINKAGE const struct mercury_type_6 mercury_common_6[];

struct mercury_type_7 {
	MR_Word * f1;
	MR_Integer f2;
	MR_Word * f3;
	MR_Word * f4;
	MR_Word * f5;
};
MR_STATIC_LINKAGE const struct mercury_type_7 mercury_common_7[];

struct mercury_type_8 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[10];
};
MR_STATIC_LINKAGE const struct mercury_type_8 mercury_common_8[];

struct mercury_type_9 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[5];
};
MR_STATIC_LINKAGE const struct mercury_type_9 mercury_common_9[];

struct mercury_type_10 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[7];
};
MR_STATIC_LINKAGE const struct mercury_type_10 mercury_common_10[];

struct mercury_type_11 {
	MR_Word * f1;
	MR_Word * f2;
	MR_Integer f3;
	MR_Word * f4;
};
MR_STATIC_LINKAGE const struct mercury_type_11 mercury_common_11[];

struct mercury_type_12 {
	MR_Word * f1;
};
MR_STATIC_LINKAGE const struct mercury_type_12 mercury_common_12[];

struct mercury_type_13 {
	MR_Integer f1;
	MR_Word * f2;
};
MR_STATIC_LINKAGE const struct mercury_type_13 mercury_common_13[];

extern const MR_TypeCtorInfo_Struct
	mercury_data_ll_backend__rtti_out__type_ctor_info_data_group_0;
MR_decl_label10(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0, 39,3,4,7,8,9,24,11,13,18)
MR_decl_label10(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0, 5,3,8,10,11,14,15,16,17,18)
MR_decl_label10(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0, 6,63,21,23,25,26,29,30,31,32)
MR_decl_label5(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0, 33,34,35,36,37)
MR_decl_label10(ll_backend__rtti_out__do_output_type_info_defn_6_0, 5,3,8,10,11,14,15,16,17,18)
MR_decl_label10(ll_backend__rtti_out__do_output_type_info_defn_6_0, 6,20,22,24,25,28,29,30,31,32)
MR_decl_label4(ll_backend__rtti_out__do_output_type_info_defn_6_0, 33,34,35,36)
MR_decl_label10(ll_backend__rtti_out__init_rtti_data_if_nec_3_0, 5,6,8,9,10,11,12,13,14,17)
MR_decl_label10(ll_backend__rtti_out__init_rtti_data_if_nec_3_0, 39,15,21,22,23,24,4,28,30,27)
MR_decl_label3(ll_backend__rtti_out__init_rtti_data_if_nec_3_0, 34,35,73)
MR_decl_label7(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0, 3,8,40,10,16,17,18)
MR_decl_label9(ll_backend__rtti_out__output_addr_of_rtti_data_3_0, 61,6,7,12,55,14,20,21,60)
MR_decl_label9(ll_backend__rtti_out__output_base_typeclass_info_defn_9_0, 3,5,6,9,10,17,18,20,21)
MR_decl_label1(ll_backend__rtti_out__output_cast_addr_of_rtti_data_4_0, 2)
MR_decl_label4(ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0, 4,3,6,8)
MR_decl_label8(ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0, 2,3,8,40,10,16,17,18)
MR_decl_label4(ll_backend__rtti_out__output_cast_addr_of_rtti_ids_4_0, 4,3,6,8)
MR_decl_label3(ll_backend__rtti_out__output_ctor_rtti_id_4_0, 3,4,5)
MR_decl_label9(ll_backend__rtti_out__output_du_arg_names_8_0, 4,5,7,8,10,11,14,15,16)
MR_decl_label10(ll_backend__rtti_out__output_du_arg_types_8_0, 3,5,6,9,10,12,13,15,16,17)
MR_decl_label10(ll_backend__rtti_out__output_du_functor_defn_7_0, 3,6,8,10,11,9,14,12,16,19)
MR_decl_label10(ll_backend__rtti_out__output_du_functor_defn_7_0, 22,23,24,25,26,27,28,29,30,32)
MR_decl_label10(ll_backend__rtti_out__output_du_functor_defn_7_0, 33,31,36,37,38,39,40,41,42,43)
MR_decl_label10(ll_backend__rtti_out__output_du_functor_defn_7_0, 44,45,46,48,51,52,54,57,58,60)
MR_decl_label2(ll_backend__rtti_out__output_du_functor_defn_7_0, 63,64)
MR_decl_label10(ll_backend__rtti_out__output_du_name_ordered_table_7_0, 3,6,7,9,11,12,14,15,23,17)
MR_decl_label3(ll_backend__rtti_out__output_du_name_ordered_table_7_0, 18,20,22)
MR_decl_label10(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0, 2,5,7,8,10,11,15,12,16,21)
MR_decl_label2(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0, 22,23)
MR_decl_label10(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0, 32,5,6,7,8,9,10,11,14,15)
MR_decl_label5(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0, 16,17,19,21,35)
MR_decl_label10(ll_backend__rtti_out__output_du_stag_ordered_table_7_0, 2,4,7,8,10,11,19,13,14,16)
MR_decl_label1(ll_backend__rtti_out__output_du_stag_ordered_table_7_0, 18)
MR_decl_label8(ll_backend__rtti_out__output_enum_functor_defn_7_0, 4,5,7,8,9,10,11,12)
MR_decl_label10(ll_backend__rtti_out__output_enum_name_ordered_table_7_0, 2,4,6,7,9,10,18,12,13,15)
MR_decl_label1(ll_backend__rtti_out__output_enum_name_ordered_table_7_0, 17)
MR_decl_label10(ll_backend__rtti_out__output_enum_value_ordered_table_7_0, 2,4,6,7,9,10,18,12,13,15)
MR_decl_label1(ll_backend__rtti_out__output_enum_value_ordered_table_7_0, 17)
MR_decl_label8(ll_backend__rtti_out__output_exist_constraints_data_8_0, 4,5,8,9,11,12,13,14)
MR_decl_label10(ll_backend__rtti_out__output_exist_info_8_0, 2,7,8,11,12,13,14,15,16,17)
MR_decl_label10(ll_backend__rtti_out__output_exist_info_8_0, 18,19,20,21,22,10,25,26,27,28)
MR_decl_label10(ll_backend__rtti_out__output_exist_info_8_0, 29,30,31,32,33,34,35,36,37,38)
MR_decl_label3(ll_backend__rtti_out__output_exist_info_8_0, 40,42,43)
MR_decl_label7(ll_backend__rtti_out__output_exist_locn_3_0, 4,5,3,7,8,9,10)
MR_decl_label9(ll_backend__rtti_out__output_exist_locns_array_8_0, 4,5,7,9,11,12,14,15,16)
MR_decl_label10(ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0, 4,5,7,8,9,10,11,12,13,14)
MR_decl_label10(ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0, 2,4,6,7,9,10,18,12,13,15)
MR_decl_label1(ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0, 17)
MR_decl_label10(ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0, 2,4,6,7,9,10,18,12,13,15)
MR_decl_label1(ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0, 17)
MR_decl_label6(ll_backend__rtti_out__output_functor_number_map_7_0, 3,4,6,7,9,10)
MR_decl_label2(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0, 2,3)
MR_decl_label10(ll_backend__rtti_out__output_init_method_pointers_6_0, 18,4,5,6,7,8,9,10,11,12)
MR_decl_label1(ll_backend__rtti_out__output_init_method_pointers_6_0, 20)
MR_decl_label1(ll_backend__rtti_out__output_maybe_pseudo_type_info_defn_6_0, 3)
MR_decl_label2(ll_backend__rtti_out__output_maybe_pseudo_type_info_or_self_defn_6_0, 3,4)
MR_decl_label3(ll_backend__rtti_out__output_maybe_quoted_string_3_0, 16,5,6)
MR_decl_label10(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0, 40,7,8,10,11,12,13,14,15,16)
MR_decl_label5(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0, 18,21,20,17,23)
MR_decl_label10(ll_backend__rtti_out__output_notag_functor_defn_7_0, 3,5,6,7,9,10,12,13,14,15)
MR_decl_label8(ll_backend__rtti_out__output_notag_functor_defn_7_0, 17,21,22,24,26,27,28,29)
MR_decl_label4(ll_backend__rtti_out__output_pseudo_type_info_defn_6_0, 24,6,8,4)
MR_decl_label2(ll_backend__rtti_out__output_record_rtti_data_decls_10_0, 19,5)
MR_decl_label5(ll_backend__rtti_out__output_record_rtti_datas_decls_10_0, 25,3,4,7,9)
MR_decl_label5(ll_backend__rtti_out__output_res_addr_functors_4_0, 2,4,5,6,7)
MR_decl_label9(ll_backend__rtti_out__output_res_name_ordered_table_7_0, 3,6,7,9,10,12,13,15,16)
MR_decl_label10(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0, 2,5,6,7,8,4,10,11,12,13)
MR_decl_label5(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0, 14,16,17,18,19)
MR_decl_label10(ll_backend__rtti_out__output_res_value_ordered_table_8_0, 3,5,6,7,9,11,12,14,15,17)
MR_decl_label10(ll_backend__rtti_out__output_res_value_ordered_table_8_0, 18,19,21,22,23,24,25,26,27,28)
MR_decl_label4(ll_backend__rtti_out__output_res_value_ordered_table_8_0, 29,30,31,32)
MR_decl_label4(ll_backend__rtti_out__output_rtti_data_decl_6_0, 21,5,6,7)
MR_decl_label10(ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0, 3,2,5,6,7,8,9,10,11,12)
MR_decl_label1(ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0, 13)
MR_decl_label10(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0, 33,5,6,7,8,9,10,11,16,15)
MR_decl_label2(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0, 17,3)
MR_decl_label2(ll_backend__rtti_out__output_rtti_data_decl_group_6_0, 2,3)
MR_decl_label3(ll_backend__rtti_out__output_rtti_data_decl_list_6_0, 2,3,4)
MR_decl_label5(ll_backend__rtti_out__output_rtti_data_defn_6_0, 3,5,7,9,11)
MR_decl_label3(ll_backend__rtti_out__output_rtti_id_3_0, 2,3,4)
MR_decl_label10(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0, 2,3,24,5,6,9,10,11,12,13)
MR_decl_label8(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0, 14,15,16,17,18,19,20,22)
MR_decl_label1(ll_backend__rtti_out__output_rtti_id_storage_type_name_no_decl_5_0, 2)
MR_decl_label10(ll_backend__rtti_out__output_rtti_type_decl_5_0, 8,10,6,13,15,5,19,17,21,22)
MR_decl_label10(ll_backend__rtti_out__output_rtti_type_decl_5_0, 23,24,25,26,27,28,29,30,2,3)
MR_decl_label10(ll_backend__rtti_out__output_rtti_type_decl_5_0, 36,41,39,43,44,45,46,47,48,49)
MR_decl_label8(ll_backend__rtti_out__output_rtti_type_decl_5_0, 50,51,52,53,54,55,33,34)
MR_decl_label2(ll_backend__rtti_out__output_static_code_addr_3_0, 2,3)
MR_decl_label10(ll_backend__rtti_out__output_type_class_constraint_10_0, 2,3,4,6,7,9,11,13,14,15)
MR_decl_label7(ll_backend__rtti_out__output_type_class_constraint_10_0, 16,17,18,19,20,21,22)
MR_decl_label10(ll_backend__rtti_out__output_type_class_decl_defn_6_0, 8,9,10,12,13,7,15,16,17,19)
MR_decl_label10(ll_backend__rtti_out__output_type_class_decl_defn_6_0, 20,14,21,22,23,24,25,26,27,28)
MR_decl_label10(ll_backend__rtti_out__output_type_class_decl_defn_6_0, 29,30,31,32,33,34,35,37,39,40)
MR_decl_label10(ll_backend__rtti_out__output_type_class_decl_defn_6_0, 42,44,45,47,50,51,52,53,54,55)
MR_decl_label10(ll_backend__rtti_out__output_type_class_decl_defn_6_0, 46,56,57,58,59,60,61,62,63,64)
MR_decl_label3(ll_backend__rtti_out__output_type_class_decl_defn_6_0, 66,68,69)
MR_decl_label6(ll_backend__rtti_out__output_type_class_id_method_id_3_0, 2,3,4,5,6,7)
MR_decl_label2(ll_backend__rtti_out__output_type_class_id_tvar_name_3_0, 2,3)
MR_decl_label10(ll_backend__rtti_out__output_type_class_instance_defn_6_0, 3,5,8,9,10,11,15,19,20,21)
MR_decl_label10(ll_backend__rtti_out__output_type_class_instance_defn_6_0, 22,23,24,14,26,29,30,31,32,33)
MR_decl_label9(ll_backend__rtti_out__output_type_class_instance_defn_6_0, 34,35,36,37,38,39,41,43,44)
MR_decl_label2(ll_backend__rtti_out__output_type_ctor_arg_defns_and_decls_6_0, 3,4)
MR_decl_label10(ll_backend__rtti_out__output_type_ctor_data_defn_6_0, 2,3,4,5,6,7,11,13,14,15)
MR_decl_label10(ll_backend__rtti_out__output_type_ctor_data_defn_6_0, 16,17,18,19,20,21,22,23,24,25)
MR_decl_label10(ll_backend__rtti_out__output_type_ctor_data_defn_6_0, 26,27,28,29,30,31,32,33,35,38)
MR_decl_label10(ll_backend__rtti_out__output_type_ctor_data_defn_6_0, 39,40,41,43,46,47,48,49,50,51)
MR_decl_label7(ll_backend__rtti_out__output_type_ctor_data_defn_6_0, 52,53,54,55,57,60,61)
MR_decl_label10(ll_backend__rtti_out__output_type_ctor_details_defn_10_0, 5,6,7,8,3,13,14,15,16,11)
MR_decl_label10(ll_backend__rtti_out__output_type_ctor_details_defn_10_0, 21,22,24,25,26,27,19,31,32,33)
MR_decl_label10(ll_backend__rtti_out__output_type_ctor_details_defn_10_0, 35,30,41,43,40,47,48,49,50,45)
MR_decl_label3(ll_backend__rtti_out__output_type_info_defn_6_0, 4,6,2)
MR_decl_label10(ll_backend__rtti_out__register_rtti_data_if_nec_3_0, 5,7,8,4,18,19,16,27,28,29)
MR_decl_label4(ll_backend__rtti_out__register_rtti_data_if_nec_3_0, 30,31,32,63)
MR_decl_label2(ll_backend__rtti_out__rtti_type_class_constraint_template_arity_2_0, 3,1)
MR_decl_label6(fn__ll_backend__rtti_out__tabling_struct_data_addr_string_2_0, 2,3,4,5,6,7)
MR_decl_label2(__Unify___ll_backend__rtti_out__data_group_0_0, 4,1)
MR_decl_label5(__Compare___ll_backend__rtti_out__data_group_0_0, 3,2,5,9,29)
MR_def_extern_entry(ll_backend__rtti_out__output_rtti_id_3_0)
MR_def_extern_entry(ll_backend__rtti_out__output_addr_of_rtti_data_3_0)
MR_def_extern_entry(ll_backend__rtti_out__output_cast_addr_of_rtti_data_4_0)
MR_decl_static(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0)
MR_def_extern_entry(ll_backend__rtti_out__output_rtti_data_decl_list_6_0)
MR_decl_static(ll_backend__rtti_out__rtti_type_class_constraint_template_arity_2_0)
MR_decl_static(ll_backend__rtti_out__output_rtti_type_decl_5_0)
MR_def_extern_entry(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0)
MR_def_extern_entry(ll_backend__rtti_out__output_rtti_data_decl_6_0)
MR_decl_static(ll_backend__rtti_out__output_base_typeclass_info_defn_9_0)
MR_decl_static(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0)
MR_decl_static(ll_backend__rtti_out__output_cast_addr_of_rtti_ids_4_0)
MR_decl_static(ll_backend__rtti_out__output_type_class_decl_defn_6_0)
MR_decl_static(ll_backend__rtti_out__output_record_rtti_id_decls_10_0)
MR_decl_static(ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0)
MR_decl_static(ll_backend__rtti_out__output_type_class_instance_defn_6_0)
MR_decl_static(ll_backend__rtti_out__output_record_rtti_data_decls_10_0)
MR_decl_static(ll_backend__rtti_out__output_record_rtti_datas_decls_10_0)
MR_decl_static(ll_backend__rtti_out__output_type_ctor_arg_defns_and_decls_6_0)
MR_decl_static(ll_backend__rtti_out__output_ctor_rtti_id_4_0)
MR_decl_static(ll_backend__rtti_out__do_output_type_info_defn_6_0)
MR_decl_static(ll_backend__rtti_out__output_type_info_defn_6_0)
MR_decl_static(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0)
MR_decl_static(ll_backend__rtti_out__output_pseudo_type_info_defn_6_0)
MR_decl_static(ll_backend__rtti_out__output_maybe_pseudo_type_info_defn_6_0)
MR_decl_static(ll_backend__rtti_out__output_notag_functor_defn_7_0)
MR_decl_static(ll_backend__rtti_out__output_enum_value_ordered_table_7_0)
MR_decl_static(ll_backend__rtti_out__output_enum_name_ordered_table_7_0)
MR_decl_static(ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0)
MR_decl_static(ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0)
MR_decl_static(ll_backend__rtti_out__output_du_name_ordered_table_7_0)
MR_decl_static(fn__ll_backend__rtti_out__this_file_0_0)
MR_decl_static(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0)
MR_decl_static(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0)
MR_decl_static(ll_backend__rtti_out__output_res_value_ordered_table_8_0)
MR_decl_static(ll_backend__rtti_out__output_res_name_ordered_table_7_0)
MR_decl_static(ll_backend__rtti_out__output_functor_number_map_7_0)
MR_decl_static(ll_backend__rtti_out__output_type_ctor_details_defn_10_0)
MR_decl_static(fn__ll_backend__rtti_out__make_code_addr_1_0)
MR_decl_static(ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0)
MR_decl_static(ll_backend__rtti_out__output_static_code_addr_3_0)
MR_decl_static(ll_backend__rtti_out__output_type_ctor_data_defn_6_0)
MR_def_extern_entry(ll_backend__rtti_out__output_rtti_data_defn_6_0)
MR_decl_static(ll_backend__rtti_out__output_init_method_pointers_6_0)
MR_def_extern_entry(ll_backend__rtti_out__init_rtti_data_if_nec_3_0)
MR_def_extern_entry(ll_backend__rtti_out__register_rtti_data_if_nec_3_0)
MR_def_extern_entry(ll_backend__rtti_out__output_rtti_id_storage_type_name_no_decl_5_0)
MR_def_extern_entry(fn__ll_backend__rtti_out__tabling_struct_data_addr_string_2_0)
MR_decl_static(ll_backend__rtti_out__output_type_class_id_tvar_name_3_0)
MR_decl_static(ll_backend__rtti_out__output_type_class_id_method_id_3_0)
MR_decl_static(ll_backend__rtti_out__make_tc_decl_super_id_4_0)
MR_decl_static(ll_backend__rtti_out__make_tc_instance_constraint_id_5_0)
MR_decl_static(ll_backend__rtti_out__output_type_class_constraint_10_0)
MR_decl_static(ll_backend__rtti_out__output_maybe_pseudo_type_info_or_self_defn_6_0)
MR_decl_static(ll_backend__rtti_out__output_enum_functor_defn_7_0)
MR_decl_static(ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0)
MR_decl_static(ll_backend__rtti_out__output_exist_locns_array_8_0)
MR_decl_static(ll_backend__rtti_out__output_exist_constraints_data_8_0)
MR_decl_static(ll_backend__rtti_out__output_exist_info_8_0)
MR_decl_static(ll_backend__rtti_out__output_du_arg_types_8_0)
MR_decl_static(ll_backend__rtti_out__output_du_arg_names_8_0)
MR_decl_static(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0)
MR_decl_static(ll_backend__rtti_out__output_du_functor_defn_7_0)
MR_decl_static(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0)
MR_decl_static(ll_backend__rtti_out__make_exist_tc_constr_id_5_0)
MR_decl_static(ll_backend__rtti_out__output_du_stag_ordered_table_7_0)
MR_decl_static(ll_backend__rtti_out__output_res_addr_functors_4_0)
MR_decl_static(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0)
MR_decl_static(ll_backend__rtti_out__output_rtti_data_decl_group_6_0)
MR_decl_static(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0)
MR_decl_static(ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0)
MR_decl_static(ll_backend__rtti_out__output_maybe_quoted_string_3_0)
MR_decl_static(ll_backend__rtti_out__output_exist_locn_3_0)
MR_decl_static(__Unify___ll_backend__rtti_out__data_group_0_0)
MR_decl_static(__Compare___ll_backend__rtti_out__data_group_0_0)
MR_decl_static(ll_backend__rtti_out__IntroducedFrom__pred__output_type_ctor_details_defn__723__1_2_0)
MR_decl_static(fn__ll_backend__rtti_out__IntroducedFrom__func__output_du_functor_defn__879__1_1_0)
MR_decl_static(ll_backend__rtti_out__IntroducedFrom__pred__output_du_arg_types__1103__1_1_0)
MR_decl_static(ll_backend__rtti_out__IntroducedFrom__pred__output_du_arg_names__1117__1_1_0)
MR_decl_static(ll_backend__rtti_out__IntroducedFrom__pred__output_du_name_ordered_table__1189__1_2_0)
MR_decl_static(ll_backend__rtti_out__IntroducedFrom__pred__output_du_ptag_ordered_table_body__1245__1_2_0)
MR_decl_static(ll_backend__rtti_out__IntroducedFrom__pred__output_res_value_ordered_table__1296__1_2_0)
MR_decl_static(ll_backend__rtti_out__IntroducedFrom__pred__output_res_name_ordered_table__1331__1_2_0)

extern const MR_TypeCtorInfo_Struct mercury_data_list__type_ctor_info_list_1;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_rtti_id_0;
extern const MR_TypeCtorInfo_Struct mercury_data_set_tree234__type_ctor_info_set_tree234_1;
extern const MR_TypeCtorInfo_Struct mercury_data_ll_backend__llds_out__llds_out_util__type_ctor_info_decl_id_0;
extern const MR_TypeCtorInfo_Struct mercury_data_list__type_ctor_info_list_1;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_rtti_id_0;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_rtti_maybe_pseudo_type_info_0;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_du_functor_0;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_du_functor_0;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_maybe_reserved_functor_0;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_maybe_reserved_functor_0;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_rtti_maybe_pseudo_type_info_or_self_0;
extern const MR_TypeCtorInfo_Struct mercury_data_maybe__type_ctor_info_maybe_1;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_string_0;
extern const MR_TypeCtorInfo_Struct mercury_data_maybe__type_ctor_info_maybe_1;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_string_0;
static const struct mercury_type_0 mercury_common_0[14] =
{
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(backend_libs__rtti, rtti_id)
}
},
{
{
MR_CTOR1_ADDR(set_tree234, set_tree234),
MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, decl_id)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(backend_libs__rtti, rtti_id)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(backend_libs__rtti, du_functor)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(backend_libs__rtti, du_functor)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(backend_libs__rtti, maybe_reserved_functor)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(backend_libs__rtti, maybe_reserved_functor)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info_or_self)
}
},
{
{
MR_CTOR1_ADDR(maybe, maybe),
MR_STRING_CTOR_ADDR
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_COMMON(0,9)
}
},
{
{
MR_CTOR1_ADDR(maybe, maybe),
MR_STRING_CTOR_ADDR
}
},
{
{
MR_CTOR1_ADDR(maybe, maybe),
MR_STRING_CTOR_ADDR
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(backend_libs__rtti, rtti_id)
}
},
};

extern const MR_TypeCtorInfo_Struct mercury_data_pair__type_ctor_info_pair_2;
extern const MR_TypeCtorInfo_Struct mercury_data_ll_backend__rtti_out__type_ctor_info_data_group_0;
extern const MR_TypeCtorInfo_Struct mercury_data_tree234__type_ctor_info_tree234_2;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_int_0;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_int_0;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_sectag_table_0;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_sectag_table_0;
static const struct mercury_type_1 mercury_common_1[8] =
{
{
{
MR_CTOR_ADDR(pair, pair, 2),
MR_CTOR0_ADDR(ll_backend__rtti_out, data_group),
MR_COMMON(0,0)
}
},
{
{
MR_CTOR_ADDR(pair, pair, 2),
MR_CTOR0_ADDR(ll_backend__rtti_out, data_group),
MR_TAG_COMMON(0,0,2)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(backend_libs__rtti, du_functor)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(backend_libs__rtti, du_functor)
}
},
{
{
MR_CTOR_ADDR(pair, pair, 2),
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(backend_libs__rtti, sectag_table)
}
},
{
{
MR_CTOR_ADDR(pair, pair, 2),
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(backend_libs__rtti, sectag_table)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(backend_libs__rtti, maybe_reserved_functor)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(backend_libs__rtti, maybe_reserved_functor)
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_rtti_data_decl_list_6_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_ll_backend__llds_out__llds_out_util__type_ctor_info_llds_out_info_0;
extern const MR_TypeCtorInfo_Struct mercury_data_io__type_ctor_info_state_0;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_base_typeclass_info_defn_9_0_2;
extern const MR_TypeCtorInfo_Struct mercury_data_ll_backend__llds__type_ctor_info_code_addr_0;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_instance_defn_6_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_rtti_maybe_pseudo_type_info_0;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_ctor_arg_defns_and_decls_6_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_rtti_data_0;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_ctor_data_defn_6_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_constraint_10_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_arg_types_8_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_rtti_maybe_pseudo_type_info_or_self_0;
static const struct mercury_type_2 mercury_common_2[7] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_rtti_data_decl_list_6_0_1,
(MR_Word *) (MR_Integer) 0
},
6,
{
MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, llds_out_info),
MR_COMMON(1,0),
MR_COMMON(0,1),
MR_COMMON(0,1),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_base_typeclass_info_defn_9_0_2,
(MR_Word *) (MR_Integer) 0
},
6,
{
MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, llds_out_info),
MR_CTOR0_ADDR(ll_backend__llds, code_addr),
MR_COMMON(0,1),
MR_COMMON(0,1),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_instance_defn_6_0_1,
(MR_Word *) (MR_Integer) 0
},
6,
{
MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, llds_out_info),
MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info),
MR_COMMON(0,1),
MR_COMMON(0,1),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_type_ctor_arg_defns_and_decls_6_0_1,
(MR_Word *) (MR_Integer) 0
},
6,
{
MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, llds_out_info),
MR_CTOR0_ADDR(backend_libs__rtti, rtti_data),
MR_COMMON(0,1),
MR_COMMON(0,1),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_type_ctor_data_defn_6_0_1,
(MR_Word *) (MR_Integer) 0
},
6,
{
MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, llds_out_info),
MR_CTOR0_ADDR(ll_backend__llds, code_addr),
MR_COMMON(0,1),
MR_COMMON(0,1),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_constraint_10_0_1,
(MR_Word *) (MR_Integer) 0
},
6,
{
MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, llds_out_info),
MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info),
MR_COMMON(0,1),
MR_COMMON(0,1),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_du_arg_types_8_0_1,
(MR_Word *) (MR_Integer) 0
},
6,
{
MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, llds_out_info),
MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info_or_self),
MR_COMMON(0,1),
MR_COMMON(0,1),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_base_typeclass_info_defn_9_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_rtti__type_ctor_info_rtti_proc_label_0;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_instance_defn_6_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__do_output_type_info_defn_6_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_rtti_type_info_0;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__do_output_type_info_defn_6_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_enum_value_ordered_table_7_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_enum_functor_0;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_ctor_rtti_name_0;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_enum_name_ordered_table_7_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_foreign_enum_functor_0;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_name_ordered_table_7_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_name_ordered_table_7_0_2;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_du_functor_0;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_int_0;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_res_value_ordered_table_8_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_reserved_functor_0;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_data__type_ctor_info_reserved_address_0;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_res_value_ordered_table_8_0_3;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_res_name_ordered_table_7_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_ctor_details_defn_10_0_3;
extern const MR_TypeCtorInfo_Struct mercury_data_libs__globals__type_ctor_info_foreign_language_0;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__init_rtti_data_if_nec_3_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_constraint_10_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_arg_types_8_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_functor_defn_7_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_du_arg_info_0;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_functor_defn_7_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_functor_defn_7_0_3;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_string_0;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_stag_ordered_table_7_0_1;
static const struct mercury_type_3 mercury_common_3[24] =
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_base_typeclass_info_defn_9_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(hlds__hlds_rtti, rtti_proc_label),
MR_CTOR0_ADDR(ll_backend__llds, code_addr)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_instance_defn_6_0_2,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info),
MR_CTOR0_ADDR(backend_libs__rtti, rtti_data)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__do_output_type_info_defn_6_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(backend_libs__rtti, rtti_type_info),
MR_CTOR0_ADDR(backend_libs__rtti, rtti_data)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__do_output_type_info_defn_6_0_2,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(backend_libs__rtti, rtti_type_info),
MR_CTOR0_ADDR(backend_libs__rtti, rtti_data)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info),
MR_CTOR0_ADDR(backend_libs__rtti, rtti_data)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_2,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info),
MR_CTOR0_ADDR(backend_libs__rtti, rtti_data)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_enum_value_ordered_table_7_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(backend_libs__rtti, enum_functor),
MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_enum_name_ordered_table_7_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(backend_libs__rtti, enum_functor),
MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(backend_libs__rtti, foreign_enum_functor),
MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(backend_libs__rtti, foreign_enum_functor),
MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_du_name_ordered_table_7_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(1,3),
MR_COMMON(0,5)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_du_name_ordered_table_7_0_2,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(backend_libs__rtti, du_functor),
MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_INT_CTOR_ADDR,
MR_INT_CTOR_ADDR
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_res_value_ordered_table_8_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(backend_libs__rtti, reserved_functor),
MR_CTOR0_ADDR(hlds__hlds_data, reserved_address)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_res_value_ordered_table_8_0_3,
(MR_Word *) (MR_Integer) 0,
2,
MR_INT_CTOR_ADDR,
MR_INT_CTOR_ADDR
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_res_name_ordered_table_7_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(1,7),
MR_COMMON(0,7)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_type_ctor_details_defn_10_0_3,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(libs__globals, foreign_language),
MR_CTOR0_ADDR(libs__globals, foreign_language)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__init_rtti_data_if_nec_3_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(hlds__hlds_rtti, rtti_proc_label),
MR_CTOR0_ADDR(ll_backend__llds, code_addr)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_constraint_10_0_2,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info),
MR_CTOR0_ADDR(backend_libs__rtti, rtti_data)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_du_arg_types_8_0_2,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info_or_self),
MR_CTOR0_ADDR(backend_libs__rtti, rtti_data)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_du_functor_defn_7_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(backend_libs__rtti, du_arg_info),
MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info_or_self)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_du_functor_defn_7_0_2,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(backend_libs__rtti, du_arg_info),
MR_COMMON(0,12)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_du_functor_defn_7_0_3,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(0,12),
MR_STRING_CTOR_ADDR
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_du_stag_ordered_table_7_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(backend_libs__rtti, du_functor),
MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name)
},
};

MR_decl_entry(io__write_int_3_0);
MR_decl_entry(fn__backend_libs__rtti__maybe_pseudo_type_info_to_rtti_data_1_0);
MR_decl_entry(fn__backend_libs__rtti__type_info_to_rtti_data_1_0);
MR_decl_entry(fn__backend_libs__rtti__enum_functor_rtti_name_1_0);
MR_decl_entry(fn__backend_libs__rtti__foreign_enum_functor_rtti_name_1_0);
MR_decl_entry(fn__backend_libs__rtti__du_functor_rtti_name_1_0);
MR_decl_entry(fn__backend_libs__rtti__res_addr_rep_1_0);
MR_decl_entry(backend_libs__rtti__res_addr_is_numeric_1_0);
MR_decl_entry(fn__backend_libs__rtti__maybe_pseudo_type_info_or_self_to_rtti_data_1_0);
MR_decl_entry(fn__backend_libs__rtti__du_arg_info_type_1_0);
MR_decl_entry(fn__backend_libs__rtti__du_arg_info_name_1_0);
static const struct mercury_type_4 mercury_common_4[29] =
{
{
MR_COMMON(3,0),
MR_ENTRY_AP(fn__ll_backend__rtti_out__make_code_addr_1_0),
0
},
{
MR_COMMON(5,0),
MR_ENTRY_AP(io__write_int_3_0),
0
},
{
MR_COMMON(5,1),
MR_ENTRY_AP(ll_backend__rtti_out__output_static_code_addr_3_0),
0
},
{
MR_COMMON(5,2),
MR_ENTRY_AP(ll_backend__rtti_out__output_type_class_id_tvar_name_3_0),
0
},
{
MR_COMMON(5,3),
MR_ENTRY_AP(ll_backend__rtti_out__output_type_class_id_method_id_3_0),
0
},
{
MR_COMMON(3,1),
MR_ENTRY_AP(fn__backend_libs__rtti__maybe_pseudo_type_info_to_rtti_data_1_0),
0
},
{
MR_COMMON(3,2),
MR_ENTRY_AP(fn__backend_libs__rtti__type_info_to_rtti_data_1_0),
0
},
{
MR_COMMON(3,3),
MR_ENTRY_AP(fn__backend_libs__rtti__type_info_to_rtti_data_1_0),
0
},
{
MR_COMMON(3,4),
MR_ENTRY_AP(fn__backend_libs__rtti__maybe_pseudo_type_info_to_rtti_data_1_0),
0
},
{
MR_COMMON(3,5),
MR_ENTRY_AP(fn__backend_libs__rtti__maybe_pseudo_type_info_to_rtti_data_1_0),
0
},
{
MR_COMMON(3,6),
MR_ENTRY_AP(fn__backend_libs__rtti__enum_functor_rtti_name_1_0),
0
},
{
MR_COMMON(3,7),
MR_ENTRY_AP(fn__backend_libs__rtti__enum_functor_rtti_name_1_0),
0
},
{
MR_COMMON(3,8),
MR_ENTRY_AP(fn__backend_libs__rtti__foreign_enum_functor_rtti_name_1_0),
0
},
{
MR_COMMON(3,9),
MR_ENTRY_AP(fn__backend_libs__rtti__foreign_enum_functor_rtti_name_1_0),
0
},
{
MR_COMMON(3,10),
MR_ENTRY_AP(ll_backend__rtti_out__IntroducedFrom__pred__output_du_name_ordered_table__1189__1_2_0),
0
},
{
MR_COMMON(3,11),
MR_ENTRY_AP(fn__backend_libs__rtti__du_functor_rtti_name_1_0),
0
},
{
MR_COMMON(3,13),
MR_ENTRY_AP(fn__backend_libs__rtti__res_addr_rep_1_0),
0
},
{
MR_COMMON(11,0),
MR_ENTRY_AP(backend_libs__rtti__res_addr_is_numeric_1_0),
0
},
{
MR_COMMON(3,15),
MR_ENTRY_AP(ll_backend__rtti_out__IntroducedFrom__pred__output_res_name_ordered_table__1331__1_2_0),
0
},
{
MR_COMMON(5,4),
MR_ENTRY_AP(io__write_int_3_0),
0
},
{
MR_COMMON(3,17),
MR_ENTRY_AP(fn__ll_backend__rtti_out__make_code_addr_1_0),
0
},
{
MR_COMMON(3,18),
MR_ENTRY_AP(fn__backend_libs__rtti__maybe_pseudo_type_info_to_rtti_data_1_0),
0
},
{
MR_COMMON(5,5),
MR_ENTRY_AP(ll_backend__rtti_out__output_exist_locn_3_0),
0
},
{
MR_COMMON(3,19),
MR_ENTRY_AP(fn__backend_libs__rtti__maybe_pseudo_type_info_or_self_to_rtti_data_1_0),
0
},
{
MR_COMMON(5,6),
MR_ENTRY_AP(ll_backend__rtti_out__output_maybe_quoted_string_3_0),
0
},
{
MR_COMMON(3,20),
MR_ENTRY_AP(fn__backend_libs__rtti__du_arg_info_type_1_0),
0
},
{
MR_COMMON(3,21),
MR_ENTRY_AP(fn__backend_libs__rtti__du_arg_info_name_1_0),
0
},
{
MR_COMMON(3,22),
MR_ENTRY_AP(fn__ll_backend__rtti_out__IntroducedFrom__func__output_du_functor_defn__879__1_1_0),
0
},
{
MR_COMMON(3,23),
MR_ENTRY_AP(fn__backend_libs__rtti__du_functor_rtti_name_1_0),
0
},
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_base_typeclass_info_defn_9_0_3;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_base_typeclass_info_defn_9_0_4;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_decl_defn_6_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_decl_defn_6_0_2;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_tc_method_id_0;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_functor_number_map_7_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_exist_locns_array_8_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_exist_typeinfo_locn_0;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_arg_names_8_0_2;
static const struct mercury_type_5 mercury_common_5[7] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_base_typeclass_info_defn_9_0_3,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_INT_CTOR_ADDR,
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_base_typeclass_info_defn_9_0_4,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(ll_backend__llds, code_addr),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_decl_defn_6_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_STRING_CTOR_ADDR,
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_decl_defn_6_0_2,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(backend_libs__rtti, tc_method_id),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_functor_number_map_7_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_INT_CTOR_ADDR,
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_exist_locns_array_8_0_1,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(backend_libs__rtti, exist_typeinfo_locn),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_du_arg_names_8_0_2,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_COMMON(0,12),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_cast_addr_of_rtti_ids_4_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_rtti_id_0;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_decl_defn_6_0_3;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_tc_name_0;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_enum_value_ordered_table_7_0_2;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_rtti_type_ctor_0;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_enum_name_ordered_table_7_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_name_ordered_table_7_0_3;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_res_value_ordered_table_8_0_4;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_res_name_ordered_table_7_0_2;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_maybe_reserved_functor_0;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_stag_ordered_table_7_0_2;
static const struct mercury_type_6 mercury_common_6[11] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_cast_addr_of_rtti_ids_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_STRING_CTOR_ADDR,
MR_CTOR0_ADDR(backend_libs__rtti, rtti_id),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_decl_defn_6_0_3,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(backend_libs__rtti, tc_name),
MR_INT_CTOR_ADDR,
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(backend_libs__rtti, rtti_id)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0_1,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_STRING_CTOR_ADDR,
MR_CTOR0_ADDR(backend_libs__rtti, rtti_data),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_enum_value_ordered_table_7_0_2,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(backend_libs__rtti, rtti_type_ctor),
MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_enum_name_ordered_table_7_0_2,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(backend_libs__rtti, rtti_type_ctor),
MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0_2,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(backend_libs__rtti, rtti_type_ctor),
MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0_2,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(backend_libs__rtti, rtti_type_ctor),
MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_du_name_ordered_table_7_0_3,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(backend_libs__rtti, rtti_type_ctor),
MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_res_value_ordered_table_8_0_4,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(backend_libs__rtti, rtti_type_ctor),
MR_CTOR0_ADDR(backend_libs__rtti, reserved_functor),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_res_name_ordered_table_7_0_2,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(backend_libs__rtti, rtti_type_ctor),
MR_CTOR0_ADDR(backend_libs__rtti, maybe_reserved_functor),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_du_stag_ordered_table_7_0_2,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(backend_libs__rtti, rtti_type_ctor),
MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
};

extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_pred_0;
static const struct mercury_type_7 mercury_common_7[1] =
{
{
MR_CTOR0_ADDR(builtin, pred),
3,
MR_INT_CTOR_ADDR,
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(backend_libs__rtti, rtti_id)
},
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_decl_defn_6_0_4;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_tc_constraint_0;
extern const MR_TypeCtorInfo_Struct mercury_data_counter__type_ctor_info_counter_0;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_instance_defn_6_0_4;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_exist_constraints_data_8_0_2;
static const struct mercury_type_8 mercury_common_8[3] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_decl_defn_6_0_4,
(MR_Word *) (MR_Integer) 0
},
10,
{
MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, llds_out_info),
MR_COMMON(7,0),
MR_CTOR0_ADDR(backend_libs__rtti, tc_constraint),
MR_CTOR0_ADDR(backend_libs__rtti, rtti_id),
MR_CTOR0_ADDR(counter, counter),
MR_CTOR0_ADDR(counter, counter),
MR_COMMON(0,1),
MR_COMMON(0,1),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_instance_defn_6_0_4,
(MR_Word *) (MR_Integer) 0
},
10,
{
MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, llds_out_info),
MR_COMMON(7,0),
MR_CTOR0_ADDR(backend_libs__rtti, tc_constraint),
MR_CTOR0_ADDR(backend_libs__rtti, rtti_id),
MR_CTOR0_ADDR(counter, counter),
MR_CTOR0_ADDR(counter, counter),
MR_COMMON(0,1),
MR_COMMON(0,1),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_exist_constraints_data_8_0_2,
(MR_Word *) (MR_Integer) 0
},
10,
{
MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, llds_out_info),
MR_COMMON(7,0),
MR_CTOR0_ADDR(backend_libs__rtti, tc_constraint),
MR_CTOR0_ADDR(backend_libs__rtti, rtti_id),
MR_CTOR0_ADDR(counter, counter),
MR_CTOR0_ADDR(counter, counter),
MR_COMMON(0,1),
MR_COMMON(0,1),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_instance_defn_6_0_3;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_exist_constraints_data_8_0_1;
static const struct mercury_type_9 mercury_common_9[2] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_instance_defn_6_0_3,
(MR_Word *) (MR_Integer) 0
},
5,
{
MR_CTOR0_ADDR(backend_libs__rtti, tc_name),
MR_COMMON(0,3),
MR_INT_CTOR_ADDR,
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(backend_libs__rtti, rtti_id)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_exist_constraints_data_8_0_1,
(MR_Word *) (MR_Integer) 0
},
5,
{
MR_CTOR0_ADDR(backend_libs__rtti, rtti_type_ctor),
MR_INT_CTOR_ADDR,
MR_INT_CTOR_ADDR,
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(backend_libs__rtti, rtti_id)
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_ptag_ordered_table_7_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_ctor_details_defn_10_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_ctor_details_defn_10_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_ctor_details_defn_10_0_4;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_ctor_details_defn_10_0_5;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_rtti_data_decl_group_6_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_ll_backend__rtti_out__type_ctor_info_data_group_0;
static const struct mercury_type_10 mercury_common_10[6] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_du_ptag_ordered_table_7_0_1,
(MR_Word *) (MR_Integer) 0
},
7,
{
MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, llds_out_info),
MR_CTOR0_ADDR(backend_libs__rtti, rtti_type_ctor),
MR_COMMON(1,4),
MR_COMMON(0,1),
MR_COMMON(0,1),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_type_ctor_details_defn_10_0_1,
(MR_Word *) (MR_Integer) 0
},
7,
{
MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, llds_out_info),
MR_CTOR0_ADDR(backend_libs__rtti, rtti_type_ctor),
MR_CTOR0_ADDR(backend_libs__rtti, du_functor),
MR_COMMON(0,1),
MR_COMMON(0,1),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_type_ctor_details_defn_10_0_2,
(MR_Word *) (MR_Integer) 0
},
7,
{
MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, llds_out_info),
MR_CTOR0_ADDR(backend_libs__rtti, rtti_type_ctor),
MR_CTOR0_ADDR(backend_libs__rtti, enum_functor),
MR_COMMON(0,1),
MR_COMMON(0,1),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_type_ctor_details_defn_10_0_4,
(MR_Word *) (MR_Integer) 0
},
7,
{
MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, llds_out_info),
MR_CTOR0_ADDR(backend_libs__rtti, rtti_type_ctor),
MR_CTOR0_ADDR(backend_libs__rtti, foreign_enum_functor),
MR_COMMON(0,1),
MR_COMMON(0,1),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_type_ctor_details_defn_10_0_5,
(MR_Word *) (MR_Integer) 0
},
7,
{
MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, llds_out_info),
MR_CTOR0_ADDR(backend_libs__rtti, rtti_type_ctor),
MR_CTOR0_ADDR(backend_libs__rtti, maybe_reserved_functor),
MR_COMMON(0,1),
MR_COMMON(0,1),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_rtti_data_decl_group_6_0_1,
(MR_Word *) (MR_Integer) 0
},
7,
{
MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, llds_out_info),
MR_CTOR0_ADDR(ll_backend__rtti_out, data_group),
MR_COMMON(0,13),
MR_COMMON(0,1),
MR_COMMON(0,1),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_res_value_ordered_table_8_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_arg_types_8_0_3;
static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_arg_names_8_0_1;
static const struct mercury_type_11 mercury_common_11[3] =
{
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_res_value_ordered_table_8_0_2,
(MR_Word *) (MR_Integer) 0,
1,
MR_CTOR0_ADDR(hlds__hlds_data, reserved_address)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_du_arg_types_8_0_3,
(MR_Word *) (MR_Integer) 0,
1,
MR_COMMON(0,8)
},
{
(MR_Word *) &mercury_data__closure_layout__ll_backend__rtti_out__output_du_arg_names_8_0_1,
(MR_Word *) (MR_Integer) 0,
1,
MR_COMMON(0,10)
},
};

static const struct mercury_type_12 mercury_common_12[9] =
{
{
MR_tbmkword(0, 9)
},
{
MR_tbmkword(0, 8)
},
{
MR_tbmkword(0, 5)
},
{
MR_tbmkword(0, 4)
},
{
MR_tbmkword(0, 7)
},
{
MR_tbmkword(0, 6)
},
{
MR_tbmkword(0, 3)
},
{
MR_tbmkword(0, 10)
},
{
MR_tbmkword(0, 11)
},
};

static const struct mercury_type_13 mercury_common_13[1] =
{
{
0,
MR_tbmkword(0, 0)
},
};
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_is_array_0;
extern const MR_TypeCtorInfo_Struct mercury_data_ll_backend__llds_out__llds_out_file__type_ctor_info_linkage_0;
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_is_array_0;
extern const MR_TypeCtorInfo_Struct mercury_data_ll_backend__llds_out__llds_out_file__type_ctor_info_linkage_0;

const MR_PseudoTypeInfo mercury_data_ll_backend__rtti_out__field_types_data_group_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_builtin__type_ctor_info_string_0,
	(MR_PseudoTypeInfo) &mercury_data_backend_libs__rtti__type_ctor_info_is_array_0,
	(MR_PseudoTypeInfo) &mercury_data_ll_backend__llds_out__llds_out_file__type_ctor_info_linkage_0
};

const MR_ConstString mercury_data_ll_backend__rtti_out__field_names_data_group_0_0[] = {
	"data_c_type",
	"data_is_array",
	"data_linkage"
};

static const MR_DuFunctorDesc mercury_data_ll_backend__rtti_out__du_functor_desc_data_group_0_0 = {
	"data_group",
	3,
	0,
	MR_SECTAG_NONE,
	0,
	-1,
	0,
	(MR_PseudoTypeInfo *) mercury_data_ll_backend__rtti_out__field_types_data_group_0_0,
	mercury_data_ll_backend__rtti_out__field_names_data_group_0_0,
	NULL
};

const MR_DuFunctorDescPtr mercury_data_ll_backend__rtti_out__du_stag_ordered_data_group_0_0[] = {
	&mercury_data_ll_backend__rtti_out__du_functor_desc_data_group_0_0

};

const MR_DuPtagLayout mercury_data_ll_backend__rtti_out__du_ptag_ordered_data_group_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_ll_backend__rtti_out__du_stag_ordered_data_group_0_0 }

};

const MR_DuFunctorDescPtr mercury_data_ll_backend__rtti_out__du_name_ordered_data_group_0[] = {
	&mercury_data_ll_backend__rtti_out__du_functor_desc_data_group_0_0
};

const MR_Integer mercury_data_ll_backend__rtti_out__functor_number_map_data_group_0[] = {
	0 };
	
const MR_TypeCtorInfo_Struct mercury_data_ll_backend__rtti_out__type_ctor_info_data_group_0 = {
	0,
	13,
	1,
	MR_TYPECTOR_REP_DU,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___ll_backend__rtti_out__data_group_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___ll_backend__rtti_out__data_group_0_0)),
	"ll_backend.rtti_out",
	"data_group",
	{ (void *)mercury_data_ll_backend__rtti_out__du_name_ordered_data_group_0 },
	{ (void *)mercury_data_ll_backend__rtti_out__du_ptag_ordered_data_group_0 },
	1,
	4,
	mercury_data_ll_backend__rtti_out__functor_number_map_data_group_0
};


static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_rtti_data_decl_group_6_0_1 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_rtti_data_decl_chunk",
7,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1444,
"d1;c10;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_stag_ordered_table_7_0_2 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_addr_of_ctor_rtti_id",
4,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1791,
"d2;c9;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_stag_ordered_table_7_0_1 = {
{
MR_FUNCTION,
"backend_libs.rtti",
"backend_libs.rtti",
"du_functor_rtti_name",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1207,
"d1;c11;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_functor_defn_7_0_3 = {
{
MR_FUNCTION,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"lambda_rtti_out_m_879",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
879,
"d1;c14;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_functor_defn_7_0_2 = {
{
MR_FUNCTION,
"backend_libs.rtti",
"backend_libs.rtti",
"du_arg_info_name",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
878,
"d1;c12;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_functor_defn_7_0_1 = {
{
MR_FUNCTION,
"backend_libs.rtti",
"backend_libs.rtti",
"du_arg_info_type",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
877,
"d1;c10;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_arg_names_8_0_2 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_maybe_quoted_string",
3,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1894,
"d1;c7;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_arg_names_8_0_1 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"lambda_rtti_out_m_1117",
1,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1117,
"d1;c14;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_arg_types_8_0_3 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"lambda_rtti_out_m_1103",
1,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1103,
"d1;c22;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_arg_types_8_0_2 = {
{
MR_FUNCTION,
"backend_libs.rtti",
"backend_libs.rtti",
"maybe_pseudo_type_info_or_self_to_rtti_data",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1095,
"d1;c12;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_arg_types_8_0_1 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_maybe_pseudo_type_info_or_self_defn",
6,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1093,
"d1;c9;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_exist_constraints_data_8_0_2 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_type_class_constraint",
10,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1042,
"d1;c9;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_exist_constraints_data_8_0_1 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"make_exist_tc_constr_id",
5,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1042,
"d1;c10;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_exist_locns_array_8_0_1 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_exist_locn",
3,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1921,
"d1;c7;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_constraint_10_0_2 = {
{
MR_FUNCTION,
"backend_libs.rtti",
"backend_libs.rtti",
"maybe_pseudo_type_info_to_rtti_data",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
423,
"d1;c21;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_constraint_10_0_1 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_maybe_pseudo_type_info_defn",
6,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
421,
"d1;c18;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__init_rtti_data_if_nec_3_0_1 = {
{
MR_FUNCTION,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"make_code_addr",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1669,
"d1;c4;d2;c7;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_ctor_data_defn_6_0_1 = {
{
MR_PREDICATE,
"ll_backend.llds_out.llds_out_code_addr",
"ll_backend.llds_out.llds_out_code_addr",
"output_record_code_addr_decls",
6,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
626,
"d1;c17;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_ctor_details_defn_10_0_5 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_maybe_res_functor_defn",
7,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
753,
"d1;c11;d4;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_ctor_details_defn_10_0_4 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_foreign_enum_functor_defn",
7,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
725,
"d1;c11;d2;c7;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_ctor_details_defn_10_0_3 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"lambda_rtti_out_m_723",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
723,
"d1;c11;d2;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_ctor_details_defn_10_0_2 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_enum_functor_defn",
7,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
709,
"d1;c11;d1;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_ctor_details_defn_10_0_1 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_du_functor_defn",
7,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
739,
"d1;c11;d3;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_functor_number_map_7_0_1 = {
{
MR_PREDICATE,
"io",
"io",
"write_int",
3,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1396,
"d1;c14;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_res_name_ordered_table_7_0_2 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_res_name_ordered_table_element",
4,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1337,
"d1;c17;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_res_name_ordered_table_7_0_1 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"lambda_rtti_out_m_1331",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1331,
"d1;c9;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_res_value_ordered_table_8_0_4 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_res_addr_functors",
4,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1303,
"d1;c25;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_res_value_ordered_table_8_0_3 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"lambda_rtti_out_m_1296",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1296,
"d1;c15;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_res_value_ordered_table_8_0_2 = {
{
MR_PREDICATE,
"backend_libs.rtti",
"backend_libs.rtti",
"res_addr_is_numeric",
1,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1292,
"d1;c11;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_res_value_ordered_table_8_0_1 = {
{
MR_FUNCTION,
"backend_libs.rtti",
"backend_libs.rtti",
"res_addr_rep",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1291,
"d1;c10;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_ptag_ordered_table_7_0_1 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_du_stag_ordered_table",
7,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1221,
"d1;c9;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0_1 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"lambda_rtti_out_m_1245",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1245,
"d2;c7;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_name_ordered_table_7_0_3 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_addr_of_ctor_rtti_id",
4,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1791,
"d2;c9;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_name_ordered_table_7_0_2 = {
{
MR_FUNCTION,
"backend_libs.rtti",
"backend_libs.rtti",
"du_functor_rtti_name",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1191,
"d1;c13;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_du_name_ordered_table_7_0_1 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"lambda_rtti_out_m_1189",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1189,
"d1;c9;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0_2 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_addr_of_ctor_rtti_id",
4,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1791,
"d2;c9;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0_1 = {
{
MR_FUNCTION,
"backend_libs.rtti",
"backend_libs.rtti",
"foreign_enum_functor_rtti_name",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1175,
"d1;c10;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0_2 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_addr_of_ctor_rtti_id",
4,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1791,
"d2;c9;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0_1 = {
{
MR_FUNCTION,
"backend_libs.rtti",
"backend_libs.rtti",
"foreign_enum_functor_rtti_name",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1160,
"d1;c10;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_enum_name_ordered_table_7_0_2 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_addr_of_ctor_rtti_id",
4,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1791,
"d2;c9;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_enum_name_ordered_table_7_0_1 = {
{
MR_FUNCTION,
"backend_libs.rtti",
"backend_libs.rtti",
"enum_functor_rtti_name",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1145,
"d1;c10;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_enum_value_ordered_table_7_0_2 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_addr_of_ctor_rtti_id",
4,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1791,
"d2;c9;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_enum_value_ordered_table_7_0_1 = {
{
MR_FUNCTION,
"backend_libs.rtti",
"backend_libs.rtti",
"enum_functor_rtti_name",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1131,
"d1;c10;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_2 = {
{
MR_FUNCTION,
"backend_libs.rtti",
"backend_libs.rtti",
"maybe_pseudo_type_info_to_rtti_data",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
575,
"d1;c7;d3;c10;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_1 = {
{
MR_FUNCTION,
"backend_libs.rtti",
"backend_libs.rtti",
"maybe_pseudo_type_info_to_rtti_data",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
556,
"d1;c7;d2;c9;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__do_output_type_info_defn_6_0_2 = {
{
MR_FUNCTION,
"backend_libs.rtti",
"backend_libs.rtti",
"type_info_to_rtti_data",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
507,
"d1;c7;d3;c10;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__do_output_type_info_defn_6_0_1 = {
{
MR_FUNCTION,
"backend_libs.rtti",
"backend_libs.rtti",
"type_info_to_rtti_data",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
490,
"d1;c7;d2;c9;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_ctor_arg_defns_and_decls_6_0_1 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_rtti_data_defn",
6,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
605,
"d1;c7;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_instance_defn_6_0_4 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_type_class_constraint",
10,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
334,
"d1;c23;d2;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_instance_defn_6_0_3 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"make_tc_instance_constraint_id",
5,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
334,
"d1;c23;d2;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_instance_defn_6_0_2 = {
{
MR_FUNCTION,
"backend_libs.rtti",
"backend_libs.rtti",
"maybe_pseudo_type_info_to_rtti_data",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
319,
"d1;c11;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_instance_defn_6_0_1 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_maybe_pseudo_type_info_defn",
6,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
317,
"d1;c8;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0_1 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_cast_addr_of_rtti_data",
4,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1804,
"d2;c9;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_decl_defn_6_0_4 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_type_class_constraint",
10,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
255,
"d1;c49;d2;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_decl_defn_6_0_3 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"make_tc_decl_super_id",
4,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
255,
"d1;c49;d2;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_decl_defn_6_0_2 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_type_class_id_method_id",
3,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
218,
"d1;c21;d2;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_type_class_decl_defn_6_0_1 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_type_class_id_tvar_name",
3,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
208,
"d1;c20;d2;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_cast_addr_of_rtti_ids_4_0_1 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_cast_addr_of_rtti_id",
4,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1781,
"d2;c9;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_base_typeclass_info_defn_9_0_4 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_static_code_addr",
3,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
178,
"d1;c35;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_base_typeclass_info_defn_9_0_3 = {
{
MR_PREDICATE,
"io",
"io",
"write_int",
3,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
175,
"d1;c30;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_base_typeclass_info_defn_9_0_2 = {
{
MR_PREDICATE,
"ll_backend.llds_out.llds_out_code_addr",
"ll_backend.llds_out.llds_out_code_addr",
"output_record_code_addr_decls",
6,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
167,
"d1;c13;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_base_typeclass_info_defn_9_0_1 = {
{
MR_FUNCTION,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"make_code_addr",
2,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
166,
"d1;c12;"
};

static const MR_UserClosureId
mercury_data__closure_layout__ll_backend__rtti_out__output_rtti_data_decl_list_6_0_1 = {
{
MR_PREDICATE,
"ll_backend.rtti_out",
"ll_backend.rtti_out",
"output_rtti_data_decl_group",
6,
0
},
"ll_backend.rtti_out",
"rtti_out.m",
1411,
"d1;c10;"
};


MR_decl_entry(fn__backend_libs__name_mangle__mercury_data_prefix_0_0);
MR_decl_entry(io__write_string_3_0);
MR_decl_entry(backend_libs__rtti__id_to_c_identifier_2_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module0)
	MR_init_entry1(ll_backend__rtti_out__output_rtti_id_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_rtti_id_3_0);
	MR_init_label3(ll_backend__rtti_out__output_rtti_id_3_0,2,3,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_rtti_id'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__ll_backend__rtti_out__output_rtti_id_3_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_np_call_localret_ent(fn__backend_libs__name_mangle__mercury_data_prefix_0_0,
		ll_backend__rtti_out__output_rtti_id_3_0_i2);
MR_def_label(ll_backend__rtti_out__output_rtti_id_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_rtti_id_3_0_i3);
MR_def_label(ll_backend__rtti_out__output_rtti_id_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(backend_libs__rtti__id_to_c_identifier_2_0,
		ll_backend__rtti_out__output_rtti_id_3_0_i4);
MR_def_label(ll_backend__rtti_out__output_rtti_id_3_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__write_string_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(backend_libs__rtti__rtti_data_to_id_2_0);
MR_decl_entry(fn__backend_libs__rtti__rtti_id_has_array_type_1_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module1)
	MR_init_entry1(ll_backend__rtti_out__output_addr_of_rtti_data_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_addr_of_rtti_data_3_0);
	MR_init_label9(ll_backend__rtti_out__output_addr_of_rtti_data_3_0,61,6,7,12,55,14,20,21,60)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_addr_of_rtti_data'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__ll_backend__rtti_out__output_addr_of_rtti_data_3_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_addr_of_rtti_data_3_0_i61);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(2, MR_r1, 0);
	if (MR_PTAG_TESTR(MR_tempr1,3)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_addr_of_rtti_data_3_0_i61);
	}
	MR_r1 = MR_tfield(3, MR_tempr1, 0);
	MR_np_tailcall_ent(io__write_int_3_0);
	}
MR_def_label(ll_backend__rtti_out__output_addr_of_rtti_data_3_0,61)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_np_call_localret_ent(backend_libs__rtti__rtti_data_to_id_2_0,
		ll_backend__rtti_out__output_addr_of_rtti_data_3_0_i6);
MR_def_label(ll_backend__rtti_out__output_addr_of_rtti_data_3_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_addr_of_rtti_data_3_0_i7);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_tfield(0, MR_r1, 1);
	if (MR_RTAGS_TESTR(MR_tempr1,3,11)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_addr_of_rtti_data_3_0_i7);
	}
	MR_tempr2 = MR_tfield(3, MR_tempr1, 1);
	if (MR_PTAG_TESTR(MR_tempr2,3)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_addr_of_rtti_data_3_0_i7);
	}
	MR_r1 = MR_tfield(3, MR_tempr2, 0);
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__write_int_3_0);
	}
MR_def_label(ll_backend__rtti_out__output_addr_of_rtti_data_3_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_np_call_localret_ent(fn__backend_libs__rtti__rtti_id_has_array_type_1_0,
		ll_backend__rtti_out__output_addr_of_rtti_data_3_0_i12);
MR_def_label(ll_backend__rtti_out__output_addr_of_rtti_data_3_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_addr_of_rtti_data_3_0_i14);
	}
MR_def_label(ll_backend__rtti_out__output_addr_of_rtti_data_3_0,55)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__backend_libs__name_mangle__mercury_data_prefix_0_0,
		ll_backend__rtti_out__output_addr_of_rtti_data_3_0_i20);
MR_def_label(ll_backend__rtti_out__output_addr_of_rtti_data_3_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("&", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_addr_of_rtti_data_3_0_i55);
MR_def_label(ll_backend__rtti_out__output_addr_of_rtti_data_3_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_addr_of_rtti_data_3_0_i21);
MR_def_label(ll_backend__rtti_out__output_addr_of_rtti_data_3_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(backend_libs__rtti__id_to_c_identifier_2_0,
		ll_backend__rtti_out__output_addr_of_rtti_data_3_0_i60);
MR_def_label(ll_backend__rtti_out__output_addr_of_rtti_data_3_0,60)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__write_string_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module2)
	MR_init_entry1(ll_backend__rtti_out__output_cast_addr_of_rtti_data_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_cast_addr_of_rtti_data_4_0);
	MR_init_label1(ll_backend__rtti_out__output_cast_addr_of_rtti_data_4_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_cast_addr_of_rtti_data'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__ll_backend__rtti_out__output_cast_addr_of_rtti_data_4_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_cast_addr_of_rtti_data_4_0_i2);
MR_def_label(ll_backend__rtti_out__output_cast_addr_of_rtti_data_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(ll_backend__rtti_out__output_addr_of_rtti_data_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(backend_libs__rtti__rtti_id_c_type_3_0);
MR_decl_entry(svmulti_map__set_4_0);
MR_decl_entry(fn__backend_libs__rtti__rtti_id_is_exported_1_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module3)
	MR_init_entry1(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0);
	MR_init_label10(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0,39,3,4,7,8,9,24,11,13,18)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'classify_rtti_datas_to_decl'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
MR_def_label(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0_i3);
	}
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(6);
MR_def_label(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_tfield(1, MR_r1, 1);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_tfield(1, MR_r1, 0);
	MR_r4 = MR_tempr1;
	if (MR_PTAG_TESTR(MR_tempr1,2)) {
		MR_GOTO_LAB(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0_i4);
	}
	MR_tempr2 = MR_tfield(2, MR_tempr1, 0);
	if (MR_PTAG_TESTR(MR_tempr2,3)) {
		MR_GOTO_LAB(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0_i4);
	}
	MR_r1 = MR_r3;
	MR_succip_word = MR_sv(6);
	MR_GOTO_LAB(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0_i39);
	}
MR_def_label(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r3;
	MR_r1 = MR_r4;
	MR_np_call_localret_ent(backend_libs__rtti__rtti_data_to_id_2_0,
		ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0_i7);
MR_def_label(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_np_call_localret_ent(backend_libs__rtti__rtti_id_c_type_3_0,
		ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0_i8);
MR_def_label(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_sv(5) = MR_r2;
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(fn__backend_libs__rtti__rtti_id_has_array_type_1_0,
		ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0_i9);
MR_def_label(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0_i11);
	}
MR_def_label(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 3);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(4);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(5);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 0;
	MR_r5 = MR_sv(1);
	MR_r4 = MR_sv(3);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(ll_backend__rtti_out, data_group);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_id);
	}
	MR_np_call_localret_ent(svmulti_map__set_4_0,
		ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0_i18);
MR_def_label(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(fn__backend_libs__rtti__rtti_id_is_exported_1_0,
		ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0_i13);
MR_def_label(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0_i24);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 3);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(4);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(5);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_r5 = MR_sv(1);
	MR_r4 = MR_sv(3);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(ll_backend__rtti_out, data_group);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_id);
	}
	MR_np_call_localret_ent(svmulti_map__set_4_0,
		ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0_i18);
MR_def_label(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(6);
	MR_GOTO_LAB(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0_i39);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__multi_map__init_0_0);
MR_decl_entry(multi_map__to_assoc_list_2_0);
extern const MR_TypeCtorInfo_Struct mercury_data_ll_backend__llds_out__llds_out_util__type_ctor_info_decl_set_0;
extern const MR_TypeCtorInfo_Struct mercury_data_io__type_ctor_info_state_0;
MR_decl_entry(list__foldl2_6_2);

MR_BEGIN_MODULE(ll_backend__rtti_out_module4)
	MR_init_entry1(ll_backend__rtti_out__output_rtti_data_decl_list_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_rtti_data_decl_list_6_0);
	MR_init_label3(ll_backend__rtti_out__output_rtti_data_decl_list_6_0,2,3,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_rtti_data_decl_list'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__ll_backend__rtti_out__output_rtti_data_decl_list_6_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_sv(4) = (MR_Word) MR_CTOR0_ADDR(ll_backend__rtti_out, data_group);
	MR_sv(5) = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_id);
	MR_r1 = MR_sv(4);
	MR_r2 = MR_sv(5);
	MR_np_call_localret_ent(fn__multi_map__init_0_0,
		ll_backend__rtti_out__output_rtti_data_decl_list_6_0_i2);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_list_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__classify_rtti_datas_to_decl_3_0,
		ll_backend__rtti_out__output_rtti_data_decl_list_6_0_i3);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_list_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = MR_sv(5);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(multi_map__to_assoc_list_2_0,
		ll_backend__rtti_out__output_rtti_data_decl_list_6_0_i4);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_list_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_rtti_data_decl_group_6_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tempr2 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,1);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, decl_set);
	MR_r3 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r5 = MR_tempr2;
	MR_r6 = MR_sv(3);
	MR_succip_word = MR_sv(6);
	MR_decr_sp(6);
	MR_np_tailcall_ent(list__foldl2_6_2);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module5)
	MR_init_entry1(ll_backend__rtti_out__rtti_type_class_constraint_template_arity_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__rtti_type_class_constraint_template_arity_2_0);
	MR_init_label2(ll_backend__rtti_out__rtti_type_class_constraint_template_arity_2_0,3,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'rtti_type_class_constraint_template_arity'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__rtti_type_class_constraint_template_arity_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(ll_backend__rtti_out__rtti_type_class_constraint_template_arity_2_0_i3);
	}
	MR_r2 = MR_tfield(2, MR_r1, 1);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(ll_backend__rtti_out__rtti_type_class_constraint_template_arity_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r1,3,2)) {
		MR_GOTO_LAB(ll_backend__rtti_out__rtti_type_class_constraint_template_arity_2_0_i1);
	}
	MR_r2 = MR_tfield(3, MR_r1, 3);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(ll_backend__rtti_out__rtti_type_class_constraint_template_arity_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_rtti_maybe_pseudo_type_info_0;
MR_decl_entry(fn__list__length_1_0);
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_rtti_type_info_0;
MR_decl_entry(ll_backend__llds_out__llds_out_util__decl_set_is_member_2_0);
MR_decl_entry(fn__string__int_to_string_1_0);
MR_decl_entry(fn__f_115_116_114_105_110_103_95_95_43_43_2_0);
MR_decl_entry(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module6)
	MR_init_entry1(ll_backend__rtti_out__output_rtti_type_decl_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_rtti_type_decl_5_0);
	MR_init_label10(ll_backend__rtti_out__output_rtti_type_decl_5_0,8,10,6,13,15,5,19,17,21,22)
	MR_init_label10(ll_backend__rtti_out__output_rtti_type_decl_5_0,23,24,25,26,27,28,29,30,2,3)
	MR_init_label10(ll_backend__rtti_out__output_rtti_type_decl_5_0,36,41,39,43,44,45,46,47,48,49)
	MR_init_label8(ll_backend__rtti_out__output_rtti_type_decl_5_0,50,51,52,53,54,55,33,34)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_rtti_type_decl'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_rtti_type_decl_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_type_decl_5_0_i3);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_tfield(0, MR_r1, 1);
	MR_r4 = MR_tempr1;
	if (MR_RTAGS_TESTR(MR_tempr1,3,11)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_type_decl_5_0_i6);
	}
	MR_tempr2 = MR_tfield(3, MR_tempr1, 1);
	MR_r5 = MR_tempr2;
	if (MR_PTAG_TESTR(MR_tempr2,1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_type_decl_5_0_i8);
	}
	MR_sv(1) = MR_r1;
	MR_sv(3) = MR_r2;
	MR_r2 = MR_tfield(1, MR_tempr2, 1);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info);
	}
	MR_np_call_localret_ent(fn__list__length_1_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i10);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r5,2)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_type_decl_5_0_i3);
	}
	MR_sv(1) = MR_r1;
	MR_sv(3) = MR_r2;
	MR_r2 = MR_tfield(2, MR_r5, 1);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info);
	MR_np_call_localret_ent(fn__list__length_1_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i10);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_LE(MR_r1,20)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_type_decl_5_0_i2);
	}
	MR_r2 = MR_sv(3);
	MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_type_decl_5_0_i5);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r4,3,10)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_type_decl_5_0_i3);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(3, MR_r4, 1);
	MR_r5 = MR_tempr1;
	if (MR_PTAG_TESTR(MR_tempr1,1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_type_decl_5_0_i13);
	}
	MR_sv(1) = MR_r1;
	MR_sv(3) = MR_r2;
	MR_r2 = MR_tfield(1, MR_tempr1, 1);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_type_info);
	}
	MR_np_call_localret_ent(fn__list__length_1_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i15);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r5,2)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_type_decl_5_0_i3);
	}
	MR_sv(1) = MR_r1;
	MR_sv(3) = MR_r2;
	MR_r2 = MR_tfield(2, MR_r5, 1);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_type_info);
	MR_np_call_localret_ent(fn__list__length_1_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i15);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_LE(MR_r1,20)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_type_decl_5_0_i2);
	}
	MR_r2 = MR_sv(3);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 5;
	MR_tfield(3, MR_tempr1, 1) = MR_r1;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tempr1;
	MR_sv(3) = MR_r2;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_is_member_2_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i19);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_type_decl_5_0_i17);
	}
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(5);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(2);
	MR_r2 = MR_sv(3);
	}
	MR_np_call_localret_ent(fn__string__int_to_string_1_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i21);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_string_const(");\n#endif\n", 10);
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i22);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("_GUARD\nMR_DECLARE_ALL_TYPE_INFO_LIKE_STRUCTS_FOR_ARITY(", 55);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i23);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(fn__string__int_to_string_1_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i24);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(4);
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i25);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("_GUARD\n#define MR_TYPE_INFO_LIKE_STRUCTS_FOR_ARITY_", 51);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i26);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__string__int_to_string_1_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i27);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i28);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("#ifndef MR_TYPE_INFO_LIKE_STRUCTS_FOR_ARITY_", 44);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i29);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i30);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(3);
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(3);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_type_decl_5_0_i34);
	}
	MR_sv(3) = MR_r2;
	MR_r1 = MR_tfield(1, MR_r1, 1);
	MR_np_call_localret_ent(ll_backend__rtti_out__rtti_type_class_constraint_template_arity_2_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i36);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_type_decl_5_0_i33);
	}
	if (MR_INT_LE(MR_r2,10)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_type_decl_5_0_i33);
	}
	MR_tag_alloc_heap(MR_r1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_r1, 0) = (MR_Integer) 6;
	MR_tfield(3, MR_r1, 1) = MR_r2;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_is_member_2_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i41);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,41)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_type_decl_5_0_i39);
	}
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(5);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__string__int_to_string_1_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i43);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_string_const(");\n#endif\n", 10);
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i44);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,44)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i45);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,45)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(fn__string__int_to_string_1_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i46);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,46)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(4);
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i47);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,47)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("_GUARD\nMR_DEFINE_TYPECLASS_CONSTRAINT_STRUCT(MR_TypeClassConstraint_", 68);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i48);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,48)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(fn__string__int_to_string_1_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i49);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,49)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(4);
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i50);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,50)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("_GUARD\n#define MR_TYPECLASS_CONSTRAINT_STRUCT_", 46);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i51);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,51)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_sv(2) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__string__int_to_string_1_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i52);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,52)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i53);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,53)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("#ifndef MR_TYPECLASS_CONSTRAINT_STRUCT_", 39);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i54);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,54)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_rtti_type_decl_5_0_i55);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,55)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(3);
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
MR_def_label(ll_backend__rtti_out__output_rtti_type_decl_5_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(5);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__ll_backend__llds_out__llds_out_file__c_data_linkage_string_2_0);
MR_decl_entry(fn__backend_libs__rtti__rtti_id_would_include_code_addr_1_0);
MR_decl_entry(fn__ll_backend__llds_out__llds_out_file__c_data_const_string_2_0);
MR_decl_entry(backend_libs__c_util__output_quoted_string_3_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module7)
	MR_init_entry1(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0);
	MR_init_label10(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,2,3,24,5,6,9,10,11,12,13)
	MR_init_label8(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,14,15,16,17,18,19,20,22)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_rtti_id_storage_type_name'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_r1 = MR_r2;
	MR_r2 = MR_r4;
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_type_decl_5_0,
		ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0_i2);
MR_def_label(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(fn__backend_libs__rtti__rtti_id_has_array_type_1_0,
		ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0_i3);
MR_def_label(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0_i5);
	}
MR_def_label(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_r1 = (MR_Integer) 0;
	MR_np_call_localret_ent(fn__ll_backend__llds_out__llds_out_file__c_data_linkage_string_2_0,
		ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0_i9);
MR_def_label(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(fn__backend_libs__rtti__rtti_id_is_exported_1_0,
		ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0_i6);
MR_def_label(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0_i24);
	}
	MR_r2 = MR_sv(3);
	MR_r1 = (MR_Integer) 1;
	MR_np_call_localret_ent(fn__ll_backend__llds_out__llds_out_file__c_data_linkage_string_2_0,
		ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0_i9);
MR_def_label(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0_i10);
MR_def_label(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_tfield(0, MR_sv(1), 18);
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(fn__backend_libs__rtti__rtti_id_would_include_code_addr_1_0,
		ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0_i11);
MR_def_label(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__ll_backend__llds_out__llds_out_file__c_data_const_string_2_0,
		ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0_i12);
MR_def_label(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0_i13);
MR_def_label(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(backend_libs__rtti__rtti_id_c_type_3_0,
		ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0_i14);
MR_def_label(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	MR_np_call_localret_ent(backend_libs__c_util__output_quoted_string_3_0,
		ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0_i15);
MR_def_label(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(" ", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0_i16);
MR_def_label(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__backend_libs__name_mangle__mercury_data_prefix_0_0,
		ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0_i17);
MR_def_label(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0_i18);
MR_def_label(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(backend_libs__rtti__id_to_c_identifier_2_0,
		ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0_i19);
MR_def_label(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0_i20);
MR_def_label(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(1),0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0_i22);
	}
	MR_r1 = (MR_Word) MR_string_const("[]", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0_i22);
MR_def_label(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_decr_sp_and_return(5);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module8)
	MR_init_entry1(ll_backend__rtti_out__output_rtti_data_decl_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_rtti_data_decl_6_0);
	MR_init_label4(ll_backend__rtti_out__output_rtti_data_decl_6_0,21,5,6,7)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_rtti_data_decl'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__ll_backend__rtti_out__output_rtti_data_decl_6_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,2)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_data_decl_6_0_i21);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(2, MR_r2, 0);
	if (MR_PTAG_TESTR(MR_tempr1,3)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_data_decl_6_0_i21);
	}
	MR_r1 = MR_r3;
	MR_proceed();
	}
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_6_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r3;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(backend_libs__rtti__rtti_data_to_id_2_0,
		ll_backend__rtti_out__output_rtti_data_decl_6_0_i5);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_sv(1);
	MR_r3 = (MR_Integer) 0;
	MR_r4 = MR_sv(2);
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_rtti_data_decl_6_0_i6);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_6_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(";\n", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_rtti_data_decl_6_0_i7);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(1);
	MR_r1 = MR_tempr1;
	MR_r2 = MR_sv(2);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_ll_backend__llds__type_ctor_info_code_addr_0;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_rtti__type_ctor_info_rtti_proc_label_0;
MR_decl_entry(fn__list__map_2_0);
MR_decl_entry(ll_backend__llds_out__llds_out_code_addr__output_record_code_addr_decls_6_0);
MR_decl_entry(io__write_list_5_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module9)
	MR_init_entry1(ll_backend__rtti_out__output_base_typeclass_info_defn_9_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_base_typeclass_info_defn_9_0);
	MR_init_label9(ll_backend__rtti_out__output_base_typeclass_info_defn_9_0,3,5,6,9,10,17,18,20,21)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_base_typeclass_info_defn'/9 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_base_typeclass_info_defn_9_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(13);
	MR_sv(13) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_sv(4) = MR_r4;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r5;
	MR_sv(5) = MR_tfield(0, MR_tempr1, 0);
	MR_sv(6) = MR_tfield(0, MR_tempr1, 1);
	MR_sv(7) = MR_tfield(0, MR_tempr1, 2);
	MR_sv(8) = MR_tfield(0, MR_tempr1, 3);
	MR_sv(9) = MR_tfield(0, MR_tempr1, 4);
	MR_sv(10) = MR_r6;
	MR_sv(12) = (MR_Word) MR_CTOR0_ADDR(ll_backend__llds, code_addr);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_rtti, rtti_proc_label);
	MR_r2 = MR_sv(12);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,0);
	MR_r4 = MR_tfield(0, MR_tempr1, 5);
	}
	MR_np_call_localret_ent(fn__list__map_2_0,
		ll_backend__rtti_out__output_base_typeclass_info_defn_9_0_i3);
MR_def_label(ll_backend__rtti_out__output_base_typeclass_info_defn_9_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,1);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__llds_out__llds_out_code_addr__output_record_code_addr_decls_6_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tempr2 = MR_sv(10);
	MR_sv(10) = MR_r1;
	MR_r1 = MR_sv(12);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, decl_set);
	MR_r3 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r5 = MR_sv(10);
	MR_r6 = MR_tempr2;
	}
	MR_np_call_localret_ent(list__foldl2_6_2,
		ll_backend__rtti_out__output_base_typeclass_info_defn_9_0_i5);
MR_def_label(ll_backend__rtti_out__output_base_typeclass_info_defn_9_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(11) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_base_typeclass_info_defn_9_0_i6);
MR_def_label(ll_backend__rtti_out__output_base_typeclass_info_defn_9_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_sv(3);
	MR_tfield(1, MR_tempr1, 1) = MR_sv(4);
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_sv(2);
	MR_tfield(1, MR_r2, 1) = MR_tempr1;
	MR_r1 = MR_sv(1);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(11);
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_base_typeclass_info_defn_9_0_i9);
MR_def_label(ll_backend__rtti_out__output_base_typeclass_info_defn_9_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n\t(MR_Code *) ", 18);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_base_typeclass_info_defn_9_0_i10);
MR_def_label(ll_backend__rtti_out__output_base_typeclass_info_defn_9_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_sv(9);
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = MR_sv(8);
	MR_tfield(1, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_sv(7);
	MR_tfield(1, MR_tempr1, 1) = MR_tempr2;
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = MR_sv(6);
	MR_tfield(1, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_sv(5);
	MR_tfield(1, MR_r2, 1) = MR_tempr2;
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r3 = (MR_Word) MR_string_const(",\n\t(MR_Code *) ", 15);
	MR_r4 = (MR_Word) MR_TAG_COMMON(0,4,1);
	}
	MR_np_call_localret_ent(io__write_list_5_0,
		ll_backend__rtti_out__output_base_typeclass_info_defn_9_0_i17);
MR_def_label(ll_backend__rtti_out__output_base_typeclass_info_defn_9_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_base_typeclass_info_defn_9_0_i18);
MR_def_label(ll_backend__rtti_out__output_base_typeclass_info_defn_9_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(12);
	MR_r2 = MR_sv(10);
	MR_r3 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_r4 = (MR_Word) MR_TAG_COMMON(0,4,2);
	MR_np_call_localret_ent(io__write_list_5_0,
		ll_backend__rtti_out__output_base_typeclass_info_defn_9_0_i20);
MR_def_label(ll_backend__rtti_out__output_base_typeclass_info_defn_9_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n};\n", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_base_typeclass_info_defn_9_0_i21);
MR_def_label(ll_backend__rtti_out__output_base_typeclass_info_defn_9_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(13);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module10)
	MR_init_entry1(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0);
	MR_init_label2(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0,2,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_generic_rtti_data_defn_start'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0_i2);
MR_def_label(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(3);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0_i3);
MR_def_label(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(2);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module11)
	MR_init_entry1(ll_backend__rtti_out__output_cast_addr_of_rtti_ids_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_cast_addr_of_rtti_ids_4_0);
	MR_init_label4(ll_backend__rtti_out__output_cast_addr_of_rtti_ids_4_0,4,3,6,8)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_cast_addr_of_rtti_ids'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_cast_addr_of_rtti_ids_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_cast_addr_of_rtti_ids_4_0_i3);
	}
	MR_r1 = (MR_Word) MR_string_const("\t/* Dummy entry, since ISO C forbids zero-sized arrays */\n", 58);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_cast_addr_of_rtti_ids_4_0_i4);
MR_def_label(ll_backend__rtti_out__output_cast_addr_of_rtti_ids_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\t0\n", 3);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(io__write_string_3_0);
MR_def_label(ll_backend__rtti_out__output_cast_addr_of_rtti_ids_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = (MR_Word) MR_string_const("\t", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_cast_addr_of_rtti_ids_4_0_i6);
MR_def_label(ll_backend__rtti_out__output_cast_addr_of_rtti_ids_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(6,0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_id);
	MR_r2 = MR_sv(2);
	MR_r3 = (MR_Word) MR_string_const(",\n\t", 3);
	}
	MR_np_call_localret_ent(io__write_list_5_0,
		ll_backend__rtti_out__output_cast_addr_of_rtti_ids_4_0_i8);
MR_def_label(ll_backend__rtti_out__output_cast_addr_of_rtti_ids_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(io__write_string_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(list__foldl_4_2);
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_tc_method_id_0;
MR_decl_entry(list__length_2_0);
MR_decl_entry(fn__mdbcomp__prim_data__sym_name_to_string_1_0);
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_tc_constraint_0;
MR_decl_entry(fn__counter__init_1_0);
extern const MR_TypeCtorInfo_Struct mercury_data_counter__type_ctor_info_counter_0;
MR_decl_entry(list__map_foldl3_9_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module12)
	MR_init_entry1(ll_backend__rtti_out__output_type_class_decl_defn_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_type_class_decl_defn_6_0);
	MR_init_label10(ll_backend__rtti_out__output_type_class_decl_defn_6_0,8,9,10,12,13,7,15,16,17,19)
	MR_init_label10(ll_backend__rtti_out__output_type_class_decl_defn_6_0,20,14,21,22,23,24,25,26,27,28)
	MR_init_label10(ll_backend__rtti_out__output_type_class_decl_defn_6_0,29,30,31,32,33,34,35,37,39,40)
	MR_init_label10(ll_backend__rtti_out__output_type_class_decl_defn_6_0,42,44,45,47,50,51,52,53,54,55)
	MR_init_label10(ll_backend__rtti_out__output_type_class_decl_defn_6_0,46,56,57,58,59,60,61,62,63,64)
	MR_init_label3(ll_backend__rtti_out__output_type_class_decl_defn_6_0,66,68,69)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_type_class_decl_defn'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_type_class_decl_defn_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(18);
	MR_sv(18) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6, MR_tempr7, MR_tempr8;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_sv(10) = MR_tempr1;
	MR_tempr2 = MR_tfield(0, MR_r2, 0);
	MR_r5 = MR_tempr2;
	MR_tfield(1, MR_tempr1, 0) = MR_tfield(0, MR_tempr2, 0);
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 1);
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 2);
	MR_sv(11) = MR_tempr3;
	MR_tfield(1, MR_tempr3, 0) = MR_tfield(1, MR_tempr1, 0);
	MR_tfield(1, MR_tempr3, 1) = (MR_Word) MR_tbmkword(0, 2);
	MR_tag_alloc_heap(MR_tempr4, 1, (MR_Integer) 2);
	MR_sv(12) = MR_tempr4;
	MR_tfield(1, MR_tempr4, 0) = MR_tfield(1, MR_tempr1, 0);
	MR_tfield(1, MR_tempr4, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr5, 1, (MR_Integer) 2);
	MR_sv(13) = MR_tempr5;
	MR_tfield(1, MR_tempr5, 0) = MR_tfield(1, MR_tempr1, 0);
	MR_tfield(1, MR_tempr5, 1) = (MR_Word) MR_tbmkword(0, 4);
	MR_tag_alloc_heap(MR_tempr6, 1, (MR_Integer) 2);
	MR_sv(14) = MR_tempr6;
	MR_tfield(1, MR_tempr6, 0) = MR_tfield(1, MR_tempr1, 0);
	MR_tfield(1, MR_tempr6, 1) = (MR_Word) MR_tbmkword(0, 3);
	MR_tempr7 = MR_tfield(0, MR_tempr2, 1);
	MR_r6 = MR_tempr7;
	if (MR_LTAGS_TESTR(MR_tempr7,0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_type_class_decl_defn_6_0_i8);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(0, MR_r2, 1);
	MR_sv(3) = MR_tfield(0, MR_r2, 2);
	MR_tempr8 = MR_tfield(1, MR_tempr1, 0);
	MR_sv(4) = MR_tempr8;
	MR_r2 = MR_tempr7;
	MR_sv(6) = MR_tfield(0, MR_tempr2, 2);
	MR_sv(7) = MR_tfield(0, MR_tempr8, 0);
	MR_sv(8) = MR_tfield(0, MR_tempr8, 1);
	MR_sv(9) = MR_tfield(0, MR_tempr8, 2);
	MR_sv(15) = MR_r3;
	MR_GOTO_LAB(ll_backend__rtti_out__output_type_class_decl_defn_6_0_i7);
	}
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(0, MR_r2, 1);
	MR_sv(3) = MR_tfield(0, MR_r2, 2);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_sv(10);
	MR_tempr1 = MR_tfield(1, MR_tempr2, 0);
	MR_sv(4) = MR_tempr1;
	MR_sv(5) = MR_r6;
	MR_sv(6) = MR_tfield(0, MR_r5, 2);
	MR_sv(7) = MR_tfield(0, MR_tempr1, 0);
	MR_sv(8) = MR_tfield(0, MR_tempr1, 1);
	MR_sv(9) = MR_tfield(0, MR_tempr1, 2);
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i9);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(15) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i10);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r2 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,3);
	MR_r4 = MR_sv(5);
	MR_np_call_localret_ent(list__foldl_4_2,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i12);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("};\n", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i13);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(5);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(6),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_type_class_decl_defn_6_0_i15);
	}
	MR_sv(16) = MR_sv(15);
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_GOTO_LAB(ll_backend__rtti_out__output_type_class_decl_defn_6_0_i14);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(5) = MR_r2;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(11);
	MR_r3 = MR_sv(15);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i16);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(16) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i17);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, tc_method_id);
	MR_r2 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,4);
	MR_r4 = MR_sv(6);
	MR_np_call_localret_ent(list__foldl_4_2,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i19);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("};\n", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i20);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(5);
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(5) = MR_r2;
	MR_np_call_localret_ent(list__length_2_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i21);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(15) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, tc_method_id);
	MR_r2 = MR_sv(6);
	MR_np_call_localret_ent(list__length_2_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i22);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(16);
	MR_sv(16) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(12);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i23);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(17) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n\t\"", 7);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i24);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(7);
	MR_np_call_localret_ent(fn__mdbcomp__prim_data__sym_name_to_string_1_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i25);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(backend_libs__c_util__output_quoted_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i26);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\",\n\t\"", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i27);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(8);
	MR_np_call_localret_ent(backend_libs__c_util__output_quoted_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i28);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\",\n\t", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i29);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(9);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i30);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i31);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(15);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i32);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i33);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(16);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i34);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i35);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(5),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_type_class_decl_defn_6_0_i37);
	}
	MR_r1 = (MR_Word) MR_string_const("NULL", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i39);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,37)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(10);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i39);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i40);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(6),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_type_class_decl_defn_6_0_i42);
	}
	MR_r1 = (MR_Word) MR_string_const("NULL", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i44);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,42)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(11);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i44);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,44)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n};\n", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i45);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,45)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(3),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_type_class_decl_defn_6_0_i47);
	}
	MR_r2 = MR_sv(3);
	MR_sv(5) = MR_sv(17);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, tc_constraint);
	MR_GOTO_LAB(ll_backend__rtti_out__output_type_class_decl_defn_6_0_i46);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,47)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 4);
	MR_tfield(0, MR_r2, 0) = (MR_Word) MR_COMMON(6,1);
	MR_tfield(0, MR_r2, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__make_tc_decl_super_id_4_0);
	MR_tfield(0, MR_r2, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_r2, 3) = MR_sv(4);
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_sv(4) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(8,0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_type_class_constraint_10_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 4) = MR_r2;
	MR_r1 = (MR_Integer) 1;
	}
	MR_np_call_localret_ent(fn__counter__init_1_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i50);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,50)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, tc_constraint);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_id);
	MR_r3 = (MR_Word) MR_CTOR0_ADDR(counter, counter);
	MR_r4 = (MR_Word) MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, decl_set);
	MR_r5 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r6 = MR_sv(4);
	MR_r7 = MR_sv(3);
	MR_r8 = MR_tempr1;
	MR_r9 = MR_sv(17);
	}
	MR_np_call_localret_ent(list__map_foldl3_9_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i51);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,51)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(13);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i52);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,52)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(5) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i53);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,53)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("(MR_TypeClassConstraint) ", 25);
	MR_r2 = MR_sv(4);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_cast_addr_of_rtti_ids_4_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i54);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,54)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("};\n", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i55);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,55)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, tc_constraint);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,46)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r2;
	MR_np_call_localret_ent(list__length_2_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i56);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,56)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_sv(14);
	MR_r3 = MR_sv(5);
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i57);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,57)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n\t&", 7);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i58);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,58)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(12);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i59);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,59)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i60);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,60)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i61);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,61)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i62);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,62)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i63);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,63)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i64);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,64)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(3),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_type_class_decl_defn_6_0_i66);
	}
	MR_r1 = (MR_Word) MR_string_const("NULL", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i68);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,66)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(13);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i68);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,68)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n};\n", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_decl_defn_6_0_i69);
MR_def_label(ll_backend__rtti_out__output_type_class_decl_defn_6_0,69)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_decr_sp_and_return(18);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(ll_backend__llds_out__llds_out_data__output_record_data_id_decls_format_10_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module13)
	MR_init_entry1(ll_backend__rtti_out__output_record_rtti_id_decls_10_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_record_rtti_id_decls_10_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_record_rtti_id_decls'/10 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_record_rtti_id_decls_10_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 1);
	MR_tfield(0, MR_tempr1, 0) = MR_r2;
	MR_r2 = MR_tempr1;
	MR_np_tailcall_ent(ll_backend__llds_out__llds_out_data__output_record_data_id_decls_format_10_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_rtti_data_0;

MR_BEGIN_MODULE(ll_backend__rtti_out_module14)
	MR_init_entry1(ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0);
	MR_init_label4(ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0,4,3,6,8)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_cast_addr_of_rtti_datas'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0_i3);
	}
	MR_r1 = (MR_Word) MR_string_const("\t/* Dummy entry, since ISO C forbids zero-sized arrays */\n", 58);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0_i4);
MR_def_label(ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\t0\n", 3);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(io__write_string_3_0);
MR_def_label(ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = (MR_Word) MR_string_const("\t", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0_i6);
MR_def_label(ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(6,2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_cast_addr_of_rtti_data_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_data);
	MR_r2 = MR_sv(2);
	MR_r3 = (MR_Word) MR_string_const(",\n\t", 3);
	}
	MR_np_call_localret_ent(io__write_list_5_0,
		ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0_i8);
MR_def_label(ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(io__write_string_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module15)
	MR_init_entry1(ll_backend__rtti_out__output_type_class_instance_defn_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_type_class_instance_defn_6_0);
	MR_init_label10(ll_backend__rtti_out__output_type_class_instance_defn_6_0,3,5,8,9,10,11,15,19,20,21)
	MR_init_label10(ll_backend__rtti_out__output_type_class_instance_defn_6_0,22,23,24,14,26,29,30,31,32,33)
	MR_init_label9(ll_backend__rtti_out__output_type_class_instance_defn_6_0,34,35,36,37,38,39,41,43,44)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_type_class_instance_defn'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_type_class_instance_defn_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(12);
	MR_sv(12) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_maybe_pseudo_type_info_defn_6_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(0, MR_r2, 0);
	MR_sv(3) = MR_tfield(0, MR_r2, 1);
	MR_sv(4) = MR_tfield(0, MR_r2, 2);
	MR_sv(5) = MR_tfield(0, MR_r2, 3);
	MR_sv(6) = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info);
	MR_sv(10) = (MR_Word) MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, decl_set);
	MR_sv(11) = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(10);
	MR_tempr2 = MR_r3;
	MR_r3 = MR_sv(11);
	MR_r4 = MR_tempr1;
	MR_r5 = MR_sv(3);
	MR_r6 = MR_tempr2;
	}
	MR_np_call_localret_ent(list__foldl2_6_2,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i3);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(6) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_data);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,5);
	MR_r4 = MR_sv(3);
	MR_np_call_localret_ent(fn__list__map_2_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i5);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 1;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(3);
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_sv(2);
	MR_tfield(1, MR_r2, 1) = MR_tempr1;
	MR_tempr2 = MR_sv(6);
	MR_sv(6) = MR_r1;
	MR_sv(7) = MR_r2;
	MR_r1 = MR_sv(1);
	MR_r3 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i8);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(8) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i9);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("(MR_PseudoTypeInfo) ", 20);
	MR_r2 = MR_sv(6);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i10);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("};\n", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i11);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_r8 = MR_tempr1;
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 3;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(3);
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_sv(6) = MR_tempr2;
	MR_tempr3 = MR_sv(2);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr3;
	MR_tfield(1, MR_tempr2, 1) = MR_tempr1;
	if (MR_LTAGS_TESTR(MR_sv(5),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_type_class_instance_defn_6_0_i15);
	}
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_tempr3;
	MR_tfield(1, MR_r2, 1) = (MR_Word) MR_tbmkword(0, 3);
	MR_r1 = MR_sv(1);
	MR_r6 = MR_sv(8);
	MR_r3 = (MR_Word) MR_string_const("", 0);
	MR_r4 = (MR_Word) MR_string_const("", 0);
	MR_r5 = (MR_Integer) 0;
	MR_GOTO_LAB(ll_backend__rtti_out__output_type_class_instance_defn_6_0_i14);
	}
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 5);
	MR_tfield(0, MR_r2, 0) = (MR_Word) MR_COMMON(9,0);
	MR_tfield(0, MR_r2, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__make_tc_instance_constraint_id_5_0);
	MR_tfield(0, MR_r2, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_r2, 3) = MR_sv(2);
	MR_tfield(0, MR_r2, 4) = MR_sv(3);
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_sv(9) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(8,1);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_type_class_constraint_10_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 4) = MR_r2;
	MR_r1 = (MR_Integer) 1;
	}
	MR_np_call_localret_ent(fn__counter__init_1_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i19);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, tc_constraint);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_id);
	MR_r3 = (MR_Word) MR_CTOR0_ADDR(counter, counter);
	MR_r4 = MR_sv(10);
	MR_r5 = MR_sv(11);
	MR_r6 = MR_sv(9);
	MR_r7 = MR_sv(5);
	MR_r8 = MR_tempr1;
	MR_r9 = MR_sv(8);
	}
	MR_np_call_localret_ent(list__map_foldl3_9_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i20);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(8) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(6);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i21);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(9) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i22);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("(MR_TypeClassConstraint) ", 25);
	MR_r2 = MR_sv(8);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_cast_addr_of_rtti_ids_4_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i23);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("};\n", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i24);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_sv(2);
	MR_tfield(1, MR_r2, 1) = (MR_Word) MR_tbmkword(0, 3);
	MR_r1 = MR_sv(1);
	MR_r6 = MR_sv(9);
	MR_r3 = (MR_Word) MR_string_const("", 0);
	MR_r4 = (MR_Word) MR_string_const("", 0);
	MR_r5 = (MR_Integer) 0;
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_sv(8) = MR_r2;
	MR_np_call_localret_ent(ll_backend__rtti_out__output_record_rtti_id_decls_10_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i26);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(3);
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = MR_sv(2);
	MR_tfield(1, MR_tempr2, 1) = MR_tempr1;
	MR_r1 = MR_sv(1);
	MR_tempr1 = MR_r2;
	MR_r2 = MR_tempr2;
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i29);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n\t&", 7);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i30);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(8);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_3_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i31);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i32);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i33);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i34);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, tc_constraint);
	MR_r2 = MR_sv(5);
	MR_np_call_localret_ent(fn__list__length_1_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i35);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i36);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i37);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,37)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(7);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_3_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i38);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,38)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i39);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(5),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_type_class_instance_defn_6_0_i41);
	}
	MR_r1 = (MR_Word) MR_string_const("NULL", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i43);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,41)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(6);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_3_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i43);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n};\n", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_instance_defn_6_0_i44);
MR_def_label(ll_backend__rtti_out__output_type_class_instance_defn_6_0,44)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(12);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module16)
	MR_init_entry1(ll_backend__rtti_out__output_record_rtti_data_decls_10_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_record_rtti_data_decls_10_0);
	MR_init_label2(ll_backend__rtti_out__output_record_rtti_data_decls_10_0,19,5)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_record_rtti_data_decls'/10 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_record_rtti_data_decls_10_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,2)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_record_rtti_data_decls_10_0_i19);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(2, MR_r2, 0);
	if (MR_PTAG_TESTR(MR_tempr1,3)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_record_rtti_data_decls_10_0_i19);
	}
	MR_r1 = MR_r5;
	MR_r2 = MR_r6;
	MR_proceed();
	}
MR_def_label(ll_backend__rtti_out__output_record_rtti_data_decls_10_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_r4;
	MR_sv(4) = MR_r5;
	MR_sv(5) = MR_r6;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(backend_libs__rtti__rtti_data_to_id_2_0,
		ll_backend__rtti_out__output_record_rtti_data_decls_10_0_i5);
MR_def_label(ll_backend__rtti_out__output_record_rtti_data_decls_10_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 1);
	MR_tfield(0, MR_r2, 0) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r3 = MR_sv(2);
	MR_r4 = MR_sv(3);
	MR_r5 = MR_sv(4);
	MR_r6 = MR_sv(5);
	MR_succip_word = MR_sv(6);
	MR_decr_sp(6);
	MR_np_tailcall_ent(ll_backend__llds_out__llds_out_data__output_record_data_id_decls_format_10_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module17)
	MR_init_entry1(ll_backend__rtti_out__output_record_rtti_datas_decls_10_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_record_rtti_datas_decls_10_0);
	MR_init_label5(ll_backend__rtti_out__output_record_rtti_datas_decls_10_0,25,3,4,7,9)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_record_rtti_datas_decls'/10 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_record_rtti_datas_decls_10_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
MR_def_label(ll_backend__rtti_out__output_record_rtti_datas_decls_10_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_record_rtti_datas_decls_10_0_i3);
	}
	MR_r1 = MR_r5;
	MR_r2 = MR_r6;
	MR_decr_sp_and_return(7);
MR_def_label(ll_backend__rtti_out__output_record_rtti_datas_decls_10_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r8 = MR_tfield(1, MR_r2, 1);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_tfield(1, MR_r2, 0);
	MR_r9 = MR_tempr1;
	if (MR_PTAG_TESTR(MR_tempr1,2)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_record_rtti_datas_decls_10_0_i4);
	}
	MR_tempr2 = MR_tfield(2, MR_tempr1, 0);
	if (MR_PTAG_TESTR(MR_tempr2,3)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_record_rtti_datas_decls_10_0_i4);
	}
	MR_r2 = MR_r8;
	MR_succip_word = MR_sv(7);
	MR_GOTO_LAB(ll_backend__rtti_out__output_record_rtti_datas_decls_10_0_i25);
	}
MR_def_label(ll_backend__rtti_out__output_record_rtti_datas_decls_10_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_r4;
	MR_sv(4) = MR_r5;
	MR_sv(5) = MR_r6;
	MR_sv(6) = MR_r8;
	MR_r1 = MR_r9;
	MR_np_call_localret_ent(backend_libs__rtti__rtti_data_to_id_2_0,
		ll_backend__rtti_out__output_record_rtti_datas_decls_10_0_i7);
MR_def_label(ll_backend__rtti_out__output_record_rtti_datas_decls_10_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 1);
	MR_tfield(0, MR_r2, 0) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r3 = MR_sv(2);
	MR_r4 = MR_sv(3);
	MR_r5 = MR_sv(4);
	MR_r6 = MR_sv(5);
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_data__output_record_data_id_decls_format_10_0,
		ll_backend__rtti_out__output_record_rtti_datas_decls_10_0_i9);
MR_def_label(ll_backend__rtti_out__output_record_rtti_datas_decls_10_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r3 = MR_sv(2);
	MR_r4 = MR_sv(3);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_sv(6);
	MR_r5 = MR_tempr1;
	MR_r6 = MR_tempr2;
	MR_succip_word = MR_sv(7);
	MR_GOTO_LAB(ll_backend__rtti_out__output_record_rtti_datas_decls_10_0_i25);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module18)
	MR_init_entry1(ll_backend__rtti_out__output_type_ctor_arg_defns_and_decls_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_type_ctor_arg_defns_and_decls_6_0);
	MR_init_label2(ll_backend__rtti_out__output_type_ctor_arg_defns_and_decls_6_0,3,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_type_ctor_arg_defns_and_decls'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_type_ctor_arg_defns_and_decls_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,3);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_rtti_data_defn_6_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_data);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, decl_set);
	MR_tempr2 = MR_r3;
	MR_r3 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r4 = MR_tempr1;
	MR_r5 = MR_sv(2);
	MR_r6 = MR_tempr2;
	}
	MR_np_call_localret_ent(list__foldl2_6_2,
		ll_backend__rtti_out__output_type_ctor_arg_defns_and_decls_6_0_i3);
MR_def_label(ll_backend__rtti_out__output_type_ctor_arg_defns_and_decls_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = (MR_Word) MR_string_const("", 0);
	MR_r4 = (MR_Word) MR_string_const("", 0);
	MR_r5 = (MR_Integer) 0;
	MR_r6 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_record_rtti_datas_decls_10_0,
		ll_backend__rtti_out__output_type_ctor_arg_defns_and_decls_6_0_i4);
MR_def_label(ll_backend__rtti_out__output_type_ctor_arg_defns_and_decls_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(3);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module19)
	MR_init_entry1(ll_backend__rtti_out__output_ctor_rtti_id_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_ctor_rtti_id_4_0);
	MR_init_label3(ll_backend__rtti_out__output_ctor_rtti_id_4_0,3,4,5)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_ctor_rtti_id'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_ctor_rtti_id_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_sv(1) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_r1;
	MR_tfield(0, MR_tempr1, 1) = MR_r2;
	}
	MR_np_call_localret_ent(fn__backend_libs__name_mangle__mercury_data_prefix_0_0,
		ll_backend__rtti_out__output_ctor_rtti_id_4_0_i3);
MR_def_label(ll_backend__rtti_out__output_ctor_rtti_id_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_ctor_rtti_id_4_0_i4);
MR_def_label(ll_backend__rtti_out__output_ctor_rtti_id_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(backend_libs__rtti__id_to_c_identifier_2_0,
		ll_backend__rtti_out__output_ctor_rtti_id_4_0_i5);
MR_def_label(ll_backend__rtti_out__output_ctor_rtti_id_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__write_string_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__backend_libs__rtti__var_arity_id_to_rtti_type_ctor_1_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module20)
	MR_init_entry1(ll_backend__rtti_out__do_output_type_info_defn_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__do_output_type_info_defn_6_0);
	MR_init_label10(ll_backend__rtti_out__do_output_type_info_defn_6_0,5,3,8,10,11,14,15,16,17,18)
	MR_init_label10(ll_backend__rtti_out__do_output_type_info_defn_6_0,6,20,22,24,25,28,29,30,31,32)
	MR_init_label4(ll_backend__rtti_out__do_output_type_info_defn_6_0,33,34,35,36)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'do_output_type_info_defn'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__do_output_type_info_defn_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	if (MR_PTAG_TESTR(MR_r2,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__do_output_type_info_defn_6_0_i3);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_tfield(0, MR_r2, 0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 16);
	MR_r2 = MR_tempr1;
	MR_tempr2 = MR_r3;
	MR_r3 = (MR_Word) MR_string_const("", 0);
	MR_r4 = (MR_Word) MR_string_const("", 0);
	MR_r5 = (MR_Integer) 0;
	MR_r6 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_record_rtti_id_decls_10_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i5);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(7);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__do_output_type_info_defn_6_0_i6);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_tfield(1, MR_r2, 0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 16);
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_tfield(1, MR_r2, 1);
	MR_sv(4) = MR_tfield(0, MR_tempr1, 0);
	MR_r2 = MR_tempr1;
	MR_tempr2 = MR_r3;
	MR_r3 = (MR_Word) MR_string_const("", 0);
	MR_r4 = (MR_Word) MR_string_const("", 0);
	MR_r5 = (MR_Integer) 0;
	MR_r6 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_record_rtti_id_decls_10_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i8);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(3);
	MR_sv(3) = MR_r2;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_type_info);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_data);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,6);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__list__map_2_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i10);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(3);
	MR_sv(3) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(3);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_type_ctor_arg_defns_and_decls_6_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i11);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 10;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(2);
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr2, 0) = MR_sv(4);
	MR_tfield(0, MR_tempr2, 1) = MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr2;
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i14);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n\t&", 7);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i15);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_r2 = (MR_Word) MR_tbmkword(0, 16);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_ctor_rtti_id_4_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i16);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n{", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i17);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("(MR_TypeInfo) ", 14);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i18);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("}};\n", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i36);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_sv(4) = MR_tfield(2, MR_r2, 1);
	MR_r1 = MR_tfield(2, MR_r2, 0);
	MR_np_call_localret_ent(fn__backend_libs__rtti__var_arity_id_to_rtti_type_ctor_1_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i20);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_r1;
	MR_tfield(0, MR_r2, 1) = (MR_Word) MR_tbmkword(0, 16);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(3);
	MR_sv(3) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r3 = (MR_Word) MR_string_const("", 0);
	MR_r4 = (MR_Word) MR_string_const("", 0);
	MR_r5 = (MR_Integer) 0;
	MR_r6 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_record_rtti_id_decls_10_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i22);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(5) = MR_r2;
	MR_sv(6) = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_type_info);
	MR_r1 = MR_sv(6);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_data);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,7);
	MR_r4 = MR_sv(4);
	MR_np_call_localret_ent(fn__list__map_2_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i24);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(5);
	MR_sv(5) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(5);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_type_ctor_arg_defns_and_decls_6_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i25);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 10;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(2);
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr2, 0) = MR_sv(3);
	MR_tfield(0, MR_tempr2, 1) = MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr2;
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i28);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n\t&", 7);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i29);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_tbmkword(0, 16);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_ctor_rtti_id_4_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i30);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i31);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(4);
	MR_np_call_localret_ent(list__length_2_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i32);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i33);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n{", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i34);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("(MR_TypeInfo) ", 14);
	MR_r2 = MR_sv(5);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i35);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("}};\n", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__do_output_type_info_defn_6_0_i36);
MR_def_label(ll_backend__rtti_out__do_output_type_info_defn_6_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(7);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module21)
	MR_init_entry1(ll_backend__rtti_out__output_type_info_defn_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_type_info_defn_6_0);
	MR_init_label3(ll_backend__rtti_out__output_type_info_defn_6_0,4,6,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_type_info_defn'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_type_info_defn_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 1);
	MR_tfield(1, MR_tempr1, 0) = MR_r2;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(backend_libs__rtti__rtti_data_to_id_2_0,
		ll_backend__rtti_out__output_type_info_defn_6_0_i4);
MR_def_label(ll_backend__rtti_out__output_type_info_defn_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_sv(3);
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_is_member_2_0,
		ll_backend__rtti_out__output_type_info_defn_6_0_i6);
MR_def_label(ll_backend__rtti_out__output_type_info_defn_6_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_type_info_defn_6_0_i2);
	}
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(4);
MR_def_label(ll_backend__rtti_out__output_type_info_defn_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(3);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(ll_backend__rtti_out__do_output_type_info_defn_6_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module22)
	MR_init_entry1(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0);
	MR_init_label10(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,5,3,8,10,11,14,15,16,17,18)
	MR_init_label10(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,6,63,21,23,25,26,29,30,31,32)
	MR_init_label5(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,33,34,35,36,37)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'do_output_pseudo_type_info_defn'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i3);
	}
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_tfield(0, MR_r2, 0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 16);
	MR_r2 = MR_tempr1;
	MR_tempr2 = MR_r3;
	MR_r3 = (MR_Word) MR_string_const("", 0);
	MR_r4 = (MR_Word) MR_string_const("", 0);
	MR_r5 = (MR_Integer) 0;
	MR_r6 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_record_rtti_id_decls_10_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i5);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(7);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i6);
	}
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_tfield(1, MR_r2, 0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 16);
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_tfield(1, MR_r2, 1);
	MR_sv(4) = MR_tfield(0, MR_tempr1, 0);
	MR_r2 = MR_tempr1;
	MR_tempr2 = MR_r3;
	MR_r3 = (MR_Word) MR_string_const("", 0);
	MR_r4 = (MR_Word) MR_string_const("", 0);
	MR_r5 = (MR_Integer) 0;
	MR_r6 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_record_rtti_id_decls_10_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i8);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(3);
	MR_sv(3) = MR_r2;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_data);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,8);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__list__map_2_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i10);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(3);
	MR_sv(3) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(3);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_type_ctor_arg_defns_and_decls_6_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i11);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 11;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(2);
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr2, 0) = MR_sv(4);
	MR_tfield(0, MR_tempr2, 1) = MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr2;
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i14);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n\t&", 7);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i15);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_r2 = (MR_Word) MR_tbmkword(0, 16);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_ctor_rtti_id_4_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i16);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n{", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i17);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("(MR_PseudoTypeInfo) ", 20);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i18);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("}};\n", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i37);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,3)) {
		MR_GOTO_LAB(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i63);
	}
	MR_r1 = MR_r3;
	MR_proceed();
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,63)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_sv(4) = MR_tfield(2, MR_r2, 1);
	MR_r1 = MR_tfield(2, MR_r2, 0);
	MR_np_call_localret_ent(fn__backend_libs__rtti__var_arity_id_to_rtti_type_ctor_1_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i21);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_r1;
	MR_tfield(0, MR_r2, 1) = (MR_Word) MR_tbmkword(0, 16);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(3);
	MR_sv(3) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r3 = (MR_Word) MR_string_const("", 0);
	MR_r4 = (MR_Word) MR_string_const("", 0);
	MR_r5 = (MR_Integer) 0;
	MR_r6 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_record_rtti_id_decls_10_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i23);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(5) = MR_r2;
	MR_sv(6) = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info);
	MR_r1 = MR_sv(6);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_data);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,9);
	MR_r4 = MR_sv(4);
	MR_np_call_localret_ent(fn__list__map_2_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i25);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(5);
	MR_sv(5) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(5);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_type_ctor_arg_defns_and_decls_6_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i26);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 11;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(2);
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr2, 0) = MR_sv(3);
	MR_tfield(0, MR_tempr2, 1) = MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr2;
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i29);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n\t&", 7);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i30);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_tbmkword(0, 16);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_ctor_rtti_id_4_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i31);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i32);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(6);
	MR_r2 = MR_sv(4);
	MR_np_call_localret_ent(list__length_2_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i33);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i34);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n{", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i35);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("(MR_PseudoTypeInfo) ", 20);
	MR_r2 = MR_sv(5);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i36);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("}};\n", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0_i37);
MR_def_label(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0,37)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(7);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module23)
	MR_init_entry1(ll_backend__rtti_out__output_pseudo_type_info_defn_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_pseudo_type_info_defn_6_0);
	MR_init_label4(ll_backend__rtti_out__output_pseudo_type_info_defn_6_0,24,6,8,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_pseudo_type_info_defn'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_pseudo_type_info_defn_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,3)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_pseudo_type_info_defn_6_0_i24);
	}
	MR_r1 = MR_r3;
	MR_proceed();
MR_def_label(ll_backend__rtti_out__output_pseudo_type_info_defn_6_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 2, (MR_Integer) 1);
	MR_tfield(2, MR_tempr1, 0) = MR_r2;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(backend_libs__rtti__rtti_data_to_id_2_0,
		ll_backend__rtti_out__output_pseudo_type_info_defn_6_0_i6);
MR_def_label(ll_backend__rtti_out__output_pseudo_type_info_defn_6_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_sv(3);
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_is_member_2_0,
		ll_backend__rtti_out__output_pseudo_type_info_defn_6_0_i8);
MR_def_label(ll_backend__rtti_out__output_pseudo_type_info_defn_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_pseudo_type_info_defn_6_0_i4);
	}
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(4);
MR_def_label(ll_backend__rtti_out__output_pseudo_type_info_defn_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(3);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(ll_backend__rtti_out__do_output_pseudo_type_info_defn_6_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module24)
	MR_init_entry1(ll_backend__rtti_out__output_maybe_pseudo_type_info_defn_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_maybe_pseudo_type_info_defn_6_0);
	MR_init_label1(ll_backend__rtti_out__output_maybe_pseudo_type_info_defn_6_0,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_maybe_pseudo_type_info_defn'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_maybe_pseudo_type_info_defn_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_maybe_pseudo_type_info_defn_6_0_i3);
	}
	MR_r2 = MR_tfield(1, MR_r2, 0);
	MR_np_tailcall_ent(ll_backend__rtti_out__output_type_info_defn_6_0);
MR_def_label(ll_backend__rtti_out__output_maybe_pseudo_type_info_defn_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_tfield(0, MR_r2, 0);
	MR_np_tailcall_ent(ll_backend__rtti_out__output_pseudo_type_info_defn_6_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module25)
	MR_init_entry1(ll_backend__rtti_out__output_notag_functor_defn_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_notag_functor_defn_7_0);
	MR_init_label10(ll_backend__rtti_out__output_notag_functor_defn_7_0,3,5,6,7,9,10,12,13,14,15)
	MR_init_label8(ll_backend__rtti_out__output_notag_functor_defn_7_0,17,21,22,24,26,27,28,29)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_notag_functor_defn'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_notag_functor_defn_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_r3;
	MR_tempr1 = MR_tfield(0, MR_tempr2, 1);
	MR_r6 = MR_tempr1;
	if (MR_PTAG_TESTR(MR_tempr1,1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_notag_functor_defn_7_0_i3);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_tfield(0, MR_tempr2, 0);
	MR_sv(4) = MR_tempr1;
	MR_sv(5) = MR_tfield(0, MR_tempr2, 2);
	MR_r2 = MR_tfield(1, MR_tempr1, 0);
	MR_r3 = MR_r4;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_type_info_defn_6_0,
		ll_backend__rtti_out__output_notag_functor_defn_7_0_i5);
MR_def_label(ll_backend__rtti_out__output_notag_functor_defn_7_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r3;
	MR_sv(3) = MR_tfield(0, MR_tempr1, 0);
	MR_tempr2 = MR_r6;
	MR_sv(4) = MR_tempr2;
	MR_sv(5) = MR_tfield(0, MR_tempr1, 2);
	MR_r2 = MR_tfield(0, MR_tempr2, 0);
	MR_r3 = MR_r4;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_pseudo_type_info_defn_6_0,
		ll_backend__rtti_out__output_notag_functor_defn_7_0_i5);
MR_def_label(ll_backend__rtti_out__output_notag_functor_defn_7_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(6) = MR_r1;
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(fn__backend_libs__rtti__maybe_pseudo_type_info_to_rtti_data_1_0,
		ll_backend__rtti_out__output_notag_functor_defn_7_0_i6);
MR_def_label(ll_backend__rtti_out__output_notag_functor_defn_7_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_r3 = (MR_Word) MR_string_const("", 0);
	MR_r4 = (MR_Word) MR_string_const("", 0);
	MR_r5 = (MR_Integer) 0;
	MR_r6 = MR_sv(6);
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_record_rtti_data_decls_10_0,
		ll_backend__rtti_out__output_notag_functor_defn_7_0_i7);
MR_def_label(ll_backend__rtti_out__output_notag_functor_defn_7_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_sv(6) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 3);
	MR_sv(2) = MR_r2;
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_notag_functor_defn_7_0_i9);
MR_def_label(ll_backend__rtti_out__output_notag_functor_defn_7_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(6);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(2);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_notag_functor_defn_7_0_i10);
MR_def_label(ll_backend__rtti_out__output_notag_functor_defn_7_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(6);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0,
		ll_backend__rtti_out__output_notag_functor_defn_7_0_i12);
MR_def_label(ll_backend__rtti_out__output_notag_functor_defn_7_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n\t\"", 7);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_notag_functor_defn_7_0_i13);
MR_def_label(ll_backend__rtti_out__output_notag_functor_defn_7_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(backend_libs__c_util__output_quoted_string_3_0,
		ll_backend__rtti_out__output_notag_functor_defn_7_0_i14);
MR_def_label(ll_backend__rtti_out__output_notag_functor_defn_7_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\",\n\t", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_notag_functor_defn_7_0_i15);
MR_def_label(ll_backend__rtti_out__output_notag_functor_defn_7_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(4),1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_notag_functor_defn_7_0_i17);
	}
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 1);
	MR_tfield(1, MR_r2, 0) = MR_tfield(1, MR_sv(4), 0);
	MR_r1 = (MR_Word) MR_string_const("(MR_PseudoTypeInfo) ", 20);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_cast_addr_of_rtti_data_4_0,
		ll_backend__rtti_out__output_notag_functor_defn_7_0_i21);
MR_def_label(ll_backend__rtti_out__output_notag_functor_defn_7_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 2, (MR_Integer) 1);
	MR_tfield(2, MR_r2, 0) = MR_tfield(0, MR_sv(4), 0);
	MR_r1 = (MR_Word) MR_string_const("(MR_PseudoTypeInfo) ", 20);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_cast_addr_of_rtti_data_4_0,
		ll_backend__rtti_out__output_notag_functor_defn_7_0_i21);
MR_def_label(ll_backend__rtti_out__output_notag_functor_defn_7_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_notag_functor_defn_7_0_i22);
MR_def_label(ll_backend__rtti_out__output_notag_functor_defn_7_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(5),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_notag_functor_defn_7_0_i24);
	}
	MR_r1 = (MR_Word) MR_string_const("NULL", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_notag_functor_defn_7_0_i28);
MR_def_label(ll_backend__rtti_out__output_notag_functor_defn_7_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_tfield(1, MR_sv(5), 0);
	MR_r1 = (MR_Word) MR_string_const("\"", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_notag_functor_defn_7_0_i26);
MR_def_label(ll_backend__rtti_out__output_notag_functor_defn_7_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_notag_functor_defn_7_0_i27);
MR_def_label(ll_backend__rtti_out__output_notag_functor_defn_7_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\"", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_notag_functor_defn_7_0_i28);
MR_def_label(ll_backend__rtti_out__output_notag_functor_defn_7_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n};\n", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_notag_functor_defn_7_0_i29);
MR_def_label(ll_backend__rtti_out__output_notag_functor_defn_7_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_decr_sp_and_return(7);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_enum_functor_0;
MR_decl_entry(fn__map__values_1_0);
extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_ctor_rtti_name_0;

MR_BEGIN_MODULE(ll_backend__rtti_out_module26)
	MR_init_entry1(ll_backend__rtti_out__output_enum_value_ordered_table_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_enum_value_ordered_table_7_0);
	MR_init_label10(ll_backend__rtti_out__output_enum_value_ordered_table_7_0,2,4,6,7,9,10,18,12,13,15)
	MR_init_label1(ll_backend__rtti_out__output_enum_value_ordered_table_7_0,17)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_enum_value_ordered_table'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_enum_value_ordered_table_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(4) = MR_r4;
	MR_sv(3) = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, enum_functor);
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__map__values_1_0,
		ll_backend__rtti_out__output_enum_value_ordered_table_7_0_i2);
MR_def_label(ll_backend__rtti_out__output_enum_value_ordered_table_7_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,10);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__list__map_2_0,
		ll_backend__rtti_out__output_enum_value_ordered_table_7_0_i4);
MR_def_label(ll_backend__rtti_out__output_enum_value_ordered_table_7_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_sv(5) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 5);
	MR_sv(3) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_enum_value_ordered_table_7_0_i6);
MR_def_label(ll_backend__rtti_out__output_enum_value_ordered_table_7_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(5);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(4);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_enum_value_ordered_table_7_0_i7);
MR_def_label(ll_backend__rtti_out__output_enum_value_ordered_table_7_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(5);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0,
		ll_backend__rtti_out__output_enum_value_ordered_table_7_0_i9);
MR_def_label(ll_backend__rtti_out__output_enum_value_ordered_table_7_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_enum_value_ordered_table_7_0_i10);
MR_def_label(ll_backend__rtti_out__output_enum_value_ordered_table_7_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(3),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_enum_value_ordered_table_7_0_i12);
	}
MR_def_label(ll_backend__rtti_out__output_enum_value_ordered_table_7_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("};\n", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_enum_value_ordered_table_7_0_i17);
MR_def_label(ll_backend__rtti_out__output_enum_value_ordered_table_7_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\t", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_enum_value_ordered_table_7_0_i13);
MR_def_label(ll_backend__rtti_out__output_enum_value_ordered_table_7_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(6,3);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(2);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name);
	MR_r2 = MR_sv(3);
	MR_r3 = (MR_Word) MR_string_const(",\n\t", 3);
	}
	MR_np_call_localret_ent(io__write_list_5_0,
		ll_backend__rtti_out__output_enum_value_ordered_table_7_0_i15);
MR_def_label(ll_backend__rtti_out__output_enum_value_ordered_table_7_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_enum_value_ordered_table_7_0_i18);
MR_def_label(ll_backend__rtti_out__output_enum_value_ordered_table_7_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(6);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module27)
	MR_init_entry1(ll_backend__rtti_out__output_enum_name_ordered_table_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_enum_name_ordered_table_7_0);
	MR_init_label10(ll_backend__rtti_out__output_enum_name_ordered_table_7_0,2,4,6,7,9,10,18,12,13,15)
	MR_init_label1(ll_backend__rtti_out__output_enum_name_ordered_table_7_0,17)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_enum_name_ordered_table'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_enum_name_ordered_table_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(4) = MR_r4;
	MR_sv(3) = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, enum_functor);
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__map__values_1_0,
		ll_backend__rtti_out__output_enum_name_ordered_table_7_0_i2);
MR_def_label(ll_backend__rtti_out__output_enum_name_ordered_table_7_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,11);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__list__map_2_0,
		ll_backend__rtti_out__output_enum_name_ordered_table_7_0_i4);
MR_def_label(ll_backend__rtti_out__output_enum_name_ordered_table_7_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_sv(5) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 4);
	MR_sv(3) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_enum_name_ordered_table_7_0_i6);
MR_def_label(ll_backend__rtti_out__output_enum_name_ordered_table_7_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(5);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(4);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_enum_name_ordered_table_7_0_i7);
MR_def_label(ll_backend__rtti_out__output_enum_name_ordered_table_7_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(5);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0,
		ll_backend__rtti_out__output_enum_name_ordered_table_7_0_i9);
MR_def_label(ll_backend__rtti_out__output_enum_name_ordered_table_7_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_enum_name_ordered_table_7_0_i10);
MR_def_label(ll_backend__rtti_out__output_enum_name_ordered_table_7_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(3),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_enum_name_ordered_table_7_0_i12);
	}
MR_def_label(ll_backend__rtti_out__output_enum_name_ordered_table_7_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("};\n", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_enum_name_ordered_table_7_0_i17);
MR_def_label(ll_backend__rtti_out__output_enum_name_ordered_table_7_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\t", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_enum_name_ordered_table_7_0_i13);
MR_def_label(ll_backend__rtti_out__output_enum_name_ordered_table_7_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(6,4);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(2);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name);
	MR_r2 = MR_sv(3);
	MR_r3 = (MR_Word) MR_string_const(",\n\t", 3);
	}
	MR_np_call_localret_ent(io__write_list_5_0,
		ll_backend__rtti_out__output_enum_name_ordered_table_7_0_i15);
MR_def_label(ll_backend__rtti_out__output_enum_name_ordered_table_7_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_enum_name_ordered_table_7_0_i18);
MR_def_label(ll_backend__rtti_out__output_enum_name_ordered_table_7_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(6);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_foreign_enum_functor_0;

MR_BEGIN_MODULE(ll_backend__rtti_out_module28)
	MR_init_entry1(ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0);
	MR_init_label10(ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0,2,4,6,7,9,10,18,12,13,15)
	MR_init_label1(ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0,17)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_foreign_enum_ordinal_ordered_table'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(5) = MR_r4;
	MR_sv(3) = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, foreign_enum_functor);
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__map__values_1_0,
		ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0_i2);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,12);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__list__map_2_0,
		ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0_i4);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_sv(4) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 7);
	MR_sv(3) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0_i6);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(4);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(5);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0_i7);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(4);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0,
		ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0_i9);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0_i10);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(3),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0_i12);
	}
MR_def_label(ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("};\n", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0_i17);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\t", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0_i13);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(6,5);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(2);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name);
	MR_r2 = MR_sv(3);
	MR_r3 = (MR_Word) MR_string_const(",\n\t", 3);
	}
	MR_np_call_localret_ent(io__write_list_5_0,
		ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0_i15);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0_i18);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(6);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module29)
	MR_init_entry1(ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0);
	MR_init_label10(ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0,2,4,6,7,9,10,18,12,13,15)
	MR_init_label1(ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0,17)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_foreign_enum_name_ordered_table'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(4) = MR_r4;
	MR_sv(3) = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, foreign_enum_functor);
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__map__values_1_0,
		ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0_i2);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,13);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__list__map_2_0,
		ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0_i4);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_sv(5) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 6);
	MR_sv(3) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0_i6);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(5);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(4);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0_i7);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(5);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0,
		ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0_i9);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0_i10);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(3),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0_i12);
	}
MR_def_label(ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("};\n", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0_i17);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\t", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0_i13);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(6,6);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(2);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name);
	MR_r2 = MR_sv(3);
	MR_r3 = (MR_Word) MR_string_const(",\n\t", 3);
	}
	MR_np_call_localret_ent(io__write_list_5_0,
		ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0_i15);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0_i18);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(6);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(map__values_2_0);
MR_decl_entry(list__map_3_0);
MR_decl_entry(list__condense_2_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module30)
	MR_init_entry1(ll_backend__rtti_out__output_du_name_ordered_table_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_du_name_ordered_table_7_0);
	MR_init_label10(ll_backend__rtti_out__output_du_name_ordered_table_7_0,3,6,7,9,11,12,14,15,23,17)
	MR_init_label3(ll_backend__rtti_out__output_du_name_ordered_table_7_0,18,20,22)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_du_name_ordered_table'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_du_name_ordered_table_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(4) = MR_r4;
	MR_sv(3) = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, du_functor);
	MR_sv(5) = (MR_Word) MR_TAG_COMMON(0,1,2);
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r2 = MR_sv(5);
	MR_np_call_localret_ent(map__values_2_0,
		ll_backend__rtti_out__output_du_name_ordered_table_7_0_i3);
MR_def_label(ll_backend__rtti_out__output_du_name_ordered_table_7_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,4);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,14);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__map_3_0,
		ll_backend__rtti_out__output_du_name_ordered_table_7_0_i6);
MR_def_label(ll_backend__rtti_out__output_du_name_ordered_table_7_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__condense_2_0,
		ll_backend__rtti_out__output_du_name_ordered_table_7_0_i7);
MR_def_label(ll_backend__rtti_out__output_du_name_ordered_table_7_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,15);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__list__map_2_0,
		ll_backend__rtti_out__output_du_name_ordered_table_7_0_i9);
MR_def_label(ll_backend__rtti_out__output_du_name_ordered_table_7_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_sv(5) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 8);
	MR_sv(3) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_name_ordered_table_7_0_i11);
MR_def_label(ll_backend__rtti_out__output_du_name_ordered_table_7_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(5);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(4);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_du_name_ordered_table_7_0_i12);
MR_def_label(ll_backend__rtti_out__output_du_name_ordered_table_7_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(5);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0,
		ll_backend__rtti_out__output_du_name_ordered_table_7_0_i14);
MR_def_label(ll_backend__rtti_out__output_du_name_ordered_table_7_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_name_ordered_table_7_0_i15);
MR_def_label(ll_backend__rtti_out__output_du_name_ordered_table_7_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(3),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_du_name_ordered_table_7_0_i17);
	}
MR_def_label(ll_backend__rtti_out__output_du_name_ordered_table_7_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("};\n", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_name_ordered_table_7_0_i22);
MR_def_label(ll_backend__rtti_out__output_du_name_ordered_table_7_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\t", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_name_ordered_table_7_0_i18);
MR_def_label(ll_backend__rtti_out__output_du_name_ordered_table_7_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(6,7);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(2);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name);
	MR_r2 = MR_sv(3);
	MR_r3 = (MR_Word) MR_string_const(",\n\t", 3);
	}
	MR_np_call_localret_ent(io__write_list_5_0,
		ll_backend__rtti_out__output_du_name_ordered_table_7_0_i20);
MR_def_label(ll_backend__rtti_out__output_du_name_ordered_table_7_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_name_ordered_table_7_0_i23);
MR_def_label(ll_backend__rtti_out__output_du_name_ordered_table_7_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(6);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module31)
	MR_init_entry1(fn__ll_backend__rtti_out__this_file_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__ll_backend__rtti_out__this_file_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'this_file'/1 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__ll_backend__rtti_out__this_file_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("rtti_out.m", 10);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(libs__compiler_util__expect_3_0);
MR_decl_entry(backend_libs__rtti__sectag_locn_to_string_2_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module32)
	MR_init_entry1(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0);
	MR_init_label10(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0,32,5,6,7,8,9,10,11,14,15)
	MR_init_label5(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0,16,17,19,21,35)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_du_ptag_ordered_table_body'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_r2,0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0_i35);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,12);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__IntroducedFrom__pred__output_du_ptag_ordered_table_body__1245__1_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tempr3 = MR_r3;
	MR_tfield(0, MR_tempr1, 3) = MR_tempr3;
	MR_tempr2 = MR_tfield(1, MR_r2, 0);
	MR_tfield(0, MR_tempr1, 4) = MR_tfield(0, MR_tempr2, 0);
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tempr3;
	MR_sv(3) = MR_tfield(0, MR_tempr1, 4);
	MR_sv(4) = MR_tfield(0, MR_tempr2, 1);
	MR_sv(5) = MR_tfield(1, MR_r2, 1);
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Word) MR_string_const("rtti_out.m", 10);
	MR_r3 = (MR_Word) MR_string_const("output_du_ptag_ordered_table_body: ptag mismatch", 48);
	}
	MR_np_call_localret_ent(libs__compiler_util__expect_3_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0_i5);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(4);
	MR_sv(4) = MR_tfield(0, MR_tempr1, 0);
	MR_sv(6) = MR_tfield(0, MR_tempr1, 1);
	MR_r1 = (MR_Word) MR_string_const("\t{ ", 3);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0_i6);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(6);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0_i7);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0_i8);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(backend_libs__rtti__sectag_locn_to_string_2_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0_i9);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0_i10);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0_i11);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 3, (MR_Integer) 2);
	MR_tfield(3, MR_r2, 0) = (MR_Integer) 8;
	MR_tfield(3, MR_r2, 1) = MR_sv(3);
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_sv(3) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 1) = MR_r2;
	}
	MR_np_call_localret_ent(fn__backend_libs__name_mangle__mercury_data_prefix_0_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0_i14);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0_i15);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(backend_libs__rtti__id_to_c_identifier_2_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0_i16);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0_i17);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(5),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0_i19);
	}
	MR_r1 = (MR_Word) MR_string_const(" }\n", 3);
	MR_succip_word = MR_sv(7);
	MR_decr_sp(7);
	MR_np_tailcall_ent(io__write_string_3_0);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(" },\n", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0_i21);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(5);
	MR_r3 = ((MR_Integer) MR_sv(2) + (MR_Integer) 1);
	MR_succip_word = MR_sv(7);
	MR_GOTO_LAB(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0_i32);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(7);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(map__to_assoc_list_2_0);
MR_decl_entry(libs__compiler_util__unexpected_2_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module33)
	MR_init_entry1(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_du_ptag_ordered_table_7_0);
	MR_init_label10(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0,2,5,7,8,10,11,15,12,16,21)
	MR_init_label2(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0,22,23)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_du_ptag_ordered_table'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r4;
	MR_sv(4) = (MR_Word) MR_INT_CTOR_ADDR;
	MR_sv(5) = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, sectag_table);
	MR_r1 = MR_sv(4);
	MR_r2 = MR_sv(5);
	MR_np_call_localret_ent(map__to_assoc_list_2_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_7_0_i2);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(10,0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_du_stag_ordered_table_7_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 4) = MR_sv(2);
	MR_tempr2 = MR_sv(3);
	MR_sv(3) = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,1,5);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, decl_set);
	MR_r3 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r5 = MR_sv(3);
	MR_r6 = MR_tempr2;
	}
	MR_np_call_localret_ent(list__foldl2_6_2,
		ll_backend__rtti_out__output_du_ptag_ordered_table_7_0_i5);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_sv(5) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 9);
	MR_sv(4) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_7_0_i7);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(5);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(4);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_7_0_i8);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(5);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_7_0_i10);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_7_0_i11);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_sv(3),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0_i12);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(0, MR_tfield(1, MR_sv(3), 0), 0);
	if (MR_INT_NE(MR_tempr1,1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0_i12);
	}
	MR_r1 = (MR_Word) MR_string_const("\t{ 0, MR_SECTAG_VARIABLE, NULL },\n", 34);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_7_0_i15);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(3);
	MR_r3 = (MR_Integer) 1;
	MR_np_call_localret_ent(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_7_0_i22);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_sv(3),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0_i16);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_sv(3);
	MR_tempr1 = MR_tfield(0, MR_tfield(1, MR_tempr2, 0), 0);
	if (MR_INT_NE(MR_tempr1,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0_i16);
	}
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr2;
	MR_r3 = (MR_Integer) 0;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_7_0_i22);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("rtti_out.m", 10);
	MR_r2 = (MR_Word) MR_string_const("output_dummy_ptag_layout_defn: bad ptag list", 44);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_7_0_i21);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(ll_backend__rtti_out__output_du_ptag_ordered_table_body_5_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_7_0_i22);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n};\n", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_ptag_ordered_table_7_0_i23);
MR_def_label(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(6);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_reserved_functor_0;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_data__type_ctor_info_reserved_address_0;
MR_decl_entry(list__filter_4_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module34)
	MR_init_entry1(ll_backend__rtti_out__output_res_value_ordered_table_8_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_res_value_ordered_table_8_0);
	MR_init_label10(ll_backend__rtti_out__output_res_value_ordered_table_8_0,3,5,6,7,9,11,12,14,15,17)
	MR_init_label10(ll_backend__rtti_out__output_res_value_ordered_table_8_0,18,19,21,22,23,24,25,26,27,28)
	MR_init_label4(ll_backend__rtti_out__output_res_value_ordered_table_8_0,29,30,31,32)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_res_value_ordered_table'/8 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_res_value_ordered_table_8_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(10);
	MR_sv(10) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_sv(4) = MR_r4;
	MR_sv(7) = MR_r5;
	MR_sv(9) = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, reserved_functor);
	MR_sv(6) = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_data, reserved_address);
	MR_r1 = MR_sv(9);
	MR_r2 = MR_sv(6);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,16);
	MR_r4 = MR_sv(3);
	MR_np_call_localret_ent(fn__list__map_2_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i3);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,4,17);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__filter_4_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i5);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(5) = MR_r2;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__length_2_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i6);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(5);
	MR_sv(5) = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__length_2_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i7);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,14);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__IntroducedFrom__pred__output_res_value_ordered_table__1296__1_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_tfield(0, MR_tempr1, 4) = (MR_Integer) 0;
	MR_sv(6) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Word) MR_string_const("rtti_out.m", 10);
	MR_r3 = (MR_Word) MR_string_const("output_res_value_ordered_table: symbolic functors", 49);
	}
	MR_np_call_localret_ent(libs__compiler_util__expect_3_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i9);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_sv(8) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 2);
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i11);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(8);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(7);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i12);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(8);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i14);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(7) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i15);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(6,8);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_res_addr_functors_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(2);
	MR_r1 = MR_sv(9);
	MR_r2 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r4 = MR_sv(3);
	}
	MR_np_call_localret_ent(list__foldl_4_2,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i17);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("};\n", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i18);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(4);
	MR_r4 = MR_sv(7);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i19);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 10);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i21);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n\t\"", 7);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i22);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(5);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i23);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i24);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(6);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i25);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i26);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("NULL", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i27);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i28);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_r2 = (MR_Word) MR_tbmkword(0, 2);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_ctor_rtti_id_4_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i29);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i30);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_r2 = (MR_Word) MR_tbmkword(0, 9);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_ctor_rtti_id_4_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i31);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n};\n", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_value_ordered_table_8_0_i32);
MR_def_label(ll_backend__rtti_out__output_res_value_ordered_table_8_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(10);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module35)
	MR_init_entry1(ll_backend__rtti_out__output_res_name_ordered_table_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_res_name_ordered_table_7_0);
	MR_init_label9(ll_backend__rtti_out__output_res_name_ordered_table_7_0,3,6,7,9,10,12,13,15,16)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_res_name_ordered_table'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_res_name_ordered_table_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(4) = MR_r4;
	MR_sv(6) = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, maybe_reserved_functor);
	MR_sv(3) = (MR_Word) MR_TAG_COMMON(0,1,6);
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(map__values_2_0,
		ll_backend__rtti_out__output_res_name_ordered_table_7_0_i3);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_7_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,0,6);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,18);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__map_3_0,
		ll_backend__rtti_out__output_res_name_ordered_table_7_0_i6);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_7_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__condense_2_0,
		ll_backend__rtti_out__output_res_name_ordered_table_7_0_i7);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_7_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_sv(5) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 11);
	MR_sv(3) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_name_ordered_table_7_0_i9);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_7_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(5);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(4);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_res_name_ordered_table_7_0_i10);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_7_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(5);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0,
		ll_backend__rtti_out__output_res_name_ordered_table_7_0_i12);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_7_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n\t\"", 7);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_name_ordered_table_7_0_i13);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_7_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(6,9);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(2);
	MR_r1 = MR_sv(6);
	MR_r2 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r4 = MR_sv(3);
	}
	MR_np_call_localret_ent(list__foldl_4_2,
		ll_backend__rtti_out__output_res_name_ordered_table_7_0_i15);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_7_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n};\n", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_name_ordered_table_7_0_i16);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_7_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(7);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module36)
	MR_init_entry1(ll_backend__rtti_out__output_functor_number_map_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_functor_number_map_7_0);
	MR_init_label6(ll_backend__rtti_out__output_functor_number_map_7_0,3,4,6,7,9,10)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_functor_number_map'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_functor_number_map_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_sv(4) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_r2;
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 13);
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_r4;
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_functor_number_map_7_0_i3);
MR_def_label(ll_backend__rtti_out__output_functor_number_map_7_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(4);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(3);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_functor_number_map_7_0_i4);
MR_def_label(ll_backend__rtti_out__output_functor_number_map_7_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(4);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0,
		ll_backend__rtti_out__output_functor_number_map_7_0_i6);
MR_def_label(ll_backend__rtti_out__output_functor_number_map_7_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n\t", 6);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_functor_number_map_7_0_i7);
MR_def_label(ll_backend__rtti_out__output_functor_number_map_7_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_sv(2);
	MR_r3 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_r4 = (MR_Word) MR_TAG_COMMON(0,4,19);
	MR_np_call_localret_ent(io__write_list_5_0,
		ll_backend__rtti_out__output_functor_number_map_7_0_i9);
MR_def_label(ll_backend__rtti_out__output_functor_number_map_7_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(" };\n\t", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_functor_number_map_7_0_i10);
MR_def_label(ll_backend__rtti_out__output_functor_number_map_7_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(5);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module37)
	MR_init_entry1(ll_backend__rtti_out__output_type_ctor_details_defn_10_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_type_ctor_details_defn_10_0);
	MR_init_label10(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,5,6,7,8,3,13,14,15,16,11)
	MR_init_label10(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,21,22,24,25,26,27,19,31,32,33)
	MR_init_label10(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,35,30,41,43,40,47,48,49,50,45)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_type_ctor_details_defn'/10 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_type_ctor_details_defn_10_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r3,2)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i3);
	}
	MR_incr_sp(9);
	MR_sv(9) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(10,1);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_du_functor_defn_7_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_tfield(0, MR_tempr1, 4) = MR_r2;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_tempr4 = MR_r3;
	MR_sv(3) = MR_tfield(2, MR_tempr4, 2);
	MR_sv(4) = MR_tfield(2, MR_tempr4, 3);
	MR_sv(5) = MR_tfield(2, MR_tempr4, 4);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, du_functor);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, decl_set);
	MR_tempr2 = MR_tempr4;
	MR_r3 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_tempr3 = MR_r4;
	MR_r4 = MR_tempr1;
	MR_r5 = MR_tfield(2, MR_tempr2, 1);
	MR_r6 = MR_tempr3;
	}
	MR_np_call_localret_ent(list__foldl2_6_2,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i5);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(3);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_du_ptag_ordered_table_7_0,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i6);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(4);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_du_name_ordered_table_7_0,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i7);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_functor_number_map_7_0,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i8);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(1,12,1);
	MR_r2 = (MR_Word) MR_TAG_COMMON(1,12,0);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_tempr1;
	MR_decr_sp_and_return(9);
	}
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r3,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i11);
	}
	MR_incr_sp(9);
	MR_sv(9) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(10,2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_enum_functor_defn_7_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_tfield(0, MR_tempr1, 4) = MR_r2;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_tempr4 = MR_r3;
	MR_sv(3) = MR_tfield(0, MR_tempr4, 2);
	MR_sv(4) = MR_tfield(0, MR_tempr4, 3);
	MR_sv(5) = MR_tfield(0, MR_tempr4, 5);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, enum_functor);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, decl_set);
	MR_tempr2 = MR_tempr4;
	MR_r3 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_tempr3 = MR_r4;
	MR_r4 = MR_tempr1;
	MR_r5 = MR_tfield(0, MR_tempr2, 1);
	MR_r6 = MR_tempr3;
	}
	MR_np_call_localret_ent(list__foldl2_6_2,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i13);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(3);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_enum_value_ordered_table_7_0,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i14);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(4);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_enum_name_ordered_table_7_0,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i15);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_functor_number_map_7_0,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i16);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(1,12,3);
	MR_r2 = (MR_Word) MR_TAG_COMMON(1,12,2);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_tempr1;
	MR_decr_sp_and_return(9);
	}
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r3,1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i19);
	}
	MR_incr_sp(9);
	MR_sv(9) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_sv(7) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,16);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__IntroducedFrom__pred__output_type_ctor_details_defn__723__1_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tempr2 = MR_r3;
	MR_tfield(0, MR_tempr1, 3) = MR_tfield(1, MR_tempr2, 0);
	MR_tfield(0, MR_tempr1, 4) = (MR_Integer) 0;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_tfield(1, MR_tempr2, 2);
	MR_sv(4) = MR_tfield(1, MR_tempr2, 3);
	MR_sv(5) = MR_tfield(1, MR_tempr2, 4);
	MR_sv(6) = MR_r4;
	MR_sv(8) = MR_tfield(1, MR_tempr2, 5);
	}
	MR_np_call_localret_ent(fn__ll_backend__rtti_out__this_file_0_0,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i21);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(7);
	MR_r2 = MR_tempr1;
	MR_r3 = (MR_Word) MR_string_const("language other than C for foreign enumeration", 45);
	}
	MR_np_call_localret_ent(libs__compiler_util__expect_3_0,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i22);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(10,3);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 4) = MR_sv(2);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, foreign_enum_functor);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, decl_set);
	MR_r3 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r5 = MR_sv(3);
	MR_r6 = MR_sv(6);
	}
	MR_np_call_localret_ent(list__foldl2_6_2,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i24);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(4);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_foreign_enum_ordinal_ordered_table_7_0,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i25);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_foreign_enum_name_ordered_table_7_0,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i26);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(8);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_functor_number_map_7_0,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i27);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(1,12,5);
	MR_r2 = (MR_Word) MR_TAG_COMMON(1,12,4);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_tempr1;
	MR_decr_sp_and_return(9);
	}
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r3,3,2)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i30);
	}
	MR_incr_sp(9);
	MR_sv(9) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(3, MR_r3, 1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_r4;
	MR_np_call_localret_ent(ll_backend__rtti_out__output_maybe_pseudo_type_info_defn_6_0,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i31);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(fn__backend_libs__rtti__maybe_pseudo_type_info_to_rtti_data_1_0,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i32);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_r3 = (MR_Word) MR_string_const("", 0);
	MR_r4 = (MR_Word) MR_string_const("", 0);
	MR_r5 = (MR_Integer) 0;
	MR_r6 = MR_sv(3);
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_record_rtti_data_decls_10_0,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i33);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i35);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 10;
	MR_tfield(3, MR_tempr1, 1) = MR_tfield(1, MR_sv(2), 0);
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 1);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr1;
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_tempr3 = MR_r2;
	MR_r2 = MR_tempr2;
	MR_r3 = (MR_Integer) 0;
	MR_r4 = MR_tempr3;
	MR_decr_sp_and_return(9);
	}
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 11;
	MR_tfield(3, MR_tempr1, 1) = MR_tfield(0, MR_sv(2), 0);
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 1);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr1;
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_tempr3 = MR_r2;
	MR_r2 = MR_tempr2;
	MR_r3 = (MR_Integer) 0;
	MR_r4 = MR_tempr3;
	MR_decr_sp_and_return(9);
	}
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r3,3,1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i40);
	}
	MR_incr_sp(9);
	MR_sv(9) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r3 = MR_tfield(3, MR_r3, 2);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_notag_functor_defn_7_0,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i41);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,41)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = (MR_Word) MR_TAG_COMMON(1,13,0);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_functor_number_map_7_0,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i43);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(1,12,6);
	MR_r2 = (MR_Word) MR_TAG_COMMON(1,12,6);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_tempr1;
	MR_decr_sp_and_return(9);
	}
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r3,3,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i45);
	}
	MR_incr_sp(9);
	MR_sv(9) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(10,4);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_tfield(0, MR_tempr1, 4) = MR_r2;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_tempr4 = MR_r3;
	MR_sv(3) = MR_tfield(3, MR_tempr4, 3);
	MR_sv(4) = MR_tfield(3, MR_tempr4, 5);
	MR_sv(5) = MR_tfield(3, MR_tempr4, 6);
	MR_sv(6) = MR_tfield(3, MR_tempr4, 4);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, maybe_reserved_functor);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, decl_set);
	MR_tempr2 = MR_tempr4;
	MR_r3 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_tempr3 = MR_r4;
	MR_r4 = MR_tempr1;
	MR_r5 = MR_tfield(3, MR_tempr2, 2);
	MR_r6 = MR_tempr3;
	}
	MR_np_call_localret_ent(list__foldl2_6_2,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i47);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,47)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(3);
	MR_r4 = MR_sv(6);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_res_value_ordered_table_8_0,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i48);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,48)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(4);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_res_name_ordered_table_7_0,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i49);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,49)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_functor_number_map_7_0,
		ll_backend__rtti_out__output_type_ctor_details_defn_10_0_i50);
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,50)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(1,12,8);
	MR_r2 = (MR_Word) MR_TAG_COMMON(1,12,7);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_tempr1;
	MR_decr_sp_and_return(9);
	}
MR_def_label(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,45)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_r2 = (MR_Word) MR_tbmkword(0, 0);
	MR_r3 = (MR_Integer) 0;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__ll_backend__code_util__make_entry_label_from_rtti_2_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module38)
	MR_init_entry1(fn__ll_backend__rtti_out__make_code_addr_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__ll_backend__rtti_out__make_code_addr_1_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'make_code_addr'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__ll_backend__rtti_out__make_code_addr_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_tbmkword(0, 0);
	MR_np_tailcall_ent(fn__ll_backend__code_util__make_entry_label_from_rtti_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module39)
	MR_init_entry1(ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0);
	MR_init_label8(ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0,2,3,8,40,10,16,17,18)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_cast_addr_of_rtti_id'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0_i2);
MR_def_label(ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(1),0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0_i3);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(0, MR_sv(1), 1);
	MR_r3 = MR_tempr1;
	if (MR_RTAGS_TESTR(MR_tempr1,3,11)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0_i3);
	}
	MR_r4 = MR_tfield(3, MR_r3, 1);
	if (MR_PTAG_TESTR(MR_r4,3)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0_i3);
	}
	MR_r1 = MR_tfield(3, MR_r4, 0);
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__write_int_3_0);
	}
MR_def_label(ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(fn__backend_libs__rtti__rtti_id_has_array_type_1_0,
		ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0_i8);
MR_def_label(ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0_i10);
	}
MR_def_label(ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__backend_libs__name_mangle__mercury_data_prefix_0_0,
		ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0_i16);
MR_def_label(ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("&", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0_i40);
MR_def_label(ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0_i17);
MR_def_label(ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(backend_libs__rtti__id_to_c_identifier_2_0,
		ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0_i18);
MR_def_label(ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__write_string_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(ll_backend__llds_out__llds_out_code_addr__output_code_addr_3_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module40)
	MR_init_entry1(ll_backend__rtti_out__output_static_code_addr_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_static_code_addr_3_0);
	MR_init_label2(ll_backend__rtti_out__output_static_code_addr_3_0,2,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_static_code_addr'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_static_code_addr_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("MR_MAYBE_STATIC_CODE(", 21);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_static_code_addr_3_0_i2);
MR_def_label(ll_backend__rtti_out__output_static_code_addr_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_code_addr__output_code_addr_3_0,
		ll_backend__rtti_out__output_static_code_addr_3_0_i3);
MR_def_label(ll_backend__rtti_out__output_static_code_addr_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(")", 1);
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__write_string_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__backend_libs__rtti__tcd_get_rtti_type_ctor_1_0);
MR_decl_entry(univ__det_univ_to_type_2_0);
MR_decl_entry(fn__backend_libs__rtti__type_ctor_details_num_ptags_1_0);
MR_decl_entry(backend_libs__rtti__type_ctor_rep_to_string_2_0);
MR_decl_entry(fn__backend_libs__rtti__type_ctor_details_num_functors_1_0);
MR_decl_entry(fn__backend_libs__rtti__encode_type_ctor_flags_1_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module41)
	MR_init_entry1(ll_backend__rtti_out__output_type_ctor_data_defn_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_type_ctor_data_defn_6_0);
	MR_init_label10(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,2,3,4,5,6,7,11,13,14,15)
	MR_init_label10(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,16,17,18,19,20,21,22,23,24,25)
	MR_init_label10(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,26,27,28,29,30,31,32,33,35,38)
	MR_init_label10(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,39,40,41,43,46,47,48,49,50,51)
	MR_init_label7(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,52,53,54,55,57,60,61)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_type_ctor_data_defn'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_type_ctor_data_defn_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(16);
	MR_sv(16) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__backend_libs__rtti__tcd_get_rtti_type_ctor_1_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i2);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_sv(3);
	MR_sv(3) = MR_r1;
	MR_tempr2 = MR_sv(2);
	MR_sv(4) = MR_tfield(0, MR_tempr2, 0);
	MR_sv(5) = MR_tfield(0, MR_tempr2, 1);
	MR_sv(6) = MR_tfield(0, MR_tempr2, 2);
	MR_sv(7) = MR_tfield(0, MR_tempr2, 3);
	MR_sv(8) = MR_tfield(0, MR_tempr2, 4);
	MR_sv(9) = MR_tfield(0, MR_tempr2, 5);
	MR_sv(10) = MR_tfield(0, MR_tempr2, 6);
	MR_sv(11) = MR_tfield(0, MR_tempr2, 7);
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(3);
	MR_r3 = MR_sv(11);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_type_ctor_details_defn_10_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i3);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(8);
	MR_sv(8) = MR_r1;
	MR_sv(12) = MR_r2;
	MR_sv(13) = MR_r3;
	MR_sv(14) = MR_r4;
	MR_sv(15) = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_rtti, rtti_proc_label);
	MR_r1 = MR_sv(15);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(univ__det_univ_to_type_2_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i4);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__ll_backend__rtti_out__make_code_addr_1_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i5);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(9);
	MR_sv(9) = MR_r1;
	MR_r1 = MR_sv(15);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(univ__det_univ_to_type_2_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i6);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__ll_backend__rtti_out__make_code_addr_1_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i7);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_r1;
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_r5 = MR_tempr2;
	MR_tfield(1, MR_tempr2, 0) = MR_sv(9);
	MR_tfield(1, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr3, 0, (MR_Integer) 4);
	MR_r4 = MR_tempr3;
	MR_tfield(0, MR_tempr3, 0) = (MR_Word) MR_COMMON(2,4);
	MR_tfield(0, MR_tempr3, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__llds_out__llds_out_code_addr__output_record_code_addr_decls_6_0);
	MR_tfield(0, MR_tempr3, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr3, 3) = MR_sv(1);
	MR_tempr4 = MR_sv(14);
	MR_sv(14) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(ll_backend__llds, code_addr);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, decl_set);
	MR_r3 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r6 = MR_tempr4;
	}
	MR_np_call_localret_ent(list__foldl2_6_2,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i11);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(3);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 16);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i13);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(15) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n\t", 6);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i14);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(7);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i15);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i16);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i17);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i18);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(11);
	MR_np_call_localret_ent(fn__backend_libs__rtti__type_ctor_details_num_ptags_1_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i19);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i20);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i21);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(backend_libs__rtti__type_ctor_rep_to_string_2_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i22);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i23);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i24);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(9);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_static_code_addr_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i25);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i26);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(14);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_static_code_addr_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i27);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t\"", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i28);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(5);
	MR_np_call_localret_ent(fn__mdbcomp__prim_data__sym_name_to_string_1_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i29);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(backend_libs__c_util__output_quoted_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i30);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\",\n\t\"", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i31);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(6);
	MR_np_call_localret_ent(backend_libs__c_util__output_quoted_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i32);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\",\n\t", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i33);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(8),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i35);
	}
	MR_r1 = (MR_Word) MR_string_const("{ 0 }", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i40);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_sv(1) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(3);
	MR_tfield(0, MR_tempr1, 1) = MR_tfield(1, MR_sv(8), 0);
	MR_r1 = (MR_Word) MR_string_const("{ ", 2);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i38);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,38)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("(void *)", 8);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i39);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(" }", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i40);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i41);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,41)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(12),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i43);
	}
	MR_r1 = (MR_Word) MR_string_const("{ 0 }", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i48);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_sv(1) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(3);
	MR_tfield(0, MR_tempr1, 1) = MR_tfield(1, MR_sv(12), 0);
	MR_r1 = (MR_Word) MR_string_const("{ ", 2);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i46);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,46)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("(void *)", 8);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_cast_addr_of_rtti_id_4_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i47);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,47)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(" }", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i48);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,48)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i49);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,49)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(11);
	MR_np_call_localret_ent(fn__backend_libs__rtti__type_ctor_details_num_functors_1_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i50);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,50)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i51);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,51)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i52);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,52)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(10);
	MR_np_call_localret_ent(fn__backend_libs__rtti__encode_type_ctor_flags_1_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i53);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,53)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i54);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,54)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i55);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,55)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(13),0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i57);
	}
	MR_r1 = (MR_Word) MR_string_const("NULL", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i60);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,57)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(3);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 13);
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i60);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,60)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n};\n", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_ctor_data_defn_6_0_i61);
MR_def_label(ll_backend__rtti_out__output_type_ctor_data_defn_6_0,61)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(15);
	MR_decr_sp_and_return(16);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module42)
	MR_init_entry1(ll_backend__rtti_out__output_rtti_data_defn_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_rtti_data_defn_6_0);
	MR_init_label5(ll_backend__rtti_out__output_rtti_data_defn_6_0,3,5,7,9,11)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_rtti_data_defn'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__ll_backend__rtti_out__output_rtti_data_defn_6_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,2)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_data_defn_6_0_i3);
	}
	MR_r2 = MR_tfield(2, MR_r2, 0);
	MR_np_tailcall_ent(ll_backend__rtti_out__output_pseudo_type_info_defn_6_0);
MR_def_label(ll_backend__rtti_out__output_rtti_data_defn_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_data_defn_6_0_i5);
	}
	MR_r2 = MR_tfield(0, MR_r2, 0);
	MR_np_tailcall_ent(ll_backend__rtti_out__output_type_ctor_data_defn_6_0);
MR_def_label(ll_backend__rtti_out__output_rtti_data_defn_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_data_defn_6_0_i7);
	}
	MR_r2 = MR_tfield(1, MR_r2, 0);
	MR_np_tailcall_ent(ll_backend__rtti_out__output_type_info_defn_6_0);
MR_def_label(ll_backend__rtti_out__output_rtti_data_defn_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_data_defn_6_0_i9);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_tfield(3, MR_r2, 1);
	MR_tempr2 = MR_r3;
	MR_r3 = MR_tfield(3, MR_tempr1, 2);
	MR_r4 = MR_tfield(3, MR_tempr1, 3);
	MR_r5 = MR_tfield(3, MR_tempr1, 4);
	MR_r6 = MR_tempr2;
	MR_np_tailcall_ent(ll_backend__rtti_out__output_base_typeclass_info_defn_9_0);
	}
MR_def_label(ll_backend__rtti_out__output_rtti_data_defn_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_data_defn_6_0_i11);
	}
	MR_r2 = MR_tfield(3, MR_r2, 1);
	MR_np_tailcall_ent(ll_backend__rtti_out__output_type_class_decl_defn_6_0);
MR_def_label(ll_backend__rtti_out__output_rtti_data_defn_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_tfield(3, MR_r2, 1);
	MR_np_tailcall_ent(ll_backend__rtti_out__output_type_class_instance_defn_6_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(backend_libs__name_mangle__output_base_typeclass_info_name_4_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module43)
	MR_init_entry1(ll_backend__rtti_out__output_init_method_pointers_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_init_method_pointers_6_0);
	MR_init_label10(ll_backend__rtti_out__output_init_method_pointers_6_0,18,4,5,6,7,8,9,10,11,12)
	MR_init_label1(ll_backend__rtti_out__output_init_method_pointers_6_0,20)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_init_method_pointers'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_init_method_pointers_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
MR_def_label(ll_backend__rtti_out__output_init_method_pointers_6_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_r2,0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_init_method_pointers_6_0_i20);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_r4;
	MR_sv(4) = MR_tfield(1, MR_r2, 0);
	MR_sv(5) = MR_tfield(1, MR_r2, 1);
	MR_r1 = (MR_Word) MR_string_const("\t\t", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_init_method_pointers_6_0_i4);
MR_def_label(ll_backend__rtti_out__output_init_method_pointers_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("MR_field(MR_mktag(0), ", 22);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_init_method_pointers_6_0_i5);
MR_def_label(ll_backend__rtti_out__output_init_method_pointers_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(backend_libs__name_mangle__output_base_typeclass_info_name_4_0,
		ll_backend__rtti_out__output_init_method_pointers_6_0_i6);
MR_def_label(ll_backend__rtti_out__output_init_method_pointers_6_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(fn__string__int_to_string_1_0,
		ll_backend__rtti_out__output_init_method_pointers_6_0_i7);
MR_def_label(ll_backend__rtti_out__output_init_method_pointers_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_string_const(") =\n\t\t\t", 7);
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		ll_backend__rtti_out__output_init_method_pointers_6_0_i8);
MR_def_label(ll_backend__rtti_out__output_init_method_pointers_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		ll_backend__rtti_out__output_init_method_pointers_6_0_i9);
MR_def_label(ll_backend__rtti_out__output_init_method_pointers_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_init_method_pointers_6_0_i10);
MR_def_label(ll_backend__rtti_out__output_init_method_pointers_6_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_code_addr__output_code_addr_3_0,
		ll_backend__rtti_out__output_init_method_pointers_6_0_i11);
MR_def_label(ll_backend__rtti_out__output_init_method_pointers_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(";\n", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_init_method_pointers_6_0_i12);
MR_def_label(ll_backend__rtti_out__output_init_method_pointers_6_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = ((MR_Integer) MR_sv(1) + (MR_Integer) 1);
	MR_r2 = MR_sv(5);
	MR_r3 = MR_sv(2);
	MR_r4 = MR_sv(3);
	MR_succip_word = MR_sv(6);
	MR_GOTO_LAB(ll_backend__rtti_out__output_init_method_pointers_6_0_i18);
MR_def_label(ll_backend__rtti_out__output_init_method_pointers_6_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(6);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__parse_tree__prog_foreign__sym_name_mangle_1_0);
MR_decl_entry(string__append_3_2);
MR_decl_entry(string__append_3_1);
MR_decl_entry(fn__parse_tree__prog_foreign__name_mangle_1_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module44)
	MR_init_entry1(ll_backend__rtti_out__init_rtti_data_if_nec_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__init_rtti_data_if_nec_3_0);
	MR_init_label10(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,5,6,8,9,10,11,12,13,14,17)
	MR_init_label10(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,39,15,21,22,23,24,4,28,30,27)
	MR_init_label3(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,34,35,73)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'init_rtti_data_if_nec'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__ll_backend__rtti_out__init_rtti_data_if_nec_3_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TEST(MR_r1,2)) {
		MR_GOTO_LAB(ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i73);
	}
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i4);
	}
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_r1 = MR_tfield(0, MR_r1, 0);
	MR_np_call_localret_ent(fn__backend_libs__rtti__tcd_get_rtti_type_ctor_1_0,
		ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i5);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("\tMR_INIT_TYPE_CTOR_INFO(\n\t\t", 27);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i6);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_sv(2) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 16);
	}
	MR_np_call_localret_ent(fn__backend_libs__name_mangle__mercury_data_prefix_0_0,
		ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i8);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i9);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(backend_libs__rtti__id_to_c_identifier_2_0,
		ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i10);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i11);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t\t", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i12);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_tfield(0, MR_sv(1), 1);
	MR_r2 = MR_tfield(0, MR_sv(2), 0);
	MR_sv(2) = MR_tfield(0, MR_r2, 2);
	MR_r1 = MR_tfield(0, MR_r2, 0);
	MR_np_call_localret_ent(fn__parse_tree__prog_foreign__sym_name_mangle_1_0,
		ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i13);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_string_const("__", 2);
	MR_np_call_localret_ent(string__append_3_2,
		ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i14);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(string__append_3_1,
		ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i17);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i15);
	}
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(fn__parse_tree__prog_foreign__name_mangle_1_0,
		ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i21);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i39);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i22);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("_", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i23);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i24);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("_0);\n", 5);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(io__write_string_3_0);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TEST(MR_r1,1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i73);
	}
	if (MR_RTAGS_TESTR(MR_r1,3,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i27);
	}
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_tfield(3, MR_r1, 1);
	MR_sv(2) = MR_tfield(3, MR_r1, 3);
	MR_sv(3) = MR_tfield(0, MR_tfield(3, MR_r1, 4), 5);
	MR_r1 = (MR_Word) MR_string_const("#ifndef MR_STATIC_CODE_ADDRESSES\n", 33);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i28);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_rtti, rtti_proc_label);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(ll_backend__llds, code_addr);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,20);
	MR_r4 = MR_sv(3);
	MR_np_call_localret_ent(fn__list__map_2_0,
		ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i30);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Integer) 5;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(1);
	MR_r4 = MR_sv(2);
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_init_method_pointers_6_0,
		ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i35);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TEST(MR_r1,3,1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i73);
	}
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_r1 = (MR_Word) MR_string_const("#ifndef MR_STATIC_CODE_ADDRESSES\n", 33);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i34);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("#error \"type_class_instance not yet supported without static code addresses\"\n", 77);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__init_rtti_data_if_nec_3_0_i35);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("#endif /* MR_STATIC_CODE_ADDRESSES */\n", 38);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(io__write_string_3_0);
MR_def_label(ll_backend__rtti_out__init_rtti_data_if_nec_3_0,73)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module45)
	MR_init_entry1(ll_backend__rtti_out__register_rtti_data_if_nec_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__register_rtti_data_if_nec_3_0);
	MR_init_label10(ll_backend__rtti_out__register_rtti_data_if_nec_3_0,5,7,8,4,18,19,16,27,28,29)
	MR_init_label4(ll_backend__rtti_out__register_rtti_data_if_nec_3_0,30,31,32,63)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'register_rtti_data_if_nec'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__ll_backend__rtti_out__register_rtti_data_if_nec_3_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TEST(MR_r1,2)) {
		MR_GOTO_LAB(ll_backend__rtti_out__register_rtti_data_if_nec_3_0_i63);
	}
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__register_rtti_data_if_nec_3_0_i4);
	}
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_r1 = MR_tfield(0, MR_r1, 0);
	MR_np_call_localret_ent(fn__backend_libs__rtti__tcd_get_rtti_type_ctor_1_0,
		ll_backend__rtti_out__register_rtti_data_if_nec_3_0_i5);
MR_def_label(ll_backend__rtti_out__register_rtti_data_if_nec_3_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_sv(1) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_r1;
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 16);
	MR_r1 = (MR_Word) MR_string_const("\t{\n\t", 4);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__register_rtti_data_if_nec_3_0_i7);
MR_def_label(ll_backend__rtti_out__register_rtti_data_if_nec_3_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\tMR_register_type_ctor_info(\n\t\t&", 32);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__register_rtti_data_if_nec_3_0_i8);
MR_def_label(ll_backend__rtti_out__register_rtti_data_if_nec_3_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__backend_libs__name_mangle__mercury_data_prefix_0_0,
		ll_backend__rtti_out__register_rtti_data_if_nec_3_0_i29);
MR_def_label(ll_backend__rtti_out__register_rtti_data_if_nec_3_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TEST(MR_r1,1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__register_rtti_data_if_nec_3_0_i63);
	}
	if (MR_RTAGS_TEST(MR_r1,3,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__register_rtti_data_if_nec_3_0_i63);
	}
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	if (MR_RTAGS_TESTR(MR_r1,3,1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__register_rtti_data_if_nec_3_0_i16);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_sv(1) = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = MR_tfield(0, MR_tfield(0, MR_tfield(3, MR_r1, 1), 0), 0);
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 3);
	MR_r1 = (MR_Word) MR_string_const("\t{\n\t", 4);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__register_rtti_data_if_nec_3_0_i18);
MR_def_label(ll_backend__rtti_out__register_rtti_data_if_nec_3_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\tMR_register_type_class_decl(\n\t\t&", 33);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__register_rtti_data_if_nec_3_0_i19);
MR_def_label(ll_backend__rtti_out__register_rtti_data_if_nec_3_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__backend_libs__name_mangle__mercury_data_prefix_0_0,
		ll_backend__rtti_out__register_rtti_data_if_nec_3_0_i29);
MR_def_label(ll_backend__rtti_out__register_rtti_data_if_nec_3_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tempr2 = MR_tfield(3, MR_r1, 1);
	MR_tfield(3, MR_tempr1, 1) = MR_tfield(0, MR_tempr2, 1);
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 2);
	MR_sv(1) = MR_tempr3;
	MR_tfield(1, MR_tempr3, 0) = MR_tfield(0, MR_tempr2, 0);
	MR_tfield(1, MR_tempr3, 1) = MR_tempr1;
	MR_r1 = (MR_Word) MR_string_const("\t{\n\t", 4);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__register_rtti_data_if_nec_3_0_i27);
MR_def_label(ll_backend__rtti_out__register_rtti_data_if_nec_3_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\tMR_register_type_class_instance(\n\t\t&", 37);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__register_rtti_data_if_nec_3_0_i28);
MR_def_label(ll_backend__rtti_out__register_rtti_data_if_nec_3_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__backend_libs__name_mangle__mercury_data_prefix_0_0,
		ll_backend__rtti_out__register_rtti_data_if_nec_3_0_i29);
MR_def_label(ll_backend__rtti_out__register_rtti_data_if_nec_3_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__register_rtti_data_if_nec_3_0_i30);
MR_def_label(ll_backend__rtti_out__register_rtti_data_if_nec_3_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(backend_libs__rtti__id_to_c_identifier_2_0,
		ll_backend__rtti_out__register_rtti_data_if_nec_3_0_i31);
MR_def_label(ll_backend__rtti_out__register_rtti_data_if_nec_3_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__register_rtti_data_if_nec_3_0_i32);
MR_def_label(ll_backend__rtti_out__register_rtti_data_if_nec_3_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(");\n\t}\n", 6);
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__write_string_3_0);
MR_def_label(ll_backend__rtti_out__register_rtti_data_if_nec_3_0,63)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(ll_backend__llds_out__llds_out_util__decl_set_init_1_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module46)
	MR_init_entry1(ll_backend__rtti_out__output_rtti_id_storage_type_name_no_decl_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_rtti_id_storage_type_name_no_decl_5_0);
	MR_init_label1(ll_backend__rtti_out__output_rtti_id_storage_type_name_no_decl_5_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_rtti_id_storage_type_name_no_decl'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__ll_backend__rtti_out__output_rtti_id_storage_type_name_no_decl_5_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_init_1_0,
		ll_backend__rtti_out__output_rtti_id_storage_type_name_no_decl_5_0_i2);
MR_def_label(ll_backend__rtti_out__output_rtti_id_storage_type_name_no_decl_5_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(3);
	MR_r4 = MR_tempr1;
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__backend_libs__name_mangle__mercury_var_prefix_0_0);
MR_decl_entry(fn__backend_libs__rtti__tabling_info_id_str_1_0);
MR_decl_entry(fn__backend_libs__name_mangle__proc_label_to_c_string_2_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module47)
	MR_init_entry1(fn__ll_backend__rtti_out__tabling_struct_data_addr_string_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__ll_backend__rtti_out__tabling_struct_data_addr_string_2_0);
	MR_init_label6(fn__ll_backend__rtti_out__tabling_struct_data_addr_string_2_0,2,3,4,5,6,7)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'tabling_struct_data_addr_string'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__ll_backend__rtti_out__tabling_struct_data_addr_string_2_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_np_call_localret_ent(fn__backend_libs__name_mangle__mercury_var_prefix_0_0,
		fn__ll_backend__rtti_out__tabling_struct_data_addr_string_2_0_i2);
MR_def_label(fn__ll_backend__rtti_out__tabling_struct_data_addr_string_2_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_sv(2) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__backend_libs__rtti__tabling_info_id_str_1_0,
		fn__ll_backend__rtti_out__tabling_struct_data_addr_string_2_0_i3);
MR_def_label(fn__ll_backend__rtti_out__tabling_struct_data_addr_string_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Integer) 0;
	}
	MR_np_call_localret_ent(fn__backend_libs__name_mangle__proc_label_to_c_string_2_0,
		fn__ll_backend__rtti_out__tabling_struct_data_addr_string_2_0_i4);
MR_def_label(fn__ll_backend__rtti_out__tabling_struct_data_addr_string_2_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("__", 2);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		fn__ll_backend__rtti_out__tabling_struct_data_addr_string_2_0_i5);
MR_def_label(fn__ll_backend__rtti_out__tabling_struct_data_addr_string_2_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		fn__ll_backend__rtti_out__tabling_struct_data_addr_string_2_0_i6);
MR_def_label(fn__ll_backend__rtti_out__tabling_struct_data_addr_string_2_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("_proc", 5);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		fn__ll_backend__rtti_out__tabling_struct_data_addr_string_2_0_i7);
MR_def_label(fn__ll_backend__rtti_out__tabling_struct_data_addr_string_2_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module48)
	MR_init_entry1(ll_backend__rtti_out__output_type_class_id_tvar_name_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_type_class_id_tvar_name_3_0);
	MR_init_label2(ll_backend__rtti_out__output_type_class_id_tvar_name_3_0,2,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_type_class_id_tvar_name'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_type_class_id_tvar_name_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("\t\"", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_id_tvar_name_3_0_i2);
MR_def_label(ll_backend__rtti_out__output_type_class_id_tvar_name_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(backend_libs__c_util__output_quoted_string_3_0,
		ll_backend__rtti_out__output_type_class_id_tvar_name_3_0_i3);
MR_def_label(ll_backend__rtti_out__output_type_class_id_tvar_name_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\",\n", 3);
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__write_string_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(ll_backend__layout_out__output_pred_or_func_3_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module49)
	MR_init_entry1(ll_backend__rtti_out__output_type_class_id_method_id_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_type_class_id_method_id_3_0);
	MR_init_label6(ll_backend__rtti_out__output_type_class_id_method_id_3_0,2,3,4,5,6,7)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_type_class_id_method_id'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_type_class_id_method_id_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_tfield(0, MR_r1, 0);
	MR_sv(2) = MR_tfield(0, MR_r1, 1);
	MR_sv(3) = MR_tfield(0, MR_r1, 2);
	MR_r1 = (MR_Word) MR_string_const("\t{ \"", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_id_method_id_3_0_i2);
MR_def_label(ll_backend__rtti_out__output_type_class_id_method_id_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(backend_libs__c_util__output_quoted_string_3_0,
		ll_backend__rtti_out__output_type_class_id_method_id_3_0_i3);
MR_def_label(ll_backend__rtti_out__output_type_class_id_method_id_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\", ", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_id_method_id_3_0_i4);
MR_def_label(ll_backend__rtti_out__output_type_class_id_method_id_3_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_type_class_id_method_id_3_0_i5);
MR_def_label(ll_backend__rtti_out__output_type_class_id_method_id_3_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_id_method_id_3_0_i6);
MR_def_label(ll_backend__rtti_out__output_type_class_id_method_id_3_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(ll_backend__layout_out__output_pred_or_func_3_0,
		ll_backend__rtti_out__output_type_class_id_method_id_3_0_i7);
MR_def_label(ll_backend__rtti_out__output_type_class_id_method_id_3_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(" },\n", 4);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(io__write_string_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module50)
	MR_init_entry1(ll_backend__rtti_out__make_tc_decl_super_id_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__make_tc_decl_super_id_4_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'make_tc_decl_super_id'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__make_tc_decl_super_id_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 2, (MR_Integer) 2);
	MR_tfield(2, MR_tempr1, 0) = MR_r2;
	MR_tfield(2, MR_tempr1, 1) = MR_r3;
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_r1;
	MR_tfield(1, MR_r2, 1) = MR_tempr1;
	MR_r1 = MR_r2;
	MR_proceed();
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module51)
	MR_init_entry1(ll_backend__rtti_out__make_tc_instance_constraint_id_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__make_tc_instance_constraint_id_5_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'make_tc_instance_constraint_id'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__make_tc_instance_constraint_id_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 4);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 2;
	MR_tfield(3, MR_tempr1, 1) = MR_r2;
	MR_tfield(3, MR_tempr1, 2) = MR_r3;
	MR_tfield(3, MR_tempr1, 3) = MR_r4;
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_r1;
	MR_tfield(1, MR_r2, 1) = MR_tempr1;
	MR_r1 = MR_r2;
	MR_proceed();
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(counter__allocate_3_0);
MR_declare_entry(mercury__do_call_closure_2);

MR_BEGIN_MODULE(ll_backend__rtti_out_module52)
	MR_init_entry1(ll_backend__rtti_out__output_type_class_constraint_10_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_type_class_constraint_10_0);
	MR_init_label10(ll_backend__rtti_out__output_type_class_constraint_10_0,2,3,4,6,7,9,11,13,14,15)
	MR_init_label7(ll_backend__rtti_out__output_type_class_constraint_10_0,16,17,18,19,20,21,22)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_type_class_constraint'/10 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_type_class_constraint_10_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(8);
	MR_sv(8) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_sv(3) = MR_tfield(0, MR_tempr1, 0);
	MR_sv(4) = MR_tfield(0, MR_tempr1, 1);
	MR_sv(5) = MR_r4;
	MR_sv(6) = MR_r5;
	MR_sv(7) = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info);
	MR_r1 = MR_sv(7);
	MR_r2 = MR_sv(4);
	}
	MR_np_call_localret_ent(list__length_2_0,
		ll_backend__rtti_out__output_type_class_constraint_10_0_i2);
MR_def_label(ll_backend__rtti_out__output_type_class_constraint_10_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(5);
	MR_sv(5) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(counter__allocate_3_0,
		ll_backend__rtti_out__output_type_class_constraint_10_0_i3);
MR_def_label(ll_backend__rtti_out__output_type_class_constraint_10_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_sv(5);
	MR_sv(5) = MR_r2;
	MR_tempr2 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr2;
	MR_r3 = MR_tempr1;
	}
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(ll_backend__rtti_out__output_type_class_constraint_10_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_closure_2),
		mercury__ll_backend__rtti_out__output_type_class_constraint_10_0_i4);
MR_def_label(ll_backend__rtti_out__output_type_class_constraint_10_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_sv(3);
	MR_tfield(1, MR_r2, 1) = (MR_Word) MR_tbmkword(0, 3);
	MR_sv(2) = MR_r1;
	MR_sv(3) = MR_r2;
	MR_r1 = MR_sv(1);
	MR_r3 = (MR_Integer) 0;
	MR_r4 = MR_sv(6);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_type_class_constraint_10_0_i6);
MR_def_label(ll_backend__rtti_out__output_type_class_constraint_10_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(6) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(";\n", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_constraint_10_0_i7);
MR_def_label(ll_backend__rtti_out__output_type_class_constraint_10_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(3);
	MR_r1 = MR_tempr1;
	MR_r2 = MR_sv(6);
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0,
		ll_backend__rtti_out__output_type_class_constraint_10_0_i9);
MR_def_label(ll_backend__rtti_out__output_type_class_constraint_10_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,5);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_maybe_pseudo_type_info_defn_6_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_sv(7);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, decl_set);
	MR_r3 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r5 = MR_sv(4);
	MR_r6 = MR_tempr2;
	}
	MR_np_call_localret_ent(list__foldl2_6_2,
		ll_backend__rtti_out__output_type_class_constraint_10_0_i11);
MR_def_label(ll_backend__rtti_out__output_type_class_constraint_10_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(4);
	MR_sv(4) = MR_r1;
	MR_r1 = MR_sv(7);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_data);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,21);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__list__map_2_0,
		ll_backend__rtti_out__output_type_class_constraint_10_0_i13);
MR_def_label(ll_backend__rtti_out__output_type_class_constraint_10_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(4);
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0,
		ll_backend__rtti_out__output_type_class_constraint_10_0_i14);
MR_def_label(ll_backend__rtti_out__output_type_class_constraint_10_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n\t&", 7);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_constraint_10_0_i15);
MR_def_label(ll_backend__rtti_out__output_type_class_constraint_10_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__backend_libs__name_mangle__mercury_data_prefix_0_0,
		ll_backend__rtti_out__output_type_class_constraint_10_0_i16);
MR_def_label(ll_backend__rtti_out__output_type_class_constraint_10_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_constraint_10_0_i17);
MR_def_label(ll_backend__rtti_out__output_type_class_constraint_10_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(backend_libs__rtti__id_to_c_identifier_2_0,
		ll_backend__rtti_out__output_type_class_constraint_10_0_i18);
MR_def_label(ll_backend__rtti_out__output_type_class_constraint_10_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_constraint_10_0_i19);
MR_def_label(ll_backend__rtti_out__output_type_class_constraint_10_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t{\n", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_constraint_10_0_i20);
MR_def_label(ll_backend__rtti_out__output_type_class_constraint_10_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("(MR_PseudoTypeInfo) ", 20);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0,
		ll_backend__rtti_out__output_type_class_constraint_10_0_i21);
MR_def_label(ll_backend__rtti_out__output_type_class_constraint_10_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\t}\n};\n", 6);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_type_class_constraint_10_0_i22);
MR_def_label(ll_backend__rtti_out__output_type_class_constraint_10_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(5);
	MR_r3 = MR_sv(4);
	MR_decr_sp_and_return(8);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module53)
	MR_init_entry1(ll_backend__rtti_out__output_maybe_pseudo_type_info_or_self_defn_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_maybe_pseudo_type_info_or_self_defn_6_0);
	MR_init_label2(ll_backend__rtti_out__output_maybe_pseudo_type_info_or_self_defn_6_0,3,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_maybe_pseudo_type_info_or_self_defn'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_maybe_pseudo_type_info_or_self_defn_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_maybe_pseudo_type_info_or_self_defn_6_0_i3);
	}
	MR_r1 = MR_r3;
	MR_proceed();
MR_def_label(ll_backend__rtti_out__output_maybe_pseudo_type_info_or_self_defn_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,2)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_maybe_pseudo_type_info_or_self_defn_6_0_i4);
	}
	MR_r2 = MR_tfield(2, MR_r2, 0);
	MR_np_tailcall_ent(ll_backend__rtti_out__output_type_info_defn_6_0);
MR_def_label(ll_backend__rtti_out__output_maybe_pseudo_type_info_or_self_defn_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_tfield(1, MR_r2, 0);
	MR_np_tailcall_ent(ll_backend__rtti_out__output_pseudo_type_info_defn_6_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module54)
	MR_init_entry1(ll_backend__rtti_out__output_enum_functor_defn_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_enum_functor_defn_7_0);
	MR_init_label8(ll_backend__rtti_out__output_enum_functor_defn_7_0,4,5,7,8,9,10,11,12)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_enum_functor_defn'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_enum_functor_defn_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 4;
	MR_tempr3 = MR_r3;
	MR_tfield(3, MR_tempr1, 1) = MR_tfield(0, MR_tempr3, 1);
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 2);
	MR_sv(5) = MR_tempr2;
	MR_tfield(0, MR_tempr2, 0) = MR_r2;
	MR_tfield(0, MR_tempr2, 1) = MR_tempr1;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(0, MR_tempr3, 0);
	MR_sv(3) = MR_tfield(3, MR_tempr1, 1);
	MR_sv(4) = MR_r4;
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_enum_functor_defn_7_0_i4);
MR_def_label(ll_backend__rtti_out__output_enum_functor_defn_7_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(5);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(4);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_enum_functor_defn_7_0_i5);
MR_def_label(ll_backend__rtti_out__output_enum_functor_defn_7_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(5);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0,
		ll_backend__rtti_out__output_enum_functor_defn_7_0_i7);
MR_def_label(ll_backend__rtti_out__output_enum_functor_defn_7_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n\t\"", 7);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_enum_functor_defn_7_0_i8);
MR_def_label(ll_backend__rtti_out__output_enum_functor_defn_7_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(backend_libs__c_util__output_quoted_string_3_0,
		ll_backend__rtti_out__output_enum_functor_defn_7_0_i9);
MR_def_label(ll_backend__rtti_out__output_enum_functor_defn_7_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\",\n\t", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_enum_functor_defn_7_0_i10);
MR_def_label(ll_backend__rtti_out__output_enum_functor_defn_7_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_enum_functor_defn_7_0_i11);
MR_def_label(ll_backend__rtti_out__output_enum_functor_defn_7_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n};\n", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_enum_functor_defn_7_0_i12);
MR_def_label(ll_backend__rtti_out__output_enum_functor_defn_7_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(6);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module55)
	MR_init_entry1(ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0);
	MR_init_label10(ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0,4,5,7,8,9,10,11,12,13,14)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_foreign_enum_functor_defn'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 5;
	MR_tempr3 = MR_r3;
	MR_tfield(3, MR_tempr1, 1) = MR_tfield(0, MR_tempr3, 1);
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 2);
	MR_sv(5) = MR_tempr2;
	MR_tfield(0, MR_tempr2, 0) = MR_r2;
	MR_tfield(0, MR_tempr2, 1) = MR_tempr1;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(0, MR_tempr3, 0);
	MR_sv(3) = MR_tfield(3, MR_tempr1, 1);
	MR_sv(4) = MR_tfield(0, MR_tempr3, 2);
	MR_sv(6) = MR_r4;
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0_i4);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(5);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(6);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0_i5);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(5);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0,
		ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0_i7);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n\t\"", 7);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0_i8);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(backend_libs__c_util__output_quoted_string_3_0,
		ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0_i9);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\",\n\t", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0_i10);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0_i11);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0_i12);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0_i13);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n};\n", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0_i14);
MR_def_label(ll_backend__rtti_out__output_foreign_enum_functor_defn_7_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(7);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_exist_typeinfo_locn_0;

MR_BEGIN_MODULE(ll_backend__rtti_out_module56)
	MR_init_entry1(ll_backend__rtti_out__output_exist_locns_array_8_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_exist_locns_array_8_0);
	MR_init_label9(ll_backend__rtti_out__output_exist_locns_array_8_0,4,5,7,9,11,12,14,15,16)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_exist_locns_array'/8 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_exist_locns_array_8_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 1);
	MR_tfield(1, MR_tempr1, 0) = MR_r3;
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 2);
	MR_sv(4) = MR_tempr2;
	MR_tfield(0, MR_tempr2, 0) = MR_r2;
	MR_tfield(0, MR_tempr2, 1) = MR_tempr1;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r4;
	MR_sv(3) = MR_r5;
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_locns_array_8_0_i4);
MR_def_label(ll_backend__rtti_out__output_exist_locns_array_8_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(4);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(3);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_exist_locns_array_8_0_i5);
MR_def_label(ll_backend__rtti_out__output_exist_locns_array_8_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(4);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0,
		ll_backend__rtti_out__output_exist_locns_array_8_0_i7);
MR_def_label(ll_backend__rtti_out__output_exist_locns_array_8_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_exist_locns_array_8_0_i9);
	}
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("= { {0, 0} };\n", 14);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_locns_array_8_0_i16);
MR_def_label(ll_backend__rtti_out__output_exist_locns_array_8_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_locns_array_8_0_i11);
MR_def_label(ll_backend__rtti_out__output_exist_locns_array_8_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\t", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_locns_array_8_0_i12);
MR_def_label(ll_backend__rtti_out__output_exist_locns_array_8_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, exist_typeinfo_locn);
	MR_r2 = MR_sv(2);
	MR_r3 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_r4 = (MR_Word) MR_TAG_COMMON(0,4,22);
	MR_np_call_localret_ent(io__write_list_5_0,
		ll_backend__rtti_out__output_exist_locns_array_8_0_i14);
MR_def_label(ll_backend__rtti_out__output_exist_locns_array_8_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_locns_array_8_0_i15);
MR_def_label(ll_backend__rtti_out__output_exist_locns_array_8_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("};\n", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_locns_array_8_0_i16);
MR_def_label(ll_backend__rtti_out__output_exist_locns_array_8_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(5);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module57)
	MR_init_entry1(ll_backend__rtti_out__output_exist_constraints_data_8_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_exist_constraints_data_8_0);
	MR_init_label8(ll_backend__rtti_out__output_exist_constraints_data_8_0,4,5,8,9,11,12,13,14)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_exist_constraints_data'/8 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_exist_constraints_data_8_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(9,1);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__make_exist_tc_constr_id_5_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_r2;
	MR_tempr3 = MR_r3;
	MR_tfield(0, MR_tempr1, 4) = MR_tempr3;
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 5);
	MR_sv(6) = MR_tempr2;
	MR_tfield(0, MR_tempr2, 0) = (MR_Word) MR_COMMON(8,2);
	MR_tfield(0, MR_tempr2, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_type_class_constraint_10_0);
	MR_tfield(0, MR_tempr2, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr2, 3) = MR_r1;
	MR_tfield(0, MR_tempr2, 4) = MR_tempr1;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_tempr3;
	MR_sv(4) = MR_r4;
	MR_sv(5) = MR_r5;
	MR_r1 = (MR_Integer) 1;
	}
	MR_np_call_localret_ent(fn__counter__init_1_0,
		ll_backend__rtti_out__output_exist_constraints_data_8_0_i4);
MR_def_label(ll_backend__rtti_out__output_exist_constraints_data_8_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, tc_constraint);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_id);
	MR_r3 = (MR_Word) MR_CTOR0_ADDR(counter, counter);
	MR_r4 = (MR_Word) MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, decl_set);
	MR_r5 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r6 = MR_sv(6);
	MR_r7 = MR_sv(4);
	MR_r8 = MR_tempr1;
	MR_r9 = MR_sv(5);
	}
	MR_np_call_localret_ent(list__map_foldl3_9_0,
		ll_backend__rtti_out__output_exist_constraints_data_8_0_i5);
MR_def_label(ll_backend__rtti_out__output_exist_constraints_data_8_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(3);
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 2);
	MR_sv(3) = MR_tempr2;
	MR_tfield(0, MR_tempr2, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr2, 1) = MR_tempr1;
	MR_sv(2) = MR_r1;
	MR_sv(4) = MR_r3;
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_constraints_data_8_0_i8);
MR_def_label(ll_backend__rtti_out__output_exist_constraints_data_8_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(3);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(4);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_exist_constraints_data_8_0_i9);
MR_def_label(ll_backend__rtti_out__output_exist_constraints_data_8_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(3);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0,
		ll_backend__rtti_out__output_exist_constraints_data_8_0_i11);
MR_def_label(ll_backend__rtti_out__output_exist_constraints_data_8_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n\t", 6);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_constraints_data_8_0_i12);
MR_def_label(ll_backend__rtti_out__output_exist_constraints_data_8_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("(MR_TypeClassConstraint) ", 25);
	MR_r2 = MR_sv(2);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_cast_addr_of_rtti_ids_4_0,
		ll_backend__rtti_out__output_exist_constraints_data_8_0_i13);
MR_def_label(ll_backend__rtti_out__output_exist_constraints_data_8_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n};\n", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_constraints_data_8_0_i14);
MR_def_label(ll_backend__rtti_out__output_exist_constraints_data_8_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(7);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module58)
	MR_init_entry1(ll_backend__rtti_out__output_exist_info_8_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_exist_info_8_0);
	MR_init_label10(ll_backend__rtti_out__output_exist_info_8_0,2,7,8,11,12,13,14,15,16,17)
	MR_init_label10(ll_backend__rtti_out__output_exist_info_8_0,18,19,20,21,22,10,25,26,27,28)
	MR_init_label10(ll_backend__rtti_out__output_exist_info_8_0,29,30,31,32,33,34,35,36,37,38)
	MR_init_label3(ll_backend__rtti_out__output_exist_info_8_0,40,42,43)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_exist_info'/8 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_exist_info_8_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(11);
	MR_sv(11) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r4;
	MR_sv(4) = MR_tfield(0, MR_tempr1, 0);
	MR_sv(5) = MR_tfield(0, MR_tempr1, 1);
	MR_sv(6) = MR_tfield(0, MR_tempr1, 2);
	MR_r4 = MR_tfield(0, MR_r4, 3);
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_exist_locns_array_8_0,
		ll_backend__rtti_out__output_exist_info_8_0_i2);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 1;
	MR_tempr5 = MR_sv(3);
	MR_tfield(3, MR_tempr1, 1) = MR_tempr5;
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 2);
	MR_sv(8) = MR_tempr2;
	MR_tempr6 = MR_sv(2);
	MR_tfield(0, MR_tempr2, 0) = MR_tempr6;
	MR_tfield(0, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 1);
	MR_tfield(1, MR_tempr3, 0) = MR_tempr5;
	MR_tag_alloc_heap(MR_tempr4, 0, (MR_Integer) 2);
	MR_sv(9) = MR_tempr4;
	MR_tfield(0, MR_tempr4, 0) = MR_tempr6;
	MR_tfield(0, MR_tempr4, 1) = MR_tempr3;
	MR_sv(7) = MR_r1;
	}
	MR_np_call_localret_ent(fn__backend_libs__name_mangle__mercury_data_prefix_0_0,
		ll_backend__rtti_out__output_exist_info_8_0_i7);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(10) = MR_r1;
	MR_r1 = MR_sv(9);
	MR_np_call_localret_ent(backend_libs__rtti__id_to_c_identifier_2_0,
		ll_backend__rtti_out__output_exist_info_8_0_i8);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(6),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_exist_info_8_0_i10);
	}
	MR_sv(9) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i11);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(8);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(7);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_exist_info_8_0_i12);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n\t", 6);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i13);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i14);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i15);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(5);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i16);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i17);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, tc_constraint);
	MR_r2 = MR_sv(6);
	MR_np_call_localret_ent(list__length_2_0,
		ll_backend__rtti_out__output_exist_info_8_0_i18);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i19);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i20);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(10);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i21);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(9);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i22);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i40);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(9) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(3);
	MR_r4 = MR_sv(6);
	MR_r5 = MR_sv(7);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_exist_constraints_data_8_0,
		ll_backend__rtti_out__output_exist_info_8_0_i25);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(7) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i26);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(8);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(7);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_exist_info_8_0_i27);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n\t", 6);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i28);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i29);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i30);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(5);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i31);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i32);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, tc_constraint);
	MR_r2 = MR_sv(6);
	MR_np_call_localret_ent(list__length_2_0,
		ll_backend__rtti_out__output_exist_info_8_0_i33);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i34);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i35);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(10);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i36);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(9);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i37);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,37)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i38);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,38)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 3, (MR_Integer) 2);
	MR_tfield(3, MR_r2, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_r2, 1) = MR_sv(3);
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_ctor_rtti_id_4_0,
		ll_backend__rtti_out__output_exist_info_8_0_i40);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(8);
	MR_r2 = MR_sv(1);
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i42);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,42)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("\n};\n", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_info_8_0_i43);
MR_def_label(ll_backend__rtti_out__output_exist_info_8_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(11);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_rtti_maybe_pseudo_type_info_or_self_0;

MR_BEGIN_MODULE(ll_backend__rtti_out_module59)
	MR_init_entry1(ll_backend__rtti_out__output_du_arg_types_8_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_du_arg_types_8_0);
	MR_init_label10(ll_backend__rtti_out__output_du_arg_types_8_0,3,5,6,9,10,12,13,15,16,17)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_du_arg_types'/8 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_du_arg_types_8_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(2,6);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_maybe_pseudo_type_info_or_self_defn_6_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_sv(4) = MR_r4;
	MR_sv(5) = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info_or_self);
	MR_r1 = MR_sv(5);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, decl_set);
	MR_r3 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r4 = MR_tempr1;
	MR_tempr2 = MR_r5;
	MR_r5 = MR_sv(4);
	MR_r6 = MR_tempr2;
	}
	MR_np_call_localret_ent(list__foldl2_6_2,
		ll_backend__rtti_out__output_du_arg_types_8_0_i3);
MR_def_label(ll_backend__rtti_out__output_du_arg_types_8_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(5) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info_or_self);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_data);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,23);
	MR_r4 = MR_sv(4);
	MR_np_call_localret_ent(fn__list__map_2_0,
		ll_backend__rtti_out__output_du_arg_types_8_0_i5);
MR_def_label(ll_backend__rtti_out__output_du_arg_types_8_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(5);
	MR_sv(5) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(5);
	MR_r3 = (MR_Word) MR_string_const("", 0);
	MR_r4 = (MR_Word) MR_string_const("", 0);
	MR_r5 = (MR_Integer) 0;
	MR_r6 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_record_rtti_datas_decls_10_0,
		ll_backend__rtti_out__output_du_arg_types_8_0_i6);
MR_def_label(ll_backend__rtti_out__output_du_arg_types_8_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 3;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(3);
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 2);
	MR_sv(3) = MR_tempr2;
	MR_tfield(0, MR_tempr2, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr2, 1) = MR_tempr1;
	MR_sv(2) = MR_r2;
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_arg_types_8_0_i9);
MR_def_label(ll_backend__rtti_out__output_du_arg_types_8_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(3);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(2);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_du_arg_types_8_0_i10);
MR_def_label(ll_backend__rtti_out__output_du_arg_types_8_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(3);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0,
		ll_backend__rtti_out__output_du_arg_types_8_0_i12);
MR_def_label(ll_backend__rtti_out__output_du_arg_types_8_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_arg_types_8_0_i13);
MR_def_label(ll_backend__rtti_out__output_du_arg_types_8_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(11,1);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__IntroducedFrom__pred__output_du_arg_types__1103__1_1_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(4);
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Word) MR_string_const("rtti_out.m", 10);
	MR_r3 = (MR_Word) MR_string_const("output_du_arg_types: empty list", 31);
	}
	MR_np_call_localret_ent(libs__compiler_util__expect_3_0,
		ll_backend__rtti_out__output_du_arg_types_8_0_i15);
MR_def_label(ll_backend__rtti_out__output_du_arg_types_8_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("(MR_PseudoTypeInfo) ", 20);
	MR_r2 = MR_sv(5);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_cast_addr_of_rtti_datas_4_0,
		ll_backend__rtti_out__output_du_arg_types_8_0_i16);
MR_def_label(ll_backend__rtti_out__output_du_arg_types_8_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("};\n", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_arg_types_8_0_i17);
MR_def_label(ll_backend__rtti_out__output_du_arg_types_8_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(6);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module60)
	MR_init_entry1(ll_backend__rtti_out__output_du_arg_names_8_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_du_arg_names_8_0);
	MR_init_label9(ll_backend__rtti_out__output_du_arg_names_8_0,4,5,7,8,10,11,14,15,16)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_du_arg_names'/8 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_du_arg_names_8_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 2;
	MR_tfield(3, MR_tempr1, 1) = MR_r3;
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 2);
	MR_sv(4) = MR_tempr2;
	MR_tfield(0, MR_tempr2, 0) = MR_r2;
	MR_tfield(0, MR_tempr2, 1) = MR_tempr1;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r4;
	MR_sv(3) = MR_r5;
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_arg_names_8_0_i4);
MR_def_label(ll_backend__rtti_out__output_du_arg_names_8_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(4);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(3);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_du_arg_names_8_0_i5);
MR_def_label(ll_backend__rtti_out__output_du_arg_names_8_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(4);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0,
		ll_backend__rtti_out__output_du_arg_names_8_0_i7);
MR_def_label(ll_backend__rtti_out__output_du_arg_names_8_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_arg_names_8_0_i8);
MR_def_label(ll_backend__rtti_out__output_du_arg_names_8_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(11,2);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__IntroducedFrom__pred__output_du_arg_names__1117__1_1_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(2);
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Word) MR_string_const("rtti_out.m", 10);
	MR_r3 = (MR_Word) MR_string_const("output_du_arg_names: empty list", 31);
	}
	MR_np_call_localret_ent(libs__compiler_util__expect_3_0,
		ll_backend__rtti_out__output_du_arg_names_8_0_i10);
MR_def_label(ll_backend__rtti_out__output_du_arg_names_8_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\t", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_arg_names_8_0_i11);
MR_def_label(ll_backend__rtti_out__output_du_arg_names_8_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,11);
	MR_r2 = MR_sv(2);
	MR_r3 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_r4 = (MR_Word) MR_TAG_COMMON(0,4,24);
	MR_np_call_localret_ent(io__write_list_5_0,
		ll_backend__rtti_out__output_du_arg_names_8_0_i14);
MR_def_label(ll_backend__rtti_out__output_du_arg_names_8_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_arg_names_8_0_i15);
MR_def_label(ll_backend__rtti_out__output_du_arg_names_8_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("};\n", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_arg_names_8_0_i16);
MR_def_label(ll_backend__rtti_out__output_du_arg_names_8_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(5);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module61)
	MR_init_entry1(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0);
	MR_init_label7(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0,3,8,40,10,16,17,18)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_addr_of_ctor_rtti_id'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_sv(1) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_r1;
	MR_tfield(0, MR_tempr1, 1) = MR_r2;
	if (MR_PTAG_TESTR(MR_tempr1,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0_i3);
	}
	MR_tempr1 = MR_tfield(0, MR_sv(1), 1);
	MR_r4 = MR_tempr1;
	if (MR_RTAGS_TESTR(MR_tempr1,3,11)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0_i3);
	}
	MR_r5 = MR_tfield(3, MR_r4, 1);
	if (MR_PTAG_TESTR(MR_r5,3)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0_i3);
	}
	MR_r1 = MR_tfield(3, MR_r5, 0);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__write_int_3_0);
	}
MR_def_label(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(fn__backend_libs__rtti__rtti_id_has_array_type_1_0,
		ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0_i8);
MR_def_label(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0_i10);
	}
MR_def_label(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__backend_libs__name_mangle__mercury_data_prefix_0_0,
		ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0_i16);
MR_def_label(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("&", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0_i40);
MR_def_label(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0_i17);
MR_def_label(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(backend_libs__rtti__id_to_c_identifier_2_0,
		ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0_i18);
MR_def_label(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__write_string_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_backend_libs__rtti__type_ctor_info_du_arg_info_0;
MR_decl_entry(fn__list__filter_map_2_0);
MR_decl_entry(fn__backend_libs__type_ctor_info__compute_contains_var_bit_vector_1_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module62)
	MR_init_entry1(ll_backend__rtti_out__output_du_functor_defn_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_du_functor_defn_7_0);
	MR_init_label10(ll_backend__rtti_out__output_du_functor_defn_7_0,3,6,8,10,11,9,14,12,16,19)
	MR_init_label10(ll_backend__rtti_out__output_du_functor_defn_7_0,22,23,24,25,26,27,28,29,30,32)
	MR_init_label10(ll_backend__rtti_out__output_du_functor_defn_7_0,33,31,36,37,38,39,40,41,42,43)
	MR_init_label10(ll_backend__rtti_out__output_du_functor_defn_7_0,44,45,46,48,51,52,54,57,58,60)
	MR_init_label2(ll_backend__rtti_out__output_du_functor_defn_7_0,63,64)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_du_functor_defn'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_du_functor_defn_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(13);
	MR_sv(13) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_sv(3) = MR_tfield(0, MR_tempr1, 0);
	MR_sv(4) = MR_tfield(0, MR_tempr1, 1);
	MR_sv(5) = MR_tfield(0, MR_tempr1, 2);
	MR_sv(6) = MR_tfield(0, MR_tempr1, 3);
	MR_sv(7) = MR_tfield(0, MR_tempr1, 4);
	MR_sv(8) = MR_tfield(0, MR_tempr1, 5);
	MR_sv(11) = MR_r4;
	MR_sv(9) = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, du_arg_info);
	MR_r1 = MR_sv(9);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info_or_self);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,25);
	MR_r4 = MR_sv(7);
	}
	MR_np_call_localret_ent(fn__list__map_2_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i3);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(9) = MR_r1;
	MR_sv(10) = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_sv(12) = (MR_Word) MR_TAG_COMMON(0,0,11);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, du_arg_info);
	MR_r2 = MR_sv(12);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,26);
	MR_r4 = MR_sv(7);
	MR_np_call_localret_ent(fn__list__map_2_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i6);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(10) = MR_r1;
	MR_r1 = MR_sv(12);
	MR_r2 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,27);
	MR_r4 = MR_sv(10);
	MR_np_call_localret_ent(fn__list__filter_map_2_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i8);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(7),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_du_functor_defn_7_0_i10);
	}
	MR_r5 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r6 = MR_sv(11);
	MR_sv(11) = MR_r5;
	MR_r3 = MR_r6;
	MR_GOTO_LAB(ll_backend__rtti_out__output_du_functor_defn_7_0_i9);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(11);
	MR_sv(11) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(9);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_du_arg_types_8_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i11);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r3 = MR_tempr1;
	}
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_sv(11),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_du_functor_defn_7_0_i12);
	}
	MR_sv(1) = MR_r1;
	MR_r2 = MR_sv(2);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(10);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_du_arg_names_8_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i14);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r3 = MR_tempr1;
	}
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(8),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_du_functor_defn_7_0_i16);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 6;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(5);
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(2);
	MR_tfield(0, MR_r2, 1) = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i22);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r2 = MR_sv(2);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_r3 = MR_sv(5);
	MR_r4 = MR_tfield(1, MR_sv(8), 0);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_exist_info_8_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i19);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 6;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(5);
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr2, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr2, 1) = MR_tempr1;
	MR_tempr3 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r3 = MR_tempr3;
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__rtti_out__output_generic_rtti_data_defn_start_6_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i22);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(10) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n\t\"", 7);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i23);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(backend_libs__c_util__output_quoted_string_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i24);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\",\n\t", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i25);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i26);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i27);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(9);
	MR_np_call_localret_ent(fn__backend_libs__type_ctor_info__compute_contains_var_bit_vector_1_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i28);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i29);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i30);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(6),0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_du_functor_defn_7_0_i32);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(6);
	MR_sv(1) = MR_tfield(0, MR_tempr1, 0);
	MR_r1 = MR_tfield(0, MR_tempr1, 1);
	MR_GOTO_LAB(ll_backend__rtti_out__output_du_functor_defn_7_0_i31);
	}
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__ll_backend__rtti_out__this_file_0_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i33);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_string_const("output_du_functor_defn: du_hl_rep", 33);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i31);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_du_functor_defn_7_0_i36);
	}
	MR_r1 = (MR_Word) MR_string_const("MR_SECTAG_NONE", 14);
	MR_sv(3) = (MR_Integer) -1;
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i38);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_du_functor_defn_7_0_i37);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("MR_SECTAG_LOCAL", 15);
	MR_sv(3) = MR_tfield(1, MR_tempr1, 0);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i38);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,37)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("MR_SECTAG_REMOTE", 16);
	MR_sv(3) = MR_tfield(2, MR_tempr1, 0);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i38);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,38)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i39);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i40);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i41);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,41)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i42);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,42)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i43);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(5);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i44);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,44)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i45);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,45)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("(MR_PseudoTypeInfo *) ", 22);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i46);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,46)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(7),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_du_functor_defn_7_0_i48);
	}
	MR_r1 = (MR_Word) MR_string_const("NULL", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i51);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,48)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 3, (MR_Integer) 2);
	MR_tfield(3, MR_r2, 0) = (MR_Integer) 3;
	MR_tfield(3, MR_r2, 1) = MR_sv(5);
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i51);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,51)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i52);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,52)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(11),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_du_functor_defn_7_0_i54);
	}
	MR_r1 = (MR_Word) MR_string_const("NULL", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i57);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,54)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 3, (MR_Integer) 2);
	MR_tfield(3, MR_r2, 0) = (MR_Integer) 2;
	MR_tfield(3, MR_r2, 1) = MR_sv(5);
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i57);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,57)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i58);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,58)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(8),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_du_functor_defn_7_0_i60);
	}
	MR_r1 = (MR_Word) MR_string_const("NULL", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i63);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,60)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 3, (MR_Integer) 2);
	MR_tfield(3, MR_r2, 0) = (MR_Integer) 1;
	MR_tfield(3, MR_r2, 1) = MR_sv(5);
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i63);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,63)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n};\n", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_functor_defn_7_0_i64);
MR_def_label(ll_backend__rtti_out__output_du_functor_defn_7_0,64)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(10);
	MR_decr_sp_and_return(13);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module63)
	MR_init_entry1(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_maybe_res_functor_defn_7_0);
	MR_init_label10(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0,40,7,8,10,11,12,13,14,15,16)
	MR_init_label5(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0,18,21,20,17,23)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_maybe_res_functor_defn'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r3,1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0_i40);
	}
	MR_r3 = MR_tfield(1, MR_r3, 0);
	MR_np_tailcall_ent(ll_backend__rtti_out__output_du_functor_defn_7_0);
MR_def_label(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 7;
	MR_tempr2 = MR_tfield(0, MR_r3, 0);
	MR_tfield(3, MR_tempr1, 1) = MR_tfield(0, MR_tempr2, 1);
	MR_tag_alloc_heap(MR_tempr3, 0, (MR_Integer) 2);
	MR_sv(6) = MR_tempr3;
	MR_tfield(0, MR_tempr3, 0) = MR_r2;
	MR_tfield(0, MR_tempr3, 1) = MR_tempr1;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r4;
	MR_sv(3) = MR_tfield(0, MR_tempr2, 0);
	MR_sv(4) = MR_tfield(3, MR_tempr1, 1);
	MR_sv(5) = MR_tfield(0, MR_tempr2, 2);
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_maybe_res_functor_defn_7_0_i7);
MR_def_label(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(6);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(2);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_maybe_res_functor_defn_7_0_i8);
MR_def_label(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(6);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0,
		ll_backend__rtti_out__output_maybe_res_functor_defn_7_0_i10);
MR_def_label(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n\t\"", 7);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_maybe_res_functor_defn_7_0_i11);
MR_def_label(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(backend_libs__c_util__output_quoted_string_3_0,
		ll_backend__rtti_out__output_maybe_res_functor_defn_7_0_i12);
MR_def_label(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\",\n\t", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_maybe_res_functor_defn_7_0_i13);
MR_def_label(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_maybe_res_functor_defn_7_0_i14);
MR_def_label(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n\t", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_maybe_res_functor_defn_7_0_i15);
MR_def_label(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("(void *) ", 9);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_maybe_res_functor_defn_7_0_i16);
MR_def_label(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(5),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0_i18);
	}
	MR_r1 = (MR_Word) MR_string_const("NULL", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_maybe_res_functor_defn_7_0_i21);
MR_def_label(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(5),1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0_i20);
	}
	MR_r1 = MR_tfield(1, MR_sv(5), 0);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_maybe_res_functor_defn_7_0_i21);
MR_def_label(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n};\n", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_maybe_res_functor_defn_7_0_i23);
MR_def_label(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("rtti_out.m", 10);
	MR_r2 = (MR_Word) MR_string_const("output_res_functor_defn: reserved object", 40);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		ll_backend__rtti_out__output_maybe_res_functor_defn_7_0_i17);
MR_def_label(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_maybe_res_functor_defn_7_0_i23);
MR_def_label(ll_backend__rtti_out__output_maybe_res_functor_defn_7_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(7);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module64)
	MR_init_entry1(ll_backend__rtti_out__make_exist_tc_constr_id_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__make_exist_tc_constr_id_5_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'make_exist_tc_constr_id'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__make_exist_tc_constr_id_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 2, (MR_Integer) 3);
	MR_tfield(2, MR_tempr1, 0) = MR_r2;
	MR_tfield(2, MR_tempr1, 1) = MR_r3;
	MR_tfield(2, MR_tempr1, 2) = MR_r4;
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_r1;
	MR_tfield(0, MR_r2, 1) = MR_tempr1;
	MR_r1 = MR_r2;
	MR_proceed();
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module65)
	MR_init_entry1(ll_backend__rtti_out__output_du_stag_ordered_table_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_du_stag_ordered_table_7_0);
	MR_init_label10(ll_backend__rtti_out__output_du_stag_ordered_table_7_0,2,4,7,8,10,11,19,13,14,16)
	MR_init_label1(ll_backend__rtti_out__output_du_stag_ordered_table_7_0,18)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_du_stag_ordered_table'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_du_stag_ordered_table_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_tfield(0, MR_r3, 0);
	MR_sv(4) = MR_r4;
	MR_sv(5) = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, du_functor);
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_sv(5);
	MR_r3 = MR_tfield(0, MR_tfield(0, MR_r3, 1), 2);
	MR_np_call_localret_ent(map__values_2_0,
		ll_backend__rtti_out__output_du_stag_ordered_table_7_0_i2);
MR_def_label(ll_backend__rtti_out__output_du_stag_ordered_table_7_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,4,28);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__list__map_2_0,
		ll_backend__rtti_out__output_du_stag_ordered_table_7_0_i4);
MR_def_label(ll_backend__rtti_out__output_du_stag_ordered_table_7_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 8;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(3);
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 2);
	MR_sv(5) = MR_tempr2;
	MR_tfield(0, MR_tempr2, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr2, 1) = MR_tempr1;
	MR_sv(3) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_stag_ordered_table_7_0_i7);
MR_def_label(ll_backend__rtti_out__output_du_stag_ordered_table_7_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(5);
	MR_r3 = (MR_Integer) 1;
	MR_r4 = MR_sv(4);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_id_storage_type_name_7_0,
		ll_backend__rtti_out__output_du_stag_ordered_table_7_0_i8);
MR_def_label(ll_backend__rtti_out__output_du_stag_ordered_table_7_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(5);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0,
		ll_backend__rtti_out__output_du_stag_ordered_table_7_0_i10);
MR_def_label(ll_backend__rtti_out__output_du_stag_ordered_table_7_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" = {\n", 5);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_stag_ordered_table_7_0_i11);
MR_def_label(ll_backend__rtti_out__output_du_stag_ordered_table_7_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(3),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_du_stag_ordered_table_7_0_i13);
	}
MR_def_label(ll_backend__rtti_out__output_du_stag_ordered_table_7_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n};\n", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_stag_ordered_table_7_0_i18);
MR_def_label(ll_backend__rtti_out__output_du_stag_ordered_table_7_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\t", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_stag_ordered_table_7_0_i14);
MR_def_label(ll_backend__rtti_out__output_du_stag_ordered_table_7_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(6,10);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_addr_of_ctor_rtti_id_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(2);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, ctor_rtti_name);
	MR_r2 = MR_sv(3);
	MR_r3 = (MR_Word) MR_string_const(",\n\t", 3);
	}
	MR_np_call_localret_ent(io__write_list_5_0,
		ll_backend__rtti_out__output_du_stag_ordered_table_7_0_i16);
MR_def_label(ll_backend__rtti_out__output_du_stag_ordered_table_7_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_du_stag_ordered_table_7_0_i19);
MR_def_label(ll_backend__rtti_out__output_du_stag_ordered_table_7_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(6);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__backend_libs__rtti__res_functor_rtti_name_1_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module66)
	MR_init_entry1(ll_backend__rtti_out__output_res_addr_functors_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_res_addr_functors_4_0);
	MR_init_label5(ll_backend__rtti_out__output_res_addr_functors_4_0,2,4,5,6,7)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_res_addr_functors'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_res_addr_functors_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__backend_libs__rtti__res_functor_rtti_name_1_0,
		ll_backend__rtti_out__output_res_addr_functors_4_0_i2);
MR_def_label(ll_backend__rtti_out__output_res_addr_functors_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(1);
	MR_tfield(0, MR_r2, 1) = MR_r1;
	MR_sv(1) = MR_r2;
	MR_np_call_localret_ent(fn__backend_libs__name_mangle__mercury_data_prefix_0_0,
		ll_backend__rtti_out__output_res_addr_functors_4_0_i4);
MR_def_label(ll_backend__rtti_out__output_res_addr_functors_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_addr_functors_4_0_i5);
MR_def_label(ll_backend__rtti_out__output_res_addr_functors_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(backend_libs__rtti__id_to_c_identifier_2_0,
		ll_backend__rtti_out__output_res_addr_functors_4_0_i6);
MR_def_label(ll_backend__rtti_out__output_res_addr_functors_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_addr_functors_4_0_i7);
MR_def_label(ll_backend__rtti_out__output_res_addr_functors_4_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n", 2);
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__write_string_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__backend_libs__rtti__maybe_res_functor_rtti_name_1_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module67)
	MR_init_entry1(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_res_name_ordered_table_element_4_0);
	MR_init_label10(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0,2,5,6,7,8,4,10,11,12,13)
	MR_init_label5(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0,14,16,17,18,19)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_res_name_ordered_table_element'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = (MR_Word) MR_string_const("\t{ \"", 4);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_name_ordered_table_element_4_0_i2);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0_i4);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_sv(2), 0);
	MR_sv(3) = MR_tfield(0, MR_tempr1, 1);
	MR_r1 = MR_tfield(0, MR_tempr1, 0);
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_name_ordered_table_element_4_0_i5);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\", ", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_name_ordered_table_element_4_0_i6);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_res_name_ordered_table_element_4_0_i7);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_name_ordered_table_element_4_0_i8);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("MR_FALSE, ", 10);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_name_ordered_table_element_4_0_i13);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_tfield(0, MR_sv(2), 0), 0);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_name_ordered_table_element_4_0_i10);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\", ", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_name_ordered_table_element_4_0_i11);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("0, ", 3);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_name_ordered_table_element_4_0_i12);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("MR_TRUE, ", 9);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_name_ordered_table_element_4_0_i13);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(fn__backend_libs__rtti__maybe_res_functor_rtti_name_1_0,
		ll_backend__rtti_out__output_res_name_ordered_table_element_4_0_i14);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(1);
	MR_tfield(0, MR_r2, 1) = MR_r1;
	MR_sv(1) = MR_r2;
	MR_np_call_localret_ent(fn__backend_libs__name_mangle__mercury_data_prefix_0_0,
		ll_backend__rtti_out__output_res_name_ordered_table_element_4_0_i16);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_name_ordered_table_element_4_0_i17);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(backend_libs__rtti__id_to_c_identifier_2_0,
		ll_backend__rtti_out__output_res_name_ordered_table_element_4_0_i18);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_res_name_ordered_table_element_4_0_i19);
MR_def_label(ll_backend__rtti_out__output_res_name_ordered_table_element_4_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(" },\n", 4);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(io__write_string_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__list__reverse_1_0);
MR_decl_entry(list__chunk_3_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module68)
	MR_init_entry1(ll_backend__rtti_out__output_rtti_data_decl_group_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_rtti_data_decl_group_6_0);
	MR_init_label2(ll_backend__rtti_out__output_rtti_data_decl_group_6_0,2,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_rtti_data_decl_group'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_rtti_data_decl_group_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(0, MR_r2, 0);
	MR_sv(3) = MR_r3;
	MR_sv(4) = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_id);
	MR_r1 = MR_sv(4);
	MR_r2 = MR_tfield(0, MR_r2, 1);
	MR_np_call_localret_ent(fn__list__reverse_1_0,
		ll_backend__rtti_out__output_rtti_data_decl_group_6_0_i2);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_group_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = MR_tempr1;
	MR_r3 = (MR_Integer) 10;
	}
	MR_np_call_localret_ent(list__chunk_3_0,
		ll_backend__rtti_out__output_rtti_data_decl_group_6_0_i3);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_group_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(10,5);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 4) = MR_sv(2);
	MR_tempr2 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,2);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(ll_backend__llds_out__llds_out_util, decl_set);
	MR_r3 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r5 = MR_tempr2;
	MR_r6 = MR_sv(3);
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(list__foldl2_6_2);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module69)
	MR_init_entry1(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0);
	MR_init_label10(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0,33,5,6,7,8,9,10,11,16,15)
	MR_init_label2(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0,17,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_rtti_data_decl_chunk_entries'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_r2,0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0_i3);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_tfield(1, MR_r2, 0);
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_tfield(3, MR_tempr1, 1);
	MR_sv(3) = MR_tfield(1, MR_r2, 1);
	MR_r1 = MR_tempr1;
	MR_r2 = MR_r3;
	}
	MR_np_call_localret_ent(ll_backend__llds_out__llds_out_util__decl_set_insert_3_0,
		ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0_i5);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("\t", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0_i6);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__backend_libs__name_mangle__mercury_data_prefix_0_0,
		ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0_i7);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0_i8);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(backend_libs__rtti__id_to_c_identifier_2_0,
		ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0_i9);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0_i10);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(1),0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0_i11);
	}
	MR_r1 = (MR_Word) MR_string_const("[]", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0_i11);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(3),0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0_i15);
	}
	MR_r1 = (MR_Word) MR_string_const(";\n", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0_i16);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_decr_sp_and_return(5);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(",\n", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0_i17);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(3);
	MR_r3 = MR_sv(4);
	MR_succip_word = MR_sv(5);
	MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0_i33);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("rtti_out.m", 10);
	MR_r2 = (MR_Word) MR_string_const("output_rtti_data_decl_chunk_entries: empty list", 47);
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(libs__compiler_util__unexpected_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(io__nl_2_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module70)
	MR_init_entry1(ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0);
	MR_init_label10(ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0,3,2,5,6,7,8,9,10,11,12)
	MR_init_label1(ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0,13)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_rtti_data_decl_chunk'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(8);
	MR_sv(8) = (MR_Word) MR_succip;
	if (MR_LTAGS_TEST(MR_r3,0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0_i3);
	}
	MR_sv(1) = MR_r1;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_sv(2) = MR_tempr1;
	MR_sv(3) = MR_tfield(1, MR_tempr1, 0);
	MR_sv(4) = MR_tfield(0, MR_r2, 0);
	MR_sv(5) = MR_tfield(0, MR_r2, 1);
	MR_sv(6) = MR_tfield(0, MR_r2, 2);
	MR_sv(7) = MR_r4;
	}
	MR_np_call_localret_ent(io__nl_2_0,
		ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0_i5);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("rtti_out.m", 10);
	MR_r2 = (MR_Word) MR_string_const("output_rtti_data_decl_group: empty list", 39);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0_i2);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__nl_2_0,
		ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0_i5);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(7);
	MR_np_call_localret_ent(ll_backend__rtti_out__output_rtti_type_decl_5_0,
		ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0_i6);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_tfield(0, MR_sv(1), 18);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(6);
	MR_sv(6) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Integer) 0;
	}
	MR_np_call_localret_ent(fn__ll_backend__llds_out__llds_out_file__c_data_linkage_string_2_0,
		ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0_i7);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_sv(3) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__backend_libs__rtti__rtti_id_would_include_code_addr_1_0,
		ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0_i8);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(3);
	MR_sv(3) = MR_r1;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0_i9);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__ll_backend__llds_out__llds_out_file__c_data_const_string_2_0,
		ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0_i10);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0_i11);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_np_call_localret_ent(backend_libs__c_util__output_quoted_string_3_0,
		ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0_i12);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(io__nl_2_0,
		ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0_i13);
MR_def_label(ll_backend__rtti_out__output_rtti_data_decl_chunk_7_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(6);
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_np_tailcall_ent(ll_backend__rtti_out__output_rtti_data_decl_chunk_entries_6_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module71)
	MR_init_entry1(ll_backend__rtti_out__output_maybe_quoted_string_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_maybe_quoted_string_3_0);
	MR_init_label3(ll_backend__rtti_out__output_maybe_quoted_string_3_0,16,5,6)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_maybe_quoted_string'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_maybe_quoted_string_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_maybe_quoted_string_3_0_i16);
	}
	MR_r1 = (MR_Word) MR_string_const("NULL", 4);
	MR_np_tailcall_ent(io__write_string_3_0);
MR_def_label(ll_backend__rtti_out__output_maybe_quoted_string_3_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_tfield(1, MR_r1, 0);
	MR_r1 = (MR_Word) MR_string_const("\"", 1);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_maybe_quoted_string_3_0_i5);
MR_def_label(ll_backend__rtti_out__output_maybe_quoted_string_3_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(backend_libs__c_util__output_quoted_string_3_0,
		ll_backend__rtti_out__output_maybe_quoted_string_3_0_i6);
MR_def_label(ll_backend__rtti_out__output_maybe_quoted_string_3_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("\"", 1);
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(io__write_string_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module72)
	MR_init_entry1(ll_backend__rtti_out__output_exist_locn_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__output_exist_locn_3_0);
	MR_init_label7(ll_backend__rtti_out__output_exist_locn_3_0,4,5,3,7,8,9,10)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'output_exist_locn'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__output_exist_locn_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(ll_backend__rtti_out__output_exist_locn_3_0_i3);
	}
	MR_sv(1) = MR_tfield(0, MR_r1, 0);
	MR_r1 = (MR_Word) MR_string_const("{ ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_locn_3_0_i4);
MR_def_label(ll_backend__rtti_out__output_exist_locn_3_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_exist_locn_3_0_i5);
MR_def_label(ll_backend__rtti_out__output_exist_locn_3_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(", -1 }", 6);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(io__write_string_3_0);
MR_def_label(ll_backend__rtti_out__output_exist_locn_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_tfield(1, MR_r1, 1);
	MR_sv(2) = MR_tfield(1, MR_r1, 0);
	MR_r1 = (MR_Word) MR_string_const("{ ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_locn_3_0_i7);
MR_def_label(ll_backend__rtti_out__output_exist_locn_3_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_exist_locn_3_0_i8);
MR_def_label(ll_backend__rtti_out__output_exist_locn_3_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(", ", 2);
	MR_np_call_localret_ent(io__write_string_3_0,
		ll_backend__rtti_out__output_exist_locn_3_0_i9);
MR_def_label(ll_backend__rtti_out__output_exist_locn_3_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(io__write_int_3_0,
		ll_backend__rtti_out__output_exist_locn_3_0_i10);
MR_def_label(ll_backend__rtti_out__output_exist_locn_3_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(" }", 2);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(io__write_string_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module73)
	MR_init_entry1(__Unify___ll_backend__rtti_out__data_group_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___ll_backend__rtti_out__data_group_0_0);
	MR_init_label2(__Unify___ll_backend__rtti_out__data_group_0_0,4,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Unify___ll_backend__rtti_out__data_group_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Unify___ll_backend__rtti_out__data_group_0_0_i4);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_sv(1) = MR_tempr1;
	MR_tempr2 = MR_r2;
	MR_sv(2) = MR_tempr2;
	MR_r1 = MR_tfield(0, MR_tempr1, 0);
	MR_r2 = MR_tfield(0, MR_tempr2, 0);
	if ((strcmp((char *) (MR_Word *) MR_r1, (char *) (MR_Word *) MR_r2) != 0)) {
		MR_GOTO_LAB(__Unify___ll_backend__rtti_out__data_group_0_0_i1);
	}
	MR_r1 = MR_tfield(0, MR_tempr1, 1);
	MR_r2 = MR_tfield(0, MR_tempr2, 1);
	if ((MR_r1 != MR_r2)) {
		MR_GOTO_LAB(__Unify___ll_backend__rtti_out__data_group_0_0_i1);
	}
	MR_r1 = MR_tfield(0, MR_tempr1, 2);
	MR_r2 = MR_tfield(0, MR_tempr2, 2);
	MR_r1 = (MR_r1 == MR_r2);
	MR_decr_sp(2);
	MR_proceed();
	}
MR_def_label(__Unify___ll_backend__rtti_out__data_group_0_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp(2);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(__Unify___ll_backend__rtti_out__data_group_0_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp(2);
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(private_builtin__builtin_compare_string_3_0);
MR_decl_entry(private_builtin__builtin_compare_int_3_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module74)
	MR_init_entry1(__Compare___ll_backend__rtti_out__data_group_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___ll_backend__rtti_out__data_group_0_0);
	MR_init_label5(__Compare___ll_backend__rtti_out__data_group_0_0,3,2,5,9,29)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Compare___ll_backend__rtti_out__data_group_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Compare___ll_backend__rtti_out__data_group_0_0_i3);
	}
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_GOTO_LAB(__Compare___ll_backend__rtti_out__data_group_0_0_i2);
MR_def_label(__Compare___ll_backend__rtti_out__data_group_0_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_def_label(__Compare___ll_backend__rtti_out__data_group_0_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6;
	MR_tempr5 = MR_sv(2);
	MR_sv(4) = MR_tfield(0, MR_tempr5, 2);
	MR_sv(3) = MR_tfield(0, MR_tempr5, 1);
	MR_tempr6 = MR_sv(1);
	MR_tempr1 = MR_tfield(0, MR_tempr6, 2);
	MR_tempr2 = MR_tfield(0, MR_tempr6, 1);
	MR_tempr3 = MR_tempr6;
	MR_sv(1) = MR_tempr2;
	MR_tempr4 = MR_tempr5;
	MR_sv(2) = MR_tempr1;
	MR_r1 = MR_tfield(0, MR_tempr3, 0);
	MR_r2 = MR_tfield(0, MR_tempr4, 0);
	}
	MR_np_call_localret_ent(private_builtin__builtin_compare_string_3_0,
		__Compare___ll_backend__rtti_out__data_group_0_0_i5);
MR_def_label(__Compare___ll_backend__rtti_out__data_group_0_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___ll_backend__rtti_out__data_group_0_0_i29);
	}
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(private_builtin__builtin_compare_int_3_0,
		__Compare___ll_backend__rtti_out__data_group_0_0_i9);
MR_def_label(__Compare___ll_backend__rtti_out__data_group_0_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___ll_backend__rtti_out__data_group_0_0_i29);
	}
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(4);
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(private_builtin__builtin_compare_int_3_0);
MR_def_label(__Compare___ll_backend__rtti_out__data_group_0_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(5);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module75)
	MR_init_entry1(ll_backend__rtti_out__IntroducedFrom__pred__output_type_ctor_details_defn__723__1_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__IntroducedFrom__pred__output_type_ctor_details_defn__723__1_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__output_type_ctor_details_defn__723__1'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__IntroducedFrom__pred__output_type_ctor_details_defn__723__1_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_r1 == MR_r2);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__backend_libs__rtti__project_yes_1_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module76)
	MR_init_entry1(fn__ll_backend__rtti_out__IntroducedFrom__func__output_du_functor_defn__879__1_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__ll_backend__rtti_out__IntroducedFrom__func__output_du_functor_defn__879__1_1_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__func__output_du_functor_defn__879__1'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__ll_backend__rtti_out__IntroducedFrom__func__output_du_functor_defn__879__1_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r2 = MR_tempr1;
	MR_np_tailcall_ent(fn__backend_libs__rtti__project_yes_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(list__is_not_empty_1_0);

MR_BEGIN_MODULE(ll_backend__rtti_out_module77)
	MR_init_entry1(ll_backend__rtti_out__IntroducedFrom__pred__output_du_arg_types__1103__1_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__IntroducedFrom__pred__output_du_arg_types__1103__1_1_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__output_du_arg_types__1103__1'/1 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__IntroducedFrom__pred__output_du_arg_types__1103__1_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, rtti_maybe_pseudo_type_info_or_self);
	MR_r2 = MR_tempr1;
	MR_np_tailcall_ent(list__is_not_empty_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module78)
	MR_init_entry1(ll_backend__rtti_out__IntroducedFrom__pred__output_du_arg_names__1117__1_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__IntroducedFrom__pred__output_du_arg_names__1117__1_1_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__output_du_arg_names__1117__1'/1 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__IntroducedFrom__pred__output_du_arg_names__1117__1_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,0,11);
	MR_r2 = MR_tempr1;
	MR_np_tailcall_ent(list__is_not_empty_1_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module79)
	MR_init_entry1(ll_backend__rtti_out__IntroducedFrom__pred__output_du_name_ordered_table__1189__1_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__IntroducedFrom__pred__output_du_name_ordered_table__1189__1_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__output_du_name_ordered_table__1189__1'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__IntroducedFrom__pred__output_du_name_ordered_table__1189__1_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, du_functor);
	MR_r3 = MR_tempr1;
	MR_np_tailcall_ent(map__values_2_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module80)
	MR_init_entry1(ll_backend__rtti_out__IntroducedFrom__pred__output_du_ptag_ordered_table_body__1245__1_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__IntroducedFrom__pred__output_du_ptag_ordered_table_body__1245__1_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__output_du_ptag_ordered_table_body__1245__1'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__IntroducedFrom__pred__output_du_ptag_ordered_table_body__1245__1_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_r2 == MR_r1);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module81)
	MR_init_entry1(ll_backend__rtti_out__IntroducedFrom__pred__output_res_value_ordered_table__1296__1_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__IntroducedFrom__pred__output_res_value_ordered_table__1296__1_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__output_res_value_ordered_table__1296__1'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__IntroducedFrom__pred__output_res_value_ordered_table__1296__1_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_r1 == MR_r2);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(ll_backend__rtti_out_module82)
	MR_init_entry1(ll_backend__rtti_out__IntroducedFrom__pred__output_res_name_ordered_table__1331__1_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__ll_backend__rtti_out__IntroducedFrom__pred__output_res_name_ordered_table__1331__1_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__output_res_name_ordered_table__1331__1'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(ll_backend__rtti_out__IntroducedFrom__pred__output_res_name_ordered_table__1331__1_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(backend_libs__rtti, maybe_reserved_functor);
	MR_r3 = MR_tempr1;
	MR_np_tailcall_ent(map__values_2_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

static void mercury__ll_backend__rtti_out_maybe_bunch_0(void)
{
	ll_backend__rtti_out_module0();
	ll_backend__rtti_out_module1();
	ll_backend__rtti_out_module2();
	ll_backend__rtti_out_module3();
	ll_backend__rtti_out_module4();
	ll_backend__rtti_out_module5();
	ll_backend__rtti_out_module6();
	ll_backend__rtti_out_module7();
	ll_backend__rtti_out_module8();
	ll_backend__rtti_out_module9();
	ll_backend__rtti_out_module10();
	ll_backend__rtti_out_module11();
	ll_backend__rtti_out_module12();
	ll_backend__rtti_out_module13();
	ll_backend__rtti_out_module14();
	ll_backend__rtti_out_module15();
	ll_backend__rtti_out_module16();
	ll_backend__rtti_out_module17();
	ll_backend__rtti_out_module18();
	ll_backend__rtti_out_module19();
	ll_backend__rtti_out_module20();
	ll_backend__rtti_out_module21();
	ll_backend__rtti_out_module22();
	ll_backend__rtti_out_module23();
	ll_backend__rtti_out_module24();
	ll_backend__rtti_out_module25();
	ll_backend__rtti_out_module26();
	ll_backend__rtti_out_module27();
	ll_backend__rtti_out_module28();
	ll_backend__rtti_out_module29();
	ll_backend__rtti_out_module30();
	ll_backend__rtti_out_module31();
	ll_backend__rtti_out_module32();
	ll_backend__rtti_out_module33();
	ll_backend__rtti_out_module34();
	ll_backend__rtti_out_module35();
	ll_backend__rtti_out_module36();
	ll_backend__rtti_out_module37();
	ll_backend__rtti_out_module38();
	ll_backend__rtti_out_module39();
}

static void mercury__ll_backend__rtti_out_maybe_bunch_1(void)
{
	ll_backend__rtti_out_module40();
	ll_backend__rtti_out_module41();
	ll_backend__rtti_out_module42();
	ll_backend__rtti_out_module43();
	ll_backend__rtti_out_module44();
	ll_backend__rtti_out_module45();
	ll_backend__rtti_out_module46();
	ll_backend__rtti_out_module47();
	ll_backend__rtti_out_module48();
	ll_backend__rtti_out_module49();
	ll_backend__rtti_out_module50();
	ll_backend__rtti_out_module51();
	ll_backend__rtti_out_module52();
	ll_backend__rtti_out_module53();
	ll_backend__rtti_out_module54();
	ll_backend__rtti_out_module55();
	ll_backend__rtti_out_module56();
	ll_backend__rtti_out_module57();
	ll_backend__rtti_out_module58();
	ll_backend__rtti_out_module59();
	ll_backend__rtti_out_module60();
	ll_backend__rtti_out_module61();
	ll_backend__rtti_out_module62();
	ll_backend__rtti_out_module63();
	ll_backend__rtti_out_module64();
	ll_backend__rtti_out_module65();
	ll_backend__rtti_out_module66();
	ll_backend__rtti_out_module67();
	ll_backend__rtti_out_module68();
	ll_backend__rtti_out_module69();
	ll_backend__rtti_out_module70();
	ll_backend__rtti_out_module71();
	ll_backend__rtti_out_module72();
	ll_backend__rtti_out_module73();
	ll_backend__rtti_out_module74();
	ll_backend__rtti_out_module75();
	ll_backend__rtti_out_module76();
	ll_backend__rtti_out_module77();
	ll_backend__rtti_out_module78();
	ll_backend__rtti_out_module79();
}

static void mercury__ll_backend__rtti_out_maybe_bunch_2(void)
{
	ll_backend__rtti_out_module80();
	ll_backend__rtti_out_module81();
	ll_backend__rtti_out_module82();
}

/* suppress gcc -Wmissing-decls warnings */
void mercury__ll_backend__rtti_out__init(void);
void mercury__ll_backend__rtti_out__init_type_tables(void);
void mercury__ll_backend__rtti_out__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__ll_backend__rtti_out__write_out_proc_statics(FILE *deep_fp, FILE *procrep_fp);
#endif
#ifdef MR_RECORD_TERM_SIZES
void mercury__ll_backend__rtti_out__init_complexity_procs(void);
#endif

void mercury__ll_backend__rtti_out__init(void)
{
	static MR_bool done = MR_FALSE;
	if (done) {
		return;
	}
	done = MR_TRUE;
	mercury__ll_backend__rtti_out_maybe_bunch_0();
	mercury__ll_backend__rtti_out_maybe_bunch_1();
	mercury__ll_backend__rtti_out_maybe_bunch_2();
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_ll_backend__rtti_out__type_ctor_info_data_group_0,
		ll_backend__rtti_out__data_group_0_0);
	mercury__ll_backend__rtti_out__init_debugger();
}

void mercury__ll_backend__rtti_out__init_type_tables(void)
{
	static MR_bool done = MR_FALSE;
	if (done) {
		return;
	}
	done = MR_TRUE;
	{
		MR_register_type_ctor_info(
		&mercury_data_ll_backend__rtti_out__type_ctor_info_data_group_0);
	}
}


void mercury__ll_backend__rtti_out__init_debugger(void)
{
	static MR_bool done = MR_FALSE;
	if (done) {
		return;
	}
	done = MR_TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__ll_backend__rtti_out__write_out_proc_statics(FILE *deep_fp, FILE *procrep_fp)
{
	MR_write_out_module_proc_reps_start(procrep_fp, &mercury_data__module_common_layout__ll_backend__rtti_out);
	MR_write_out_module_proc_reps_end(procrep_fp);
}

#endif

#ifdef MR_RECORD_TERM_SIZES

void mercury__ll_backend__rtti_out__init_complexity_procs(void)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
