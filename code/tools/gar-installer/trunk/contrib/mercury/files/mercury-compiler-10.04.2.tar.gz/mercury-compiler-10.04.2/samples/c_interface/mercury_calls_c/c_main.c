#include <stdio.h>

#include "c_main.h"

void c_main(void) {
	printf("In c_main().\n");
}
