/*
** Automatically generated from `add_type.m'
** by the Mercury compiler,
** version 10.04.2, configured for x86_64-unknown-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
** HIGHLEVEL_CODE=no
**
** END_OF_C_GRADE_INFO
*/

/*
INIT mercury__hlds__make_hlds__add_type__init
ENDINIT
*/

#define MR_ALLOW_RESET
#include "mercury_imp.h"
#line 141 "../library/io.int2"
#include "io.mh"

#line 28 "hlds.make_hlds.add_type.c"
#line 149 "../library/io.int2"
#include "string.mh"

#line 32 "hlds.make_hlds.add_type.c"
#line 33 "../mdbcomp/mdbcomp.rtti_access.int2"
#include "mdbcomp.rtti_access.mh"

#line 36 "hlds.make_hlds.add_type.c"
#line 31 "../library/array.int2"
#include "array.mh"

#line 40 "hlds.make_hlds.add_type.c"
#line 29 "../library/bitmap.int2"
#include "bitmap.mh"

#line 44 "hlds.make_hlds.add_type.c"
#line 28 "../library/time.int2"
#include "time.mh"

#line 48 "hlds.make_hlds.add_type.c"
#line 49 "hlds.make_hlds.add_type.c"
#include "hlds.make_hlds.add_type.mh"

#line 52 "hlds.make_hlds.add_type.c"
#line 53 "hlds.make_hlds.add_type.c"
#ifndef HLDS__MAKE_HLDS__ADD_TYPE_DECL_GUARD
#define HLDS__MAKE_HLDS__ADD_TYPE_DECL_GUARD

#line 57 "hlds.make_hlds.add_type.c"
#line 58 "hlds.make_hlds.add_type.c"

#endif
#line 61 "hlds.make_hlds.add_type.c"

#ifdef _MSC_VER
#define MR_STATIC_LINKAGE extern
#else
#define MR_STATIC_LINKAGE static
#endif

struct mercury_type_0 {
	MR_Integer f1;
};
MR_STATIC_LINKAGE const struct mercury_type_0 mercury_common_0[];

struct mercury_type_1 {
	MR_Integer f1;
	MR_String f2;
};
MR_STATIC_LINKAGE const struct mercury_type_1 mercury_common_1[];

struct mercury_type_2 {
	MR_Word * f1[2];
};
MR_STATIC_LINKAGE const struct mercury_type_2 mercury_common_2[];

struct mercury_type_3 {
	MR_String f1;
};
MR_STATIC_LINKAGE const struct mercury_type_3 mercury_common_3[];

struct mercury_type_4 {
	MR_Word * f1;
};
MR_STATIC_LINKAGE const struct mercury_type_4 mercury_common_4[];

struct mercury_type_5 {
	MR_Integer f1;
	MR_Integer f2;
	MR_Word * f3;
};
MR_STATIC_LINKAGE const struct mercury_type_5 mercury_common_5[];

struct mercury_type_6 {
	MR_Word * f1[3];
};
MR_STATIC_LINKAGE const struct mercury_type_6 mercury_common_6[];

struct mercury_type_7 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[5];
};
MR_STATIC_LINKAGE const struct mercury_type_7 mercury_common_7[];

struct mercury_type_8 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[7];
};
MR_STATIC_LINKAGE const struct mercury_type_8 mercury_common_8[];

struct mercury_type_9 {
	MR_Word * f1;
	MR_Word * f2;
	MR_Integer f3;
	MR_Word * f4;
	MR_Word * f5;
};
MR_STATIC_LINKAGE const struct mercury_type_9 mercury_common_9[];

struct mercury_type_10 {
	MR_Word * f1;
	MR_Code * f2;
	MR_Integer f3;
};
MR_STATIC_LINKAGE const struct mercury_type_10 mercury_common_10[];
MR_decl_label10(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0, 106,3,4,5,9,12,17,15,19,22)
MR_decl_label10(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0, 20,24,29,30,27,32,33,34,26,56)
MR_decl_label10(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0, 57,58,61,60,63,66,67,69,72,73)
MR_decl_label10(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0, 2,4,6,11,12,10,9,7,8,16)
MR_decl_label10(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0, 22,24,17,18,43,44,47,49,50,51)
MR_decl_label10(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0, 52,55,53,75,45,78,79,80,81,101)
MR_decl_label10(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0, 102,104,106,97,98,124,125,126,127,128)
MR_decl_label10(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0, 129,130,131,134,135,138,136,139,144,142)
MR_decl_label10(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0, 146,147,140,152,156,158,159,155,161,150)
MR_decl_label10(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0, 181,183,184,121,122,188,189,196,201,202)
MR_decl_label6(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0, 200,192,193,205,207,191)
MR_decl_label10(hlds__make_hlds__add_type__add_ctor_field_name_8_0, 3,2,7,9,13,14,5,36,40,38)
MR_decl_label1(hlds__make_hlds__add_type__add_ctor_field_name_8_0, 49)
MR_decl_label4(hlds__make_hlds__add_type__add_ctor_field_names_12_0, 18,3,5,7)
MR_decl_label10(hlds__make_hlds__add_type__check_foreign_type_8_0, 2,3,5,4,7,97,20,33,46,6)
MR_decl_label6(hlds__make_hlds__add_type__check_foreign_type_visibility_2_0, 4,2,43,9,11,1)
MR_decl_label10(hlds__make_hlds__add_type__combine_status_3_0, 4,9,8,12,15,16,17,18,19,20)
MR_decl_label10(hlds__make_hlds__add_type__combine_status_3_0, 14,13,27,28,29,30,31,32,25,34)
MR_decl_label8(hlds__make_hlds__add_type__combine_status_3_0, 71,37,38,40,41,43,2,249)
MR_decl_label10(hlds__make_hlds__add_type__convert_type_defn_4_0, 3,6,10,16,20,7,8,5,29,33)
MR_decl_label3(hlds__make_hlds__add_type__convert_type_defn_4_0, 38,43,31)
MR_decl_label4(hlds__make_hlds__add_type__is_solver_type_is_inconsistent_2_0, 3,2,6,1)
MR_decl_label2(hlds__make_hlds__add_type__make_status_abstract_2_0, 2,7)
MR_decl_label10(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0, 174,3,11,10,15,13,12,20,18,17)
MR_decl_label10(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0, 25,23,22,30,28,27,36,35,9,43)
MR_decl_label1(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0, 1)
MR_decl_label10(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0, 3,27,2,10,8,7,15,13,12,20)
MR_decl_label2(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0, 18,1)
MR_decl_label10(hlds__make_hlds__add_type__process_type_defn_8_0, 2,3,4,5,6,7,8,9,12,13)
MR_decl_label10(hlds__make_hlds__add_type__process_type_defn_8_0, 14,16,15,18,19,20,22,23,21,26)
MR_decl_label10(hlds__make_hlds__add_type__process_type_defn_8_0, 29,30,31,24,11,34,33,35,39,40)
MR_decl_label3(hlds__make_hlds__add_type__process_type_defn_8_0, 41,42,37)
MR_def_extern_entry(hlds__make_hlds__add_type__make_status_abstract_2_0)
MR_def_extern_entry(hlds__make_hlds__add_type__combine_status_3_0)
MR_decl_static(fn__hlds__make_hlds__add_type__abstract_monotype_workaround_0_0)
MR_decl_static(hlds__make_hlds__add_type__combine_is_solver_type_4_0)
MR_decl_static(hlds__make_hlds__add_type__is_solver_type_is_inconsistent_2_0)
MR_decl_static(hlds__make_hlds__add_type__check_foreign_type_visibility_2_0)
MR_decl_static(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0)
MR_decl_static(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0)
MR_decl_static(hlds__make_hlds__add_type__convert_type_defn_4_0)
MR_def_extern_entry(hlds__make_hlds__add_type__module_add_type_defn_11_0)
MR_decl_static(hlds__make_hlds__add_type__check_foreign_type_8_0)
MR_decl_static(hlds__make_hlds__add_type__add_ctor_field_name_8_0)
MR_decl_static(hlds__make_hlds__add_type__add_ctor_field_names_12_0)
MR_def_extern_entry(hlds__make_hlds__add_type__process_type_defn_8_0)
MR_decl_static(hlds__make_hlds__add_type__add_ctor_7_0)
MR_decl_static(hlds__make_hlds__add_type__do_add_ctor_field_5_0)
MR_decl_static(fn__hlds__make_hlds__add_type__IntroducedFrom__func__ctors_add__753__1_1_0)
MR_def_extern_entry(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0)
MR_decl_static(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0)

static const struct mercury_type_0 mercury_common_0[2] =
{
{
1
},
{
0
},
};

static const struct mercury_type_1 mercury_common_1[36] =
{
{
4,
MR_string_const("optimize the wrapper away.)", 27)
},
{
4,
MR_string_const("(There\'s no performance penalty for this -- the compiler will", 61)
},
{
4,
MR_string_const("functor that has just one arg, instead of an equivalence type.", 62)
},
{
4,
MR_string_const("A better work-around is to use a \"wrapper\" type, with just one", 62)
},
{
4,
MR_string_const("type by putting the type definition in the interface section.", 61)
},
{
4,
MR_string_const("A quick work-around is to just export the type as a concrete,", 61)
},
{
4,
MR_string_const("Error: no", 9)
},
{
4,
MR_string_const("declaration for", 15)
},
{
4,
MR_string_const("on other back-ends, but none for this back-end.", 47)
},
{
4,
MR_string_const("There are representations for this type", 39)
},
{
4,
MR_string_const("Error: field", 12)
},
{
4,
MR_string_const("multiply defined.", 17)
},
{
4,
MR_string_const("Here is the previous definition of field", 40)
},
{
3,
MR_string_const(".", 1)
},
{
4,
MR_string_const("Error: the type", 15)
},
{
4,
MR_string_const("is not allowed to have user-defined equality", 44)
},
{
4,
MR_string_const("or comparison.", 14)
},
{
4,
MR_string_const("cannot have user-defined equality or comparison.", 48)
},
{
4,
MR_string_const("consists of a single zero-arity constructor", 43)
},
{
4,
MR_string_const("Discriminated unions whose body", 31)
},
{
4,
MR_string_const("In definition of type", 21)
},
{
3,
MR_string_const(":", 1)
},
{
4,
MR_string_const("error: all definitions of a type must have", 42)
},
{
4,
MR_string_const("consistent \140solver\' annotations", 31)
},
{
4,
MR_string_const("Error: type ", 12)
},
{
4,
MR_string_const("defined as foreign_type without being declared.", 47)
},
{
4,
MR_string_const("Error: pragma foreign_type ", 27)
},
{
4,
MR_string_const("must have the same visibility as the type declaration.", 54)
},
{
4,
MR_string_const("error: all definitions of a type", 32)
},
{
4,
MR_string_const("must have the same visibility", 29)
},
{
4,
MR_string_const("exported as abstract type.", 26)
},
{
4,
MR_string_const("with monomorphic definition,", 28)
},
{
4,
MR_string_const("polymorphic equivalence type,", 29)
},
{
4,
MR_string_const("Sorry, not implemented:", 23)
},
{
4,
MR_string_const("Error: constructor", 18)
},
{
4,
MR_string_const("for type", 8)
},
};

extern const MR_TypeCtorInfo_Struct mercury_data_list__type_ctor_info_list_1;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_data__type_ctor_info_hlds_ctor_field_defn_0;
extern const MR_TypeCtorInfo_Struct mercury_data_list__type_ctor_info_list_1;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_data__type_ctor_info_hlds_ctor_field_defn_0;
extern const MR_TypeCtorInfo_Struct mercury_data_term__type_ctor_info_var_1;
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_tvar_type_0;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_data__type_ctor_info_hlds_cons_defn_0;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_data__type_ctor_info_hlds_cons_defn_0;
extern const MR_TypeCtorInfo_Struct mercury_data_maybe__type_ctor_info_maybe_1;
extern const MR_TypeCtorInfo_Struct mercury_data_mdbcomp__prim_data__type_ctor_info_sym_name_0;
extern const MR_TypeCtorInfo_Struct mercury_data_mdbcomp__prim_data__type_ctor_info_sym_name_0;
static const struct mercury_type_2 mercury_common_2[40] =
{
{
{
MR_TAG_COMMON(3,1,0),
MR_tbmkword(0, 0)
}
},
{
{
MR_TAG_COMMON(3,1,1),
MR_TAG_COMMON(1,2,0)
}
},
{
{
MR_TAG_COMMON(3,1,2),
MR_TAG_COMMON(1,2,1)
}
},
{
{
MR_TAG_COMMON(3,1,3),
MR_TAG_COMMON(1,2,2)
}
},
{
{
MR_TAG_COMMON(3,1,4),
MR_TAG_COMMON(1,2,3)
}
},
{
{
MR_TAG_COMMON(3,1,5),
MR_TAG_COMMON(1,2,4)
}
},
{
{
MR_tbmkword(0, 1),
MR_tbmkword(0, 0)
}
},
{
{
MR_TAG_COMMON(3,1,8),
MR_TAG_COMMON(1,2,6)
}
},
{
{
MR_TAG_COMMON(3,1,9),
MR_TAG_COMMON(1,2,7)
}
},
{
{
MR_TAG_COMMON(0,4,0),
MR_tbmkword(0, 0)
}
},
{
{
MR_TAG_COMMON(1,5,0),
MR_tbmkword(0, 0)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(hlds__hlds_data, hlds_ctor_field_defn)
}
},
{
{
MR_TAG_COMMON(3,1,11),
MR_tbmkword(0, 0)
}
},
{
{
MR_TAG_COMMON(3,1,13),
MR_tbmkword(0, 0)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(hlds__hlds_data, hlds_ctor_field_defn)
}
},
{
{
MR_CTOR1_ADDR(term, var),
MR_CTOR0_ADDR(parse_tree__prog_data, tvar_type)
}
},
{
{
MR_TAG_COMMON(3,1,16),
MR_tbmkword(0, 0)
}
},
{
{
MR_TAG_COMMON(3,1,15),
MR_TAG_COMMON(1,2,16)
}
},
{
{
MR_TAG_COMMON(3,1,17),
MR_tbmkword(0, 0)
}
},
{
{
MR_TAG_COMMON(3,1,18),
MR_TAG_COMMON(1,2,18)
}
},
{
{
MR_TAG_COMMON(3,1,19),
MR_TAG_COMMON(1,2,19)
}
},
{
{
MR_TAG_COMMON(2,4,1),
MR_tbmkword(0, 0)
}
},
{
{
MR_TAG_COMMON(3,1,23),
MR_tbmkword(0, 0)
}
},
{
{
MR_TAG_COMMON(3,1,22),
MR_TAG_COMMON(1,2,22)
}
},
{
{
MR_tbmkword(0, 1),
MR_TAG_COMMON(1,2,23)
}
},
{
{
MR_TAG_COMMON(3,1,21),
MR_TAG_COMMON(1,2,24)
}
},
{
{
MR_TAG_COMMON(3,1,25),
MR_tbmkword(0, 0)
}
},
{
{
MR_TAG_COMMON(3,1,27),
MR_tbmkword(0, 0)
}
},
{
{
MR_TAG_COMMON(3,1,29),
MR_tbmkword(0, 0)
}
},
{
{
MR_TAG_COMMON(3,1,28),
MR_TAG_COMMON(1,2,28)
}
},
{
{
MR_tbmkword(0, 1),
MR_TAG_COMMON(1,2,29)
}
},
{
{
MR_TAG_COMMON(3,1,21),
MR_TAG_COMMON(1,2,30)
}
},
{
{
MR_TAG_COMMON(3,1,30),
MR_tbmkword(0, 0)
}
},
{
{
MR_TAG_COMMON(3,1,31),
MR_TAG_COMMON(1,2,32)
}
},
{
{
MR_TAG_COMMON(3,1,32),
MR_TAG_COMMON(1,2,33)
}
},
{
{
MR_TAG_COMMON(3,1,33),
MR_TAG_COMMON(1,2,34)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(hlds__hlds_data, hlds_cons_defn)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(hlds__hlds_data, hlds_cons_defn)
}
},
{
{
MR_CTOR1_ADDR(maybe, maybe),
MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name)
}
},
{
{
MR_CTOR1_ADDR(maybe, maybe),
MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name)
}
},
};

static const struct mercury_type_3 mercury_common_3[5] =
{
{
MR_string_const("C", 1)
},
{
MR_string_const("\140pragma foreign_type\'", 21)
},
{
MR_string_const("Erlang", 6)
},
{
MR_string_const("IL", 2)
},
{
MR_string_const("Java", 4)
},
};

static const struct mercury_type_4 mercury_common_4[3] =
{
{
MR_TAG_COMMON(1,2,8)
},
{
MR_TAG_COMMON(1,2,20)
},
{
MR_TAG_COMMON(1,2,35)
},
};

static const struct mercury_type_5 mercury_common_5[1] =
{
{
40,
1,
MR_TAG_COMMON(1,2,9)
},
};

extern const MR_TypeCtorInfo_Struct mercury_data_tree234__type_ctor_info_tree234_2;
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_cons_id_0;
static const struct mercury_type_6 mercury_common_6[3] =
{
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name),
MR_COMMON(2,14)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name),
MR_TAG_COMMON(0,2,11)
}
},
{
{
MR_CTOR_ADDR(tree234, tree234, 2),
MR_CTOR0_ADDR(parse_tree__prog_data, cons_id),
MR_COMMON(2,37)
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__hlds__make_hlds__add_type__add_ctor_field_name_8_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_string_0;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_data__type_ctor_info_hlds_ctor_field_defn_0;
extern const MR_TypeCtorInfo_Struct mercury_data_mdbcomp__prim_data__type_ctor_info_sym_name_0;
static const MR_UserClosureId
mercury_data__closure_layout__hlds__make_hlds__add_type__add_ctor_field_name_8_0_2;
static const struct mercury_type_7 mercury_common_7[2] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__hlds__make_hlds__add_type__add_ctor_field_name_8_0_1,
(MR_Word *) (MR_Integer) 0
},
5,
{
MR_STRING_CTOR_ADDR,
MR_CTOR0_ADDR(hlds__hlds_data, hlds_ctor_field_defn),
MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name),
MR_COMMON(6,0),
MR_COMMON(6,0)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__hlds__make_hlds__add_type__add_ctor_field_name_8_0_2,
(MR_Word *) (MR_Integer) 0
},
5,
{
MR_STRING_CTOR_ADDR,
MR_CTOR0_ADDR(hlds__hlds_data, hlds_ctor_field_defn),
MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name),
MR_COMMON(6,0),
MR_COMMON(6,0)
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_type_ctor_0;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_int_0;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_data__type_ctor_info_hlds_cons_defn_0;
static const MR_UserClosureId
mercury_data__closure_layout__f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_2;
static const struct mercury_type_8 mercury_common_8[2] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_1,
(MR_Word *) (MR_Integer) 0
},
7,
{
MR_CTOR0_ADDR(parse_tree__prog_data, type_ctor),
MR_STRING_CTOR_ADDR,
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(hlds__hlds_data, hlds_cons_defn),
MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name),
MR_COMMON(6,2),
MR_COMMON(6,2)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_2,
(MR_Word *) (MR_Integer) 0
},
7,
{
MR_CTOR0_ADDR(parse_tree__prog_data, type_ctor),
MR_STRING_CTOR_ADDR,
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(hlds__hlds_data, hlds_cons_defn),
MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name),
MR_COMMON(6,2),
MR_COMMON(6,2)
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_3;
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_constructor_arg_0;
static const struct mercury_type_9 mercury_common_9[1] =
{
{
(MR_Word *) &mercury_data__closure_layout__f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_3,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(parse_tree__prog_data, constructor_arg),
MR_COMMON(2,39)
},
};

static const struct mercury_type_10 mercury_common_10[1] =
{
{
MR_COMMON(9,0),
MR_ENTRY_AP(fn__hlds__make_hlds__add_type__IntroducedFrom__func__ctors_add__753__1_1_0),
0
},
};


static const MR_UserClosureId
mercury_data__closure_layout__f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_3 = {
{
MR_FUNCTION,
"hlds.make_hlds.add_type",
"hlds.make_hlds.add_type",
"lambda_add_type_m_753",
2,
0
},
"hlds.make_hlds.add_type",
"add_type.m",
753,
"d2;c43;"
};

static const MR_UserClosureId
mercury_data__closure_layout__f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_2 = {
{
MR_PREDICATE,
"hlds.make_hlds.add_type",
"hlds.make_hlds.add_type",
"add_ctor",
7,
0
},
"hlds.make_hlds.add_type",
"add_type.m",
749,
"d2;c39;"
};

static const MR_UserClosureId
mercury_data__closure_layout__f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_1 = {
{
MR_PREDICATE,
"hlds.make_hlds.add_type",
"hlds.make_hlds.add_type",
"add_ctor",
7,
0
},
"hlds.make_hlds.add_type",
"add_type.m",
746,
"d2;c37;"
};

static const MR_UserClosureId
mercury_data__closure_layout__hlds__make_hlds__add_type__add_ctor_field_name_8_0_2 = {
{
MR_PREDICATE,
"hlds.make_hlds.add_type",
"hlds.make_hlds.add_type",
"do_add_ctor_field",
5,
0
},
"hlds.make_hlds.add_type",
"add_type.m",
849,
"d1;c10;e;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__hlds__make_hlds__add_type__add_ctor_field_name_8_0_1 = {
{
MR_PREDICATE,
"hlds.make_hlds.add_type",
"hlds.make_hlds.add_type",
"do_add_ctor_field",
5,
0
},
"hlds.make_hlds.add_type",
"add_type.m",
849,
"d1;c10;e;c3;"
};



MR_BEGIN_MODULE(hlds__make_hlds__add_type_module0)
	MR_init_entry1(hlds__make_hlds__add_type__make_status_abstract_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__hlds__make_hlds__add_type__make_status_abstract_2_0);
	MR_init_label2(hlds__make_hlds__add_type__make_status_abstract_2_0,2,7)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'make_status_abstract'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__hlds__make_hlds__add_type__make_status_abstract_2_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,3)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__make_status_abstract_2_0_i2);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 5);
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__make_status_abstract_2_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__make_status_abstract_2_0_i7);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 1);
MR_def_label(hlds__make_hlds__add_type__make_status_abstract_2_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(libs__compiler_util__unexpected_2_0);

MR_BEGIN_MODULE(hlds__make_hlds__add_type_module1)
	MR_init_entry1(hlds__make_hlds__add_type__combine_status_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__hlds__make_hlds__add_type__combine_status_3_0);
	MR_init_label10(hlds__make_hlds__add_type__combine_status_3_0,4,9,8,12,15,16,17,18,19,20)
	MR_init_label10(hlds__make_hlds__add_type__combine_status_3_0,14,13,27,28,29,30,31,32,25,34)
	MR_init_label8(hlds__make_hlds__add_type__combine_status_3_0,71,37,38,40,41,43,2,249)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'combine_status'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__hlds__make_hlds__add_type__combine_status_3_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,5)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i4);
	}
	if (MR_LTAGS_TESTR(MR_r2,0,3)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i71);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 3);
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,1)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i8);
	}
	if (MR_PTAG_TESTR(MR_r2,2)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i9);
	}
	MR_r1 = MR_r2;
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_tbmkword(0, 1);
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,3)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i12);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 3);
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,7)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i13);
	}
	if (MR_LTAGS_TESTR(MR_r2,0,5)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i15);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 5);
	MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i14);
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,1)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i16);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 8);
	MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i14);
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,3)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i17);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 3);
	MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i14);
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,7)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i18);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 7);
	MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i14);
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,8)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i19);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 8);
	MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i14);
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i20);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 8);
	MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i14);
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,2)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i2);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 8);
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,8)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i249);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 7);
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,8)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i25);
	}
	if (MR_LTAGS_TESTR(MR_r2,0,5)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i27);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 5);
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,1)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i28);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 8);
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,3)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i29);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 3);
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,7)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i30);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 7);
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,8)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i31);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 8);
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i32);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 8);
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,2)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i2);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 8);
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i34);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i2);
	}
	if (MR_LTAGS_TESTR(MR_r2,0,5)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i37);
	}
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,71)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_tbmkword(0, 5);
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,37)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,1)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i38);
	}
	MR_r1 = (MR_Word) MR_TAG_COMMON(2,0,0);
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,38)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,3)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i40);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 3);
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,8)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i41);
	}
	MR_r1 = (MR_Word) MR_TAG_COMMON(2,0,1);
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,41)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i43);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,2)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__combine_status_3_0_i2);
	}
	MR_r1 = MR_r2;
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("add_type.m", 10);
	MR_r2 = (MR_Word) MR_string_const("unexpected status for type definition", 37);
	MR_np_tailcall_ent(libs__compiler_util__unexpected_2_0);
MR_def_label(hlds__make_hlds__add_type__combine_status_3_0,249)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(hlds__make_hlds__add_type_module2)
	MR_init_entry1(fn__hlds__make_hlds__add_type__abstract_monotype_workaround_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__hlds__make_hlds__add_type__abstract_monotype_workaround_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'abstract_monotype_workaround'/1 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__hlds__make_hlds__add_type__abstract_monotype_workaround_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_TAG_COMMON(1,2,5);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(hlds__make_hlds__add_type_module3)
	MR_init_entry1(hlds__make_hlds__add_type__combine_is_solver_type_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__hlds__make_hlds__add_type__combine_is_solver_type_4_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'combine_is_solver_type'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(hlds__make_hlds__add_type__combine_is_solver_type_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(hlds__make_hlds__add_type_module4)
	MR_init_entry1(hlds__make_hlds__add_type__is_solver_type_is_inconsistent_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__hlds__make_hlds__add_type__is_solver_type_is_inconsistent_2_0);
	MR_init_label4(hlds__make_hlds__add_type__is_solver_type_is_inconsistent_2_0,3,2,6,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'is_solver_type_is_inconsistent'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(hlds__make_hlds__add_type__is_solver_type_is_inconsistent_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r1,3,1)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__is_solver_type_is_inconsistent_2_0_i3);
	}
	MR_r3 = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = MR_tfield(3, MR_r3, 1);
	MR_GOTO_LAB(hlds__make_hlds__add_type__is_solver_type_is_inconsistent_2_0_i2);
MR_def_label(hlds__make_hlds__add_type__is_solver_type_is_inconsistent_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r1,3,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__is_solver_type_is_inconsistent_2_0_i1);
	}
	MR_r1 = MR_r2;
	MR_r2 = (MR_Integer) 1;
MR_def_label(hlds__make_hlds__add_type__is_solver_type_is_inconsistent_2_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r1,3,1)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__is_solver_type_is_inconsistent_2_0_i6);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(3, MR_r1, 1);
	MR_r1 = (MR_r2 != MR_tempr1);
	MR_proceed();
	}
MR_def_label(hlds__make_hlds__add_type__is_solver_type_is_inconsistent_2_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r1,3,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__is_solver_type_is_inconsistent_2_0_i1);
	}
	MR_r1 = ((MR_Integer) MR_r2 != (MR_Integer) 1);
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__is_solver_type_is_inconsistent_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__hlds__hlds_pred__status_is_exported_to_non_submodules_1_0);

MR_BEGIN_MODULE(hlds__make_hlds__add_type_module5)
	MR_init_entry1(hlds__make_hlds__add_type__check_foreign_type_visibility_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__hlds__make_hlds__add_type__check_foreign_type_visibility_2_0);
	MR_init_label6(hlds__make_hlds__add_type__check_foreign_type_visibility_2_0,4,2,43,9,11,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'check_foreign_type_visibility'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(hlds__make_hlds__add_type__check_foreign_type_visibility_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,5)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__check_foreign_type_visibility_2_0_i2);
	}
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__hlds__hlds_pred__status_is_exported_to_non_submodules_1_0,
		hlds__make_hlds__add_type__check_foreign_type_visibility_2_0_i4);
MR_def_label(hlds__make_hlds__add_type__check_foreign_type_visibility_2_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__check_foreign_type_visibility_2_0_i1);
	}
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(2);
MR_def_label(hlds__make_hlds__add_type__check_foreign_type_visibility_2_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,3)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__check_foreign_type_visibility_2_0_i43);
	}
	MR_r1 = ((MR_Integer) MR_r2 == (MR_Integer) MR_tbmkword(0, 3));
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__check_foreign_type_visibility_2_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_np_call_localret_ent(fn__hlds__hlds_pred__status_is_exported_to_non_submodules_1_0,
		hlds__make_hlds__add_type__check_foreign_type_visibility_2_0_i9);
MR_def_label(hlds__make_hlds__add_type__check_foreign_type_visibility_2_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__check_foreign_type_visibility_2_0_i1);
	}
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(fn__hlds__hlds_pred__status_is_exported_to_non_submodules_1_0,
		hlds__make_hlds__add_type__check_foreign_type_visibility_2_0_i11);
MR_def_label(hlds__make_hlds__add_type__check_foreign_type_visibility_2_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__check_foreign_type_visibility_2_0_i1);
	}
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(2);
MR_def_label(hlds__make_hlds__add_type__check_foreign_type_visibility_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_decr_sp_and_return(2);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(hlds__make_hlds__add_type_module6)
	MR_init_entry1(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0);
	MR_init_label10(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0,3,27,2,10,8,7,15,13,12,20)
	MR_init_label2(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0,18,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'merge_foreign_type_bodies_2'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_tfield(0, MR_r1, 0);
	if (MR_LTAGS_TESTR(MR_r3,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0_i3);
	}
	MR_r3 = MR_tfield(0, MR_r2, 0);
	if (MR_LTAGS_TESTR(MR_r3,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0_i27);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r8 = MR_tempr1;
	MR_r1 = MR_tfield(0, MR_r1, 1);
	MR_tempr2 = MR_r2;
	MR_r9 = MR_tempr2;
	MR_r2 = MR_tfield(0, MR_tempr1, 2);
	MR_r3 = MR_tfield(0, MR_tempr1, 3);
	MR_r4 = MR_tfield(0, MR_tempr2, 1);
	MR_r5 = MR_tfield(0, MR_tempr2, 2);
	MR_r6 = MR_tfield(0, MR_tempr2, 3);
	MR_r7 = (MR_Word) MR_tbmkword(0, 0);
	MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0_i2);
	}
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(0, MR_r2, 0);
	if (MR_LTAGS_TESTR(MR_tempr1,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0_i1);
	}
	}
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_tfield(0, MR_r1, 1);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tfield(0, MR_tempr1, 2);
	MR_tempr3 = MR_r3;
	MR_r3 = MR_tfield(0, MR_tempr1, 3);
	MR_r4 = MR_tfield(0, MR_tempr2, 1);
	MR_r5 = MR_tfield(0, MR_tempr2, 2);
	MR_r6 = MR_tfield(0, MR_tempr2, 3);
	MR_r7 = MR_tempr3;
	}
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0_i8);
	}
	if (MR_LTAGS_TESTR(MR_r4,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0_i10);
	}
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_r3 = MR_r5;
	MR_r4 = MR_r6;
	MR_r5 = MR_r7;
	MR_r6 = (MR_Word) MR_tbmkword(0, 0);
	MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0_i7);
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_r3 = MR_r5;
	MR_r8 = MR_r4;
	MR_r4 = MR_r6;
	MR_r5 = MR_r7;
	MR_r6 = MR_r8;
	MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0_i7);
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r4,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_r3 = MR_r5;
	MR_r4 = MR_r6;
	MR_r5 = MR_r7;
	MR_r6 = MR_tempr1;
	}
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0_i13);
	}
	if (MR_LTAGS_TESTR(MR_r3,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0_i15);
	}
	MR_r1 = MR_r2;
	MR_r2 = MR_r4;
	MR_r3 = MR_r5;
	MR_r4 = MR_r6;
	MR_r5 = (MR_Word) MR_tbmkword(0, 0);
	MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0_i12);
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_r2 = MR_r4;
	MR_r7 = MR_r3;
	MR_r3 = MR_r5;
	MR_r4 = MR_r6;
	MR_r5 = MR_r7;
	MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0_i12);
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r3,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = MR_r4;
	MR_r3 = MR_r5;
	MR_r4 = MR_r6;
	MR_r5 = MR_tempr1;
	}
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0_i18);
	}
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0_i20);
	}
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 4);
	MR_tfield(0, MR_r2, 0) = MR_r3;
	MR_tfield(0, MR_r2, 1) = MR_r4;
	MR_tfield(0, MR_r2, 2) = MR_r5;
	MR_tfield(0, MR_r2, 3) = (MR_Word) MR_tbmkword(0, 0);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = MR_r3;
	MR_tfield(0, MR_tempr1, 1) = MR_r4;
	MR_tfield(0, MR_tempr1, 2) = MR_r5;
	MR_tfield(0, MR_tempr1, 3) = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r1 = MR_TRUE;
	MR_proceed();
	}
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0_i1);
	}
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 4);
	MR_tfield(0, MR_r2, 0) = MR_r3;
	MR_tfield(0, MR_r2, 1) = MR_r4;
	MR_tfield(0, MR_r2, 2) = MR_r5;
	MR_tfield(0, MR_r2, 3) = MR_r1;
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(backend_libs__foreign__have_foreign_type_for_backend_3_0);

MR_BEGIN_MODULE(hlds__make_hlds__add_type_module7)
	MR_init_entry1(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0);
	MR_init_label10(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,174,3,11,10,15,13,12,20,18,17)
	MR_init_label10(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,25,23,22,30,28,27,36,35,9,43)
	MR_init_label1(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'merge_foreign_type_bodies'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,174)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	while (1) {
	if (MR_PTAG_TESTR(MR_r3,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i3);
	}
	if (MR_PTAG_TESTR(MR_r4,2)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_r3 = MR_r4;
	MR_r4 = MR_tempr1;
	MR_succip_word = MR_sv(4);
	continue;
	}
	break; } /* end while */
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r3,2)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i1);
	}
	if (MR_PTAG_TESTR(MR_r4,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i9);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_r4;
	MR_r5 = MR_tfield(0, MR_tempr2, 7);
	if (MR_LTAGS_TESTR(MR_r5,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i11);
	}
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_tempr2;
	MR_tempr1 = MR_tfield(2, MR_r3, 0);
	MR_r10 = MR_tempr1;
	MR_r2 = MR_tfield(0, MR_tempr1, 0);
	MR_r3 = MR_tfield(0, MR_tempr1, 1);
	MR_r4 = MR_tfield(0, MR_tempr1, 2);
	MR_r5 = MR_tfield(0, MR_tempr1, 3);
	MR_r6 = (MR_Word) MR_tbmkword(0, 0);
	MR_r7 = (MR_Word) MR_tbmkword(0, 0);
	MR_r8 = (MR_Word) MR_tbmkword(0, 0);
	MR_r9 = (MR_Word) MR_tbmkword(0, 0);
	MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i10);
	}
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r4;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_tfield(2, MR_r3, 0);
	MR_r2 = MR_tfield(0, MR_tempr1, 0);
	MR_r3 = MR_tfield(0, MR_tempr1, 1);
	MR_r4 = MR_tfield(0, MR_tempr1, 2);
	MR_tempr2 = MR_r5;
	MR_r5 = MR_tfield(0, MR_tempr1, 3);
	MR_tempr1 = MR_tfield(1, MR_tempr2, 0);
	MR_r6 = MR_tfield(0, MR_tempr1, 0);
	MR_r7 = MR_tfield(0, MR_tempr1, 1);
	MR_r8 = MR_tfield(0, MR_tempr1, 2);
	MR_r9 = MR_tfield(0, MR_tempr1, 3);
	}
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i13);
	}
	if (MR_LTAGS_TESTR(MR_r6,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i15);
	}
	MR_r2 = MR_r3;
	MR_r3 = MR_r4;
	MR_r4 = MR_r5;
	MR_r5 = MR_r7;
	MR_r6 = MR_r8;
	MR_r7 = MR_r9;
	MR_r8 = (MR_Word) MR_tbmkword(0, 0);
	MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i12);
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_r3;
	MR_r3 = MR_r4;
	MR_r4 = MR_r5;
	MR_r5 = MR_r7;
	MR_r10 = MR_r6;
	MR_r6 = MR_r8;
	MR_r7 = MR_r9;
	MR_r8 = MR_r10;
	MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i12);
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r6,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_r3;
	MR_r3 = MR_r4;
	MR_r4 = MR_r5;
	MR_r5 = MR_r7;
	MR_r6 = MR_r8;
	MR_r7 = MR_r9;
	MR_r8 = MR_tempr1;
	}
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i18);
	}
	if (MR_LTAGS_TESTR(MR_r5,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i20);
	}
	MR_r2 = MR_r3;
	MR_r3 = MR_r4;
	MR_r4 = MR_r6;
	MR_r5 = MR_r7;
	MR_r6 = MR_r8;
	MR_r7 = (MR_Word) MR_tbmkword(0, 0);
	MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i17);
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_r3;
	MR_r3 = MR_r4;
	MR_r4 = MR_r6;
	MR_r9 = MR_r5;
	MR_r5 = MR_r7;
	MR_r6 = MR_r8;
	MR_r7 = MR_r9;
	MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i17);
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r5,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_r3;
	MR_r3 = MR_r4;
	MR_r4 = MR_r6;
	MR_r5 = MR_r7;
	MR_r6 = MR_r8;
	MR_r7 = MR_tempr1;
	}
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i23);
	}
	if (MR_LTAGS_TESTR(MR_r4,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i25);
	}
	MR_r2 = MR_r3;
	MR_r3 = MR_r5;
	MR_r4 = MR_r6;
	MR_r5 = MR_r7;
	MR_r6 = (MR_Word) MR_tbmkword(0, 0);
	MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i22);
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_r3;
	MR_r3 = MR_r5;
	MR_r8 = MR_r4;
	MR_r4 = MR_r6;
	MR_r5 = MR_r7;
	MR_r6 = MR_r8;
	MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i22);
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r4,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_r3;
	MR_r3 = MR_r5;
	MR_r4 = MR_r6;
	MR_r5 = MR_r7;
	MR_r6 = MR_tempr1;
	}
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i28);
	}
	if (MR_LTAGS_TESTR(MR_r3,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i30);
	}
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 4);
	MR_tfield(0, MR_r2, 0) = MR_r4;
	MR_tfield(0, MR_r2, 1) = MR_r5;
	MR_tfield(0, MR_r2, 2) = MR_r6;
	MR_tfield(0, MR_r2, 3) = (MR_Word) MR_tbmkword(0, 0);
	MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i27);
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 4);
	MR_tfield(0, MR_r2, 0) = MR_r4;
	MR_tfield(0, MR_r2, 1) = MR_r5;
	MR_tfield(0, MR_r2, 2) = MR_r6;
	MR_tfield(0, MR_r2, 3) = MR_r3;
	MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i27);
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r3,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = MR_r4;
	MR_tfield(0, MR_tempr1, 1) = MR_r5;
	MR_tfield(0, MR_tempr1, 2) = MR_r6;
	MR_tfield(0, MR_tempr1, 3) = MR_r2;
	MR_r2 = MR_tempr1;
	}
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r2;
	MR_np_call_localret_ent(backend_libs__foreign__have_foreign_type_for_backend_3_0,
		hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i36);
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (((MR_Integer) 1 != (MR_Integer) MR_r1)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i35);
	}
	if (MR_INT_NE(MR_sv(1),0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i35);
	}
	MR_tag_alloc_heap(MR_r2, 2, (MR_Integer) 1);
	MR_tfield(2, MR_r2, 0) = MR_sv(3);
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(4);
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 1);
	MR_tfield(1, MR_tempr1, 0) = MR_sv(3);
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 8);
	MR_tempr2 = MR_sv(2);
	MR_tfield(0, MR_r2, 0) = MR_tfield(0, MR_tempr2, 0);
	MR_tfield(0, MR_r2, 1) = MR_tfield(0, MR_tempr2, 1);
	MR_tfield(0, MR_r2, 2) = MR_tfield(0, MR_tempr2, 2);
	MR_tfield(0, MR_r2, 3) = MR_tfield(0, MR_tempr2, 3);
	MR_tfield(0, MR_r2, 4) = MR_tfield(0, MR_tempr2, 4);
	MR_tfield(0, MR_r2, 5) = MR_tfield(0, MR_tempr2, 5);
	MR_tfield(0, MR_r2, 6) = MR_tfield(0, MR_tempr2, 6);
	MR_tfield(0, MR_r2, 7) = MR_tempr1;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(4);
	}
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r4,2)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i1);
	}
	MR_r1 = MR_tfield(2, MR_r3, 0);
	MR_r2 = MR_tfield(2, MR_r4, 0);
	MR_np_call_localret_ent(hlds__make_hlds__add_type__merge_foreign_type_bodies_2_3_0,
		hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i43);
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 2, (MR_Integer) 1);
	MR_tfield(2, MR_tempr1, 0) = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(4);
	}
MR_def_label(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_decr_sp_and_return(4);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(hlds__make_tags__assign_constructor_tags_8_0);
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_cons_id_0;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_data__type_ctor_info_cons_tag_0;
MR_decl_entry(map__to_assoc_list_2_0);

MR_BEGIN_MODULE(hlds__make_hlds__add_type_module8)
	MR_init_entry1(hlds__make_hlds__add_type__convert_type_defn_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__hlds__make_hlds__add_type__convert_type_defn_4_0);
	MR_init_label10(hlds__make_hlds__add_type__convert_type_defn_4_0,3,6,10,16,20,7,8,5,29,33)
	MR_init_label3(hlds__make_hlds__add_type__convert_type_defn_4_0,38,43,31)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'convert_type_defn'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(hlds__make_hlds__add_type__convert_type_defn_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__convert_type_defn_4_0_i3);
	}
	MR_tag_alloc_heap(MR_r2, 3, (MR_Integer) 2);
	MR_tfield(3, MR_r2, 0) = (MR_Integer) 1;
	MR_tfield(3, MR_r2, 1) = MR_tfield(2, MR_r1, 0);
	MR_r1 = MR_r2;
	MR_proceed();
MR_def_label(hlds__make_hlds__add_type__convert_type_defn_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__convert_type_defn_4_0_i5);
	}
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	MR_sv(1) = MR_tfield(0, MR_r1, 0);
	MR_sv(2) = MR_tfield(0, MR_r1, 1);
	MR_sv(3) = (MR_Integer) 1;
	MR_r1 = MR_sv(1);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_sv(2);
	MR_tempr2 = MR_r3;
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(3);
	MR_r5 = MR_tempr2;
	}
	MR_np_call_localret_ent(hlds__make_tags__assign_constructor_tags_8_0,
		hlds__make_hlds__add_type__convert_type_defn_4_0_i6);
MR_def_label(hlds__make_hlds__add_type__convert_type_defn_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r2,1)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__convert_type_defn_4_0_i8);
	}
	MR_sv(4) = MR_r1;
	MR_sv(5) = MR_r2;
	MR_sv(6) = MR_r3;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, cons_id);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_data, cons_tag);
	MR_r3 = MR_sv(4);
	MR_np_call_localret_ent(map__to_assoc_list_2_0,
		hlds__make_hlds__add_type__convert_type_defn_4_0_i10);
MR_def_label(hlds__make_hlds__add_type__convert_type_defn_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_r1,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__convert_type_defn_4_0_i7);
	}
	MR_r2 = MR_tfield(1, MR_r1, 1);
	if (MR_LTAGS_TEST(MR_r2,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__convert_type_defn_4_0_i7);
	}
	MR_r3 = MR_tfield(1, MR_r2, 1);
	if (MR_LTAGS_TESTR(MR_r3,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__convert_type_defn_4_0_i7);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tempr1 = MR_tfield(1, MR_r1, 0);
	MR_tempr2 = MR_tfield(0, MR_tempr1, 0);
	MR_r3 = MR_tempr2;
	if (MR_PTAG_TESTR(MR_tempr2,1)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__convert_type_defn_4_0_i7);
	}
	MR_tempr3 = MR_tfield(1, MR_r2, 0);
	MR_r6 = MR_tempr3;
	MR_tempr4 = MR_tfield(0, MR_tempr3, 0);
	MR_r5 = MR_tempr4;
	if (MR_PTAG_TESTR(MR_tempr4,1)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__convert_type_defn_4_0_i7);
	}
	MR_r2 = MR_tfield(1, MR_tempr4, 1);
	MR_r7 = MR_tfield(1, MR_tempr2, 1);
	MR_r8 = MR_tfield(0, MR_tempr3, 1);
	MR_r6 = MR_tfield(0, MR_tempr1, 1);
	if (MR_INT_NE(MR_r2,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__convert_type_defn_4_0_i16);
	}
	if (MR_INT_LE(MR_r7,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__convert_type_defn_4_0_i16);
	}
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 4);
	MR_tfield(1, MR_r2, 0) = MR_tempr2;
	MR_tfield(1, MR_r2, 1) = MR_r6;
	MR_tfield(1, MR_r2, 2) = MR_tempr4;
	MR_tfield(1, MR_r2, 3) = MR_r8;
	MR_tag_alloc_heap(MR_r1, 0, (MR_Integer) 8);
	MR_tfield(0, MR_r1, 0) = MR_sv(1);
	MR_tfield(0, MR_r1, 1) = MR_sv(4);
	MR_tfield(0, MR_r1, 2) = MR_r2;
	MR_tfield(0, MR_r1, 3) = MR_sv(6);
	MR_tfield(0, MR_r1, 4) = MR_sv(2);
	MR_tfield(0, MR_r1, 5) = MR_sv(3);
	MR_tfield(0, MR_r1, 6) = MR_sv(5);
	MR_tfield(0, MR_r1, 7) = (MR_Word) MR_tbmkword(0, 0);
	MR_decr_sp_and_return(7);
	}
MR_def_label(hlds__make_hlds__add_type__convert_type_defn_4_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r7,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__convert_type_defn_4_0_i20);
	}
	if (MR_INT_LE(MR_r2,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__convert_type_defn_4_0_i20);
	}
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 4);
	MR_tfield(1, MR_r2, 0) = MR_r5;
	MR_tfield(1, MR_r2, 1) = MR_r8;
	MR_tfield(1, MR_r2, 2) = MR_r3;
	MR_tfield(1, MR_r2, 3) = MR_r6;
	MR_tag_alloc_heap(MR_r1, 0, (MR_Integer) 8);
	MR_tfield(0, MR_r1, 0) = MR_sv(1);
	MR_tfield(0, MR_r1, 1) = MR_sv(4);
	MR_tfield(0, MR_r1, 2) = MR_r2;
	MR_tfield(0, MR_r1, 3) = MR_sv(6);
	MR_tfield(0, MR_r1, 4) = MR_sv(2);
	MR_tfield(0, MR_r1, 5) = MR_sv(3);
	MR_tfield(0, MR_r1, 6) = MR_sv(5);
	MR_tfield(0, MR_r1, 7) = (MR_Word) MR_tbmkword(0, 0);
	MR_decr_sp_and_return(7);
MR_def_label(hlds__make_hlds__add_type__convert_type_defn_4_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r1, 0, (MR_Integer) 8);
	MR_tfield(0, MR_r1, 0) = MR_sv(1);
	MR_tfield(0, MR_r1, 1) = MR_sv(4);
	MR_tfield(0, MR_r1, 2) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_r1, 3) = MR_sv(6);
	MR_tfield(0, MR_r1, 4) = MR_sv(2);
	MR_tfield(0, MR_r1, 5) = MR_sv(3);
	MR_tfield(0, MR_r1, 6) = MR_sv(5);
	MR_tfield(0, MR_r1, 7) = (MR_Word) MR_tbmkword(0, 0);
	MR_decr_sp_and_return(7);
MR_def_label(hlds__make_hlds__add_type__convert_type_defn_4_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_r2 = MR_sv(5);
	MR_r3 = MR_sv(6);
MR_def_label(hlds__make_hlds__add_type__convert_type_defn_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 8);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 1) = MR_r1;
	MR_tfield(0, MR_tempr1, 2) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr1, 3) = MR_r3;
	MR_tfield(0, MR_tempr1, 4) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 5) = MR_sv(3);
	MR_tfield(0, MR_tempr1, 6) = MR_r2;
	MR_tfield(0, MR_tempr1, 7) = (MR_Word) MR_tbmkword(0, 0);
	MR_r1 = MR_tempr1;
	MR_decr_sp_and_return(7);
	}
MR_def_label(hlds__make_hlds__add_type__convert_type_defn_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__convert_type_defn_4_0_i29);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 1);
	MR_tfield(1, MR_tempr1, 0) = MR_tfield(1, MR_r1, 0);
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
MR_def_label(hlds__make_hlds__add_type__convert_type_defn_4_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r1,3,1)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__convert_type_defn_4_0_i31);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr1 = MR_tfield(3, MR_r1, 1);
	MR_r6 = MR_tempr1;
	if (MR_PTAG_TESTR(MR_tempr1,1)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__convert_type_defn_4_0_i33);
	}
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 3);
	MR_tfield(0, MR_tempr2, 0) = MR_tfield(1, MR_tempr1, 0);
	MR_tfield(0, MR_tempr2, 1) = MR_tfield(3, MR_r1, 2);
	MR_tfield(0, MR_tempr2, 2) = MR_tfield(3, MR_r1, 3);
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 1);
	MR_tfield(1, MR_tempr3, 0) = MR_tempr2;
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr2, 0) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr2, 1) = MR_tempr3;
	MR_tfield(0, MR_tempr2, 2) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr2, 3) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_r1, 2, (MR_Integer) 1);
	MR_tfield(2, MR_r1, 0) = MR_tempr2;
	MR_proceed();
	}
MR_def_label(hlds__make_hlds__add_type__convert_type_defn_4_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r6,3)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__convert_type_defn_4_0_i38);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 3);
	MR_tfield(0, MR_tempr1, 1) = MR_tfield(3, MR_r1, 2);
	MR_tfield(0, MR_tempr1, 2) = MR_tfield(3, MR_r1, 3);
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 1);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr1, 3) = MR_tempr2;
	MR_tag_alloc_heap(MR_r1, 2, (MR_Integer) 1);
	MR_tfield(2, MR_r1, 0) = MR_tempr1;
	MR_proceed();
	}
MR_def_label(hlds__make_hlds__add_type__convert_type_defn_4_0,38)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r6,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__convert_type_defn_4_0_i43);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 3);
	MR_tfield(0, MR_tempr1, 0) = MR_tfield(0, MR_r6, 0);
	MR_tfield(0, MR_tempr1, 1) = MR_tfield(3, MR_r1, 2);
	MR_tfield(0, MR_tempr1, 2) = MR_tfield(3, MR_r1, 3);
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 1);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = MR_tempr2;
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr1, 3) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_r1, 2, (MR_Integer) 1);
	MR_tfield(2, MR_r1, 0) = MR_tempr1;
	MR_proceed();
	}
MR_def_label(hlds__make_hlds__add_type__convert_type_defn_4_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 3);
	MR_tfield(0, MR_tempr1, 0) = MR_tfield(2, MR_r6, 0);
	MR_tfield(0, MR_tempr1, 1) = MR_tfield(3, MR_r1, 2);
	MR_tfield(0, MR_tempr1, 2) = MR_tfield(3, MR_r1, 3);
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 1);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 4);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr1, 2) = MR_tempr2;
	MR_tfield(0, MR_tempr1, 3) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_r1, 2, (MR_Integer) 1);
	MR_tfield(2, MR_r1, 0) = MR_tempr1;
	MR_proceed();
	}
MR_def_label(hlds__make_hlds__add_type__convert_type_defn_4_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 3);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_tfield(3, MR_r1, 1);
	MR_tfield(3, MR_tempr1, 2) = MR_tfield(3, MR_r1, 2);
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(hlds__make_hlds__add_type_module9)
	MR_init_entry1(hlds__make_hlds__add_type__module_add_type_defn_11_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__hlds__make_hlds__add_type__module_add_type_defn_11_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'module_add_type_defn'/11 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__hlds__make_hlds__add_type__module_add_type_defn_11_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r5 = MR_r6;
	MR_r6 = MR_r7;
	MR_r7 = MR_r8;
	MR_r8 = MR_r9;
	MR_np_tailcall_ent(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(hlds__hlds_module__module_info_get_globals_2_0);
MR_decl_entry(libs__globals__get_target_2_0);

MR_BEGIN_MODULE(hlds__make_hlds__add_type_module10)
	MR_init_entry1(hlds__make_hlds__add_type__check_foreign_type_8_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__hlds__make_hlds__add_type__check_foreign_type_8_0);
	MR_init_label10(hlds__make_hlds__add_type__check_foreign_type_8_0,2,3,5,4,7,97,20,33,46,6)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'check_foreign_type'/8 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(hlds__make_hlds__add_type__check_foreign_type_8_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_tfield(0, MR_r1, 0);
	MR_sv(4) = MR_tfield(0, MR_r1, 1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r4;
	MR_sv(5) = MR_tempr1;
	MR_sv(6) = MR_r5;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(hlds__hlds_module__module_info_get_globals_2_0,
		hlds__make_hlds__add_type__check_foreign_type_8_0_i2);
MR_def_label(hlds__make_hlds__add_type__check_foreign_type_8_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(libs__globals__get_target_2_0,
		hlds__make_hlds__add_type__check_foreign_type_8_0_i3);
MR_def_label(hlds__make_hlds__add_type__check_foreign_type_8_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(backend_libs__foreign__have_foreign_type_for_backend_3_0,
		hlds__make_hlds__add_type__check_foreign_type_8_0_i5);
MR_def_label(hlds__make_hlds__add_type__check_foreign_type_8_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (((MR_Integer) 1 != (MR_Integer) MR_r1)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__check_foreign_type_8_0_i4);
	}
	MR_r1 = (MR_Integer) 0;
	MR_r2 = MR_sv(5);
	MR_r3 = MR_sv(6);
	MR_decr_sp_and_return(7);
MR_def_label(hlds__make_hlds__add_type__check_foreign_type_8_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(1),3)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__check_foreign_type_8_0_i7);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6, MR_tempr7;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(3);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(4);
	MR_tag_alloc_heap(MR_tempr2, 3, (MR_Integer) 2);
	MR_r5 = MR_tempr2;
	MR_tfield(3, MR_tempr2, 0) = (MR_Integer) 6;
	MR_tfield(3, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 2);
	MR_r4 = MR_tempr3;
	MR_tfield(1, MR_tempr3, 0) = MR_tempr2;
	MR_tfield(1, MR_tempr3, 1) = (MR_Word) MR_TAG_COMMON(1,2,6);
	MR_tag_alloc_heap(MR_tempr4, 1, (MR_Integer) 2);
	MR_r5 = MR_tempr4;
	MR_tfield(1, MR_tempr4, 0) = (MR_Word) MR_TAG_COMMON(3,1,7);
	MR_tfield(1, MR_tempr4, 1) = MR_tempr3;
	MR_tag_alloc_heap(MR_tempr5, 1, (MR_Integer) 2);
	MR_r4 = MR_tempr5;
	MR_tfield(1, MR_tempr5, 0) = (MR_Word) MR_TAG_COMMON(1,3,1);
	MR_tfield(1, MR_tempr5, 1) = MR_tempr4;
	MR_tag_alloc_heap(MR_tempr6, 1, (MR_Integer) 2);
	MR_r5 = MR_tempr6;
	MR_tfield(1, MR_tempr6, 0) = (MR_Word) MR_TAG_COMMON(1,3,0);
	MR_tfield(1, MR_tempr6, 1) = MR_tempr5;
	MR_tag_alloc_heap(MR_tempr7, 1, (MR_Integer) 2);
	MR_r4 = MR_tempr7;
	MR_tfield(1, MR_tempr7, 0) = (MR_Word) MR_TAG_COMMON(3,1,6);
	MR_tfield(1, MR_tempr7, 1) = MR_tempr6;
	MR_r1 = MR_tempr7;
	MR_r2 = MR_sv(5);
	MR_GOTO_LAB(hlds__make_hlds__add_type__check_foreign_type_8_0_i6);
	}
MR_def_label(hlds__make_hlds__add_type__check_foreign_type_8_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(1),0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__check_foreign_type_8_0_i20);
	}
MR_def_label(hlds__make_hlds__add_type__check_foreign_type_8_0,97)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6, MR_tempr7;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(3);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(4);
	MR_tag_alloc_heap(MR_tempr2, 3, (MR_Integer) 2);
	MR_r5 = MR_tempr2;
	MR_tfield(3, MR_tempr2, 0) = (MR_Integer) 6;
	MR_tfield(3, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 2);
	MR_r4 = MR_tempr3;
	MR_tfield(1, MR_tempr3, 0) = MR_tempr2;
	MR_tfield(1, MR_tempr3, 1) = (MR_Word) MR_TAG_COMMON(1,2,6);
	MR_tag_alloc_heap(MR_tempr4, 1, (MR_Integer) 2);
	MR_r5 = MR_tempr4;
	MR_tfield(1, MR_tempr4, 0) = (MR_Word) MR_TAG_COMMON(3,1,7);
	MR_tfield(1, MR_tempr4, 1) = MR_tempr3;
	MR_tag_alloc_heap(MR_tempr5, 1, (MR_Integer) 2);
	MR_r4 = MR_tempr5;
	MR_tfield(1, MR_tempr5, 0) = (MR_Word) MR_TAG_COMMON(1,3,1);
	MR_tfield(1, MR_tempr5, 1) = MR_tempr4;
	MR_tag_alloc_heap(MR_tempr6, 1, (MR_Integer) 2);
	MR_r5 = MR_tempr6;
	MR_tfield(1, MR_tempr6, 0) = (MR_Word) MR_TAG_COMMON(1,3,0);
	MR_tfield(1, MR_tempr6, 1) = MR_tempr5;
	MR_tag_alloc_heap(MR_tempr7, 1, (MR_Integer) 2);
	MR_r4 = MR_tempr7;
	MR_tfield(1, MR_tempr7, 0) = (MR_Word) MR_TAG_COMMON(3,1,6);
	MR_tfield(1, MR_tempr7, 1) = MR_tempr6;
	MR_r1 = MR_tempr7;
	MR_r2 = MR_sv(5);
	MR_GOTO_LAB(hlds__make_hlds__add_type__check_foreign_type_8_0_i6);
	}
MR_def_label(hlds__make_hlds__add_type__check_foreign_type_8_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(1),5)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__check_foreign_type_8_0_i33);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6, MR_tempr7;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(3);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(4);
	MR_tag_alloc_heap(MR_tempr2, 3, (MR_Integer) 2);
	MR_r5 = MR_tempr2;
	MR_tfield(3, MR_tempr2, 0) = (MR_Integer) 6;
	MR_tfield(3, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 2);
	MR_r4 = MR_tempr3;
	MR_tfield(1, MR_tempr3, 0) = MR_tempr2;
	MR_tfield(1, MR_tempr3, 1) = (MR_Word) MR_TAG_COMMON(1,2,6);
	MR_tag_alloc_heap(MR_tempr4, 1, (MR_Integer) 2);
	MR_r5 = MR_tempr4;
	MR_tfield(1, MR_tempr4, 0) = (MR_Word) MR_TAG_COMMON(3,1,7);
	MR_tfield(1, MR_tempr4, 1) = MR_tempr3;
	MR_tag_alloc_heap(MR_tempr5, 1, (MR_Integer) 2);
	MR_r4 = MR_tempr5;
	MR_tfield(1, MR_tempr5, 0) = (MR_Word) MR_TAG_COMMON(1,3,1);
	MR_tfield(1, MR_tempr5, 1) = MR_tempr4;
	MR_tag_alloc_heap(MR_tempr6, 1, (MR_Integer) 2);
	MR_r5 = MR_tempr6;
	MR_tfield(1, MR_tempr6, 0) = (MR_Word) MR_TAG_COMMON(1,3,2);
	MR_tfield(1, MR_tempr6, 1) = MR_tempr5;
	MR_tag_alloc_heap(MR_tempr7, 1, (MR_Integer) 2);
	MR_r4 = MR_tempr7;
	MR_tfield(1, MR_tempr7, 0) = (MR_Word) MR_TAG_COMMON(3,1,6);
	MR_tfield(1, MR_tempr7, 1) = MR_tempr6;
	MR_r1 = MR_tempr7;
	MR_r2 = MR_sv(5);
	MR_GOTO_LAB(hlds__make_hlds__add_type__check_foreign_type_8_0_i6);
	}
MR_def_label(hlds__make_hlds__add_type__check_foreign_type_8_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(1),1)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__check_foreign_type_8_0_i46);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6, MR_tempr7;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(3);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(4);
	MR_tag_alloc_heap(MR_tempr2, 3, (MR_Integer) 2);
	MR_r5 = MR_tempr2;
	MR_tfield(3, MR_tempr2, 0) = (MR_Integer) 6;
	MR_tfield(3, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 2);
	MR_r4 = MR_tempr3;
	MR_tfield(1, MR_tempr3, 0) = MR_tempr2;
	MR_tfield(1, MR_tempr3, 1) = (MR_Word) MR_TAG_COMMON(1,2,6);
	MR_tag_alloc_heap(MR_tempr4, 1, (MR_Integer) 2);
	MR_r5 = MR_tempr4;
	MR_tfield(1, MR_tempr4, 0) = (MR_Word) MR_TAG_COMMON(3,1,7);
	MR_tfield(1, MR_tempr4, 1) = MR_tempr3;
	MR_tag_alloc_heap(MR_tempr5, 1, (MR_Integer) 2);
	MR_r4 = MR_tempr5;
	MR_tfield(1, MR_tempr5, 0) = (MR_Word) MR_TAG_COMMON(1,3,1);
	MR_tfield(1, MR_tempr5, 1) = MR_tempr4;
	MR_tag_alloc_heap(MR_tempr6, 1, (MR_Integer) 2);
	MR_r5 = MR_tempr6;
	MR_tfield(1, MR_tempr6, 0) = (MR_Word) MR_TAG_COMMON(1,3,3);
	MR_tfield(1, MR_tempr6, 1) = MR_tempr5;
	MR_tag_alloc_heap(MR_tempr7, 1, (MR_Integer) 2);
	MR_r4 = MR_tempr7;
	MR_tfield(1, MR_tempr7, 0) = (MR_Word) MR_TAG_COMMON(3,1,6);
	MR_tfield(1, MR_tempr7, 1) = MR_tempr6;
	MR_r1 = MR_tempr7;
	MR_r2 = MR_sv(5);
	MR_GOTO_LAB(hlds__make_hlds__add_type__check_foreign_type_8_0_i6);
	}
MR_def_label(hlds__make_hlds__add_type__check_foreign_type_8_0,46)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(1),2)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__check_foreign_type_8_0_i97);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(3);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(4);
	MR_tag_alloc_heap(MR_tempr2, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr2, 0) = (MR_Integer) 6;
	MR_tfield(3, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_tempr2;
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_TAG_COMMON(1,2,6);
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = (MR_Word) MR_TAG_COMMON(3,1,7);
	MR_tfield(1, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = (MR_Word) MR_TAG_COMMON(1,3,1);
	MR_tfield(1, MR_tempr1, 1) = MR_tempr2;
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = (MR_Word) MR_TAG_COMMON(1,3,4);
	MR_tfield(1, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = (MR_Word) MR_TAG_COMMON(3,1,6);
	MR_tfield(1, MR_tempr1, 1) = MR_tempr2;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_sv(5);
	}
MR_def_label(hlds__make_hlds__add_type__check_foreign_type_8_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 1);
	MR_tfield(0, MR_tempr1, 0) = MR_r1;
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr1;
	MR_tfield(1, MR_tempr2, 1) = (MR_Word) MR_TAG_COMMON(1,2,10);
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 1) = MR_tempr2;
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr1;
	MR_tfield(1, MR_tempr2, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 3);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 2);
	MR_tfield(0, MR_tempr1, 2) = MR_tempr2;
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 2);
	MR_r3 = MR_tempr3;
	MR_tfield(1, MR_tempr3, 0) = MR_tempr1;
	MR_tfield(1, MR_tempr3, 1) = MR_sv(6);
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(7);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(map__search_3_0);
MR_decl_entry(fn__mdbcomp__prim_data__sym_name_to_string_1_0);
MR_decl_entry(fn__mdbcomp__prim_data__unqualify_name_1_0);
MR_decl_entry(svmulti_map__set_4_0);
MR_decl_entry(list__foldl_4_0);

MR_BEGIN_MODULE(hlds__make_hlds__add_type_module11)
	MR_init_entry1(hlds__make_hlds__add_type__add_ctor_field_name_8_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__hlds__make_hlds__add_type__add_ctor_field_name_8_0);
	MR_init_label10(hlds__make_hlds__add_type__add_ctor_field_name_8_0,3,2,7,9,13,14,5,36,40,38)
	MR_init_label1(hlds__make_hlds__add_type__add_ctor_field_name_8_0,49)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'add_ctor_field_name'/8 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(hlds__make_hlds__add_type__add_ctor_field_name_8_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(8);
	MR_sv(8) = (MR_Word) MR_succip;
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__add_ctor_field_name_8_0_i3);
	}
	MR_sv(4) = MR_r4;
	MR_r4 = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_sv(5) = MR_tfield(1, MR_r1, 0);
	MR_r3 = MR_r5;
	MR_sv(7) = MR_r6;
	MR_GOTO_LAB(hlds__make_hlds__add_type__add_ctor_field_name_8_0_i2);
MR_def_label(hlds__make_hlds__add_type__add_ctor_field_name_8_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("add_type.m", 10);
	MR_sv(2) = MR_r2;
	MR_r2 = (MR_Word) MR_string_const("add_ctor_field_name: unqualified field name", 43);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		hlds__make_hlds__add_type__add_ctor_field_name_8_0_i2);
MR_def_label(hlds__make_hlds__add_type__add_ctor_field_name_8_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r4;
	MR_sv(6) = MR_r3;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,2,11);
	MR_np_call_localret_ent(map__search_3_0,
		hlds__make_hlds__add_type__add_ctor_field_name_8_0_i7);
MR_def_label(hlds__make_hlds__add_type__add_ctor_field_name_8_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__add_ctor_field_name_8_0_i5);
	}
	if (MR_LTAGS_TEST(MR_r2,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__add_ctor_field_name_8_0_i9);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r2, 1);
	if (MR_LTAGS_TESTR(MR_tempr1,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__add_ctor_field_name_8_0_i9);
	}
	MR_r1 = MR_sv(1);
	MR_sv(1) = MR_tfield(0, MR_tfield(1, MR_r2, 0), 0);
	MR_sv(2) = MR_tfield(0, MR_sv(2), 0);
	}
	MR_np_call_localret_ent(fn__mdbcomp__prim_data__sym_name_to_string_1_0,
		hlds__make_hlds__add_type__add_ctor_field_name_8_0_i14);
MR_def_label(hlds__make_hlds__add_type__add_ctor_field_name_8_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("add_type.m", 10);
	MR_r2 = (MR_Word) MR_string_const("add_ctor_field_name: multiple conflicting fields", 48);
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		hlds__make_hlds__add_type__add_ctor_field_name_8_0_i13);
MR_def_label(hlds__make_hlds__add_type__add_ctor_field_name_8_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__mdbcomp__prim_data__sym_name_to_string_1_0,
		hlds__make_hlds__add_type__add_ctor_field_name_8_0_i14);
MR_def_label(hlds__make_hlds__add_type__add_ctor_field_name_8_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tag_alloc_heap(MR_tempr1, 2, (MR_Integer) 1);
	MR_tfield(2, MR_tempr1, 0) = MR_r1;
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr1;
	MR_tfield(1, MR_tempr2, 1) = (MR_Word) MR_TAG_COMMON(1,2,12);
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr3, 0) = (MR_Word) MR_TAG_COMMON(3,1,10);
	MR_tfield(1, MR_tempr3, 1) = MR_tempr2;
	MR_tag_alloc_heap(MR_tempr4, 0, (MR_Integer) 1);
	MR_tfield(0, MR_tempr4, 0) = MR_tempr3;
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr3, 0) = MR_tempr4;
	MR_tfield(1, MR_tempr3, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr4, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr4, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr4, 1) = MR_tempr3;
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr3, 0) = MR_tempr1;
	MR_tfield(1, MR_tempr3, 1) = (MR_Word) MR_TAG_COMMON(1,2,13);
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = (MR_Word) MR_TAG_COMMON(3,1,12);
	MR_tfield(1, MR_tempr1, 1) = MR_tempr3;
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 1);
	MR_tfield(0, MR_tempr2, 0) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_tempr2;
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr2, 0) = MR_sv(1);
	MR_tfield(0, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_tempr2;
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr4;
	MR_tfield(1, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 3);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 2);
	MR_tfield(0, MR_tempr1, 2) = MR_tempr2;
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_tempr1;
	MR_tfield(1, MR_r2, 1) = MR_sv(7);
	MR_r1 = MR_sv(6);
	MR_decr_sp_and_return(8);
	}
MR_def_label(hlds__make_hlds__add_type__add_ctor_field_name_8_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(fn__mdbcomp__prim_data__unqualify_name_1_0,
		hlds__make_hlds__add_type__add_ctor_field_name_8_0_i36);
MR_def_label(hlds__make_hlds__add_type__add_ctor_field_name_8_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(3),1)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__add_ctor_field_name_8_0_i38);
	}
	MR_tag_alloc_heap(MR_r3, 0, (MR_Integer) 1);
	MR_tfield(0, MR_r3, 0) = MR_r1;
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_data, hlds_ctor_field_defn);
	MR_r4 = MR_sv(2);
	MR_r5 = MR_sv(6);
	MR_np_call_localret_ent(svmulti_map__set_4_0,
		hlds__make_hlds__add_type__add_ctor_field_name_8_0_i40);
MR_def_label(hlds__make_hlds__add_type__add_ctor_field_name_8_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(7,0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(hlds__make_hlds__add_type__do_add_ctor_field_5_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 4) = MR_sv(2);
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_r4 = MR_tempr2;
	MR_tfield(1, MR_tempr2, 0) = MR_sv(5);
	MR_tfield(1, MR_tempr2, 1) = MR_sv(4);
	MR_r5 = MR_r1;
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,6,1);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name);
	}
	MR_np_call_localret_ent(list__foldl_4_0,
		hlds__make_hlds__add_type__add_ctor_field_name_8_0_i49);
MR_def_label(hlds__make_hlds__add_type__add_ctor_field_name_8_0,38)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(7,1);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(hlds__make_hlds__add_type__do_add_ctor_field_5_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_tfield(0, MR_tempr1, 4) = MR_sv(2);
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_r4 = MR_tempr2;
	MR_tfield(1, MR_tempr2, 0) = MR_sv(5);
	MR_tfield(1, MR_tempr2, 1) = MR_sv(4);
	MR_r5 = MR_sv(6);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,6,1);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name);
	}
	MR_np_call_localret_ent(list__foldl_4_0,
		hlds__make_hlds__add_type__add_ctor_field_name_8_0_i49);
MR_def_label(hlds__make_hlds__add_type__add_ctor_field_name_8_0,49)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(7);
	MR_decr_sp_and_return(8);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(hlds__make_hlds__add_type_module12)
	MR_init_entry1(hlds__make_hlds__add_type__add_ctor_field_names_12_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__hlds__make_hlds__add_type__add_ctor_field_names_12_0);
	MR_init_label4(hlds__make_hlds__add_type__add_ctor_field_names_12_0,18,3,5,7)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'add_ctor_field_names'/12 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(hlds__make_hlds__add_type__add_ctor_field_names_12_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(9);
	MR_sv(9) = (MR_Word) MR_succip;
MR_def_label(hlds__make_hlds__add_type__add_ctor_field_names_12_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__add_ctor_field_names_12_0_i3);
	}
	MR_r1 = MR_r9;
	MR_r2 = MR_r10;
	MR_decr_sp_and_return(9);
MR_def_label(hlds__make_hlds__add_type__add_ctor_field_names_12_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r11 = MR_tfield(1, MR_r1, 0);
	if (MR_LTAGS_TESTR(MR_r11,0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__add_ctor_field_names_12_0_i5);
	}
	MR_r1 = MR_tfield(1, MR_r1, 1);
	MR_r8 = ((MR_Integer) MR_r8 + (MR_Integer) 1);
	MR_succip_word = MR_sv(9);
	MR_GOTO_LAB(hlds__make_hlds__add_type__add_ctor_field_names_12_0_i18);
MR_def_label(hlds__make_hlds__add_type__add_ctor_field_names_12_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_tempr2 = MR_r6;
	MR_tfield(0, MR_tempr1, 0) = MR_tempr2;
	MR_tempr3 = MR_r7;
	MR_tfield(0, MR_tempr1, 1) = MR_tempr3;
	MR_tempr4 = MR_r4;
	MR_tfield(0, MR_tempr1, 2) = MR_tempr4;
	MR_tempr5 = MR_r5;
	MR_tfield(0, MR_tempr1, 3) = MR_tempr5;
	MR_tempr6 = MR_r8;
	MR_tfield(0, MR_tempr1, 4) = MR_tempr6;
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_tempr4;
	MR_sv(4) = MR_tempr5;
	MR_sv(5) = MR_tempr2;
	MR_sv(6) = MR_tempr3;
	MR_sv(7) = MR_tempr6;
	MR_sv(8) = MR_tfield(1, MR_r1, 1);
	MR_r1 = MR_tfield(1, MR_r11, 0);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(1);
	MR_r4 = MR_sv(2);
	MR_r5 = MR_r9;
	MR_r6 = MR_r10;
	}
	MR_np_call_localret_ent(hlds__make_hlds__add_type__add_ctor_field_name_8_0,
		hlds__make_hlds__add_type__add_ctor_field_names_12_0_i7);
MR_def_label(hlds__make_hlds__add_type__add_ctor_field_names_12_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_sv(1);
	MR_r3 = MR_sv(2);
	MR_r4 = MR_sv(3);
	MR_r5 = MR_sv(4);
	MR_r6 = MR_sv(5);
	MR_r7 = MR_sv(6);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_sv(8);
	MR_r9 = MR_tempr2;
	MR_r10 = MR_tempr1;
	MR_r8 = ((MR_Integer) MR_sv(7) + (MR_Integer) 1);
	MR_succip_word = MR_sv(9);
	MR_GOTO_LAB(hlds__make_hlds__add_type__add_ctor_field_names_12_0_i18);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(hlds__hlds_data__get_type_defn_context_2_0);
MR_decl_entry(hlds__hlds_data__get_type_defn_tvarset_2_0);
MR_decl_entry(hlds__hlds_data__get_type_defn_tparams_2_0);
MR_decl_entry(hlds__hlds_data__get_type_defn_kind_map_2_0);
MR_decl_entry(hlds__hlds_data__get_type_defn_body_2_0);
MR_decl_entry(hlds__hlds_data__get_type_defn_status_2_0);
MR_decl_entry(hlds__hlds_data__get_type_defn_need_qualifier_2_0);
MR_decl_entry(hlds__hlds_module__module_info_get_cons_table_2_0);
MR_decl_entry(hlds__hlds_module__module_info_get_partial_qualifier_info_2_0);
MR_decl_entry(hlds__hlds_module__module_info_get_ctor_field_table_2_0);
MR_decl_entry(hlds__hlds_module__module_info_set_cons_table_3_0);
MR_decl_entry(hlds__hlds_module__module_info_set_ctor_field_table_3_0);
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__error_util__type_ctor_info_error_spec_0;
MR_decl_entry(fn__f_108_105_115_116_95_95_43_43_2_0);
MR_decl_entry(parse_tree__prog_type__type_ctor_should_be_notag_8_0);
MR_decl_entry(hlds__hlds_module__module_info_get_no_tag_types_2_0);
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_type_ctor_0;
extern const MR_TypeCtorInfo_Struct mercury_data_hlds__hlds_data__type_ctor_info_no_tag_type_0;
MR_decl_entry(map__set_4_0);
MR_decl_entry(hlds__hlds_module__module_info_set_no_tag_types_3_0);
MR_decl_entry(fn__bool__or_2_0);
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_kind_0;
MR_decl_entry(fn__map__init_0_0);
MR_decl_entry(parse_tree__prog_type__var_list_to_type_list_3_0);
MR_decl_entry(parse_tree__prog_type__construct_type_3_0);
MR_decl_entry(hlds__make_hlds__add_special_pred__add_special_preds_8_0);

MR_BEGIN_MODULE(hlds__make_hlds__add_type_module13)
	MR_init_entry1(hlds__make_hlds__add_type__process_type_defn_8_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__hlds__make_hlds__add_type__process_type_defn_8_0);
	MR_init_label10(hlds__make_hlds__add_type__process_type_defn_8_0,2,3,4,5,6,7,8,9,12,13)
	MR_init_label10(hlds__make_hlds__add_type__process_type_defn_8_0,14,16,15,18,19,20,22,23,21,26)
	MR_init_label10(hlds__make_hlds__add_type__process_type_defn_8_0,29,30,31,24,11,34,33,35,39,40)
	MR_init_label3(hlds__make_hlds__add_type__process_type_defn_8_0,41,42,37)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'process_type_defn'/8 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__hlds__make_hlds__add_type__process_type_defn_8_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(18);
	MR_sv(18) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(15) = MR_r3;
	MR_sv(16) = MR_r4;
	MR_sv(17) = MR_r5;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(hlds__hlds_data__get_type_defn_context_2_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i2);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(hlds__hlds_data__get_type_defn_tvarset_2_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i3);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(hlds__hlds_data__get_type_defn_tparams_2_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i4);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(5) = MR_r1;
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(hlds__hlds_data__get_type_defn_kind_map_2_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i5);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(6) = MR_r1;
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(hlds__hlds_data__get_type_defn_body_2_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i6);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(hlds__hlds_data__get_type_defn_status_2_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i7);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_sv(2) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(hlds__hlds_data__get_type_defn_need_qualifier_2_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i8);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(8) = MR_r1;
	MR_r1 = MR_sv(16);
	MR_np_call_localret_ent(hlds__hlds_module__module_info_get_globals_2_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i9);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(7),0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__process_type_defn_8_0_i11);
	}
	MR_sv(9) = MR_r1;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(7);
	MR_sv(10) = MR_tfield(0, MR_tempr1, 0);
	MR_sv(11) = MR_tfield(0, MR_tempr1, 4);
	MR_sv(12) = MR_tfield(0, MR_tempr1, 5);
	MR_r1 = MR_sv(16);
	}
	MR_np_call_localret_ent(hlds__hlds_module__module_info_get_cons_table_2_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i12);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(13) = MR_r1;
	MR_r1 = MR_sv(16);
	MR_np_call_localret_ent(hlds__hlds_module__module_info_get_partial_qualifier_info_2_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i13);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(14) = MR_r1;
	MR_r1 = MR_sv(16);
	MR_np_call_localret_ent(hlds__hlds_module__module_info_get_ctor_field_table_2_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i14);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_sv(1);
	MR_tempr1 = MR_tfield(0, MR_tempr2, 0);
	MR_r13 = MR_tempr1;
	if (MR_PTAG_TESTR(MR_tempr1,1)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__process_type_defn_8_0_i16);
	}
	MR_r2 = MR_tempr2;
	MR_r4 = MR_sv(4);
	MR_r5 = MR_sv(5);
	MR_r6 = MR_sv(6);
	MR_r9 = MR_sv(2);
	MR_r7 = MR_sv(8);
	MR_r14 = MR_r1;
	MR_r1 = MR_sv(10);
	MR_r11 = MR_sv(13);
	MR_r8 = MR_sv(14);
	MR_r10 = MR_r14;
	MR_r3 = MR_tfield(1, MR_tempr1, 0);
	MR_r12 = (MR_Word) MR_tbmkword(0, 0);
	MR_GOTO_LAB(hlds__make_hlds__add_type__process_type_defn_8_0_i15);
	}
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("add_type.m", 10);
	MR_r2 = (MR_Word) MR_string_const("process_type_defn: unqualified TypeCtorSymName", 46);
	}
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i15);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	MR_sv(4) = MR_r4;
	MR_sv(5) = MR_r5;
	MR_sv(2) = MR_r9;
	MR_sv(10) = MR_r1;
	MR_np_call_localret_ent(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i18);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(6) = MR_r1;
	MR_sv(8) = MR_r3;
	MR_r1 = MR_r2;
	MR_r2 = MR_sv(16);
	MR_np_call_localret_ent(hlds__hlds_module__module_info_set_cons_table_3_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i19);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(hlds__hlds_module__module_info_set_ctor_field_table_3_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i20);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(8),0,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__process_type_defn_8_0_i22);
	}
	MR_r2 = MR_sv(1);
	MR_sv(13) = MR_r1;
	MR_r1 = MR_sv(9);
	MR_r4 = MR_sv(10);
	MR_r5 = MR_sv(11);
	MR_r3 = MR_sv(12);
	MR_sv(6) = (MR_Integer) 0;
	MR_sv(9) = MR_sv(17);
	MR_GOTO_LAB(hlds__make_hlds__add_type__process_type_defn_8_0_i21);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(13) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__error_util, error_spec);
	MR_r2 = MR_sv(8);
	MR_r3 = MR_sv(17);
	MR_np_call_localret_ent(fn__f_108_105_115_116_95_95_43_43_2_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i23);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(9);
	MR_r4 = MR_sv(10);
	MR_r5 = MR_sv(11);
	MR_r3 = MR_sv(12);
	MR_sv(6) = (MR_Integer) 1;
	MR_sv(9) = MR_tempr1;
	}
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	MR_np_call_localret_ent(parse_tree__prog_type__type_ctor_should_be_notag_8_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i26);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__process_type_defn_8_0_i24);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 3);
	MR_sv(8) = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(5);
	MR_tfield(0, MR_tempr1, 1) = MR_r2;
	MR_tfield(0, MR_tempr1, 2) = MR_r3;
	MR_r1 = MR_sv(13);
	}
	MR_np_call_localret_ent(hlds__hlds_module__module_info_get_no_tag_types_2_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i29);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, type_ctor);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_data, no_tag_type);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(1);
	MR_r5 = MR_sv(8);
	}
	MR_np_call_localret_ent(map__set_4_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i30);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(13);
	MR_np_call_localret_ent(hlds__hlds_module__module_info_set_no_tag_types_3_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i31);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(6);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(15);
	MR_sv(8) = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__bool__or_2_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i35);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_r2 = MR_sv(6);
	MR_r1 = MR_sv(15);
	MR_sv(8) = MR_sv(13);
	MR_np_call_localret_ent(fn__bool__or_2_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i35);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(7),2)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__process_type_defn_8_0_i33);
	}
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tfield(2, MR_sv(7), 0);
	MR_r3 = MR_sv(3);
	MR_r4 = MR_sv(16);
	MR_r5 = MR_sv(17);
	MR_np_call_localret_ent(hlds__make_hlds__add_type__check_foreign_type_8_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i34);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(8) = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = MR_sv(15);
	MR_sv(9) = MR_r3;
	MR_np_call_localret_ent(fn__bool__or_2_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i35);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Integer) 0;
	MR_r1 = MR_sv(15);
	MR_sv(9) = MR_sv(17);
	MR_sv(8) = MR_sv(16);
	MR_np_call_localret_ent(fn__bool__or_2_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i35);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(hlds__make_hlds__add_type__process_type_defn_8_0_i37);
	}
	MR_sv(6) = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,2,15);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, kind);
	MR_np_call_localret_ent(fn__map__init_0_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i39);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(5);
	MR_np_call_localret_ent(parse_tree__prog_type__var_list_to_type_list_3_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i40);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(parse_tree__prog_type__construct_type_3_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i41);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,41)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(1);
	MR_r4 = MR_sv(7);
	MR_r5 = MR_sv(3);
	MR_r6 = MR_sv(2);
	MR_r7 = MR_sv(8);
	}
	MR_np_call_localret_ent(hlds__make_hlds__add_special_pred__add_special_preds_8_0,
		hlds__make_hlds__add_type__process_type_defn_8_0_i42);
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,42)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(6);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(9);
	MR_decr_sp_and_return(18);
	}
MR_def_label(hlds__make_hlds__add_type__process_type_defn_8_0,37)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(8);
	MR_r3 = MR_sv(9);
	MR_decr_sp_and_return(18);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(hlds__make_hlds__add_type_module14)
	MR_init_entry1(hlds__make_hlds__add_type__add_ctor_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__hlds__make_hlds__add_type__add_ctor_7_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'add_ctor'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(hlds__make_hlds__add_type__add_ctor_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_r5;
	MR_tfield(1, MR_tempr1, 1) = MR_r2;
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 3);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr1;
	MR_tfield(1, MR_tempr2, 1) = MR_r3;
	MR_tfield(1, MR_tempr2, 2) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, cons_id);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_data, hlds_cons_defn);
	MR_r3 = MR_tempr2;
	MR_r5 = MR_r6;
	MR_np_tailcall_ent(svmulti_map__set_4_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(hlds__make_hlds__add_type_module15)
	MR_init_entry1(hlds__make_hlds__add_type__do_add_ctor_field_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__hlds__make_hlds__add_type__do_add_ctor_field_5_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'do_add_ctor_field'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(hlds__make_hlds__add_type__do_add_ctor_field_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_r3;
	MR_tfield(1, MR_tempr1, 1) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name);
	MR_tempr2 = MR_r2;
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_data, hlds_ctor_field_defn);
	MR_r3 = MR_tempr1;
	MR_tempr3 = MR_r4;
	MR_r4 = MR_tempr2;
	MR_r5 = MR_tempr3;
	MR_np_tailcall_ent(svmulti_map__set_4_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(hlds__make_hlds__add_type_module16)
	MR_init_entry1(fn__hlds__make_hlds__add_type__IntroducedFrom__func__ctors_add__753__1_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__hlds__make_hlds__add_type__IntroducedFrom__func__ctors_add__753__1_1_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__func__ctors_add__753__1'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__hlds__make_hlds__add_type__IntroducedFrom__func__ctors_add__753__1_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_r1, 0);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(list__length_2_0);
MR_decl_entry(fn__term__context_file_1_0);
MR_decl_entry(string__suffix_2_0);
extern const MR_TypeCtorInfo_Struct mercury_data_parse_tree__prog_data__type_ctor_info_constructor_arg_0;
MR_decl_entry(fn__hlds__hlds_pred__status_defined_in_this_module_1_0);
MR_decl_entry(hlds__hlds_module__module_info_get_type_table_2_0);
MR_decl_entry(hlds__hlds_data__search_type_ctor_defn_3_0);
MR_decl_entry(hlds__hlds_data__set_type_defn_body_3_0);
MR_decl_entry(map__init_1_0);
MR_decl_entry(hlds__hlds_data__set_type_defn_9_0);
MR_decl_entry(hlds__hlds_data__get_type_defn_in_exported_eqv_2_0);
MR_decl_entry(libs__globals__lookup_bool_option_3_0);
MR_decl_entry(hlds__hlds_module__module_info_set_contains_foreign_type_2_0);
MR_decl_entry(__Unify___hlds__hlds_pred__import_status_0_0);
MR_decl_entry(hlds__hlds_data__replace_type_ctor_defn_4_0);
MR_decl_entry(hlds__hlds_module__module_info_set_type_table_3_0);
MR_decl_entry(hlds__hlds_module__module_info_incr_errors_2_0);
MR_decl_entry(hlds__make_hlds__make_hlds_error__multiple_def_error_9_0);
MR_decl_entry(hlds__hlds_data__add_or_replace_type_ctor_defn_4_0);
MR_decl_entry(list__member_2_1);
MR_decl_entry(parse_tree__prog_type__type_contains_var_2_0);
MR_decl_entry(__Unify___term__var_1_0);
MR_declare_entry(MR_do_redo);

MR_BEGIN_MODULE(hlds__make_hlds__add_type_module17)
	MR_init_entry1(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0);
	MR_init_label10(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,2,4,6,11,12,10,9,7,8,16)
	MR_init_label10(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,22,24,17,18,43,44,47,49,50,51)
	MR_init_label10(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,52,55,53,75,45,78,79,80,81,101)
	MR_init_label10(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,102,104,106,97,98,124,125,126,127,128)
	MR_init_label10(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,129,130,131,134,135,138,136,139,144,142)
	MR_init_label10(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,146,147,140,152,156,158,159,155,161,150)
	MR_init_label10(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,181,183,184,121,122,188,189,196,201,202)
	MR_init_label6(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,200,192,193,205,207,191)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__module_add_type_defn__[5]_0'/11 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(30);
	MR_sv(30) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_sv(4) = MR_r4;
	MR_sv(5) = MR_r5;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r6;
	MR_sv(6) = MR_tfield(0, MR_tempr1, 0);
	MR_sv(7) = MR_tfield(0, MR_tempr1, 1);
	MR_tempr2 = MR_r7;
	MR_sv(20) = MR_tempr2;
	MR_sv(13) = MR_r8;
	MR_r1 = MR_tempr2;
	}
	MR_np_call_localret_ent(hlds__hlds_module__module_info_get_globals_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i2);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(8) = MR_r1;
	MR_sv(22) = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, tvar_type);
	MR_sv(23) = (MR_Word) MR_TAG_COMMON(0,2,15);
	MR_r1 = MR_sv(23);
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(list__length_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i4);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(2);
	MR_tfield(0, MR_r2, 1) = MR_r1;
	MR_sv(9) = MR_r1;
	MR_sv(10) = MR_r2;
	MR_r1 = MR_sv(4);
	MR_r3 = MR_sv(8);
	MR_np_call_localret_ent(hlds__make_hlds__add_type__convert_type_defn_4_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i6);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i10);
	}
	MR_sv(11) = MR_r1;
	MR_r1 = MR_sv(5);
	MR_np_call_localret_ent(fn__term__context_file_1_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i11);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_string_const(".int2", 5);
	MR_np_call_localret_ent(string__suffix_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i12);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i7);
	}
	MR_r1 = MR_sv(6);
	MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i9);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r1,3,1)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i8);
	}
	MR_sv(11) = MR_r1;
	MR_r1 = MR_sv(6);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(6) = MR_r1;
	MR_np_call_localret_ent(hlds__make_hlds__add_type__make_status_abstract_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i16);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(11);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(11) = MR_r1;
	MR_r1 = MR_sv(6);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(4),0)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i18);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr3 = MR_sv(4);
	MR_tempr1 = MR_tfield(0, MR_tempr3, 0);
	if (MR_LTAGS_TEST(MR_tempr1,0,0)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i18);
	}
	MR_tempr2 = MR_tfield(1, MR_tempr1, 1);
	if (MR_LTAGS_TESTR(MR_tempr2,0,0)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i18);
	}
	MR_tempr2 = MR_tempr3;
	MR_sv(4) = MR_r1;
	MR_sv(12) = MR_tfield(0, MR_tempr2, 1);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, constructor_arg);
	MR_r2 = MR_tfield(0, MR_tfield(1, MR_tempr1, 0), 3);
	}
	MR_np_call_localret_ent(list__length_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i22);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (((MR_Integer) 0 != (MR_Integer) MR_r1)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i17);
	}
	if (MR_LTAGS_TEST(MR_sv(12),0,0)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i17);
	}
	MR_r1 = MR_sv(6);
	MR_np_call_localret_ent(fn__hlds__hlds_pred__status_defined_in_this_module_1_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i24);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,1)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i17);
	}
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_sv(2);
	MR_tfield(0, MR_r2, 1) = MR_sv(9);
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6, MR_tempr7, MR_tempr8, MR_tempr9;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_r3 = MR_tempr1;
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 6;
	MR_tfield(3, MR_tempr1, 1) = MR_r2;
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_r4 = MR_tempr2;
	MR_tfield(1, MR_tempr2, 0) = MR_tempr1;
	MR_tfield(1, MR_tempr2, 1) = (MR_Word) MR_TAG_COMMON(1,2,17);
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 2);
	MR_r3 = MR_tempr3;
	MR_tfield(1, MR_tempr3, 0) = (MR_Word) MR_TAG_COMMON(3,1,14);
	MR_tfield(1, MR_tempr3, 1) = MR_tempr2;
	MR_tag_alloc_heap(MR_tempr4, 0, (MR_Integer) 1);
	MR_r4 = MR_tempr4;
	MR_tfield(0, MR_tempr4, 0) = MR_tempr3;
	MR_tag_alloc_heap(MR_tempr5, 1, (MR_Integer) 2);
	MR_r3 = MR_tempr5;
	MR_tfield(1, MR_tempr5, 0) = MR_tempr4;
	MR_tfield(1, MR_tempr5, 1) = (MR_Word) MR_TAG_COMMON(1,2,21);
	MR_tag_alloc_heap(MR_tempr6, 0, (MR_Integer) 2);
	MR_r4 = MR_tempr6;
	MR_tfield(0, MR_tempr6, 0) = MR_sv(5);
	MR_tfield(0, MR_tempr6, 1) = MR_tempr5;
	MR_tag_alloc_heap(MR_tempr7, 1, (MR_Integer) 2);
	MR_r3 = MR_tempr7;
	MR_tfield(1, MR_tempr7, 0) = MR_tempr6;
	MR_tfield(1, MR_tempr7, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr8, 0, (MR_Integer) 3);
	MR_r5 = MR_tempr8;
	MR_tfield(0, MR_tempr8, 0) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr8, 1) = (MR_Word) MR_tbmkword(0, 2);
	MR_tfield(0, MR_tempr8, 2) = MR_tempr7;
	MR_tag_alloc_heap(MR_tempr9, 1, (MR_Integer) 2);
	MR_sv(16) = MR_tempr9;
	MR_tfield(1, MR_tempr9, 0) = MR_tempr8;
	MR_tfield(1, MR_tempr9, 1) = MR_sv(13);
	MR_r1 = MR_sv(20);
	MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i43);
	}
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_r1 = MR_sv(20);
	MR_sv(16) = MR_sv(13);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(20) = MR_r1;
	MR_np_call_localret_ent(hlds__hlds_module__module_info_get_type_table_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i44);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,44)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(12) = MR_r1;
	MR_r2 = MR_sv(10);
	MR_np_call_localret_ent(hlds__hlds_data__search_type_ctor_defn_3_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i47);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,47)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i45);
	}
	MR_sv(13) = MR_r2;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(hlds__hlds_data__get_type_defn_status_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i49);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,49)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(hlds__make_hlds__add_type__combine_status_3_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i50);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,50)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(14) = MR_r1;
	MR_r1 = MR_sv(13);
	MR_np_call_localret_ent(hlds__hlds_data__get_type_defn_body_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i51);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,51)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(11);
	MR_np_call_localret_ent(hlds__make_hlds__add_type__combine_is_solver_type_4_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i52);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,52)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(11) = MR_r1;
	MR_sv(15) = MR_r2;
	MR_np_call_localret_ent(hlds__make_hlds__add_type__is_solver_type_is_inconsistent_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i55);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,55)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i53);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6, MR_tempr7, MR_tempr8, MR_tempr9, MR_tempr10;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(9);
	MR_tag_alloc_heap(MR_tempr2, 3, (MR_Integer) 2);
	MR_r4 = MR_tempr2;
	MR_tfield(3, MR_tempr2, 0) = (MR_Integer) 6;
	MR_tfield(3, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 2);
	MR_r5 = MR_tempr3;
	MR_tfield(1, MR_tempr3, 0) = MR_tempr2;
	MR_tfield(1, MR_tempr3, 1) = (MR_Word) MR_TAG_COMMON(1,2,25);
	MR_tag_alloc_heap(MR_tempr4, 1, (MR_Integer) 2);
	MR_r4 = MR_tempr4;
	MR_tfield(1, MR_tempr4, 0) = (MR_Word) MR_TAG_COMMON(3,1,20);
	MR_tfield(1, MR_tempr4, 1) = MR_tempr3;
	MR_tag_alloc_heap(MR_tempr5, 0, (MR_Integer) 1);
	MR_r5 = MR_tempr5;
	MR_tfield(0, MR_tempr5, 0) = MR_tempr4;
	MR_tag_alloc_heap(MR_tempr6, 1, (MR_Integer) 2);
	MR_r4 = MR_tempr6;
	MR_tfield(1, MR_tempr6, 0) = MR_tempr5;
	MR_tfield(1, MR_tempr6, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr7, 0, (MR_Integer) 2);
	MR_r5 = MR_tempr7;
	MR_tfield(0, MR_tempr7, 0) = MR_sv(5);
	MR_tfield(0, MR_tempr7, 1) = MR_tempr6;
	MR_tag_alloc_heap(MR_tempr8, 1, (MR_Integer) 2);
	MR_r4 = MR_tempr8;
	MR_tfield(1, MR_tempr8, 0) = MR_tempr7;
	MR_tfield(1, MR_tempr8, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr9, 0, (MR_Integer) 3);
	MR_r6 = MR_tempr9;
	MR_tfield(0, MR_tempr9, 0) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr9, 1) = (MR_Word) MR_tbmkword(0, 2);
	MR_tfield(0, MR_tempr9, 2) = MR_tempr8;
	MR_tag_alloc_heap(MR_tempr10, 1, (MR_Integer) 2);
	MR_sv(21) = MR_tempr10;
	MR_tfield(1, MR_tempr10, 0) = MR_tempr9;
	MR_tfield(1, MR_tempr10, 1) = MR_sv(16);
	MR_sv(11) = (MR_Word) MR_tbmkword(0, 0);
	MR_r1 = MR_sv(23);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, kind);
	MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i78);
	}
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,53)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(11);
	MR_r2 = MR_sv(15);
	MR_r2 = MR_sv(13);
	MR_np_call_localret_ent(hlds__hlds_data__set_type_defn_body_3_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i75);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,75)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_sv(11), 1, (MR_Integer) 1);
	MR_tfield(1, MR_sv(11), 0) = MR_r1;
	MR_sv(21) = MR_sv(16);
	MR_r1 = MR_sv(23);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, kind);
	MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i78);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,45)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(12);
	MR_sv(14) = MR_sv(4);
	MR_sv(15) = MR_sv(11);
	MR_sv(11) = (MR_Word) MR_tbmkword(0, 0);
	MR_sv(21) = MR_sv(16);
	MR_r1 = MR_sv(23);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, kind);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,78)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(23) = MR_r1;
	MR_np_call_localret_ent(map__init_1_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i79);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,79)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(3);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(15);
	MR_r5 = MR_sv(14);
	MR_r6 = (MR_Integer) 0;
	MR_r7 = MR_sv(7);
	MR_r8 = MR_sv(5);
	}
	MR_np_call_localret_ent(hlds__hlds_data__set_type_defn_9_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i80);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,80)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(11),0,0)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i81);
	}
	if (MR_PTAG_TESTR(MR_sv(15),2)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i81);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(9);
	MR_tag_alloc_heap(MR_tempr2, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr2, 0) = (MR_Integer) 6;
	MR_tfield(3, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_tempr2;
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_TAG_COMMON(1,2,26);
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = (MR_Word) MR_TAG_COMMON(3,1,24);
	MR_tfield(1, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 1);
	MR_tfield(0, MR_tempr1, 0) = MR_tempr2;
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr1;
	MR_tfield(1, MR_tempr2, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(5);
	MR_tfield(0, MR_tempr1, 1) = MR_tempr2;
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr1;
	MR_tfield(1, MR_tempr2, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 3);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 2);
	MR_tfield(0, MR_tempr1, 2) = MR_tempr2;
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_tempr1;
	MR_tfield(1, MR_r2, 1) = MR_sv(21);
	MR_r1 = MR_sv(20);
	MR_decr_sp_and_return(30);
	}
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,81)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(15),2)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i98);
	}
	if (MR_LTAGS_TEST(MR_sv(11),0,0)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i98);
	}
	MR_sv(1) = MR_r1;
	MR_sv(13) = MR_tfield(1, MR_sv(11), 0);
	MR_r1 = MR_sv(13);
	MR_np_call_localret_ent(hlds__hlds_data__get_type_defn_status_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i101);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,101)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(13);
	MR_sv(13) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(hlds__hlds_data__get_type_defn_body_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i102);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,102)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r1,3,1)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i97);
	}
	MR_r1 = MR_sv(13);
	MR_np_call_localret_ent(fn__hlds__hlds_pred__status_is_exported_to_non_submodules_1_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i104);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,104)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i97);
	}
	MR_r1 = MR_sv(6);
	MR_np_call_localret_ent(fn__hlds__hlds_pred__status_is_exported_to_non_submodules_1_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i106);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,106)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,1)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i97);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(9);
	MR_tag_alloc_heap(MR_tempr2, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr2, 0) = (MR_Integer) 6;
	MR_tfield(3, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_tempr2;
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_TAG_COMMON(1,2,27);
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = (MR_Word) MR_TAG_COMMON(3,1,26);
	MR_tfield(1, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 1);
	MR_tfield(0, MR_tempr1, 0) = MR_tempr2;
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr1;
	MR_tfield(1, MR_tempr2, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(5);
	MR_tfield(0, MR_tempr1, 1) = MR_tempr2;
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr1;
	MR_tfield(1, MR_tempr2, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 3);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 2);
	MR_tfield(0, MR_tempr1, 2) = MR_tempr2;
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_tempr1;
	MR_tfield(1, MR_r2, 1) = MR_sv(21);
	MR_r1 = MR_sv(20);
	MR_decr_sp_and_return(30);
	}
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,97)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,98)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_sv(11),0,0)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i122);
	}
	MR_sv(1) = MR_r1;
	MR_sv(6) = MR_tfield(1, MR_sv(11), 0);
	MR_r1 = MR_sv(6);
	MR_np_call_localret_ent(hlds__hlds_data__get_type_defn_tvarset_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i124);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,124)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(11) = MR_r1;
	MR_r1 = MR_sv(6);
	MR_np_call_localret_ent(hlds__hlds_data__get_type_defn_tparams_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i125);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,125)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(13) = MR_r1;
	MR_r1 = MR_sv(6);
	MR_np_call_localret_ent(hlds__hlds_data__get_type_defn_kind_map_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i126);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,126)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(16) = MR_r1;
	MR_r1 = MR_sv(6);
	MR_np_call_localret_ent(hlds__hlds_data__get_type_defn_body_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i127);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,127)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(17) = MR_r1;
	MR_r1 = MR_sv(6);
	MR_np_call_localret_ent(hlds__hlds_data__get_type_defn_context_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i128);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,128)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(18) = MR_r1;
	MR_r1 = MR_sv(6);
	MR_np_call_localret_ent(hlds__hlds_data__get_type_defn_status_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i129);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,129)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(19) = MR_r1;
	MR_r1 = MR_sv(6);
	MR_np_call_localret_ent(hlds__hlds_data__get_type_defn_in_exported_eqv_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i130);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,130)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(6);
	MR_sv(6) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(hlds__hlds_data__get_type_defn_need_qualifier_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i131);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,131)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TEST(MR_sv(17),3,1)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i121);
	}
	MR_sv(1) = MR_r1;
	MR_r1 = MR_sv(8);
	MR_np_call_localret_ent(libs__globals__get_target_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i134);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,134)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_r1 = MR_sv(8);
	MR_r2 = (MR_Integer) 77;
	MR_np_call_localret_ent(libs__globals__lookup_bool_option_3_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i135);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,135)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(15),2)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i136);
	}
	MR_sv(8) = MR_r1;
	MR_r1 = MR_sv(20);
	MR_np_call_localret_ent(hlds__hlds_module__module_info_set_contains_foreign_type_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i138);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,138)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r4 = MR_r1;
	MR_r1 = MR_sv(14);
	MR_r2 = MR_sv(19);
	MR_r3 = MR_r4;
	MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i139);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,136)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(8) = MR_r1;
	MR_r1 = MR_sv(14);
	MR_r2 = MR_sv(19);
	MR_r3 = MR_sv(20);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,139)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(15),3,1)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i140);
	}
	MR_sv(14) = MR_r1;
	MR_sv(3) = MR_r3;
	MR_np_call_localret_ent(__Unify___hlds__hlds_pred__import_status_0_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i144);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,144)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i142);
	}
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(21);
	MR_decr_sp_and_return(30);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,142)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(14);
	MR_r3 = MR_sv(3);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(11);
	MR_r2 = MR_sv(13);
	MR_r3 = MR_sv(16);
	MR_r4 = MR_sv(17);
	MR_r5 = MR_tempr1;
	MR_r6 = MR_sv(6);
	MR_r7 = MR_sv(1);
	MR_r8 = MR_sv(18);
	}
	MR_np_call_localret_ent(hlds__hlds_data__set_type_defn_9_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i146);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,146)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(10);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(12);
	}
	MR_np_call_localret_ent(hlds__hlds_data__replace_type_ctor_defn_4_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i147);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,147)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(hlds__hlds_module__module_info_set_type_table_3_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i191);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,140)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(14) = MR_r1;
	MR_sv(19) = MR_r2;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(3);
	MR_sv(3) = MR_r3;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_sv(8);
	MR_r3 = MR_sv(15);
	MR_r4 = MR_sv(17);
	}
	MR_np_call_localret_ent(hlds__make_hlds__add_type__merge_foreign_type_bodies_5_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i152);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,152)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i150);
	}
	MR_sv(1) = MR_r2;
	MR_r1 = MR_sv(19);
	MR_r2 = MR_sv(4);
	MR_np_call_localret_ent(hlds__make_hlds__add_type__check_foreign_type_visibility_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i156);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,156)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i155);
	}
	MR_r1 = MR_sv(11);
	MR_r2 = MR_sv(13);
	MR_r3 = MR_sv(16);
	MR_r4 = MR_sv(1);
	MR_r5 = MR_sv(14);
	MR_r6 = MR_sv(6);
	MR_r7 = MR_sv(7);
	MR_r8 = MR_sv(5);
	MR_np_call_localret_ent(hlds__hlds_data__set_type_defn_9_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i158);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,158)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(10);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(12);
	}
	MR_np_call_localret_ent(hlds__hlds_data__replace_type_ctor_defn_4_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i159);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,159)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(hlds__hlds_module__module_info_set_type_table_3_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i191);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,155)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(hlds__hlds_module__module_info_incr_errors_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i161);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,161)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(0, MR_tempr1, 1) = MR_sv(9);
	MR_tag_alloc_heap(MR_tempr2, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr2, 0) = (MR_Integer) 6;
	MR_tfield(3, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_tempr2;
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_TAG_COMMON(1,2,31);
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = (MR_Word) MR_TAG_COMMON(3,1,20);
	MR_tfield(1, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 1);
	MR_tfield(0, MR_tempr1, 0) = MR_tempr2;
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr1;
	MR_tfield(1, MR_tempr2, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_sv(5);
	MR_tfield(0, MR_tempr1, 1) = MR_tempr2;
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr1;
	MR_tfield(1, MR_tempr2, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 3);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 2);
	MR_tfield(0, MR_tempr1, 2) = MR_tempr2;
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_tempr1;
	MR_tfield(1, MR_r2, 1) = MR_sv(21);
	MR_decr_sp_and_return(30);
	}
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,150)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(14);
	MR_r3 = MR_sv(3);
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i181);
	}
	MR_r1 = MR_r3;
	MR_r2 = MR_sv(21);
	MR_decr_sp_and_return(30);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,181)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(14) = MR_r1;
	MR_r1 = MR_r3;
	MR_np_call_localret_ent(hlds__hlds_module__module_info_incr_errors_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i183);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,183)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r1;
	MR_r1 = MR_sv(14);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(9);
	MR_r4 = (MR_Word) MR_string_const("type", 4);
	MR_r5 = MR_sv(5);
	MR_r6 = MR_sv(18);
	MR_r7 = (MR_Word) MR_tbmkword(0, 0);
	MR_r8 = MR_sv(21);
	MR_np_call_localret_ent(hlds__make_hlds__make_hlds_error__multiple_def_error_9_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i184);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,184)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tempr1;
	MR_decr_sp_and_return(30);
	}
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,121)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,122)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(10);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(12);
	}
	MR_np_call_localret_ent(hlds__hlds_data__add_or_replace_type_ctor_defn_4_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i188);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,188)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(20);
	MR_np_call_localret_ent(hlds__hlds_module__module_info_set_type_table_3_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i189);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,189)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(24) = (MR_Word) MR_redoip_slot(MR_maxfr);
	MR_sv(25) = (MR_Word) MR_redofr_slot(MR_maxfr);
	MR_save_maxfr(MR_sv(26));
	MR_redofr_slot_word(MR_maxfr) = (MR_Word) MR_curfr;
	MR_redoip_slot_word(MR_maxfr) = (MR_Word) MR_LABEL_AP(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i192);
	if (MR_LTAGS_TESTR(MR_sv(14),0,5)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i193);
	}
	if (MR_PTAG_TESTR(MR_sv(15),1)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i193);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(3);
	MR_sv(3) = MR_r1;
	MR_sv(1) = MR_tfield(1, MR_sv(15), 0);
	MR_r1 = MR_sv(23);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__member_2_1,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i196);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,196)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(27) = (MR_Word) MR_redoip_slot(MR_maxfr);
	MR_sv(28) = (MR_Word) MR_redofr_slot(MR_maxfr);
	MR_save_maxfr(MR_sv(29));
	MR_redofr_slot_word(MR_maxfr) = (MR_Word) MR_curfr;
	MR_redoip_slot_word(MR_maxfr) = (MR_Word) MR_LABEL_AP(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i200);
	MR_sv(2) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(parse_tree__prog_type__type_contains_var_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i201);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,201)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(22);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(__Unify___term__var_1_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i202);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,202)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_restore_maxfr(MR_sv(29));
	MR_redoip_slot_word(MR_maxfr) = MR_sv(27);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(28);
	MR_GOTO(MR_ENTRY(MR_do_redo));
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,200)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_redoip_slot_word(MR_maxfr) = MR_sv(27);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(28);
	MR_restore_maxfr(MR_sv(26));
	MR_redoip_slot_word(MR_maxfr) = MR_sv(24);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(25);
	MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i205);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,192)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,193)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_redoip_slot_word(MR_maxfr) = MR_sv(24);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(25);
	MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i191);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,205)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = (MR_Word) MR_TAG_COMMON(0,4,2);
	MR_np_call_localret_ent(fn__hlds__make_hlds__add_type__abstract_monotype_workaround_0_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0_i207);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,207)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 2, (MR_Integer) 1);
	MR_tfield(2, MR_tempr1, 0) = MR_r1;
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr1;
	MR_tfield(1, MR_tempr2, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_sv(1);
	MR_tfield(1, MR_tempr1, 1) = MR_tempr2;
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr2, 0) = MR_sv(5);
	MR_tfield(0, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_tempr2;
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 3);
	MR_tfield(0, MR_tempr2, 0) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr2, 1) = (MR_Word) MR_tbmkword(0, 2);
	MR_tfield(0, MR_tempr2, 2) = MR_tempr1;
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_tempr2;
	MR_tfield(1, MR_r2, 1) = MR_sv(21);
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(30);
	}
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_109_111_100_117_108_101_95_97_100_100_95_116_121_112_101_95_100_101_102_110_95_95_91_53_93_95_48_11_0,191)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(21);
	MR_decr_sp_and_return(30);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__parse_tree__prog_data__cons_id_dummy_type_ctor_0_0);
MR_decl_entry(__Unify___parse_tree__prog_data__type_ctor_0_0);
MR_decl_entry(fn__hlds__hlds_out__hlds_out_util__cons_id_and_arity_to_string_1_0);
MR_decl_entry(fn__hlds__hlds_out__hlds_out_util__type_ctor_to_string_1_0);
MR_decl_entry(svmap__set_4_0);
MR_decl_entry(parse_tree__module_qual__get_partial_qualifiers_3_0);
MR_decl_entry(fn__list__map_2_0);

MR_BEGIN_MODULE(hlds__make_hlds__add_type_module18)
	MR_init_entry1(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0);
	MR_init_label10(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,106,3,4,5,9,12,17,15,19,22)
	MR_init_label10(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,20,24,29,30,27,32,33,34,26,56)
	MR_init_label10(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,57,58,61,60,63,66,67,69,72,73)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__ctors_add__[9]_0'/16 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(29);
	MR_sv(29) = (MR_Word) MR_succip;
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,106)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i3);
	}
	MR_r1 = MR_r10;
	MR_r2 = MR_r11;
	MR_r3 = MR_r12;
	MR_decr_sp_and_return(29);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_r4;
	MR_sv(4) = MR_r5;
	MR_sv(5) = MR_r6;
	MR_sv(6) = MR_r7;
	MR_sv(7) = MR_r8;
	MR_sv(8) = MR_r9;
	MR_sv(9) = MR_r10;
	MR_sv(10) = MR_r11;
	MR_sv(11) = MR_r12;
	MR_sv(12) = MR_tfield(1, MR_r1, 1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r1, 0);
	MR_sv(13) = MR_tfield(0, MR_tempr1, 0);
	MR_sv(14) = MR_tfield(0, MR_tempr1, 1);
	MR_sv(15) = MR_tfield(0, MR_tempr1, 2);
	MR_sv(16) = MR_tfield(0, MR_tempr1, 3);
	MR_sv(17) = MR_tfield(0, MR_tempr1, 4);
	MR_sv(25) = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, constructor_arg);
	MR_r1 = MR_sv(25);
	MR_r2 = MR_sv(16);
	}
	MR_np_call_localret_ent(list__length_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i4);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(15);
	MR_sv(15) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__mdbcomp__prim_data__unqualify_name_1_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i5);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_sv(19) = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(1, MR_tempr1, 1) = MR_r1;
	MR_tag_alloc_heap(MR_sv(20), 0, (MR_Integer) 1);
	MR_tfield(0, MR_sv(20), 0) = MR_r1;
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 3);
	MR_sv(21) = MR_tempr2;
	MR_tfield(1, MR_tempr2, 0) = MR_tempr1;
	MR_tfield(1, MR_tempr2, 1) = MR_sv(15);
	MR_tfield(1, MR_tempr2, 2) = MR_sv(1);
	MR_sv(18) = MR_r1;
	}
	MR_np_call_localret_ent(fn__parse_tree__prog_data__cons_id_dummy_type_ctor_0_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i9);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 3);
	MR_tfield(1, MR_r2, 0) = MR_sv(19);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_sv(15);
	MR_tfield(1, MR_r2, 1) = MR_tempr2;
	MR_tfield(1, MR_r2, 2) = MR_r1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 3);
	MR_sv(22) = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = MR_sv(20);
	MR_tfield(1, MR_tempr1, 1) = MR_tempr2;
	MR_tfield(1, MR_tempr1, 2) = MR_sv(1);
	MR_sv(19) = MR_r2;
	}
	MR_np_call_localret_ent(fn__parse_tree__prog_data__cons_id_dummy_type_ctor_0_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i12);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 3);
	MR_tfield(1, MR_tempr1, 0) = MR_sv(20);
	MR_tfield(1, MR_tempr1, 1) = MR_sv(15);
	MR_tfield(1, MR_tempr1, 2) = MR_r1;
	MR_tag_alloc_heap(MR_tempr2, 0, (MR_Integer) 8);
	MR_tfield(0, MR_tempr2, 0) = MR_sv(1);
	MR_tfield(0, MR_tempr2, 1) = MR_sv(3);
	MR_tfield(0, MR_tempr2, 2) = MR_sv(4);
	MR_tfield(0, MR_tempr2, 3) = MR_sv(5);
	MR_tfield(0, MR_tempr2, 4) = MR_sv(13);
	MR_tfield(0, MR_tempr2, 5) = MR_sv(14);
	MR_tfield(0, MR_tempr2, 6) = MR_sv(16);
	MR_tfield(0, MR_tempr2, 7) = MR_sv(17);
	MR_sv(13) = MR_tempr1;
	MR_sv(14) = MR_tempr2;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, cons_id);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,2,36);
	MR_r3 = MR_sv(10);
	MR_r4 = MR_sv(21);
	}
	MR_np_call_localret_ent(map__search_3_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i17);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i15);
	}
	MR_r3 = MR_sv(10);
	MR_r4 = MR_sv(19);
	MR_sv(20) = MR_r2;
	MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i19);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_sv(10);
	MR_r4 = MR_sv(19);
	MR_sv(20) = (MR_Word) MR_tbmkword(0, 0);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(10) = MR_r3;
	MR_sv(19) = MR_r4;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, cons_id);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,2,36);
	MR_np_call_localret_ent(map__search_3_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i22);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i20);
	}
	MR_sv(23) = MR_r2;
	MR_r2 = MR_sv(20);
	MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i24);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(20);
	MR_sv(23) = (MR_Word) MR_tbmkword(0, 0);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(26) = (MR_Word) MR_redoip_slot(MR_maxfr);
	MR_sv(27) = (MR_Word) MR_redofr_slot(MR_maxfr);
	MR_save_maxfr(MR_sv(28));
	MR_redofr_slot_word(MR_maxfr) = (MR_Word) MR_curfr;
	MR_redoip_slot_word(MR_maxfr) = (MR_Word) MR_LABEL_AP(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i27);
	MR_sv(20) = MR_r2;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_data, hlds_cons_defn);
	MR_np_call_localret_ent(list__member_2_1,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i29);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tfield(0, MR_tempr1, 0);
	}
	MR_np_call_localret_ent(__Unify___parse_tree__prog_data__type_ctor_0_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i30);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
	MR_restore_maxfr(MR_sv(28));
	MR_redoip_slot_word(MR_maxfr) = MR_sv(26);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(27);
	MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i32);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(20);
	MR_redoip_slot_word(MR_maxfr) = MR_sv(26);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(27);
	MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i26);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(21);
	MR_np_call_localret_ent(fn__hlds__hlds_out__hlds_out_util__cons_id_and_arity_to_string_1_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i33);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(24) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(fn__hlds__hlds_out__hlds_out_util__type_ctor_to_string_1_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i34);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6, MR_tempr7, MR_tempr8, MR_tempr9, MR_tempr10, MR_tempr11, MR_tempr12, MR_tempr13;
	MR_tag_alloc_heap(MR_tempr1, 2, (MR_Integer) 1);
	MR_r6 = MR_tempr1;
	MR_tfield(2, MR_tempr1, 0) = MR_sv(24);
	MR_tag_alloc_heap(MR_tempr2, 2, (MR_Integer) 1);
	MR_r7 = MR_tempr2;
	MR_tfield(2, MR_tempr2, 0) = MR_r1;
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 2);
	MR_r8 = MR_tempr3;
	MR_tfield(1, MR_tempr3, 0) = MR_tempr2;
	MR_tfield(1, MR_tempr3, 1) = (MR_Word) MR_TAG_COMMON(1,2,12);
	MR_tag_alloc_heap(MR_tempr4, 1, (MR_Integer) 2);
	MR_r7 = MR_tempr4;
	MR_tfield(1, MR_tempr4, 0) = (MR_Word) MR_TAG_COMMON(3,1,35);
	MR_tfield(1, MR_tempr4, 1) = MR_tempr3;
	MR_tag_alloc_heap(MR_tempr5, 1, (MR_Integer) 2);
	MR_r8 = MR_tempr5;
	MR_tfield(1, MR_tempr5, 0) = MR_tempr1;
	MR_tfield(1, MR_tempr5, 1) = MR_tempr4;
	MR_tag_alloc_heap(MR_tempr6, 1, (MR_Integer) 2);
	MR_r6 = MR_tempr6;
	MR_tfield(1, MR_tempr6, 0) = (MR_Word) MR_TAG_COMMON(3,1,34);
	MR_tfield(1, MR_tempr6, 1) = MR_tempr5;
	MR_tag_alloc_heap(MR_tempr7, 0, (MR_Integer) 1);
	MR_r7 = MR_tempr7;
	MR_tfield(0, MR_tempr7, 0) = MR_tempr6;
	MR_tag_alloc_heap(MR_tempr8, 1, (MR_Integer) 2);
	MR_r6 = MR_tempr8;
	MR_tfield(1, MR_tempr8, 0) = MR_tempr7;
	MR_tfield(1, MR_tempr8, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr9, 0, (MR_Integer) 2);
	MR_r7 = MR_tempr9;
	MR_tfield(0, MR_tempr9, 0) = MR_sv(17);
	MR_tfield(0, MR_tempr9, 1) = MR_tempr8;
	MR_tag_alloc_heap(MR_tempr10, 1, (MR_Integer) 2);
	MR_r6 = MR_tempr10;
	MR_tfield(1, MR_tempr10, 0) = MR_tempr9;
	MR_tfield(1, MR_tempr10, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_tempr11, 0, (MR_Integer) 3);
	MR_r8 = MR_tempr11;
	MR_tfield(0, MR_tempr11, 0) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr11, 1) = (MR_Word) MR_tbmkword(0, 2);
	MR_tfield(0, MR_tempr11, 2) = MR_tempr10;
	MR_tag_alloc_heap(MR_tempr12, 1, (MR_Integer) 2);
	MR_r6 = MR_tempr12;
	MR_tfield(1, MR_tempr12, 0) = MR_tempr11;
	MR_tfield(1, MR_tempr12, 1) = MR_sv(11);
	MR_tag_alloc_heap(MR_tempr13, 1, (MR_Integer) 2);
	MR_r8 = MR_tempr13;
	MR_tfield(1, MR_tempr13, 0) = MR_sv(14);
	MR_tfield(1, MR_tempr13, 1) = MR_sv(23);
	MR_r5 = MR_sv(10);
	MR_r3 = MR_sv(21);
	MR_r4 = MR_sv(20);
	MR_sv(10) = MR_tempr13;
	MR_sv(11) = MR_tempr12;
	MR_sv(20) = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_data, hlds_cons_defn);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,2,36);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, cons_id);
	MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i56);
	}
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_r4 = MR_tempr1;
	MR_tempr3 = MR_sv(14);
	MR_tfield(1, MR_tempr1, 0) = MR_tempr3;
	MR_tfield(1, MR_tempr1, 1) = MR_r2;
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr2, 0) = MR_tempr3;
	MR_tfield(1, MR_tempr2, 1) = MR_sv(23);
	MR_r5 = MR_sv(10);
	MR_r3 = MR_sv(21);
	MR_sv(10) = MR_tempr2;
	MR_sv(20) = (MR_Word) MR_CTOR0_ADDR(hlds__hlds_data, hlds_cons_defn);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,2,36);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, cons_id);
	}
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,56)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(21) = MR_r3;
	MR_sv(23) = MR_r2;
	MR_np_call_localret_ent(svmap__set_4_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i57);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,57)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, cons_id);
	MR_r2 = MR_sv(23);
	MR_r3 = MR_sv(19);
	MR_r4 = MR_sv(10);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(svmap__set_4_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i58);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,58)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(6),1)) {
		MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i60);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, cons_id);
	MR_r2 = MR_sv(20);
	MR_r3 = MR_sv(22);
	MR_r4 = MR_sv(14);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(svmulti_map__set_4_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i61);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,61)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, cons_id);
	MR_r2 = MR_sv(20);
	MR_r3 = MR_sv(13);
	MR_r4 = MR_sv(14);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(svmulti_map__set_4_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i60);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,60)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(10) = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(7);
	MR_np_call_localret_ent(parse_tree__module_qual__get_partial_qualifiers_3_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i63);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,63)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 7);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(8,0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(hlds__make_hlds__add_type__add_ctor_7_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 4;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 4) = MR_sv(18);
	MR_tfield(0, MR_tempr1, 5) = MR_sv(15);
	MR_tfield(0, MR_tempr1, 6) = MR_sv(14);
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 3);
	MR_tfield(0, MR_r2, 0) = (MR_Word) MR_CTOR_ADDR(tree234, tree234, 2);
	MR_tfield(0, MR_r2, 1) = (MR_Word) MR_CTOR0_ADDR(parse_tree__prog_data, cons_id);
	MR_tfield(0, MR_r2, 2) = MR_sv(23);
	MR_tempr2 = MR_sv(10);
	MR_sv(10) = MR_r1;
	MR_sv(19) = MR_r2;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name);
	MR_r4 = MR_sv(10);
	MR_r5 = MR_tempr2;
	}
	MR_np_call_localret_ent(list__foldl_4_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i66);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,66)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(13) = MR_r1;
	MR_np_call_localret_ent(fn__parse_tree__prog_data__cons_id_dummy_type_ctor_0_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i67);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,67)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 7);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(8,1);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(hlds__make_hlds__add_type__add_ctor_7_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 4;
	MR_tfield(0, MR_tempr1, 3) = MR_r1;
	MR_tfield(0, MR_tempr1, 4) = MR_sv(18);
	MR_tfield(0, MR_tempr1, 5) = MR_sv(15);
	MR_tfield(0, MR_tempr1, 6) = MR_sv(14);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdbcomp__prim_data, sym_name);
	MR_r2 = MR_sv(19);
	MR_r4 = MR_sv(10);
	MR_r5 = MR_sv(13);
	}
	MR_np_call_localret_ent(list__foldl_4_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i69);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,69)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(13) = MR_r1;
	MR_r1 = MR_sv(25);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,2,38);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,10,0);
	MR_r4 = MR_sv(16);
	MR_np_call_localret_ent(fn__list__map_2_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i72);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,72)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(6);
	MR_r3 = MR_sv(10);
	MR_r4 = MR_sv(1);
	MR_r5 = MR_sv(21);
	MR_r6 = MR_sv(17);
	MR_r7 = MR_sv(8);
	MR_r8 = (MR_Integer) 1;
	MR_r9 = MR_sv(9);
	MR_r10 = MR_sv(11);
	MR_np_call_localret_ent(hlds__make_hlds__add_type__add_ctor_field_names_12_0,
		f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i73);
MR_def_label(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0,73)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(12);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_sv(1);
	MR_r3 = MR_sv(2);
	MR_r4 = MR_sv(3);
	MR_r5 = MR_sv(4);
	MR_r6 = MR_sv(5);
	MR_r7 = MR_sv(6);
	MR_r8 = MR_sv(7);
	MR_r9 = MR_sv(8);
	MR_r10 = MR_tempr1;
	MR_r11 = MR_sv(13);
	MR_r12 = MR_tempr2;
	MR_succip_word = MR_sv(29);
	MR_GOTO_LAB(f_104_108_100_115_95_95_109_97_107_101_95_104_108_100_115_95_95_97_100_100_95_116_121_112_101_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_116_111_114_115_95_97_100_100_95_95_91_57_93_95_48_16_0_i106);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

static void mercury__hlds__make_hlds__add_type_maybe_bunch_0(void)
{
	hlds__make_hlds__add_type_module0();
	hlds__make_hlds__add_type_module1();
	hlds__make_hlds__add_type_module2();
	hlds__make_hlds__add_type_module3();
	hlds__make_hlds__add_type_module4();
	hlds__make_hlds__add_type_module5();
	hlds__make_hlds__add_type_module6();
	hlds__make_hlds__add_type_module7();
	hlds__make_hlds__add_type_module8();
	hlds__make_hlds__add_type_module9();
	hlds__make_hlds__add_type_module10();
	hlds__make_hlds__add_type_module11();
	hlds__make_hlds__add_type_module12();
	hlds__make_hlds__add_type_module13();
	hlds__make_hlds__add_type_module14();
	hlds__make_hlds__add_type_module15();
	hlds__make_hlds__add_type_module16();
	hlds__make_hlds__add_type_module17();
	hlds__make_hlds__add_type_module18();
}

/* suppress gcc -Wmissing-decls warnings */
void mercury__hlds__make_hlds__add_type__init(void);
void mercury__hlds__make_hlds__add_type__init_type_tables(void);
void mercury__hlds__make_hlds__add_type__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__hlds__make_hlds__add_type__write_out_proc_statics(FILE *deep_fp, FILE *procrep_fp);
#endif
#ifdef MR_RECORD_TERM_SIZES
void mercury__hlds__make_hlds__add_type__init_complexity_procs(void);
#endif

void mercury__hlds__make_hlds__add_type__init(void)
{
	static MR_bool done = MR_FALSE;
	if (done) {
		return;
	}
	done = MR_TRUE;
	mercury__hlds__make_hlds__add_type_maybe_bunch_0();
	mercury__hlds__make_hlds__add_type__init_debugger();
}

void mercury__hlds__make_hlds__add_type__init_type_tables(void)
{
	static MR_bool done = MR_FALSE;
	if (done) {
		return;
	}
	done = MR_TRUE;
}


void mercury__hlds__make_hlds__add_type__init_debugger(void)
{
	static MR_bool done = MR_FALSE;
	if (done) {
		return;
	}
	done = MR_TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__hlds__make_hlds__add_type__write_out_proc_statics(FILE *deep_fp, FILE *procrep_fp)
{
	MR_write_out_module_proc_reps_start(procrep_fp, &mercury_data__module_common_layout__hlds__make_hlds__add_type);
	MR_write_out_module_proc_reps_end(procrep_fp);
}

#endif

#ifdef MR_RECORD_TERM_SIZES

void mercury__hlds__make_hlds__add_type__init_complexity_procs(void)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
