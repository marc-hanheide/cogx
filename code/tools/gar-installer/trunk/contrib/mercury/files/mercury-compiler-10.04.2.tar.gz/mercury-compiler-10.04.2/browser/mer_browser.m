%-----------------------------------------------------------------------------%
% vim: ft=mercury ts=4 sw=4 et
%-----------------------------------------------------------------------------%
% Copyright (C) 2002, 2006 The University of Melbourne.
% This file may only be copied under the terms of the GNU General
% Public License - see the file COPYING in the Mercury distribution.
%-----------------------------------------------------------------------------%
% File: mer_browser.m
% Main author: stayl
%
% This file is only present so that the browser library is
% generated with the correct name.
%-----------------------------------------------------------------------------%
:- module mer_browser.

:- implementation.

:- import_module mdb.
