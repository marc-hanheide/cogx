/*
** Automatically generated from `declarative_user.m'
** by the Mercury compiler,
** version 10.04.2, configured for x86_64-unknown-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
** HIGHLEVEL_CODE=no
**
** END_OF_C_GRADE_INFO
*/

/*
INIT mercury__mdb__declarative_user__init
ENDINIT
*/

#define MR_ALLOW_RESET
#include "mercury_imp.h"
#line 3 "mdb.int0"
#include "mdb.mh"

#line 28 "mdb.declarative_user.c"
#line 539 "../library/io.int"
#include "io.mh"

#line 32 "mdb.declarative_user.c"
#line 547 "../library/io.int"
#include "string.mh"

#line 36 "mdb.declarative_user.c"
#line 231 "../mdbcomp/mdbcomp.program_representation.int"
#include "mdbcomp.program_representation.mh"

#line 40 "mdb.declarative_user.c"
#line 67 "../mdbcomp/mdbcomp.rtti_access.int"
#include "mdbcomp.rtti_access.mh"

#line 44 "mdb.declarative_user.c"
#line 29 "../library/bitmap.int2"
#include "bitmap.mh"

#line 48 "mdb.declarative_user.c"
#line 28 "../library/time.int2"
#include "time.mh"

#line 52 "mdb.declarative_user.c"
#line 21 "../library/stm_builtin.int2"
#include "stm_builtin.mh"

#line 56 "mdb.declarative_user.c"
#line 31 "../library/store.int2"
#include "store.mh"

#line 60 "mdb.declarative_user.c"
#line 31 "../library/array.int2"
#include "array.mh"

#line 64 "mdb.declarative_user.c"
#line 65 "mdb.declarative_user.c"
#include "mdb.declarative_user.mh"

#line 68 "mdb.declarative_user.c"
#line 69 "mdb.declarative_user.c"
#ifndef MDB__DECLARATIVE_USER_DECL_GUARD
#define MDB__DECLARATIVE_USER_DECL_GUARD

#line 73 "mdb.declarative_user.c"
#line 74 "mdb.declarative_user.c"

#endif
#line 77 "mdb.declarative_user.c"

#ifdef _MSC_VER
#define MR_STATIC_LINKAGE extern
#else
#define MR_STATIC_LINKAGE static
#endif

struct mercury_type_0 {
	MR_Word * f1[2];
};
MR_STATIC_LINKAGE const struct mercury_type_0 mercury_common_0[];

struct mercury_type_1 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[5];
};
MR_STATIC_LINKAGE const struct mercury_type_1 mercury_common_1[];

struct mercury_type_2 {
	MR_String f1[2];
};
MR_STATIC_LINKAGE const struct mercury_type_2 mercury_common_2[];

struct mercury_type_3 {
	MR_Word * f1;
	MR_Word * f2;
	MR_Integer f3;
	MR_Word * f4;
	MR_Word * f5;
};
MR_STATIC_LINKAGE const struct mercury_type_3 mercury_common_3[];

struct mercury_type_4 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[4];
};
MR_STATIC_LINKAGE const struct mercury_type_4 mercury_common_4[];

struct mercury_type_5 {
	MR_Word * f1;
	MR_Code * f2;
	MR_Integer f3;
};
MR_STATIC_LINKAGE const struct mercury_type_5 mercury_common_5[];

struct mercury_type_6 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[3];
};
MR_STATIC_LINKAGE const struct mercury_type_6 mercury_common_6[];

struct mercury_type_7 {
	MR_Word * f1;
	MR_Code * f2;
	MR_Integer f3;
	MR_Word * f4;
};
MR_STATIC_LINKAGE const struct mercury_type_7 mercury_common_7[];

struct mercury_type_8 {
	MR_Word * f1;
	MR_Code * f2;
	MR_Integer f3;
	MR_String f4;
};
MR_STATIC_LINKAGE const struct mercury_type_8 mercury_common_8[];

struct mercury_type_9 {
	MR_Integer f1;
	MR_Word * f2;
};
MR_STATIC_LINKAGE const struct mercury_type_9 mercury_common_9[];

struct mercury_type_10 {
	MR_Word * f1;
	MR_Word * f2;
	MR_Integer f3;
	MR_Word * f4;
};
MR_STATIC_LINKAGE const struct mercury_type_10 mercury_common_10[];

struct mercury_type_11 {
	MR_String f1;
	MR_Word * f2;
};
MR_STATIC_LINKAGE const struct mercury_type_11 mercury_common_11[];

struct mercury_type_12 {
	MR_String f1;
	MR_Word * f2;
	MR_Word * f3;
};
MR_STATIC_LINKAGE const struct mercury_type_12 mercury_common_12[];

struct mercury_type_13 {
	MR_Word * f1[2];
	MR_Integer f2;
	MR_Word * f3[6];
};
MR_STATIC_LINKAGE const struct mercury_type_13 mercury_common_13[];

struct mercury_type_14 {
	MR_Word * f1;
};
MR_STATIC_LINKAGE const struct mercury_type_14 mercury_common_14[];

struct mercury_type_15 {
	MR_Integer f1;
};
MR_STATIC_LINKAGE const struct mercury_type_15 mercury_common_15[];

struct mercury_type_16 {
	MR_Integer f1[2];
};
MR_STATIC_LINKAGE const struct mercury_type_16 mercury_common_16[];

extern const MR_TypeCtorInfo_Struct
	mercury_data_mdb__declarative_user__type_ctor_info_user_command_0,
	mercury_data_mdb__declarative_user__type_ctor_info_user_question_1,
	mercury_data_mdb__declarative_user__type_ctor_info_user_response_1,
	mercury_data_mdb__declarative_user__type_ctor_info_user_search_mode_0,
	mercury_data_mdb__declarative_user__type_ctor_info_user_state_0;
MR_decl_label2(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_105_111_95_97_99_116_105_111_110_115_95_95_91_49_93_95_48_2_0, 3,4)
MR_decl_label2(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_116_114_97_99_101_95_97_116_111_109_115_95_95_91_49_93_95_48_3_0, 3,4)
MR_decl_label10(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0, 7,5,8,3,12,10,13,9,15,16)
MR_decl_label10(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0, 5,8,3,12,13,14,15,16,11,36)
MR_decl_label10(mdb__declarative_user__browse_arg_cmd_2_0, 117,9,7,14,6,22,21,27,26,31)
MR_decl_label1(mdb__declarative_user__browse_arg_cmd_2_0, 1)
MR_decl_label10(mdb__declarative_user__browse_atom_7_0, 2,3,4,6,7,8,9,10,13,15)
MR_decl_label3(mdb__declarative_user__browse_atom_7_0, 16,17,14)
MR_decl_label10(mdb__declarative_user__browse_atom_argument_8_0, 2,3,5,8,9,12,14,15,16,13)
MR_decl_label2(mdb__declarative_user__browse_atom_argument_8_0, 4,19)
MR_decl_label4(mdb__declarative_user__browse_chosen_io_action_7_0, 3,5,10,7)
MR_decl_label5(mdb__declarative_user__browse_decl_bug_6_0, 5,3,2,8,10)
MR_decl_label6(mdb__declarative_user__browse_io_action_6_0, 2,3,5,6,7,4)
MR_decl_label8(mdb__declarative_user__browse_xml_atom_4_0, 2,3,4,6,7,8,9,10)
MR_decl_label6(mdb__declarative_user__browse_xml_atom_argument_5_0, 2,3,5,8,9,4)
MR_decl_label10(mdb__declarative_user__browse_xml_decl_bug_5_0, 5,3,2,9,10,11,13,14,15,16)
MR_decl_label2(mdb__declarative_user__browse_xml_decl_bug_5_0, 17,8)
MR_decl_label10(mdb__declarative_user__cmd_handler_2_0, 3,5,7,9,11,13,15,17,19,21)
MR_decl_label10(mdb__declarative_user__cmd_handler_2_0, 23,25,27,29,31,33,35,37,39,41)
MR_decl_label10(mdb__declarative_user__cmd_handler_2_0, 43,45,47,49,51,53,55,57,59,61)
MR_decl_label3(mdb__declarative_user__cmd_handler_2_0, 63,66,1)
MR_decl_label10(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0, 72,8,11,13,10,7,5,20,4,24)
MR_decl_label2(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0, 22,28)
MR_decl_label4(mdb__declarative_user__count_tabled_io_actions_2_8_0, 17,2,3,5)
MR_decl_label5(mdb__declarative_user__find_tabled_io_action_5_0, 34,2,3,5,8)
MR_decl_label2(mdb__declarative_user__format_arg_cmd_2_0, 4,1)
MR_decl_label6(mdb__declarative_user__format_param_arg_cmd_3_0, 7,13,15,2,21,1)
MR_decl_label10(mdb__declarative_user__get_command_6_0, 2,19,4,6,7,5,10,12,14,16)
MR_decl_label1(mdb__declarative_user__get_command_6_0, 13)
MR_decl_label6(mdb__declarative_user__get_user_arg_values_2_0, 36,4,9,8,11,35)
MR_decl_label10(mdb__declarative_user__handle_command_7_0, 292,3,8,10,11,6,13,17,18,16)
MR_decl_label10(mdb__declarative_user__handle_command_7_0, 21,24,25,23,29,30,28,32,34,35)
MR_decl_label10(mdb__declarative_user__handle_command_7_0, 33,39,38,42,41,44,46,47,45,51)
MR_decl_label10(mdb__declarative_user__handle_command_7_0, 52,55,57,61,60,63,64,54,67,169)
MR_decl_label10(mdb__declarative_user__handle_command_7_0, 69,71,72,50,76,77,79,75,84,85)
MR_decl_label10(mdb__declarative_user__handle_command_7_0, 83,88,92,97,176,99,90,107,104,111)
MR_decl_label5(mdb__declarative_user__handle_command_7_0, 112,110,115,116,117)
MR_decl_label2(mdb__declarative_user__help_cmd_2_0, 3,1)
MR_decl_label2(mdb__declarative_user__num_io_actions_cmd_2_0, 4,1)
MR_decl_label1(mdb__declarative_user__one_word_cmd_3_0, 1)
MR_decl_label10(mdb__declarative_user__print_arg_cmd_2_0, 166,8,6,12,15,17,19,21,5,30)
MR_decl_label7(mdb__declarative_user__print_arg_cmd_2_0, 28,34,37,39,41,43,1)
MR_decl_label10(mdb__declarative_user__print_atom_arguments_6_0, 34,2,3,5,8,9,10,4,11,12)
MR_decl_label1(mdb__declarative_user__print_atom_arguments_6_0, 36)
MR_decl_label9(mdb__declarative_user__print_chosen_io_actions_6_0, 32,3,5,8,7,9,10,2,34)
MR_decl_label6(mdb__declarative_user__print_tabled_io_actions_2_5_0, 18,3,13,5,6,20)
MR_decl_label8(mdb__declarative_user__query_user_6_0, 7,8,9,11,12,5,18,4)
MR_decl_label10(mdb__declarative_user__search_mode_cmd_2_0, 5,7,9,11,13,15,17,19,21,23)
MR_decl_label1(mdb__declarative_user__search_mode_cmd_2_0, 1)
MR_decl_label1(mdb__declarative_user__trace_atom_arg_to_univ_2_0, 3)
MR_decl_label2(mdb__declarative_user__trust_arg_cmd_2_0, 3,1)
MR_decl_label10(mdb__declarative_user__user_confirm_bug_6_0, 78,4,5,7,8,30,9,11,10,13)
MR_decl_label5(mdb__declarative_user__user_confirm_bug_6_0, 20,22,18,16,25)
MR_decl_label10(mdb__declarative_user__write_decl_atom_6_0, 2,3,4,5,6,7,9,10,11,12)
MR_decl_label3(mdb__declarative_user__write_decl_atom_6_0, 15,16,13)
MR_decl_label10(mdb__declarative_user__write_decl_bug_4_0, 6,7,9,10,5,13,14,12,16,17)
MR_decl_label9(mdb__declarative_user__write_decl_bug_4_0, 18,19,20,21,3,23,24,26,27)
MR_decl_label8(mdb__declarative_user__write_io_actions_5_0, 4,7,8,10,12,11,14,35)
MR_decl_label2(fn__mdb__declarative_user__arg_num_to_arg_pos_1_0, 2,4)
MR_decl_label9(fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0, 2,4,5,7,6,12,10,15,14)
MR_decl_label8(fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0, 2,3,5,4,10,8,13,12)
MR_decl_label10(__Unify___mdb__declarative_user__user_command_0_0, 5,6,7,8,9,10,11,12,13,14)
MR_decl_label10(__Unify___mdb__declarative_user__user_command_0_0, 15,16,17,18,22,26,28,30,34,90)
MR_decl_label2(__Unify___mdb__declarative_user__user_command_0_0, 38,1)
MR_decl_label4(__Unify___mdb__declarative_user__user_question_1_0, 16,5,10,1)
MR_decl_label10(__Unify___mdb__declarative_user__user_response_1_0, 5,6,9,7,13,17,19,51,23,1)
MR_decl_label6(__Unify___mdb__declarative_user__user_state_0_0, 4,6,8,10,12,1)
MR_decl_label10(__Compare___mdb__declarative_user__user_command_0_0, 5,6,7,8,9,10,11,12,13,14)
MR_decl_label10(__Compare___mdb__declarative_user__user_command_0_0, 15,16,17,18,19,20,21,22,23,24)
MR_decl_label10(__Compare___mdb__declarative_user__user_command_0_0, 4,26,27,28,29,30,31,32,33,34)
MR_decl_label10(__Compare___mdb__declarative_user__user_command_0_0, 35,36,37,38,39,40,41,42,43,44)
MR_decl_label10(__Compare___mdb__declarative_user__user_command_0_0, 45,25,46,47,50,51,52,53,54,55)
MR_decl_label10(__Compare___mdb__declarative_user__user_command_0_0, 56,57,58,59,60,61,229,62,63,66)
MR_decl_label9(__Compare___mdb__declarative_user__user_command_0_0, 69,72,75,78,84,81,91,48,100)
MR_decl_label7(__Compare___mdb__declarative_user__user_question_1_0, 3,2,7,5,10,12,45)
MR_decl_label10(__Compare___mdb__declarative_user__user_response_1_0, 7,8,9,10,11,12,5,16,164,17)
MR_decl_label10(__Compare___mdb__declarative_user__user_response_1_0, 18,19,20,21,14,25,26,29,27,34)
MR_decl_label10(__Compare___mdb__declarative_user__user_response_1_0, 35,36,23,40,41,42,43,45,46,38)
MR_decl_label10(__Compare___mdb__declarative_user__user_response_1_0, 50,51,52,53,54,56,48,60,61,62)
MR_decl_label10(__Compare___mdb__declarative_user__user_response_1_0, 63,64,65,58,70,71,72,73,74,75)
MR_decl_label10(__Compare___mdb__declarative_user__user_response_1_0, 68,79,80,81,149,82,83,84,152,85)
MR_decl_label1(__Compare___mdb__declarative_user__user_response_1_0, 87)
MR_decl_label8(__Compare___mdb__declarative_user__user_state_0_0, 3,2,5,9,13,17,21,53)
MR_def_extern_entry(mdb__declarative_user__user_state_init_5_0)
MR_decl_static(fn__mdb__declarative_user__arg_num_to_arg_pos_1_0)
MR_decl_static(mdb__declarative_user__find_tabled_io_action_5_0)
MR_decl_static(mdb__declarative_user__browse_io_action_6_0)
MR_decl_static(mdb__declarative_user__browse_chosen_io_action_7_0)
MR_decl_static(mdb__declarative_user__print_chosen_io_actions_6_0)
MR_decl_static(mdb__declarative_user__browse_atom_argument_8_0)
MR_decl_static(mdb__declarative_user__browse_xml_atom_argument_5_0)
MR_decl_static(mdb__declarative_user__get_user_arg_values_2_0)
MR_decl_static(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0)
MR_decl_static(mdb__declarative_user__browse_atom_7_0)
MR_decl_static(mdb__declarative_user__browse_xml_atom_4_0)
MR_decl_static(fn__mdb__declarative_user__decl_caller_type_0_0)
MR_decl_static(mdb__declarative_user__print_atom_arguments_6_0)
MR_decl_static(mdb__declarative_user__cmd_handler_2_0)
MR_decl_static(mdb__declarative_user__get_command_6_0)
MR_decl_static(mdb__declarative_user__count_tabled_io_actions_2_8_0)
MR_decl_static(mdb__declarative_user__print_tabled_io_actions_2_5_0)
MR_decl_static(mdb__declarative_user__write_io_actions_5_0)
MR_decl_static(mdb__declarative_user__write_decl_atom_6_0)
MR_decl_static(mdb__declarative_user__write_decl_init_atom_6_0)
MR_decl_static(mdb__declarative_user__write_decl_final_atom_6_0)
MR_def_extern_entry(mdb__declarative_user__query_user_6_0)
MR_decl_static(mdb__declarative_user__handle_command_7_0)
MR_decl_static(mdb__declarative_user__browse_decl_bug_6_0)
MR_decl_static(mdb__declarative_user__browse_xml_decl_bug_5_0)
MR_decl_static(mdb__declarative_user__user_confirm_bug_help_3_0)
MR_decl_static(mdb__declarative_user__write_decl_bug_4_0)
MR_def_extern_entry(mdb__declarative_user__user_confirm_bug_6_0)
MR_def_extern_entry(fn__mdb__declarative_user__get_browser_state_1_0)
MR_def_extern_entry(mdb__declarative_user__set_browser_state_3_0)
MR_def_extern_entry(fn__mdb__declarative_user__get_user_output_stream_1_0)
MR_def_extern_entry(fn__mdb__declarative_user__get_user_input_stream_1_0)
MR_def_extern_entry(mdb__declarative_user__set_user_testing_flag_3_0)
MR_decl_static(fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0)
MR_decl_static(fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0)
MR_decl_static(mdb__declarative_user__one_word_cmd_3_0)
MR_decl_static(mdb__declarative_user__browse_arg_cmd_2_0)
MR_decl_static(mdb__declarative_user__print_arg_cmd_2_0)
MR_decl_static(mdb__declarative_user__format_arg_cmd_2_0)
MR_decl_static(mdb__declarative_user__format_param_arg_cmd_3_0)
MR_decl_static(mdb__declarative_user__num_io_actions_cmd_2_0)
MR_decl_static(mdb__declarative_user__trust_arg_cmd_2_0)
MR_decl_static(mdb__declarative_user__search_mode_cmd_2_0)
MR_decl_static(mdb__declarative_user__help_cmd_2_0)
MR_decl_static(mdb__declarative_user__is_dash_1_0)
MR_decl_static(mdb__declarative_user__trace_atom_arg_to_univ_2_0)
MR_decl_static(__Unify___mdb__declarative_user__user_command_0_0)
MR_decl_static(__Compare___mdb__declarative_user__user_command_0_0)
MR_def_extern_entry(__Unify___mdb__declarative_user__user_question_1_0)
MR_def_extern_entry(__Compare___mdb__declarative_user__user_question_1_0)
MR_def_extern_entry(__Unify___mdb__declarative_user__user_response_1_0)
MR_def_extern_entry(__Compare___mdb__declarative_user__user_response_1_0)
MR_def_extern_entry(__Unify___mdb__declarative_user__user_search_mode_0_0)
MR_def_extern_entry(__Compare___mdb__declarative_user__user_search_mode_0_0)
MR_def_extern_entry(__Unify___mdb__declarative_user__user_state_0_0)
MR_def_extern_entry(__Compare___mdb__declarative_user__user_state_0_0)
MR_decl_static(mdb__declarative_user__IntroducedFrom__pred__browse_atom__695__1_2_0)
MR_decl_static(mdb__declarative_user__IntroducedFrom__pred__browse_xml_atom__714__1_2_0)
MR_decl_static(fn__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_103_101_116_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_1_0)
MR_decl_static(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0)
MR_decl_static(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_116_114_97_99_101_95_97_116_111_109_115_95_95_91_49_93_95_48_3_0)
MR_decl_static(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_105_111_95_97_99_116_105_111_110_115_95_95_91_49_93_95_48_2_0)
MR_decl_static(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0)

extern const MR_TypeCtorInfo_Struct mercury_data_list__type_ctor_info_list_1;
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__browser_info__type_ctor_info_dir_0;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_string_0;
static const struct mercury_type_0 mercury_common_0[2] =
{
{
{
MR_LIST_CTOR_ADDR,
MR_CTOR0_ADDR(mdb__browser_info, dir)
}
},
{
{
MR_LIST_CTOR_ADDR,
MR_STRING_CTOR_ADDR
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__browse_atom_argument_8_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_int_0;
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__declarative_execution__type_ctor_info_trace_atom_0;
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__browser_info__type_ctor_info_browser_term_mode_0;
static const struct mercury_type_1 mercury_common_1[1] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__browse_atom_argument_8_0_1,
(MR_Word *) (MR_Integer) 0
},
5,
{
MR_INT_CTOR_ADDR,
MR_CTOR0_ADDR(mdb__declarative_execution, trace_atom),
MR_CTOR0_ADDR(mdb__declarative_execution, trace_atom),
MR_COMMON(0,0),
MR_CTOR0_ADDR(mdb__browser_info, browser_term_mode)
}
},
};

static const struct mercury_type_2 mercury_common_2[3] =
{
{
{
MR_string_const("convert_dirs_to_term_path_from_atom", 35),
MR_string_const("argument list empty", 19)
}
},
{
{
MR_string_const("convert_dirs_to_term_path_from_atom", 35),
MR_string_const("argument of atom cannot be named", 32)
}
},
{
{
MR_string_const("convert_dirs_to_term_path_from_atom", 35),
MR_string_const("no value for first position in path", 35)
}
},
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__browse_atom_7_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_mdbcomp__prim_data__type_ctor_info_pred_or_func_0;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__browse_xml_atom_4_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__declarative_user__type_ctor_info_user_command_0;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_3;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_4;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_6;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_8;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_11;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_16;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_18;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_26;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_27;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_29;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_30;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_32;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__write_decl_atom_6_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__declarative_execution__type_ctor_info_trace_atom_arg_0;
extern const MR_TypeCtorInfo_Struct mercury_data_univ__type_ctor_info_univ_0;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__browse_xml_decl_bug_5_0_1;
static const struct mercury_type_3 mercury_common_3[17] =
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__browse_atom_7_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(mdbcomp__prim_data, pred_or_func),
MR_CTOR0_ADDR(mdbcomp__prim_data, pred_or_func)
},
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__browse_xml_atom_4_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(mdbcomp__prim_data, pred_or_func),
MR_CTOR0_ADDR(mdbcomp__prim_data, pred_or_func)
},
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
},
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_3,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
},
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_4,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
},
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_6,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
},
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_8,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
},
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_11,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
},
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_16,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
},
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_18,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
},
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_26,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
},
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_27,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
},
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_29,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
},
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_30,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
},
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_32,
(MR_Word *) (MR_Integer) 0,
2,
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
},
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__write_decl_atom_6_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(mdb__declarative_execution, trace_atom_arg),
MR_CTOR0_ADDR(univ, univ)
},
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__browse_xml_decl_bug_5_0_1,
(MR_Word *) (MR_Integer) 0,
2,
MR_CTOR0_ADDR(mdbcomp__prim_data, pred_or_func),
MR_CTOR0_ADDR(mdbcomp__prim_data, pred_or_func)
},
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__browse_atom_7_0_2;
static const struct mercury_type_4 mercury_common_4[1] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__browse_atom_7_0_2,
(MR_Word *) (MR_Integer) 0
},
4,
{
MR_CTOR0_ADDR(mdb__declarative_execution, trace_atom),
MR_CTOR0_ADDR(mdb__declarative_execution, trace_atom),
MR_COMMON(0,0),
MR_CTOR0_ADDR(mdb__browser_info, browser_term_mode)
}
},
};

MR_decl_entry(char__is_whitespace_1_0);
static const struct mercury_type_5 mercury_common_5[17] =
{
{
MR_COMMON(3,2),
MR_ENTRY_AP(mdb__declarative_user__help_cmd_2_0),
0
},
{
MR_COMMON(3,3),
MR_ENTRY_AP(mdb__declarative_user__browse_arg_cmd_2_0),
0
},
{
MR_COMMON(3,4),
MR_ENTRY_AP(mdb__declarative_user__help_cmd_2_0),
0
},
{
MR_COMMON(3,5),
MR_ENTRY_AP(mdb__declarative_user__search_mode_cmd_2_0),
0
},
{
MR_COMMON(3,6),
MR_ENTRY_AP(mdb__declarative_user__print_arg_cmd_2_0),
0
},
{
MR_COMMON(3,7),
MR_ENTRY_AP(mdb__declarative_user__trust_arg_cmd_2_0),
0
},
{
MR_COMMON(3,8),
MR_ENTRY_AP(mdb__declarative_user__help_cmd_2_0),
0
},
{
MR_COMMON(3,9),
MR_ENTRY_AP(mdb__declarative_user__search_mode_cmd_2_0),
0
},
{
MR_COMMON(3,10),
MR_ENTRY_AP(mdb__declarative_user__print_arg_cmd_2_0),
0
},
{
MR_COMMON(3,11),
MR_ENTRY_AP(mdb__declarative_user__trust_arg_cmd_2_0),
0
},
{
MR_COMMON(3,12),
MR_ENTRY_AP(mdb__declarative_user__browse_arg_cmd_2_0),
0
},
{
MR_COMMON(3,13),
MR_ENTRY_AP(mdb__declarative_user__format_arg_cmd_2_0),
0
},
{
MR_COMMON(3,14),
MR_ENTRY_AP(mdb__declarative_user__num_io_actions_cmd_2_0),
0
},
{
MR_COMMON(10,0),
MR_ENTRY_AP(char__is_whitespace_1_0),
0
},
{
MR_COMMON(3,15),
MR_ENTRY_AP(mdb__declarative_user__trace_atom_arg_to_univ_2_0),
0
},
{
MR_COMMON(10,1),
MR_ENTRY_AP(mdb__declarative_user__is_dash_1_0),
0
},
{
MR_COMMON(10,2),
MR_ENTRY_AP(mdb__declarative_user__is_dash_1_0),
0
},
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_2;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_5;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_7;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_9;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_10;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_12;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_13;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_14;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_15;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_17;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_19;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_20;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_string_0;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_21;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_22;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_23;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_24;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_25;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_28;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_31;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_33;
static const struct mercury_type_6 mercury_common_6[20] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_2,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(mdb__declarative_user, user_command),
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_5,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(mdb__declarative_user, user_command),
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_7,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(mdb__declarative_user, user_command),
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_9,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(mdb__declarative_user, user_command),
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_10,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(mdb__declarative_user, user_command),
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_12,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(mdb__declarative_user, user_command),
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_13,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(mdb__declarative_user, user_command),
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_14,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(mdb__declarative_user, user_command),
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_15,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(mdb__declarative_user, user_command),
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_17,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(mdb__declarative_user, user_command),
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_19,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(mdb__declarative_user, user_command),
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_20,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_STRING_CTOR_ADDR,
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_21,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(mdb__declarative_user, user_command),
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_22,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(mdb__declarative_user, user_command),
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_23,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(mdb__declarative_user, user_command),
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_24,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_STRING_CTOR_ADDR,
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_25,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_STRING_CTOR_ADDR,
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_28,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_STRING_CTOR_ADDR,
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_31,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(mdb__declarative_user, user_command),
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_33,
(MR_Word *) (MR_Integer) 0
},
3,
{
MR_CTOR0_ADDR(mdb__declarative_user, user_command),
MR_COMMON(0,1),
MR_CTOR0_ADDR(mdb__declarative_user, user_command)
}
},
};

static const struct mercury_type_7 mercury_common_7[16] =
{
{
MR_COMMON(6,0),
MR_ENTRY_AP(mdb__declarative_user__one_word_cmd_3_0),
1,
MR_tbmkword(0, 10)
},
{
MR_COMMON(6,1),
MR_ENTRY_AP(mdb__declarative_user__one_word_cmd_3_0),
1,
MR_tbmkword(0, 2)
},
{
MR_COMMON(6,2),
MR_ENTRY_AP(mdb__declarative_user__one_word_cmd_3_0),
1,
MR_tbmkword(0, 1)
},
{
MR_COMMON(6,3),
MR_ENTRY_AP(mdb__declarative_user__one_word_cmd_3_0),
1,
MR_tbmkword(0, 10)
},
{
MR_COMMON(6,4),
MR_ENTRY_AP(mdb__declarative_user__one_word_cmd_3_0),
1,
MR_tbmkword(0, 3)
},
{
MR_COMMON(6,5),
MR_ENTRY_AP(mdb__declarative_user__one_word_cmd_3_0),
1,
MR_tbmkword(0, 0)
},
{
MR_COMMON(6,6),
MR_ENTRY_AP(mdb__declarative_user__one_word_cmd_3_0),
1,
MR_tbmkword(0, 1)
},
{
MR_COMMON(6,7),
MR_ENTRY_AP(mdb__declarative_user__one_word_cmd_3_0),
1,
MR_tbmkword(0, 4)
},
{
MR_COMMON(6,8),
MR_ENTRY_AP(mdb__declarative_user__one_word_cmd_3_0),
1,
MR_tbmkword(0, 0)
},
{
MR_COMMON(6,9),
MR_ENTRY_AP(mdb__declarative_user__one_word_cmd_3_0),
1,
MR_tbmkword(0, 7)
},
{
MR_COMMON(6,10),
MR_ENTRY_AP(mdb__declarative_user__one_word_cmd_3_0),
1,
MR_tbmkword(0, 10)
},
{
MR_COMMON(6,12),
MR_ENTRY_AP(mdb__declarative_user__one_word_cmd_3_0),
1,
MR_tbmkword(0, 3)
},
{
MR_COMMON(6,13),
MR_ENTRY_AP(mdb__declarative_user__one_word_cmd_3_0),
1,
MR_tbmkword(0, 8)
},
{
MR_COMMON(6,14),
MR_ENTRY_AP(mdb__declarative_user__one_word_cmd_3_0),
1,
MR_tbmkword(0, 10)
},
{
MR_COMMON(6,18),
MR_ENTRY_AP(mdb__declarative_user__one_word_cmd_3_0),
1,
MR_TAG_COMMON(3,9,0)
},
{
MR_COMMON(6,19),
MR_ENTRY_AP(mdb__declarative_user__one_word_cmd_3_0),
1,
MR_tbmkword(0, 2)
},
};

static const struct mercury_type_8 mercury_common_8[4] =
{
{
MR_COMMON(6,11),
MR_ENTRY_AP(mdb__declarative_user__format_param_arg_cmd_3_0),
1,
MR_string_const("size", 4)
},
{
MR_COMMON(6,15),
MR_ENTRY_AP(mdb__declarative_user__format_param_arg_cmd_3_0),
1,
MR_string_const("depth", 5)
},
{
MR_COMMON(6,16),
MR_ENTRY_AP(mdb__declarative_user__format_param_arg_cmd_3_0),
1,
MR_string_const("lines", 5)
},
{
MR_COMMON(6,17),
MR_ENTRY_AP(mdb__declarative_user__format_param_arg_cmd_3_0),
1,
MR_string_const("width", 5)
},
};

static const struct mercury_type_9 mercury_common_9[2] =
{
{
3,
MR_tbmkword(0, 0)
},
{
5,
MR_tbmkword(0, 0)
},
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__get_command_6_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_character_0;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__print_arg_cmd_2_0_1;
static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__print_arg_cmd_2_0_2;
static const struct mercury_type_10 mercury_common_10[3] =
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__get_command_6_0_1,
(MR_Word *) (MR_Integer) 0,
1,
MR_CHAR_CTOR_ADDR
},
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__print_arg_cmd_2_0_1,
(MR_Word *) (MR_Integer) 0,
1,
MR_CHAR_CTOR_ADDR
},
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__print_arg_cmd_2_0_2,
(MR_Word *) (MR_Integer) 0,
1,
MR_CHAR_CTOR_ADDR
},
};

static const struct mercury_type_11 mercury_common_11[10] =
{
{
MR_string_const("decl_debug", 10),
MR_tbmkword(0, 0)
},
{
MR_string_const("concepts", 8),
MR_TAG_COMMON(1,11,0)
},
{
MR_string_const("\n", 1),
MR_tbmkword(0, 0)
},
{
MR_string_const("\th, ?\thelp\t\tthis help message\n", 30),
MR_tbmkword(0, 0)
},
{
MR_string_const("abort this diagnosis session and return to mdb\n", 47),
MR_TAG_COMMON(1,11,3)
},
{
MR_string_const("\tq\tquit\t\t", 9),
MR_TAG_COMMON(1,11,4)
},
{
MR_string_const("\tb\tbrowse\t\tbrowse the suspect\n", 30),
MR_TAG_COMMON(1,11,5)
},
{
MR_string_const("\tn\tno\t\tdo not accept that the suspect is a bug\n", 47),
MR_TAG_COMMON(1,11,6)
},
{
MR_string_const("\ty\tyes\t\tconfirm that the suspect is a bug\n", 42),
MR_TAG_COMMON(1,11,7)
},
{
MR_string_const("Answer one of:\n", 15),
MR_TAG_COMMON(1,11,8)
},
};

static const struct mercury_type_12 mercury_common_12[1] =
{
{
MR_string_const("", 0),
MR_tbmkword(0, 0),
MR_tbmkword(0, 0)
},
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__write_decl_bug_4_0_1;
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__declarative_user__type_ctor_info_user_state_0;
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__browser_info__type_ctor_info_browse_caller_type_0;
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__declarative_debugger__type_ctor_info_final_decl_atom_0;
extern const MR_TypeCtorInfo_Struct mercury_data_io__type_ctor_info_state_0;
static const MR_UserClosureId
mercury_data__closure_layout__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0_1;
static const struct mercury_type_13 mercury_common_13[2] =
{
{
{
(MR_Word *) &mercury_data__closure_layout__mdb__declarative_user__write_decl_bug_4_0_1,
(MR_Word *) (MR_Integer) 0
},
6,
{
MR_CTOR0_ADDR(mdb__declarative_user, user_state),
MR_STRING_CTOR_ADDR,
MR_CTOR0_ADDR(mdb__browser_info, browse_caller_type),
MR_CTOR0_ADDR(mdb__declarative_debugger, final_decl_atom),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
{
{
(MR_Word *) &mercury_data__closure_layout__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0_1,
(MR_Word *) (MR_Integer) 0
},
6,
{
MR_CTOR0_ADDR(mdb__declarative_user, user_state),
MR_STRING_CTOR_ADDR,
MR_CTOR0_ADDR(mdb__browser_info, browse_caller_type),
MR_CTOR0_ADDR(mdb__declarative_debugger, final_decl_atom),
MR_IO_CTOR_ADDR,
MR_IO_CTOR_ADDR
}
},
};

static const struct mercury_type_14 mercury_common_14[1] =
{
{
MR_tbmkword(0, 0)
},
};

static const struct mercury_type_15 mercury_common_15[2] =
{
{
0
},
{
1
},
};

static const struct mercury_type_16 mercury_common_16[4] =
{
{
{
4,
3
}
},
{
{
4,
1
}
},
{
{
4,
0
}
},
{
{
4,
2
}
},
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_0 = {
	"user_cmd_yes",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_1 = {
	"user_cmd_no",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	1,
	1,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_2 = {
	"user_cmd_inadmissible",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	2,
	2,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_3 = {
	"user_cmd_skip",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	3,
	3,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};
extern const MR_TypeCtorInfo_Struct mercury_data_maybe__type_ctor_info_maybe_1;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_int_0;
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_int_0;

static const MR_FA_TypeInfo_Struct1 mercury_data_maybe__ti_maybe_1builtin__type_ctor_info_int_0 = {
	&mercury_data_maybe__type_ctor_info_maybe_1,
{	(MR_TypeInfo) &mercury_data_builtin__type_ctor_info_int_0
}};

const MR_PseudoTypeInfo mercury_data_mdb__declarative_user__field_types_user_command_0_4[] = {
	(MR_PseudoTypeInfo) &mercury_data_maybe__ti_maybe_1builtin__type_ctor_info_int_0
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_4 = {
	"user_cmd_browse_arg",
	1,
	0,
	MR_SECTAG_NONE,
	1,
	-1,
	4,
	(MR_PseudoTypeInfo *) mercury_data_mdb__declarative_user__field_types_user_command_0_4,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_mdb__declarative_user__field_types_user_command_0_5[] = {
	(MR_PseudoTypeInfo) &mercury_data_maybe__ti_maybe_1builtin__type_ctor_info_int_0
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_5 = {
	"user_cmd_browse_xml_arg",
	1,
	0,
	MR_SECTAG_NONE,
	2,
	-1,
	5,
	(MR_PseudoTypeInfo *) mercury_data_mdb__declarative_user__field_types_user_command_0_5,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_mdb__declarative_user__field_types_user_command_0_6[] = {
	(MR_PseudoTypeInfo) &mercury_data_builtin__type_ctor_info_int_0
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_6 = {
	"user_cmd_browse_io",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	0,
	6,
	(MR_PseudoTypeInfo *) mercury_data_mdb__declarative_user__field_types_user_command_0_6,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_mdb__declarative_user__field_types_user_command_0_7[] = {
	(MR_PseudoTypeInfo) &mercury_data_builtin__type_ctor_info_int_0,
	(MR_PseudoTypeInfo) &mercury_data_builtin__type_ctor_info_int_0
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_7 = {
	"user_cmd_print_arg",
	2,
	0,
	MR_SECTAG_REMOTE,
	3,
	1,
	7,
	(MR_PseudoTypeInfo *) mercury_data_mdb__declarative_user__field_types_user_command_0_7,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_mdb__declarative_user__field_types_user_command_0_8[] = {
	(MR_PseudoTypeInfo) &mercury_data_builtin__type_ctor_info_int_0,
	(MR_PseudoTypeInfo) &mercury_data_builtin__type_ctor_info_int_0
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_8 = {
	"user_cmd_print_io",
	2,
	0,
	MR_SECTAG_REMOTE,
	3,
	2,
	8,
	(MR_PseudoTypeInfo *) mercury_data_mdb__declarative_user__field_types_user_command_0_8,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_9 = {
	"user_cmd_pd",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	4,
	9,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__browser_info__type_ctor_info_param_cmd_0;
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__browser_info__type_ctor_info_param_cmd_0;

const MR_PseudoTypeInfo mercury_data_mdb__declarative_user__field_types_user_command_0_10[] = {
	(MR_PseudoTypeInfo) &mercury_data_mdb__browser_info__type_ctor_info_param_cmd_0
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_10 = {
	"user_cmd_param_command",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	3,
	10,
	(MR_PseudoTypeInfo *) mercury_data_mdb__declarative_user__field_types_user_command_0_10,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_11 = {
	"user_cmd_trust_predicate",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	5,
	11,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_12 = {
	"user_cmd_trust_module",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	6,
	12,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_13 = {
	"user_cmd_info",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	7,
	13,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_14 = {
	"user_cmd_undo",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	8,
	14,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_15 = {
	"user_cmd_ask",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	9,
	15,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__declarative_user__type_ctor_info_user_search_mode_0;

const MR_PseudoTypeInfo mercury_data_mdb__declarative_user__field_types_user_command_0_16[] = {
	(MR_PseudoTypeInfo) &mercury_data_mdb__declarative_user__type_ctor_info_user_search_mode_0
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_16 = {
	"user_cmd_change_search",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	4,
	16,
	(MR_PseudoTypeInfo *) mercury_data_mdb__declarative_user__field_types_user_command_0_16,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_17 = {
	"user_cmd_quit",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	10,
	17,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};

static const MR_FA_TypeInfo_Struct1 mercury_data_maybe__ti_maybe_1builtin__type_ctor_info_string_0 = {
	&mercury_data_maybe__type_ctor_info_maybe_1,
{	(MR_TypeInfo) &mercury_data_builtin__type_ctor_info_string_0
}};

const MR_PseudoTypeInfo mercury_data_mdb__declarative_user__field_types_user_command_0_18[] = {
	(MR_PseudoTypeInfo) &mercury_data_maybe__ti_maybe_1builtin__type_ctor_info_string_0
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_18 = {
	"user_cmd_help",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	5,
	18,
	(MR_PseudoTypeInfo *) mercury_data_mdb__declarative_user__field_types_user_command_0_18,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_19 = {
	"user_cmd_empty",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	11,
	19,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_20 = {
	"user_cmd_illegal",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	12,
	20,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};

const MR_DuFunctorDescPtr mercury_data_mdb__declarative_user__du_stag_ordered_user_command_0_0[] = {
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_0,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_1,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_2,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_3,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_9,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_11,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_12,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_13,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_14,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_15,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_17,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_19,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_20

};

const MR_DuFunctorDescPtr mercury_data_mdb__declarative_user__du_stag_ordered_user_command_0_1[] = {
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_4

};

const MR_DuFunctorDescPtr mercury_data_mdb__declarative_user__du_stag_ordered_user_command_0_2[] = {
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_5

};

const MR_DuFunctorDescPtr mercury_data_mdb__declarative_user__du_stag_ordered_user_command_0_3[] = {
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_6,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_7,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_8,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_10,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_16,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_18

};

const MR_DuPtagLayout mercury_data_mdb__declarative_user__du_ptag_ordered_user_command_0[] = {
	{ 13, MR_SECTAG_LOCAL,
	mercury_data_mdb__declarative_user__du_stag_ordered_user_command_0_0 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_mdb__declarative_user__du_stag_ordered_user_command_0_1 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_mdb__declarative_user__du_stag_ordered_user_command_0_2 },
	{ 6, MR_SECTAG_REMOTE,
	mercury_data_mdb__declarative_user__du_stag_ordered_user_command_0_3 }

};

const MR_DuFunctorDescPtr mercury_data_mdb__declarative_user__du_name_ordered_user_command_0[] = {
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_15,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_4,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_6,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_5,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_16,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_19,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_18,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_20,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_2,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_13,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_1,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_10,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_9,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_7,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_8,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_17,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_3,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_12,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_11,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_14,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_command_0_0
};

const MR_Integer mercury_data_mdb__declarative_user__functor_number_map_user_command_0[] = {
	20,
	10,
	8,
	16,
	1,
	3,
	2,
	13,
	14,
	12,
	11,
	18,
	17,
	9,
	19,
	0,
	4,
	15,
	6,
	5,
	7 };
	
const MR_TypeCtorInfo_Struct mercury_data_mdb__declarative_user__type_ctor_info_user_command_0 = {
	0,
	13,
	4,
	MR_TYPECTOR_REP_DU,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___mdb__declarative_user__user_command_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___mdb__declarative_user__user_command_0_0)),
	"mdb.declarative_user",
	"user_command",
	{ (void *)mercury_data_mdb__declarative_user__du_name_ordered_user_command_0 },
	{ (void *)mercury_data_mdb__declarative_user__du_ptag_ordered_user_command_0 },
	21,
	4,
	mercury_data_mdb__declarative_user__functor_number_map_user_command_0
};
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__declarative_debugger__type_ctor_info_decl_question_1;

static const MR_FA_PseudoTypeInfo_Struct1 mercury_data_mdb__declarative_debugger__pti_decl_question_1__pseudo_1 = {
	&mercury_data_mdb__declarative_debugger__type_ctor_info_decl_question_1,
{	(MR_PseudoTypeInfo) 1
}};

const MR_PseudoTypeInfo mercury_data_mdb__declarative_user__field_types_user_question_1_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_mdb__declarative_debugger__pti_decl_question_1__pseudo_1
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_question_1_0 = {
	"plain_question",
	1,
	1,
	MR_SECTAG_NONE,
	0,
	-1,
	0,
	(MR_PseudoTypeInfo *) mercury_data_mdb__declarative_user__field_types_user_question_1_0,
	NULL,
	NULL
};
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__declarative_debugger__type_ctor_info_decl_truth_0;
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__declarative_debugger__type_ctor_info_decl_truth_0;

const MR_PseudoTypeInfo mercury_data_mdb__declarative_user__field_types_user_question_1_1[] = {
	(MR_PseudoTypeInfo) &mercury_data_mdb__declarative_debugger__pti_decl_question_1__pseudo_1,
	(MR_PseudoTypeInfo) &mercury_data_mdb__declarative_debugger__type_ctor_info_decl_truth_0
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_question_1_1 = {
	"question_with_default",
	2,
	1,
	MR_SECTAG_NONE,
	1,
	-1,
	1,
	(MR_PseudoTypeInfo *) mercury_data_mdb__declarative_user__field_types_user_question_1_1,
	NULL,
	NULL
};

const MR_DuFunctorDescPtr mercury_data_mdb__declarative_user__du_stag_ordered_user_question_1_0[] = {
	&mercury_data_mdb__declarative_user__du_functor_desc_user_question_1_0

};

const MR_DuFunctorDescPtr mercury_data_mdb__declarative_user__du_stag_ordered_user_question_1_1[] = {
	&mercury_data_mdb__declarative_user__du_functor_desc_user_question_1_1

};

const MR_DuPtagLayout mercury_data_mdb__declarative_user__du_ptag_ordered_user_question_1[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_mdb__declarative_user__du_stag_ordered_user_question_1_0 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_mdb__declarative_user__du_stag_ordered_user_question_1_1 }

};

const MR_DuFunctorDescPtr mercury_data_mdb__declarative_user__du_name_ordered_user_question_1[] = {
	&mercury_data_mdb__declarative_user__du_functor_desc_user_question_1_0,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_question_1_1
};

const MR_Integer mercury_data_mdb__declarative_user__functor_number_map_user_question_1[] = {
	0,
	1 };
	
const MR_TypeCtorInfo_Struct mercury_data_mdb__declarative_user__type_ctor_info_user_question_1 = {
	1,
	13,
	2,
	MR_TYPECTOR_REP_DU,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___mdb__declarative_user__user_question_1_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___mdb__declarative_user__user_question_1_0)),
	"mdb.declarative_user",
	"user_question",
	{ (void *)mercury_data_mdb__declarative_user__du_name_ordered_user_question_1 },
	{ (void *)mercury_data_mdb__declarative_user__du_ptag_ordered_user_question_1 },
	2,
	4,
	mercury_data_mdb__declarative_user__functor_number_map_user_question_1
};
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__declarative_debugger__type_ctor_info_decl_answer_1;

static const MR_FA_PseudoTypeInfo_Struct1 mercury_data_mdb__declarative_debugger__pti_decl_answer_1__pseudo_1 = {
	&mercury_data_mdb__declarative_debugger__type_ctor_info_decl_answer_1,
{	(MR_PseudoTypeInfo) 1
}};

const MR_PseudoTypeInfo mercury_data_mdb__declarative_user__field_types_user_response_1_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_mdb__declarative_debugger__pti_decl_question_1__pseudo_1,
	(MR_PseudoTypeInfo) &mercury_data_mdb__declarative_debugger__pti_decl_answer_1__pseudo_1
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_0 = {
	"user_response_answer",
	2,
	3,
	MR_SECTAG_NONE,
	1,
	-1,
	0,
	(MR_PseudoTypeInfo *) mercury_data_mdb__declarative_user__field_types_user_response_1_0,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_mdb__declarative_user__field_types_user_response_1_1[] = {
	(MR_PseudoTypeInfo) &mercury_data_mdb__declarative_debugger__pti_decl_question_1__pseudo_1
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_1 = {
	"user_response_trust_predicate",
	1,
	1,
	MR_SECTAG_NONE,
	2,
	-1,
	1,
	(MR_PseudoTypeInfo *) mercury_data_mdb__declarative_user__field_types_user_response_1_1,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_mdb__declarative_user__field_types_user_response_1_2[] = {
	(MR_PseudoTypeInfo) &mercury_data_mdb__declarative_debugger__pti_decl_question_1__pseudo_1
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_2 = {
	"user_response_trust_module",
	1,
	1,
	MR_SECTAG_REMOTE,
	3,
	0,
	2,
	(MR_PseudoTypeInfo *) mercury_data_mdb__declarative_user__field_types_user_response_1_2,
	NULL,
	NULL
};
extern const MR_TypeCtorInfo_Struct mercury_data_io__type_ctor_info_output_stream_0;
extern const MR_TypeCtorInfo_Struct mercury_data_io__type_ctor_info_output_stream_0;

const MR_PseudoTypeInfo mercury_data_mdb__declarative_user__field_types_user_response_1_3[] = {
	(MR_PseudoTypeInfo) &mercury_data_io__type_ctor_info_output_stream_0
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_3 = {
	"user_response_show_info",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	1,
	3,
	(MR_PseudoTypeInfo *) mercury_data_mdb__declarative_user__field_types_user_response_1_3,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_mdb__declarative_user__field_types_user_response_1_4[] = {
	(MR_PseudoTypeInfo) &mercury_data_mdb__declarative_user__type_ctor_info_user_search_mode_0
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_4 = {
	"user_response_change_search",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	2,
	4,
	(MR_PseudoTypeInfo *) mercury_data_mdb__declarative_user__field_types_user_response_1_4,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_5 = {
	"user_response_undo",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	0,
	5,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_mdb__declarative_user__field_types_user_response_1_6[] = {
	(MR_PseudoTypeInfo) 1
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_6 = {
	"user_response_exit_diagnosis",
	1,
	1,
	MR_SECTAG_REMOTE,
	3,
	3,
	6,
	(MR_PseudoTypeInfo *) mercury_data_mdb__declarative_user__field_types_user_response_1_6,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_7 = {
	"user_response_abort_diagnosis",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	1,
	7,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};

const MR_DuFunctorDescPtr mercury_data_mdb__declarative_user__du_stag_ordered_user_response_1_0[] = {
	&mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_5,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_7

};

const MR_DuFunctorDescPtr mercury_data_mdb__declarative_user__du_stag_ordered_user_response_1_1[] = {
	&mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_0

};

const MR_DuFunctorDescPtr mercury_data_mdb__declarative_user__du_stag_ordered_user_response_1_2[] = {
	&mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_1

};

const MR_DuFunctorDescPtr mercury_data_mdb__declarative_user__du_stag_ordered_user_response_1_3[] = {
	&mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_2,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_3,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_4,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_6

};

const MR_DuPtagLayout mercury_data_mdb__declarative_user__du_ptag_ordered_user_response_1[] = {
	{ 2, MR_SECTAG_LOCAL,
	mercury_data_mdb__declarative_user__du_stag_ordered_user_response_1_0 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_mdb__declarative_user__du_stag_ordered_user_response_1_1 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_mdb__declarative_user__du_stag_ordered_user_response_1_2 },
	{ 4, MR_SECTAG_REMOTE,
	mercury_data_mdb__declarative_user__du_stag_ordered_user_response_1_3 }

};

const MR_DuFunctorDescPtr mercury_data_mdb__declarative_user__du_name_ordered_user_response_1[] = {
	&mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_7,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_0,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_4,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_6,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_3,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_2,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_1,
	&mercury_data_mdb__declarative_user__du_functor_desc_user_response_1_5
};

const MR_Integer mercury_data_mdb__declarative_user__functor_number_map_user_response_1[] = {
	1,
	6,
	5,
	4,
	2,
	7,
	3,
	0 };
	
const MR_TypeCtorInfo_Struct mercury_data_mdb__declarative_user__type_ctor_info_user_response_1 = {
	1,
	13,
	4,
	MR_TYPECTOR_REP_DU,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___mdb__declarative_user__user_response_1_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___mdb__declarative_user__user_response_1_0)),
	"mdb.declarative_user",
	"user_response",
	{ (void *)mercury_data_mdb__declarative_user__du_name_ordered_user_response_1 },
	{ (void *)mercury_data_mdb__declarative_user__du_ptag_ordered_user_response_1 },
	8,
	4,
	mercury_data_mdb__declarative_user__functor_number_map_user_response_1
};

static const MR_EnumFunctorDesc mercury_data_mdb__declarative_user__enum_functor_desc_user_search_mode_0_0 = {
	"user_top_down",
	0
};

static const MR_EnumFunctorDesc mercury_data_mdb__declarative_user__enum_functor_desc_user_search_mode_0_1 = {
	"user_divide_and_query",
	1
};

static const MR_EnumFunctorDesc mercury_data_mdb__declarative_user__enum_functor_desc_user_search_mode_0_2 = {
	"user_suspicion_divide_and_query",
	2
};

static const MR_EnumFunctorDesc mercury_data_mdb__declarative_user__enum_functor_desc_user_search_mode_0_3 = {
	"user_binary",
	3
};

const MR_EnumFunctorDescPtr mercury_data_mdb__declarative_user__enum_value_ordered_user_search_mode_0[] = {
	&mercury_data_mdb__declarative_user__enum_functor_desc_user_search_mode_0_0,
	&mercury_data_mdb__declarative_user__enum_functor_desc_user_search_mode_0_1,
	&mercury_data_mdb__declarative_user__enum_functor_desc_user_search_mode_0_2,
	&mercury_data_mdb__declarative_user__enum_functor_desc_user_search_mode_0_3
};

const MR_EnumFunctorDescPtr mercury_data_mdb__declarative_user__enum_name_ordered_user_search_mode_0[] = {
	&mercury_data_mdb__declarative_user__enum_functor_desc_user_search_mode_0_3,
	&mercury_data_mdb__declarative_user__enum_functor_desc_user_search_mode_0_1,
	&mercury_data_mdb__declarative_user__enum_functor_desc_user_search_mode_0_2,
	&mercury_data_mdb__declarative_user__enum_functor_desc_user_search_mode_0_0
};

const MR_Integer mercury_data_mdb__declarative_user__functor_number_map_user_search_mode_0[] = {
	3,
	1,
	2,
	0 };
	
const MR_TypeCtorInfo_Struct mercury_data_mdb__declarative_user__type_ctor_info_user_search_mode_0 = {
	0,
	13,
	-1,
	MR_TYPECTOR_REP_ENUM,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___mdb__declarative_user__user_search_mode_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___mdb__declarative_user__user_search_mode_0_0)),
	"mdb.declarative_user",
	"user_search_mode",
	{ (void *)mercury_data_mdb__declarative_user__enum_name_ordered_user_search_mode_0 },
	{ (void *)mercury_data_mdb__declarative_user__enum_value_ordered_user_search_mode_0 },
	4,
	4,
	mercury_data_mdb__declarative_user__functor_number_map_user_search_mode_0
};
extern const MR_TypeCtorInfo_Struct mercury_data_io__type_ctor_info_input_stream_0;
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__browser_info__type_ctor_info_browser_persistent_state_0;
extern const MR_TypeCtorInfo_Struct mercury_data_bool__type_ctor_info_bool_0;
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__help__type_ctor_info_entry_0;
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__help__type_ctor_info_entry_0;

static const MR_FA_TypeInfo_Struct1 mercury_data_list__ti_list_1mdb__help__type_ctor_info_entry_0 = {
	&mercury_data_list__type_ctor_info_list_1,
{	(MR_TypeInfo) &mercury_data_mdb__help__type_ctor_info_entry_0
}};
extern const MR_TypeCtorInfo_Struct mercury_data_io__type_ctor_info_input_stream_0;
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__browser_info__type_ctor_info_browser_persistent_state_0;
extern const MR_TypeCtorInfo_Struct mercury_data_bool__type_ctor_info_bool_0;

const MR_PseudoTypeInfo mercury_data_mdb__declarative_user__field_types_user_state_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_io__type_ctor_info_input_stream_0,
	(MR_PseudoTypeInfo) &mercury_data_io__type_ctor_info_output_stream_0,
	(MR_PseudoTypeInfo) &mercury_data_mdb__browser_info__type_ctor_info_browser_persistent_state_0,
	(MR_PseudoTypeInfo) &mercury_data_bool__type_ctor_info_bool_0,
	(MR_PseudoTypeInfo) &mercury_data_list__ti_list_1mdb__help__type_ctor_info_entry_0,
	(MR_PseudoTypeInfo) &mercury_data_bool__type_ctor_info_bool_0
};

const MR_ConstString mercury_data_mdb__declarative_user__field_names_user_state_0_0[] = {
	"instr",
	"outstr",
	"browser",
	"display_question",
	"help_system",
	"testing"
};

static const MR_DuFunctorDesc mercury_data_mdb__declarative_user__du_functor_desc_user_state_0_0 = {
	"user_state",
	6,
	0,
	MR_SECTAG_NONE,
	0,
	-1,
	0,
	(MR_PseudoTypeInfo *) mercury_data_mdb__declarative_user__field_types_user_state_0_0,
	mercury_data_mdb__declarative_user__field_names_user_state_0_0,
	NULL
};

const MR_DuFunctorDescPtr mercury_data_mdb__declarative_user__du_stag_ordered_user_state_0_0[] = {
	&mercury_data_mdb__declarative_user__du_functor_desc_user_state_0_0

};

const MR_DuPtagLayout mercury_data_mdb__declarative_user__du_ptag_ordered_user_state_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_mdb__declarative_user__du_stag_ordered_user_state_0_0 }

};

const MR_DuFunctorDescPtr mercury_data_mdb__declarative_user__du_name_ordered_user_state_0[] = {
	&mercury_data_mdb__declarative_user__du_functor_desc_user_state_0_0
};

const MR_Integer mercury_data_mdb__declarative_user__functor_number_map_user_state_0[] = {
	0 };
	
const MR_TypeCtorInfo_Struct mercury_data_mdb__declarative_user__type_ctor_info_user_state_0 = {
	0,
	13,
	1,
	MR_TYPECTOR_REP_DU,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___mdb__declarative_user__user_state_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___mdb__declarative_user__user_state_0_0)),
	"mdb.declarative_user",
	"user_state",
	{ (void *)mercury_data_mdb__declarative_user__du_name_ordered_user_state_0 },
	{ (void *)mercury_data_mdb__declarative_user__du_ptag_ordered_user_state_0 },
	1,
	4,
	mercury_data_mdb__declarative_user__functor_number_map_user_state_0
};


static const MR_UserClosureId
mercury_data__closure_layout__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0_1 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"write_decl_final_atom",
6,
0
},
"mdb.declarative_user",
"declarative_user.m",
1152,
"d2;c8;d2;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__print_arg_cmd_2_0_2 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"is_dash",
1,
0
},
"mdb.declarative_user",
"declarative_user.m",
1057,
"d1;c4;e;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__print_arg_cmd_2_0_1 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"is_dash",
1,
0
},
"mdb.declarative_user",
"declarative_user.m",
1057,
"d1;c4;e;c5;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__write_decl_bug_4_0_1 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"write_decl_final_atom",
6,
0
},
"mdb.declarative_user",
"declarative_user.m",
1169,
"d1;c5;d1;c6;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__browse_xml_decl_bug_5_0_1 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"lambda_declarative_user_m_714",
2,
0
},
"mdb.declarative_user",
"declarative_user.m",
714,
"d1;c10;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__write_decl_atom_6_0_1 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"trace_atom_arg_to_univ",
2,
0
},
"mdb.declarative_user",
"declarative_user.m",
1219,
"d1;c15;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__get_command_6_0_1 = {
{
MR_PREDICATE,
"char",
"char",
"is_whitespace",
1,
0
},
"mdb.declarative_user",
"declarative_user.m",
868,
"d1;c10;d1;c3;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_33 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"one_word_cmd",
3,
0
},
"mdb.declarative_user",
"declarative_user.m",
903,
"d6;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_32 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"num_io_actions_cmd",
2,
0
},
"mdb.declarative_user",
"declarative_user.m",
925,
"d27;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_31 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"one_word_cmd",
3,
0
},
"mdb.declarative_user",
"declarative_user.m",
933,
"d33;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_30 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"format_arg_cmd",
2,
0
},
"mdb.declarative_user",
"declarative_user.m",
920,
"d22;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_29 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"browse_arg_cmd",
2,
0
},
"mdb.declarative_user",
"declarative_user.m",
917,
"d19;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_28 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"format_param_arg_cmd",
3,
0
},
"mdb.declarative_user",
"declarative_user.m",
923,
"d25;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_27 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"trust_arg_cmd",
2,
0
},
"mdb.declarative_user",
"declarative_user.m",
929,
"d29;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_26 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"print_arg_cmd",
2,
0
},
"mdb.declarative_user",
"declarative_user.m",
919,
"d21;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_25 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"format_param_arg_cmd",
3,
0
},
"mdb.declarative_user",
"declarative_user.m",
924,
"d26;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_24 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"format_param_arg_cmd",
3,
0
},
"mdb.declarative_user",
"declarative_user.m",
921,
"d23;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_23 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"one_word_cmd",
3,
0
},
"mdb.declarative_user",
"declarative_user.m",
909,
"d11;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_22 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"one_word_cmd",
3,
0
},
"mdb.declarative_user",
"declarative_user.m",
932,
"d32;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_21 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"one_word_cmd",
3,
0
},
"mdb.declarative_user",
"declarative_user.m",
905,
"d8;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_20 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"format_param_arg_cmd",
3,
0
},
"mdb.declarative_user",
"declarative_user.m",
922,
"d24;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_19 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"one_word_cmd",
3,
0
},
"mdb.declarative_user",
"declarative_user.m",
911,
"d13;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_18 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"search_mode_cmd",
2,
0
},
"mdb.declarative_user",
"declarative_user.m",
930,
"d30;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_17 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"one_word_cmd",
3,
0
},
"mdb.declarative_user",
"declarative_user.m",
915,
"d17;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_16 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"help_cmd",
2,
0
},
"mdb.declarative_user",
"declarative_user.m",
914,
"d16;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_15 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"one_word_cmd",
3,
0
},
"mdb.declarative_user",
"declarative_user.m",
899,
"d2;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_14 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"one_word_cmd",
3,
0
},
"mdb.declarative_user",
"declarative_user.m",
906,
"d9;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_13 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"one_word_cmd",
3,
0
},
"mdb.declarative_user",
"declarative_user.m",
901,
"d4;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_12 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"one_word_cmd",
3,
0
},
"mdb.declarative_user",
"declarative_user.m",
898,
"d1;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_11 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"trust_arg_cmd",
2,
0
},
"mdb.declarative_user",
"declarative_user.m",
928,
"d28;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_10 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"one_word_cmd",
3,
0
},
"mdb.declarative_user",
"declarative_user.m",
904,
"d7;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_9 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"one_word_cmd",
3,
0
},
"mdb.declarative_user",
"declarative_user.m",
910,
"d12;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_8 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"print_arg_cmd",
2,
0
},
"mdb.declarative_user",
"declarative_user.m",
918,
"d20;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_7 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"one_word_cmd",
3,
0
},
"mdb.declarative_user",
"declarative_user.m",
900,
"d3;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_6 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"search_mode_cmd",
2,
0
},
"mdb.declarative_user",
"declarative_user.m",
931,
"d31;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_5 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"one_word_cmd",
3,
0
},
"mdb.declarative_user",
"declarative_user.m",
902,
"d5;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_4 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"help_cmd",
2,
0
},
"mdb.declarative_user",
"declarative_user.m",
913,
"d15;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_3 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"browse_arg_cmd",
2,
0
},
"mdb.declarative_user",
"declarative_user.m",
916,
"d18;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_2 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"one_word_cmd",
3,
0
},
"mdb.declarative_user",
"declarative_user.m",
908,
"d10;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__cmd_handler_2_0_1 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"help_cmd",
2,
0
},
"mdb.declarative_user",
"declarative_user.m",
912,
"d14;c2;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__browse_xml_atom_4_0_1 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"lambda_declarative_user_m_714",
2,
0
},
"mdb.declarative_user",
"declarative_user.m",
714,
"d1;c10;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__browse_atom_7_0_2 = {
{
MR_FUNCTION,
"mdb.declarative_user",
"mdb.declarative_user",
"get_subterm_mode_from_atoms",
4,
0
},
"mdb.declarative_user",
"declarative_user.m",
700,
"d1;c23;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__browse_atom_7_0_1 = {
{
MR_PREDICATE,
"mdb.declarative_user",
"mdb.declarative_user",
"lambda_declarative_user_m_695",
2,
0
},
"mdb.declarative_user",
"declarative_user.m",
695,
"d1;c13;"
};

static const MR_UserClosureId
mercury_data__closure_layout__mdb__declarative_user__browse_atom_argument_8_0_1 = {
{
MR_FUNCTION,
"mdb.declarative_user",
"mdb.declarative_user",
"get_subterm_mode_from_atoms_for_arg",
5,
0
},
"mdb.declarative_user",
"declarative_user.m",
657,
"d1;c12;t;c5;"
};



MR_BEGIN_MODULE(mdb__declarative_user_module0)
	MR_init_entry1(mdb__declarative_user__user_state_init_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__user_state_init_5_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'user_state_init'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__mdb__declarative_user__user_state_init_5_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 6);
	MR_tfield(0, MR_tempr1, 0) = MR_r1;
	MR_tfield(0, MR_tempr1, 1) = MR_r2;
	MR_tfield(0, MR_tempr1, 2) = MR_r3;
	MR_tfield(0, MR_tempr1, 3) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 4) = MR_r4;
	MR_tfield(0, MR_tempr1, 5) = (MR_Integer) 0;
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__mdb__declarative_execution__chosen_head_vars_presentation_0_0);

MR_BEGIN_MODULE(mdb__declarative_user_module1)
	MR_init_entry1(fn__mdb__declarative_user__arg_num_to_arg_pos_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__mdb__declarative_user__arg_num_to_arg_pos_1_0);
	MR_init_label2(fn__mdb__declarative_user__arg_num_to_arg_pos_1_0,2,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'arg_num_to_arg_pos'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__mdb__declarative_user__arg_num_to_arg_pos_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_np_call_localret_ent(fn__mdb__declarative_execution__chosen_head_vars_presentation_0_0,
		fn__mdb__declarative_user__arg_num_to_arg_pos_1_0_i2);
MR_def_label(fn__mdb__declarative_user__arg_num_to_arg_pos_1_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(fn__mdb__declarative_user__arg_num_to_arg_pos_1_0_i4);
	}
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 1);
	MR_tfield(1, MR_r1, 0) = MR_sv(1);
	MR_decr_sp_and_return(2);
MR_def_label(fn__mdb__declarative_user__arg_num_to_arg_pos_1_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r1, 0, (MR_Integer) 1);
	MR_tfield(0, MR_r1, 0) = MR_sv(1);
	MR_decr_sp_and_return(2);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(mdb__io_action__get_maybe_io_action_4_0);

MR_BEGIN_MODULE(mdb__declarative_user_module2)
	MR_init_entry1(mdb__declarative_user__find_tabled_io_action_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__find_tabled_io_action_5_0);
	MR_init_label5(mdb__declarative_user__find_tabled_io_action_5_0,34,2,3,5,8)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'find_tabled_io_action'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__find_tabled_io_action_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
MR_def_label(mdb__declarative_user__find_tabled_io_action_5_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_tfield(0, MR_r1, 1);
	MR_sv(1) = MR_tfield(0, MR_r1, 0);
	if ((MR_sv(1) != MR_sv(2))) {
		MR_GOTO_LAB(mdb__declarative_user__find_tabled_io_action_5_0_i2);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_decr_sp_and_return(4);
MR_def_label(mdb__declarative_user__find_tabled_io_action_5_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r2;
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(mdb__io_action__get_maybe_io_action_4_0,
		mdb__declarative_user__find_tabled_io_action_5_0_i3);
MR_def_label(mdb__declarative_user__find_tabled_io_action_5_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__find_tabled_io_action_5_0_i5);
	}
	MR_tag_alloc_heap(MR_r1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r1, 0) = ((MR_Integer) MR_sv(1) + (MR_Integer) 1);
	MR_tfield(0, MR_r1, 1) = MR_sv(2);
	MR_r2 = MR_sv(3);
	MR_succip_word = MR_sv(4);
	MR_GOTO_LAB(mdb__declarative_user__find_tabled_io_action_5_0_i34);
MR_def_label(mdb__declarative_user__find_tabled_io_action_5_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(3),1)) {
		MR_GOTO_LAB(mdb__declarative_user__find_tabled_io_action_5_0_i8);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 1);
	MR_tfield(1, MR_tempr1, 0) = MR_tfield(1, MR_r1, 0);
	MR_r1 = MR_tempr1;
	MR_decr_sp_and_return(4);
	}
MR_def_label(mdb__declarative_user__find_tabled_io_action_5_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r1, 0) = ((MR_Integer) MR_sv(1) + (MR_Integer) 1);
	MR_tfield(0, MR_r1, 1) = MR_sv(2);
	MR_r2 = ((MR_Integer) MR_sv(3) - (MR_Integer) 1);
	MR_succip_word = MR_sv(4);
	MR_GOTO_LAB(mdb__declarative_user__find_tabled_io_action_5_0_i34);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__mdb__io_action__io_action_to_browser_term_1_0);
MR_decl_entry(mdb__browse__browse_browser_term_9_0);
MR_decl_entry(io__write_string_4_0);

MR_BEGIN_MODULE(mdb__declarative_user_module3)
	MR_init_entry1(mdb__declarative_user__browse_io_action_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__browse_io_action_6_0);
	MR_init_label6(mdb__declarative_user__browse_io_action_6_0,2,3,5,6,7,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'browse_io_action'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__browse_io_action_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(3) = MR_r2;
	MR_np_call_localret_ent(fn__mdb__io_action__io_action_to_browser_term_1_0,
		mdb__declarative_user__browse_io_action_6_0_i2);
MR_def_label(mdb__declarative_user__browse_io_action_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(3);
	MR_r2 = MR_tfield(0, MR_tempr1, 0);
	MR_r3 = MR_tfield(0, MR_tempr1, 1);
	MR_r4 = (MR_Word) MR_tbmkword(0, 0);
	MR_r5 = MR_tfield(0, MR_tempr1, 2);
	}
	MR_np_call_localret_ent(mdb__browse__browse_browser_term_9_0,
		mdb__declarative_user__browse_io_action_6_0_i3);
MR_def_label(mdb__declarative_user__browse_io_action_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_io_action_6_0_i5);
	}
	MR_sv(2) = MR_r2;
	MR_r1 = MR_sv(3);
	MR_GOTO_LAB(mdb__declarative_user__browse_io_action_6_0_i4);
MR_def_label(mdb__declarative_user__browse_io_action_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r2;
	MR_r1 = MR_tfield(0, MR_sv(3), 1);
	MR_r2 = (MR_Word) MR_string_const("Sorry, tracking of I/O actions is not yet supported.\n", 53);
	MR_np_call_localret_ent(io__write_string_4_0,
		mdb__declarative_user__browse_io_action_6_0_i6);
MR_def_label(mdb__declarative_user__browse_io_action_6_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(3);
	MR_np_localcall_lab(mdb__declarative_user__browse_io_action_6_0,
		mdb__declarative_user__browse_io_action_6_0_i7);
MR_def_label(mdb__declarative_user__browse_io_action_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
MR_def_label(mdb__declarative_user__browse_io_action_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 6);
	MR_tfield(0, MR_r2, 0) = MR_tfield(0, MR_r1, 0);
	MR_tfield(0, MR_r2, 1) = MR_tfield(0, MR_r1, 1);
	MR_tfield(0, MR_r2, 2) = MR_sv(2);
	MR_tfield(0, MR_r2, 3) = MR_tfield(0, MR_r1, 3);
	MR_tfield(0, MR_r2, 4) = MR_tfield(0, MR_r1, 4);
	MR_tfield(0, MR_r2, 5) = MR_tfield(0, MR_r1, 5);
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_decr_sp_and_return(4);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(io__write_string_3_0);

MR_BEGIN_MODULE(mdb__declarative_user_module4)
	MR_init_entry1(mdb__declarative_user__browse_chosen_io_action_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__browse_chosen_io_action_7_0);
	MR_init_label4(mdb__declarative_user__browse_chosen_io_action_7_0,3,5,10,7)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'browse_chosen_io_action'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__browse_chosen_io_action_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_chosen_io_action_7_0_i3);
	}
	MR_sv(1) = MR_r3;
	MR_r1 = (MR_Word) MR_string_const("No such IO action.\n", 19);
	MR_np_call_localret_ent(io__write_string_3_0,
		mdb__declarative_user__browse_chosen_io_action_7_0_i10);
MR_def_label(mdb__declarative_user__browse_chosen_io_action_7_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r3;
	MR_r1 = MR_tfield(1, MR_r1, 0);
	MR_np_call_localret_ent(mdb__declarative_user__find_tabled_io_action_5_0,
		mdb__declarative_user__browse_chosen_io_action_7_0_i5);
MR_def_label(mdb__declarative_user__browse_chosen_io_action_7_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_chosen_io_action_7_0_i7);
	}
MR_def_label(mdb__declarative_user__browse_chosen_io_action_7_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_r2 = MR_sv(1);
	MR_decr_sp_and_return(2);
MR_def_label(mdb__declarative_user__browse_chosen_io_action_7_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(1, MR_r1, 0);
	MR_r2 = MR_sv(1);
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(mdb__declarative_user__browse_io_action_6_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(mdb__browse__print_browser_term_6_0);

MR_BEGIN_MODULE(mdb__declarative_user_module5)
	MR_init_entry1(mdb__declarative_user__print_chosen_io_actions_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__print_chosen_io_actions_6_0);
	MR_init_label9(mdb__declarative_user__print_chosen_io_actions_6_0,32,3,5,8,7,9,10,2,34)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'print_chosen_io_actions'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__print_chosen_io_actions_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
MR_def_label(mdb__declarative_user__print_chosen_io_actions_6_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__print_chosen_io_actions_6_0_i3);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_sv(4) = MR_r4;
	MR_r1 = (MR_Word) MR_string_const("No such IO action.\n", 19);
	MR_np_call_localret_ent(io__write_string_3_0,
		mdb__declarative_user__print_chosen_io_actions_6_0_i8);
MR_def_label(mdb__declarative_user__print_chosen_io_actions_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_sv(4) = MR_r4;
	MR_r1 = MR_tfield(1, MR_r1, 0);
	MR_np_call_localret_ent(mdb__declarative_user__find_tabled_io_action_5_0,
		mdb__declarative_user__print_chosen_io_actions_6_0_i5);
MR_def_label(mdb__declarative_user__print_chosen_io_actions_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__print_chosen_io_actions_6_0_i7);
	}
	MR_r1 = (MR_Word) MR_string_const("No such IO action.\n", 19);
	MR_np_call_localret_ent(io__write_string_3_0,
		mdb__declarative_user__print_chosen_io_actions_6_0_i8);
MR_def_label(mdb__declarative_user__print_chosen_io_actions_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r3 = MR_sv(3);
	MR_r4 = MR_sv(4);
	MR_r2 = (MR_Integer) 0;
	MR_GOTO_LAB(mdb__declarative_user__print_chosen_io_actions_6_0_i2);
MR_def_label(mdb__declarative_user__print_chosen_io_actions_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(1, MR_r1, 0);
	MR_np_call_localret_ent(fn__mdb__io_action__io_action_to_browser_term_1_0,
		mdb__declarative_user__print_chosen_io_actions_6_0_i9);
MR_def_label(mdb__declarative_user__print_chosen_io_actions_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(4);
	MR_r2 = MR_tfield(0, MR_tempr1, 1);
	MR_r3 = (MR_Integer) 2;
	MR_r4 = MR_tfield(0, MR_tempr1, 2);
	}
	MR_np_call_localret_ent(mdb__browse__print_browser_term_6_0,
		mdb__declarative_user__print_chosen_io_actions_6_0_i10);
MR_def_label(mdb__declarative_user__print_chosen_io_actions_6_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r3 = MR_sv(3);
	MR_r4 = MR_sv(4);
	MR_r2 = (MR_Integer) 1;
MR_def_label(mdb__declarative_user__print_chosen_io_actions_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r2,1)) {
		MR_GOTO_LAB(mdb__declarative_user__print_chosen_io_actions_6_0_i34);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_sv(2);
	MR_tempr1 = ((MR_Integer) MR_tempr2 + (MR_Integer) 1);
	if (((MR_Integer) MR_tempr1 > (MR_Integer) MR_r3)) {
		MR_GOTO_LAB(mdb__declarative_user__print_chosen_io_actions_6_0_i34);
	}
	MR_r2 = ((MR_Integer) MR_tempr2 + (MR_Integer) 1);
	MR_succip_word = MR_sv(5);
	MR_GOTO_LAB(mdb__declarative_user__print_chosen_io_actions_6_0_i32);
	}
MR_def_label(mdb__declarative_user__print_chosen_io_actions_6_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(5);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(mdb__declarative_execution__maybe_filter_headvars_3_0);
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__declarative_execution__type_ctor_info_trace_atom_arg_0;
MR_decl_entry(list__index1_3_0);
MR_decl_entry(mdb__term_rep__rep_to_univ_2_0);
MR_decl_entry(fn__mdb__browser_term__univ_to_browser_term_1_0);
MR_decl_entry(mdb__browse__simplify_dirs_2_0);
MR_decl_entry(mdb__browser_info__convert_dirs_to_term_path_3_0);

MR_BEGIN_MODULE(mdb__declarative_user_module6)
	MR_init_entry1(mdb__declarative_user__browse_atom_argument_8_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__browse_atom_argument_8_0);
	MR_init_label10(mdb__declarative_user__browse_atom_argument_8_0,2,3,5,8,9,12,14,15,16,13)
	MR_init_label2(mdb__declarative_user__browse_atom_argument_8_0,4,19)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'browse_atom_argument'/8 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__browse_atom_argument_8_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_sv(4) = MR_tfield(0, MR_r2, 1);
	MR_sv(5) = MR_r4;
	MR_np_call_localret_ent(fn__mdb__declarative_execution__chosen_head_vars_presentation_0_0,
		mdb__declarative_user__browse_atom_argument_8_0_i2);
MR_def_label(mdb__declarative_user__browse_atom_argument_8_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(4);
	MR_np_call_localret_ent(mdb__declarative_execution__maybe_filter_headvars_3_0,
		mdb__declarative_user__browse_atom_argument_8_0_i3);
MR_def_label(mdb__declarative_user__browse_atom_argument_8_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdb__declarative_execution, trace_atom_arg);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(3);
	}
	MR_np_call_localret_ent(list__index1_3_0,
		mdb__declarative_user__browse_atom_argument_8_0_i5);
MR_def_label(mdb__declarative_user__browse_atom_argument_8_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_atom_argument_8_0_i4);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(0, MR_r2, 2);
	if (MR_LTAGS_TEST(MR_tempr1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_atom_argument_8_0_i4);
	}
	MR_sv(4) = MR_tfield(1, MR_tempr1, 0);
	MR_r1 = MR_sv(4);
	}
	MR_np_call_localret_ent(mdb__term_rep__rep_to_univ_2_0,
		mdb__declarative_user__browse_atom_argument_8_0_i8);
MR_def_label(mdb__declarative_user__browse_atom_argument_8_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__mdb__browser_term__univ_to_browser_term_1_0,
		mdb__declarative_user__browse_atom_argument_8_0_i9);
MR_def_label(mdb__declarative_user__browse_atom_argument_8_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 6);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(1,0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 3;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(3);
	MR_tfield(0, MR_tempr1, 4) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 5) = MR_sv(2);
	MR_tag_alloc_heap(MR_r4, 1, (MR_Integer) 1);
	MR_tfield(1, MR_r4, 0) = MR_tempr1;
	MR_tempr2 = MR_sv(5);
	MR_r2 = MR_tfield(0, MR_tempr2, 0);
	MR_r3 = MR_tfield(0, MR_tempr2, 1);
	MR_r5 = MR_tfield(0, MR_tempr2, 2);
	}
	MR_np_call_localret_ent(mdb__browse__browse_browser_term_9_0,
		mdb__declarative_user__browse_atom_argument_8_0_i12);
MR_def_label(mdb__declarative_user__browse_atom_argument_8_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_atom_argument_8_0_i14);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_sv(1) = MR_r2;
	MR_GOTO_LAB(mdb__declarative_user__browse_atom_argument_8_0_i13);
MR_def_label(mdb__declarative_user__browse_atom_argument_8_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_tfield(1, MR_r1, 0);
	MR_sv(3) = MR_tfield(1, MR_r1, 1);
	MR_r1 = MR_tfield(1, MR_r1, 2);
	MR_np_call_localret_ent(mdb__browse__simplify_dirs_2_0,
		mdb__declarative_user__browse_atom_argument_8_0_i15);
MR_def_label(mdb__declarative_user__browse_atom_argument_8_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(mdb__browser_info__convert_dirs_to_term_path_3_0,
		mdb__declarative_user__browse_atom_argument_8_0_i16);
MR_def_label(mdb__declarative_user__browse_atom_argument_8_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 3);
	MR_tfield(1, MR_tempr1, 0) = MR_sv(2);
	MR_tfield(1, MR_tempr1, 1) = MR_sv(3);
	MR_tfield(1, MR_tempr1, 2) = MR_r1;
	MR_r1 = MR_tempr1;
	}
MR_def_label(mdb__declarative_user__browse_atom_argument_8_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 6);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(5);
	MR_tfield(0, MR_r2, 0) = MR_tfield(0, MR_tempr1, 0);
	MR_tfield(0, MR_r2, 1) = MR_tfield(0, MR_tempr1, 1);
	MR_tfield(0, MR_r2, 2) = MR_sv(1);
	MR_tfield(0, MR_r2, 3) = MR_tfield(0, MR_tempr1, 3);
	MR_tfield(0, MR_r2, 4) = MR_tfield(0, MR_tempr1, 4);
	MR_tfield(0, MR_r2, 5) = MR_tfield(0, MR_tempr1, 5);
	MR_decr_sp_and_return(6);
	}
MR_def_label(mdb__declarative_user__browse_atom_argument_8_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_sv(5), 1);
	MR_r2 = (MR_Word) MR_string_const("Invalid argument number\n", 24);
	MR_np_call_localret_ent(io__write_string_4_0,
		mdb__declarative_user__browse_atom_argument_8_0_i19);
MR_def_label(mdb__declarative_user__browse_atom_argument_8_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_r2 = MR_sv(5);
	MR_decr_sp_and_return(6);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(mdb__browse__save_and_browse_browser_term_xml_6_0);

MR_BEGIN_MODULE(mdb__declarative_user_module7)
	MR_init_entry1(mdb__declarative_user__browse_xml_atom_argument_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__browse_xml_atom_argument_5_0);
	MR_init_label6(mdb__declarative_user__browse_xml_atom_argument_5_0,2,3,5,8,9,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'browse_xml_atom_argument'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__browse_xml_atom_argument_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_tfield(0, MR_r1, 1);
	MR_np_call_localret_ent(fn__mdb__declarative_execution__chosen_head_vars_presentation_0_0,
		mdb__declarative_user__browse_xml_atom_argument_5_0_i2);
MR_def_label(mdb__declarative_user__browse_xml_atom_argument_5_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(mdb__declarative_execution__maybe_filter_headvars_3_0,
		mdb__declarative_user__browse_xml_atom_argument_5_0_i3);
MR_def_label(mdb__declarative_user__browse_xml_atom_argument_5_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdb__declarative_execution, trace_atom_arg);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(1);
	}
	MR_np_call_localret_ent(list__index1_3_0,
		mdb__declarative_user__browse_xml_atom_argument_5_0_i5);
MR_def_label(mdb__declarative_user__browse_xml_atom_argument_5_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_xml_atom_argument_5_0_i4);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(0, MR_r2, 2);
	if (MR_LTAGS_TEST(MR_tempr1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_xml_atom_argument_5_0_i4);
	}
	MR_r1 = MR_tfield(1, MR_tempr1, 0);
	}
	MR_np_call_localret_ent(mdb__term_rep__rep_to_univ_2_0,
		mdb__declarative_user__browse_xml_atom_argument_5_0_i8);
MR_def_label(mdb__declarative_user__browse_xml_atom_argument_5_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__mdb__browser_term__univ_to_browser_term_1_0,
		mdb__declarative_user__browse_xml_atom_argument_5_0_i9);
MR_def_label(mdb__declarative_user__browse_xml_atom_argument_5_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(2);
	MR_r2 = MR_tfield(0, MR_tempr1, 1);
	MR_r3 = MR_r2;
	MR_r4 = MR_tfield(0, MR_tempr1, 2);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(mdb__browse__save_and_browse_browser_term_xml_6_0);
	}
MR_def_label(mdb__declarative_user__browse_xml_atom_argument_5_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_sv(2), 1);
	MR_r2 = (MR_Word) MR_string_const("Invalid argument number\n", 24);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(io__write_string_4_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_mdb__browse__type_ctor_info_unbound_0;
MR_decl_entry(fn__univ__univ_1_1);

MR_BEGIN_MODULE(mdb__declarative_user_module8)
	MR_init_entry1(mdb__declarative_user__get_user_arg_values_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__get_user_arg_values_2_0);
	MR_init_label6(mdb__declarative_user__get_user_arg_values_2_0,36,4,9,8,11,35)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'get_user_arg_values'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__get_user_arg_values_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__get_user_arg_values_2_0_i36);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_proceed();
MR_def_label(mdb__declarative_user__get_user_arg_values_2_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_r2 = MR_tfield(1, MR_r1, 0);
	MR_sv(1) = MR_tfield(0, MR_r2, 0);
	MR_sv(2) = MR_tfield(0, MR_r2, 2);
	MR_r1 = MR_tfield(1, MR_r1, 1);
	MR_np_localcall_lab(mdb__declarative_user__get_user_arg_values_2_0,
		mdb__declarative_user__get_user_arg_values_2_0_i4);
MR_def_label(mdb__declarative_user__get_user_arg_values_2_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_EQ(MR_sv(1),0)) {
		MR_GOTO_LAB(mdb__declarative_user__get_user_arg_values_2_0_i35);
	}
	if (MR_LTAGS_TESTR(MR_sv(2),0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__get_user_arg_values_2_0_i8);
	}
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdb__browse, unbound);
	MR_np_call_localret_ent(fn__univ__univ_1_1,
		mdb__declarative_user__get_user_arg_values_2_0_i9);
MR_def_label(mdb__declarative_user__get_user_arg_values_2_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_r1;
	MR_tfield(1, MR_r2, 1) = MR_sv(1);
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(3);
MR_def_label(mdb__declarative_user__get_user_arg_values_2_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = MR_tfield(1, MR_sv(2), 0);
	MR_np_call_localret_ent(mdb__term_rep__rep_to_univ_2_0,
		mdb__declarative_user__get_user_arg_values_2_0_i11);
MR_def_label(mdb__declarative_user__get_user_arg_values_2_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_r1;
	MR_tfield(1, MR_tempr1, 1) = MR_sv(1);
	MR_r1 = MR_tempr1;
	}
MR_def_label(mdb__declarative_user__get_user_arg_values_2_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(3);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(mdb__browse__string_is_return_value_alias_1_0);
MR_decl_entry(list__last_2_0);
MR_decl_entry(fn__list__length_1_0);
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__declarative_debugger__type_ctor_info_diagnoser_exception_0;
MR_decl_entry(exception__throw_1_0);
MR_decl_entry(fn__list__det_index1_2_0);

MR_BEGIN_MODULE(mdb__declarative_user_module9)
	MR_init_entry1(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0);
	MR_init_label10(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0,72,8,11,13,10,7,5,20,4,24)
	MR_init_label2(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0,22,28)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'convert_dirs_to_term_path_from_atom'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0_i72);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_proceed();
MR_def_label(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0,72)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r2, 0);
	MR_r3 = MR_tempr1;
	if (MR_PTAG_TESTR(MR_tempr1,2)) {
		MR_GOTO_LAB(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0_i5);
	}
	MR_sv(2) = MR_tfield(1, MR_r2, 1);
	MR_sv(1) = MR_tfield(0, MR_r1, 1);
	MR_r1 = MR_tfield(2, MR_tempr1, 0);
	}
	MR_np_call_localret_ent(mdb__browse__string_is_return_value_alias_1_0,
		mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0_i8);
MR_def_label(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0_i7);
	}
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdb__declarative_execution, trace_atom_arg);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(list__last_2_0,
		mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0_i11);
MR_def_label(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0_i10);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_tfield(0, MR_r2, 2);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdb__declarative_execution, trace_atom_arg);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__list__length_1_0,
		mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0_i13);
MR_def_label(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_GOTO_LAB(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0_i4);
MR_def_label(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdb__declarative_debugger, diagnoser_exception);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,2,0);
	MR_np_call_localret_ent(exception__throw_1_0,
		mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0_i4);
MR_def_label(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdb__declarative_debugger, diagnoser_exception);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,2,1);
	MR_np_call_localret_ent(exception__throw_1_0,
		mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0_i4);
MR_def_label(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_tfield(1, MR_r2, 1);
	MR_sv(1) = MR_tfield(1, MR_r3, 0);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdb__declarative_execution, trace_atom_arg);
	MR_r2 = MR_tfield(0, MR_tempr1, 1);
	MR_r3 = MR_sv(1);
	}
	MR_np_call_localret_ent(fn__list__det_index1_2_0,
		mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0_i20);
MR_def_label(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_r1, 2);
MR_def_label(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0_i22);
	}
	if (MR_LTAGS_TESTR(MR_sv(2),0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0_i24);
	}
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r1, 0) = MR_sv(1);
	MR_tfield(1, MR_r1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_decr_sp_and_return(3);
MR_def_label(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdb__declarative_debugger, diagnoser_exception);
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,2,2);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(exception__throw_1_0);
MR_def_label(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(1, MR_r1, 0);
	MR_r2 = MR_sv(2);
	MR_np_call_localret_ent(mdb__browser_info__convert_dirs_to_term_path_3_0,
		mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0_i28);
MR_def_label(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_sv(1);
	MR_tfield(1, MR_r2, 1) = MR_r1;
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(3);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__mdbcomp__rtti_access__get_proc_label_from_layout_1_0);
MR_decl_entry(mdb__declarative_execution__get_pred_attributes_5_0);
MR_decl_entry(fn__bool__pred_to_bool_1_0);
MR_decl_entry(fn__mdbcomp__prim_data__sym_name_to_string_1_0);
MR_decl_entry(fn__f_115_116_114_105_110_103_95_95_43_43_2_0);
MR_decl_entry(fn__mdb__browser_term__synthetic_term_to_browser_term_3_0);

MR_BEGIN_MODULE(mdb__declarative_user_module10)
	MR_init_entry1(mdb__declarative_user__browse_atom_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__browse_atom_7_0);
	MR_init_label10(mdb__declarative_user__browse_atom_7_0,2,3,4,6,7,8,9,10,13,15)
	MR_init_label3(mdb__declarative_user__browse_atom_7_0,16,17,14)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'browse_atom'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__browse_atom_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_tfield(0, MR_r2, 1);
	MR_sv(6) = MR_r3;
	MR_r1 = MR_tfield(0, MR_r2, 0);
	MR_np_call_localret_ent(fn__mdbcomp__rtti_access__get_proc_label_from_layout_1_0,
		mdb__declarative_user__browse_atom_7_0_i2);
MR_def_label(mdb__declarative_user__browse_atom_7_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_sv(3) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(mdb__declarative_user__get_user_arg_values_2_0,
		mdb__declarative_user__browse_atom_7_0_i3);
MR_def_label(mdb__declarative_user__browse_atom_7_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_sv(3) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(mdb__declarative_execution__get_pred_attributes_5_0,
		mdb__declarative_user__browse_atom_7_0_i4);
MR_def_label(mdb__declarative_user__browse_atom_7_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(mdb__declarative_user__IntroducedFrom__pred__browse_atom__695__1_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_r4;
	MR_tfield(0, MR_tempr1, 4) = (MR_Integer) 1;
	MR_sv(4) = MR_r1;
	MR_sv(5) = MR_r2;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__bool__pred_to_bool_1_0,
		mdb__declarative_user__browse_atom_7_0_i6);
MR_def_label(mdb__declarative_user__browse_atom_7_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(4);
	MR_sv(4) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__mdbcomp__prim_data__sym_name_to_string_1_0,
		mdb__declarative_user__browse_atom_7_0_i7);
MR_def_label(mdb__declarative_user__browse_atom_7_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(5);
	MR_sv(5) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(".", 1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		mdb__declarative_user__browse_atom_7_0_i8);
MR_def_label(mdb__declarative_user__browse_atom_7_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		mdb__declarative_user__browse_atom_7_0_i9);
MR_def_label(mdb__declarative_user__browse_atom_7_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_r3 = MR_sv(4);
	MR_np_call_localret_ent(fn__mdb__browser_term__synthetic_term_to_browser_term_3_0,
		mdb__declarative_user__browse_atom_7_0_i10);
MR_def_label(mdb__declarative_user__browse_atom_7_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(4,0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 4) = MR_sv(2);
	MR_tag_alloc_heap(MR_r4, 1, (MR_Integer) 1);
	MR_tfield(1, MR_r4, 0) = MR_tempr1;
	MR_tempr2 = MR_sv(6);
	MR_r2 = MR_tfield(0, MR_tempr2, 0);
	MR_r3 = MR_tfield(0, MR_tempr2, 1);
	MR_r5 = MR_tfield(0, MR_tempr2, 2);
	}
	MR_np_call_localret_ent(mdb__browse__browse_browser_term_9_0,
		mdb__declarative_user__browse_atom_7_0_i13);
MR_def_label(mdb__declarative_user__browse_atom_7_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_atom_7_0_i15);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_sv(1) = MR_r2;
	MR_GOTO_LAB(mdb__declarative_user__browse_atom_7_0_i14);
MR_def_label(mdb__declarative_user__browse_atom_7_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	MR_sv(3) = MR_tfield(1, MR_r1, 0);
	MR_sv(4) = MR_tfield(1, MR_r1, 1);
	MR_r1 = MR_tfield(1, MR_r1, 2);
	MR_np_call_localret_ent(mdb__browse__simplify_dirs_2_0,
		mdb__declarative_user__browse_atom_7_0_i16);
MR_def_label(mdb__declarative_user__browse_atom_7_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0,
		mdb__declarative_user__browse_atom_7_0_i17);
MR_def_label(mdb__declarative_user__browse_atom_7_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 3);
	MR_tfield(1, MR_tempr1, 0) = MR_sv(3);
	MR_tfield(1, MR_tempr1, 1) = MR_sv(4);
	MR_tfield(1, MR_tempr1, 2) = MR_r1;
	MR_r1 = MR_tempr1;
	}
MR_def_label(mdb__declarative_user__browse_atom_7_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 6);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(6);
	MR_tfield(0, MR_r2, 0) = MR_tfield(0, MR_tempr1, 0);
	MR_tfield(0, MR_r2, 1) = MR_tfield(0, MR_tempr1, 1);
	MR_tfield(0, MR_r2, 2) = MR_sv(1);
	MR_tfield(0, MR_r2, 3) = MR_tfield(0, MR_tempr1, 3);
	MR_tfield(0, MR_r2, 4) = MR_tfield(0, MR_tempr1, 4);
	MR_tfield(0, MR_r2, 5) = MR_tfield(0, MR_tempr1, 5);
	MR_decr_sp_and_return(7);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module11)
	MR_init_entry1(mdb__declarative_user__browse_xml_atom_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__browse_xml_atom_4_0);
	MR_init_label8(mdb__declarative_user__browse_xml_atom_4_0,2,3,4,6,7,8,9,10)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'browse_xml_atom'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__browse_xml_atom_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_tfield(0, MR_r1, 1);
	MR_r1 = MR_tfield(0, MR_r1, 0);
	MR_np_call_localret_ent(fn__mdbcomp__rtti_access__get_proc_label_from_layout_1_0,
		mdb__declarative_user__browse_xml_atom_4_0_i2);
MR_def_label(mdb__declarative_user__browse_xml_atom_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_sv(2) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(mdb__declarative_user__get_user_arg_values_2_0,
		mdb__declarative_user__browse_xml_atom_4_0_i3);
MR_def_label(mdb__declarative_user__browse_xml_atom_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_sv(2) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(mdb__declarative_execution__get_pred_attributes_5_0,
		mdb__declarative_user__browse_xml_atom_4_0_i4);
MR_def_label(mdb__declarative_user__browse_xml_atom_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,1);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(mdb__declarative_user__IntroducedFrom__pred__browse_xml_atom__714__1_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_r4;
	MR_tfield(0, MR_tempr1, 4) = (MR_Integer) 1;
	MR_sv(3) = MR_r1;
	MR_sv(4) = MR_r2;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__bool__pred_to_bool_1_0,
		mdb__declarative_user__browse_xml_atom_4_0_i6);
MR_def_label(mdb__declarative_user__browse_xml_atom_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_sv(3) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__mdbcomp__prim_data__sym_name_to_string_1_0,
		mdb__declarative_user__browse_xml_atom_4_0_i7);
MR_def_label(mdb__declarative_user__browse_xml_atom_4_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(4);
	MR_sv(4) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(".", 1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		mdb__declarative_user__browse_xml_atom_4_0_i8);
MR_def_label(mdb__declarative_user__browse_xml_atom_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		mdb__declarative_user__browse_xml_atom_4_0_i9);
MR_def_label(mdb__declarative_user__browse_xml_atom_4_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(3);
	MR_np_call_localret_ent(fn__mdb__browser_term__synthetic_term_to_browser_term_3_0,
		mdb__declarative_user__browse_xml_atom_4_0_i10);
MR_def_label(mdb__declarative_user__browse_xml_atom_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_r2 = MR_tfield(0, MR_tempr1, 1);
	MR_r3 = MR_r2;
	MR_r4 = MR_tfield(0, MR_tempr1, 2);
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(mdb__browse__save_and_browse_browser_term_xml_6_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module12)
	MR_init_entry1(fn__mdb__declarative_user__decl_caller_type_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__mdb__declarative_user__decl_caller_type_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'decl_caller_type'/1 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__mdb__declarative_user__decl_caller_type_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module13)
	MR_init_entry1(mdb__declarative_user__print_atom_arguments_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__print_atom_arguments_6_0);
	MR_init_label10(mdb__declarative_user__print_atom_arguments_6_0,34,2,3,5,8,9,10,4,11,12)
	MR_init_label1(mdb__declarative_user__print_atom_arguments_6_0,36)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'print_atom_arguments'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__print_atom_arguments_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(6);
	MR_sv(6) = (MR_Word) MR_succip;
MR_def_label(mdb__declarative_user__print_atom_arguments_6_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_sv(4) = MR_r4;
	MR_sv(5) = MR_tfield(0, MR_r1, 1);
	MR_np_call_localret_ent(fn__mdb__declarative_execution__chosen_head_vars_presentation_0_0,
		mdb__declarative_user__print_atom_arguments_6_0_i2);
MR_def_label(mdb__declarative_user__print_atom_arguments_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(5);
	MR_np_call_localret_ent(mdb__declarative_execution__maybe_filter_headvars_3_0,
		mdb__declarative_user__print_atom_arguments_6_0_i3);
MR_def_label(mdb__declarative_user__print_atom_arguments_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdb__declarative_execution, trace_atom_arg);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(2);
	}
	MR_np_call_localret_ent(list__index1_3_0,
		mdb__declarative_user__print_atom_arguments_6_0_i5);
MR_def_label(mdb__declarative_user__print_atom_arguments_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__print_atom_arguments_6_0_i4);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(0, MR_r2, 2);
	if (MR_LTAGS_TEST(MR_tempr1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__print_atom_arguments_6_0_i4);
	}
	MR_r1 = MR_tfield(1, MR_tempr1, 0);
	}
	MR_np_call_localret_ent(mdb__term_rep__rep_to_univ_2_0,
		mdb__declarative_user__print_atom_arguments_6_0_i8);
MR_def_label(mdb__declarative_user__print_atom_arguments_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__mdb__browser_term__univ_to_browser_term_1_0,
		mdb__declarative_user__print_atom_arguments_6_0_i9);
MR_def_label(mdb__declarative_user__print_atom_arguments_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(4);
	MR_r2 = MR_tfield(0, MR_tempr1, 1);
	MR_r3 = (MR_Integer) 0;
	MR_r4 = MR_tfield(0, MR_tempr1, 2);
	}
	MR_np_call_localret_ent(mdb__browse__print_browser_term_6_0,
		mdb__declarative_user__print_atom_arguments_6_0_i10);
MR_def_label(mdb__declarative_user__print_atom_arguments_6_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r3 = MR_sv(3);
	MR_r4 = MR_sv(4);
	MR_r2 = (MR_Integer) 1;
	MR_GOTO_LAB(mdb__declarative_user__print_atom_arguments_6_0_i12);
MR_def_label(mdb__declarative_user__print_atom_arguments_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_sv(4), 1);
	MR_r2 = (MR_Word) MR_string_const("Invalid argument number\n", 24);
	MR_np_call_localret_ent(io__write_string_4_0,
		mdb__declarative_user__print_atom_arguments_6_0_i11);
MR_def_label(mdb__declarative_user__print_atom_arguments_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r3 = MR_sv(3);
	MR_r4 = MR_sv(4);
	MR_r2 = (MR_Integer) 0;
MR_def_label(mdb__declarative_user__print_atom_arguments_6_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r2,1)) {
		MR_GOTO_LAB(mdb__declarative_user__print_atom_arguments_6_0_i36);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_sv(2);
	MR_tempr1 = ((MR_Integer) MR_tempr2 + (MR_Integer) 1);
	if (((MR_Integer) MR_tempr1 > (MR_Integer) MR_r3)) {
		MR_GOTO_LAB(mdb__declarative_user__print_atom_arguments_6_0_i36);
	}
	MR_r2 = ((MR_Integer) MR_tempr2 + (MR_Integer) 1);
	MR_succip_word = MR_sv(6);
	MR_GOTO_LAB(mdb__declarative_user__print_atom_arguments_6_0_i34);
	}
MR_def_label(mdb__declarative_user__print_atom_arguments_6_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(6);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module14)
	MR_init_entry1(mdb__declarative_user__cmd_handler_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__cmd_handler_2_0);
	MR_init_label10(mdb__declarative_user__cmd_handler_2_0,3,5,7,9,11,13,15,17,19,21)
	MR_init_label10(mdb__declarative_user__cmd_handler_2_0,23,25,27,29,31,33,35,37,39,41)
	MR_init_label10(mdb__declarative_user__cmd_handler_2_0,43,45,47,49,51,53,55,57,59,61)
	MR_init_label3(mdb__declarative_user__cmd_handler_2_0,63,66,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'cmd_handler'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__cmd_handler_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("?", 1)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i3);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,5,0);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("a", 1)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i5);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,7,0);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("b", 1)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i7);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,5,1);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("h", 1)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i9);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,5,2);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("i", 1)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i11);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,7,1);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("m", 1)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i13);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,5,3);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("n", 1)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i15);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,7,2);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("p", 1)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i17);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,5,4);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("q", 1)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i19);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,7,3);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("s", 1)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i21);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,7,4);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("t", 1)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i23);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,5,5);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("y", 1)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i25);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,7,5);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("no", 2)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i27);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,7,6);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("pd", 2)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i29);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,7,7);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("yes", 3)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i31);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,7,8);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("help", 4)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i33);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,5,6);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("info", 4)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i35);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,7,9);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("mode", 4)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i37);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,5,7);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,37)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("quit", 4)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i39);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,7,10);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("size", 4)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i41);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,8,0);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,41)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("skip", 4)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i43);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,7,11);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("undo", 4)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i45);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,7,12);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,45)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("abort", 5)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i47);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,7,13);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,47)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("depth", 5)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i49);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,8,1);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,49)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("lines", 5)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i51);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,8,2);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,51)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("print", 5)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i53);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,5,8);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,53)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("trust", 5)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i55);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,5,9);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,55)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("width", 5)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i57);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,8,3);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,57)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("browse", 6)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i59);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,5,10);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,59)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("format", 6)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i61);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,5,11);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,61)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("params", 6)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i63);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,7,14);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,63)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("actions", 7)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i66);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,5,12);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,66)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r1, MR_string_const("inadmissible", 12)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__cmd_handler_2_0_i1);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(0,7,15);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__cmd_handler_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(mdb__util__trace_getline_6_0);
MR_decl_entry(io__error_message_2_0);
MR_decl_entry(io__nl_3_0);
MR_decl_entry(fn__string__words_separator_2_0);
MR_declare_entry(mercury__do_call_closure_1);

MR_BEGIN_MODULE(mdb__declarative_user_module15)
	MR_init_entry1(mdb__declarative_user__get_command_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__get_command_6_0);
	MR_init_label10(mdb__declarative_user__get_command_6_0,2,19,4,6,7,5,10,12,14,16)
	MR_init_label1(mdb__declarative_user__get_command_6_0,13)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'get_command'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__get_command_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r2;
	MR_r2 = MR_tfield(0, MR_r2, 0);
	MR_r3 = MR_tfield(0, MR_sv(1), 1);
	MR_np_call_localret_ent(mdb__util__trace_getline_6_0,
		mdb__declarative_user__get_command_6_0_i2);
MR_def_label(mdb__declarative_user__get_command_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__get_command_6_0_i4);
	}
MR_def_label(mdb__declarative_user__get_command_6_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_r1 = (MR_Word) MR_tbmkword(0, 10);
	MR_decr_sp_and_return(3);
MR_def_label(mdb__declarative_user__get_command_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(mdb__declarative_user__get_command_6_0_i5);
	}
	MR_r1 = MR_tfield(2, MR_r1, 0);
	MR_np_call_localret_ent(io__error_message_2_0,
		mdb__declarative_user__get_command_6_0_i6);
MR_def_label(mdb__declarative_user__get_command_6_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_tfield(0, MR_sv(1), 1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(io__write_string_4_0,
		mdb__declarative_user__get_command_6_0_i7);
MR_def_label(mdb__declarative_user__get_command_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_sv(1), 1);
	MR_np_call_localret_ent(io__nl_3_0,
		mdb__declarative_user__get_command_6_0_i19);
MR_def_label(mdb__declarative_user__get_command_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,5,13);
	MR_r2 = MR_tfield(1, MR_tempr1, 0);
	}
	MR_np_call_localret_ent(fn__string__words_separator_2_0,
		mdb__declarative_user__get_command_6_0_i10);
MR_def_label(mdb__declarative_user__get_command_6_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__get_command_6_0_i12);
	}
	MR_r2 = MR_sv(1);
	MR_r1 = (MR_Word) MR_tbmkword(0, 11);
	MR_decr_sp_and_return(3);
MR_def_label(mdb__declarative_user__get_command_6_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_tfield(1, MR_r1, 1);
	MR_r1 = MR_tfield(1, MR_r1, 0);
	MR_np_call_localret_ent(mdb__declarative_user__cmd_handler_2_0,
		mdb__declarative_user__get_command_6_0_i14);
MR_def_label(mdb__declarative_user__get_command_6_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__get_command_6_0_i13);
	}
	MR_r1 = MR_r2;
	MR_r2 = MR_sv(2);
	MR_set_prof_ho_caller_proc(MR_ENTRY_AP(mdb__declarative_user__get_command_6_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_closure_1),
		mercury__mdb__declarative_user__get_command_6_0_i16);
MR_def_label(mdb__declarative_user__get_command_6_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__get_command_6_0_i13);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_sv(1);
	MR_r1 = MR_tempr1;
	MR_decr_sp_and_return(3);
	}
MR_def_label(mdb__declarative_user__get_command_6_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_r1 = (MR_Word) MR_tbmkword(0, 12);
	MR_decr_sp_and_return(3);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module16)
	MR_init_entry1(mdb__declarative_user__count_tabled_io_actions_2_8_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__count_tabled_io_actions_2_8_0);
	MR_init_label4(mdb__declarative_user__count_tabled_io_actions_2_8_0,17,2,3,5)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'count_tabled_io_actions_2'/8 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__count_tabled_io_actions_2_8_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
MR_def_label(mdb__declarative_user__count_tabled_io_actions_2_8_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r1 != MR_r2)) {
		MR_GOTO_LAB(mdb__declarative_user__count_tabled_io_actions_2_8_0_i2);
	}
	MR_r1 = MR_r3;
	MR_r2 = MR_r4;
	MR_decr_sp_and_return(5);
MR_def_label(mdb__declarative_user__count_tabled_io_actions_2_8_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_sv(4) = MR_r4;
	MR_np_call_localret_ent(mdb__io_action__get_maybe_io_action_4_0,
		mdb__declarative_user__count_tabled_io_actions_2_8_0_i3);
MR_def_label(mdb__declarative_user__count_tabled_io_actions_2_8_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__count_tabled_io_actions_2_8_0_i5);
	}
	MR_r2 = MR_sv(2);
	MR_r4 = ((MR_Integer) MR_sv(4) + (MR_Integer) 1);
	MR_r3 = MR_sv(3);
	MR_r1 = ((MR_Integer) MR_sv(1) + (MR_Integer) 1);
	MR_succip_word = MR_sv(5);
	MR_GOTO_LAB(mdb__declarative_user__count_tabled_io_actions_2_8_0_i17);
MR_def_label(mdb__declarative_user__count_tabled_io_actions_2_8_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_r4 = MR_sv(4);
	MR_r3 = ((MR_Integer) MR_sv(3) + (MR_Integer) 1);
	MR_r1 = ((MR_Integer) MR_sv(1) + (MR_Integer) 1);
	MR_succip_word = MR_sv(5);
	MR_GOTO_LAB(mdb__declarative_user__count_tabled_io_actions_2_8_0_i17);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module17)
	MR_init_entry1(mdb__declarative_user__print_tabled_io_actions_2_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__print_tabled_io_actions_2_5_0);
	MR_init_label6(mdb__declarative_user__print_tabled_io_actions_2_5_0,18,3,13,5,6,20)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'print_tabled_io_actions_2'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__print_tabled_io_actions_2_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
MR_def_label(mdb__declarative_user__print_tabled_io_actions_2_5_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r2 == MR_r3)) {
		MR_GOTO_LAB(mdb__declarative_user__print_tabled_io_actions_2_5_0_i20);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(mdb__io_action__get_maybe_io_action_4_0,
		mdb__declarative_user__print_tabled_io_actions_2_5_0_i3);
MR_def_label(mdb__declarative_user__print_tabled_io_actions_2_5_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__print_tabled_io_actions_2_5_0_i5);
	}
MR_def_label(mdb__declarative_user__print_tabled_io_actions_2_5_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r3 = MR_sv(3);
	MR_r2 = ((MR_Integer) MR_sv(2) + (MR_Integer) 1);
	MR_succip_word = MR_sv(4);
	MR_GOTO_LAB(mdb__declarative_user__print_tabled_io_actions_2_5_0_i18);
MR_def_label(mdb__declarative_user__print_tabled_io_actions_2_5_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(1, MR_r1, 0);
	MR_np_call_localret_ent(fn__mdb__io_action__io_action_to_browser_term_1_0,
		mdb__declarative_user__print_tabled_io_actions_2_5_0_i6);
MR_def_label(mdb__declarative_user__print_tabled_io_actions_2_5_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_r2 = MR_tfield(0, MR_tempr1, 1);
	MR_r3 = (MR_Integer) 2;
	MR_r4 = MR_tfield(0, MR_tempr1, 2);
	}
	MR_np_call_localret_ent(mdb__browse__print_browser_term_6_0,
		mdb__declarative_user__print_tabled_io_actions_2_5_0_i13);
MR_def_label(mdb__declarative_user__print_tabled_io_actions_2_5_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(4);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(io__write_int_4_0);
MR_decl_entry(fn__mdb__browser_info__get_num_printed_io_actions_1_0);

MR_BEGIN_MODULE(mdb__declarative_user_module18)
	MR_init_entry1(mdb__declarative_user__write_io_actions_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__write_io_actions_5_0);
	MR_init_label8(mdb__declarative_user__write_io_actions_5_0,4,7,8,10,12,11,14,35)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'write_io_actions'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__write_io_actions_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_EQ(MR_r2,0)) {
		MR_GOTO_LAB(mdb__declarative_user__write_io_actions_5_0_i35);
	}
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_r5 = MR_tfield(0, MR_r1, 1);
	if (MR_INT_NE(MR_r2,1)) {
		MR_GOTO_LAB(mdb__declarative_user__write_io_actions_5_0_i4);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_r1 = MR_r5;
	MR_r2 = (MR_Word) MR_string_const("1 tabled IO action:", 19);
	MR_np_call_localret_ent(io__write_string_4_0,
		mdb__declarative_user__write_io_actions_5_0_i8);
MR_def_label(mdb__declarative_user__write_io_actions_5_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_r1 = MR_r5;
	MR_np_call_localret_ent(io__write_int_4_0,
		mdb__declarative_user__write_io_actions_5_0_i7);
MR_def_label(mdb__declarative_user__write_io_actions_5_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_sv(1), 1);
	MR_r2 = (MR_Word) MR_string_const(" tabled IO actions:", 19);
	MR_np_call_localret_ent(io__write_string_4_0,
		mdb__declarative_user__write_io_actions_5_0_i8);
MR_def_label(mdb__declarative_user__write_io_actions_5_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_sv(1), 2);
	MR_np_call_localret_ent(fn__mdb__browser_info__get_num_printed_io_actions_1_0,
		mdb__declarative_user__write_io_actions_5_0_i10);
MR_def_label(mdb__declarative_user__write_io_actions_5_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_tfield(0, MR_sv(1), 1);
	if (((MR_Integer) MR_sv(2) > (MR_Integer) MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__write_io_actions_5_0_i11);
	}
	MR_r1 = MR_r3;
	MR_np_call_localret_ent(io__nl_3_0,
		mdb__declarative_user__write_io_actions_5_0_i12);
MR_def_label(mdb__declarative_user__write_io_actions_5_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(3);
	MR_r2 = MR_tfield(0, MR_tempr1, 0);
	MR_r3 = MR_tfield(0, MR_tempr1, 1);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(mdb__declarative_user__print_tabled_io_actions_2_5_0);
	}
MR_def_label(mdb__declarative_user__write_io_actions_5_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r3;
	MR_r2 = (MR_Word) MR_string_const(" too many to show", 17);
	MR_np_call_localret_ent(io__write_string_4_0,
		mdb__declarative_user__write_io_actions_5_0_i14);
MR_def_label(mdb__declarative_user__write_io_actions_5_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_sv(1), 1);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(io__nl_3_0);
MR_def_label(mdb__declarative_user__write_io_actions_5_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(mdb__declarative_debugger__unravel_decl_atom_3_0);
extern const MR_TypeCtorInfo_Struct mercury_data_univ__type_ctor_info_univ_0;
MR_decl_entry(list__map_3_0);
MR_decl_entry(fn__mdb__util__is_function_1_0);

MR_BEGIN_MODULE(mdb__declarative_user_module19)
	MR_init_entry1(mdb__declarative_user__write_decl_atom_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__write_decl_atom_6_0);
	MR_init_label10(mdb__declarative_user__write_decl_atom_6_0,2,3,4,5,6,7,9,10,11,12)
	MR_init_label3(mdb__declarative_user__write_decl_atom_6_0,15,16,13)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'write_decl_atom'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__write_decl_atom_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(7);
	MR_sv(7) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_r4;
	MR_r1 = MR_tfield(0, MR_r1, 1);
	MR_np_call_localret_ent(io__write_string_4_0,
		mdb__declarative_user__write_decl_atom_6_0_i2);
MR_def_label(mdb__declarative_user__write_decl_atom_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(mdb__declarative_debugger__unravel_decl_atom_3_0,
		mdb__declarative_user__write_decl_atom_6_0_i3);
MR_def_label(mdb__declarative_user__write_decl_atom_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_r2;
	MR_sv(4) = MR_tfield(0, MR_r1, 1);
	MR_r1 = MR_tfield(0, MR_r1, 0);
	MR_np_call_localret_ent(fn__mdbcomp__rtti_access__get_proc_label_from_layout_1_0,
		mdb__declarative_user__write_decl_atom_6_0_i4);
MR_def_label(mdb__declarative_user__write_decl_atom_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(mdb__declarative_execution__get_pred_attributes_5_0,
		mdb__declarative_user__write_decl_atom_6_0_i5);
MR_def_label(mdb__declarative_user__write_decl_atom_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(5) = MR_r2;
	MR_sv(6) = MR_r4;
	MR_np_call_localret_ent(fn__mdb__declarative_execution__chosen_head_vars_presentation_0_0,
		mdb__declarative_user__write_decl_atom_6_0_i6);
MR_def_label(mdb__declarative_user__write_decl_atom_6_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(4);
	MR_np_call_localret_ent(mdb__declarative_execution__maybe_filter_headvars_3_0,
		mdb__declarative_user__write_decl_atom_6_0_i7);
MR_def_label(mdb__declarative_user__write_decl_atom_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdb__declarative_execution, trace_atom_arg);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(univ, univ);
	MR_r3 = (MR_Word) MR_TAG_COMMON(0,5,14);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(list__map_3_0,
		mdb__declarative_user__write_decl_atom_6_0_i9);
MR_def_label(mdb__declarative_user__write_decl_atom_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_r1 = MR_sv(6);
	MR_np_call_localret_ent(fn__mdb__util__is_function_1_0,
		mdb__declarative_user__write_decl_atom_6_0_i10);
MR_def_label(mdb__declarative_user__write_decl_atom_6_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(4);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__mdb__browser_term__synthetic_term_to_browser_term_3_0,
		mdb__declarative_user__write_decl_atom_6_0_i11);
MR_def_label(mdb__declarative_user__write_decl_atom_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_r2 = MR_tfield(0, MR_tempr1, 1);
	MR_r3 = MR_sv(2);
	MR_r4 = MR_tfield(0, MR_tempr1, 2);
	}
	MR_np_call_localret_ent(mdb__browse__print_browser_term_6_0,
		mdb__declarative_user__write_decl_atom_6_0_i12);
MR_def_label(mdb__declarative_user__write_decl_atom_6_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_sv(3),0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__write_decl_atom_6_0_i13);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_sv(3), 0);
	MR_sv(2) = MR_tempr1;
	MR_r1 = MR_tfield(0, MR_tempr1, 0);
	MR_r2 = MR_tfield(0, MR_tempr1, 1);
	MR_r3 = (MR_Integer) 0;
	MR_r4 = (MR_Integer) 0;
	}
	MR_np_call_localret_ent(mdb__declarative_user__count_tabled_io_actions_2_8_0,
		mdb__declarative_user__write_decl_atom_6_0_i15);
MR_def_label(mdb__declarative_user__write_decl_atom_6_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_sv(2);
	MR_sv(2) = MR_r2;
	MR_tempr2 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr2;
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(mdb__declarative_user__write_io_actions_5_0,
		mdb__declarative_user__write_decl_atom_6_0_i16);
MR_def_label(mdb__declarative_user__write_decl_atom_6_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_LE(MR_sv(2),0)) {
		MR_GOTO_LAB(mdb__declarative_user__write_decl_atom_6_0_i13);
	}
	MR_r1 = MR_tfield(0, MR_sv(1), 1);
	MR_r2 = (MR_Word) MR_string_const("Warning: some IO actions for this atom are not tabled.\n", 55);
	MR_succip_word = MR_sv(7);
	MR_decr_sp(7);
	MR_np_tailcall_ent(io__write_string_4_0);
MR_def_label(mdb__declarative_user__write_decl_atom_6_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(7);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module20)
	MR_init_entry1(mdb__declarative_user__write_decl_init_atom_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__write_decl_init_atom_6_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'write_decl_init_atom'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__write_decl_init_atom_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 1);
	MR_tfield(0, MR_tempr1, 0) = MR_r4;
	MR_r4 = MR_tempr1;
	MR_np_tailcall_ent(mdb__declarative_user__write_decl_atom_6_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module21)
	MR_init_entry1(mdb__declarative_user__write_decl_final_atom_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__write_decl_final_atom_6_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'write_decl_final_atom'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__write_decl_final_atom_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 1);
	MR_tfield(1, MR_tempr1, 0) = MR_r4;
	MR_r4 = MR_tempr1;
	MR_np_tailcall_ent(mdb__declarative_user__write_decl_atom_6_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__mdb__declarative_debugger__get_decl_question_node_1_0);

MR_BEGIN_MODULE(mdb__declarative_user_module22)
	MR_init_entry1(mdb__declarative_user__query_user_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__query_user_6_0);
	MR_init_label8(mdb__declarative_user__query_user_6_0,7,8,9,11,12,5,18,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'query_user'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__mdb__declarative_user__query_user_6_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_sv(3) = MR_r1;
	MR_r1 = MR_mask_field(MR_r2, 0);
	MR_r2 = MR_r3;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_tfield(0, MR_r2, 5);
	MR_tempr2 = MR_tfield(0, MR_r2, 3);
	if (MR_INT_NE(MR_tempr1,0)) {
		MR_GOTO_LAB(mdb__declarative_user__query_user_6_0_i5);
	}
	if (MR_INT_NE(MR_tempr2,0)) {
		MR_GOTO_LAB(mdb__declarative_user__query_user_6_0_i7);
	}
	MR_r1 = (MR_Word) MR_string_const("dd> ", 4);
	}
	MR_np_call_localret_ent(mdb__declarative_user__get_command_6_0,
		mdb__declarative_user__query_user_6_0_i11);
MR_def_label(mdb__declarative_user__query_user_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r2;
	MR_np_call_localret_ent(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0,
		mdb__declarative_user__query_user_6_0_i8);
MR_def_label(mdb__declarative_user__query_user_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0,
		mdb__declarative_user__query_user_6_0_i9);
MR_def_label(mdb__declarative_user__query_user_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 6);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(2);
	MR_tfield(0, MR_r2, 0) = MR_tfield(0, MR_tempr1, 0);
	MR_tfield(0, MR_r2, 1) = MR_tfield(0, MR_tempr1, 1);
	MR_tfield(0, MR_r2, 2) = MR_tfield(0, MR_tempr1, 2);
	MR_tfield(0, MR_r2, 3) = (MR_Integer) 0;
	MR_tfield(0, MR_r2, 4) = MR_tfield(0, MR_tempr1, 4);
	MR_tfield(0, MR_r2, 5) = MR_tfield(0, MR_tempr1, 5);
	}
	MR_np_call_localret_ent(mdb__declarative_user__get_command_6_0,
		mdb__declarative_user__query_user_6_0_i11);
MR_def_label(mdb__declarative_user__query_user_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r3 = MR_sv(1);
	MR_r4 = MR_tempr2;
	}
	MR_np_call_localret_ent(mdb__declarative_user__handle_command_7_0,
		mdb__declarative_user__query_user_6_0_i12);
MR_def_label(mdb__declarative_user__query_user_6_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TEST(MR_r1,3,1)) {
		MR_GOTO_LAB(mdb__declarative_user__query_user_6_0_i4);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 6);
	MR_tfield(0, MR_tempr1, 0) = MR_tfield(0, MR_r2, 0);
	MR_tfield(0, MR_tempr1, 1) = MR_tfield(0, MR_r2, 1);
	MR_tfield(0, MR_tempr1, 2) = MR_tfield(0, MR_r2, 2);
	MR_tfield(0, MR_tempr1, 3) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 4) = MR_tfield(0, MR_r2, 4);
	MR_tfield(0, MR_tempr1, 5) = MR_tfield(0, MR_r2, 5);
	MR_r2 = MR_tempr1;
	MR_decr_sp_and_return(4);
	}
MR_def_label(mdb__declarative_user__query_user_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(fn__mdb__declarative_debugger__get_decl_question_node_1_0,
		mdb__declarative_user__query_user_6_0_i18);
MR_def_label(mdb__declarative_user__query_user_6_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_r1;
	MR_tfield(0, MR_tempr1, 1) = (MR_Integer) 1;
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r1, 0) = MR_sv(1);
	MR_tfield(1, MR_r1, 1) = MR_tempr1;
	MR_r2 = MR_sv(2);
	}
MR_def_label(mdb__declarative_user__query_user_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(4);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(mdb__help__path_6_0);
MR_decl_entry(io__write_strings_3_0);
MR_decl_entry(mdb__browser_info__run_param_command_7_0);

MR_BEGIN_MODULE(mdb__declarative_user_module23)
	MR_init_entry1(mdb__declarative_user__handle_command_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__handle_command_7_0);
	MR_init_label10(mdb__declarative_user__handle_command_7_0,292,3,8,10,11,6,13,17,18,16)
	MR_init_label10(mdb__declarative_user__handle_command_7_0,21,24,25,23,29,30,28,32,34,35)
	MR_init_label10(mdb__declarative_user__handle_command_7_0,33,39,38,42,41,44,46,47,45,51)
	MR_init_label10(mdb__declarative_user__handle_command_7_0,52,55,57,61,60,63,64,54,67,169)
	MR_init_label10(mdb__declarative_user__handle_command_7_0,69,71,72,50,76,77,79,75,84,85)
	MR_init_label10(mdb__declarative_user__handle_command_7_0,83,88,92,97,176,99,90,107,104,111)
	MR_init_label5(mdb__declarative_user__handle_command_7_0,112,110,115,116,117)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'handle_command'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__handle_command_7_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(8);
	MR_sv(8) = (MR_Word) MR_succip;
MR_def_label(mdb__declarative_user__handle_command_7_0,292)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,9)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i3);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 6);
	MR_tempr2 = MR_r4;
	MR_tfield(0, MR_tempr1, 0) = MR_tfield(0, MR_tempr2, 0);
	MR_tfield(0, MR_tempr1, 1) = MR_tfield(0, MR_tempr2, 1);
	MR_tfield(0, MR_tempr1, 2) = MR_tfield(0, MR_tempr2, 2);
	MR_tfield(0, MR_tempr1, 3) = (MR_Integer) 1;
	MR_tfield(0, MR_tempr1, 4) = MR_tfield(0, MR_tempr2, 4);
	MR_tfield(0, MR_tempr1, 5) = MR_tfield(0, MR_tempr2, 5);
	MR_r2 = MR_r3;
	MR_r3 = MR_tempr1;
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_np_tailcall_ent(mdb__declarative_user__query_user_6_0);
	}
MR_def_label(mdb__declarative_user__handle_command_7_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,11)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i6);
	}
	if (MR_PTAG_TESTR(MR_r3,0)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i8);
	}
	MR_r2 = (MR_Word) MR_tbmkword(0, 3);
	MR_succip_word = MR_sv(8);
	MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i292);
MR_def_label(mdb__declarative_user__handle_command_7_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r6 = MR_tfield(1, MR_r3, 1);
	if (MR_INT_NE(MR_r6,0)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i10);
	}
	MR_r2 = (MR_Word) MR_tbmkword(0, 0);
	MR_succip_word = MR_sv(8);
	MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i292);
MR_def_label(mdb__declarative_user__handle_command_7_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r6,1)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i11);
	}
	MR_r2 = (MR_Word) MR_tbmkword(0, 1);
	MR_succip_word = MR_sv(8);
	MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i292);
MR_def_label(mdb__declarative_user__handle_command_7_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_tbmkword(0, 2);
	MR_succip_word = MR_sv(8);
	MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i292);
MR_def_label(mdb__declarative_user__handle_command_7_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,12)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i13);
	}
	MR_sv(1) = MR_r3;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r4;
	MR_sv(2) = MR_tempr1;
	MR_sv(5) = MR_r1;
	MR_r1 = MR_tfield(0, MR_tempr1, 1);
	MR_r2 = (MR_Word) MR_string_const("Unknown command, \'h\' for help.\n", 31);
	}
	MR_np_call_localret_ent(io__write_string_4_0,
		mdb__declarative_user__handle_command_7_0_i117);
MR_def_label(mdb__declarative_user__handle_command_7_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,2)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i16);
	}
	MR_sv(2) = MR_r4;
	MR_sv(5) = MR_r1;
	MR_r1 = MR_r3;
	MR_np_call_localret_ent(fn__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_103_101_116_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_1_0,
		mdb__declarative_user__handle_command_7_0_i17);
MR_def_label(mdb__declarative_user__handle_command_7_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(fn__mdb__declarative_debugger__get_decl_question_node_1_0,
		mdb__declarative_user__handle_command_7_0_i18);
MR_def_label(mdb__declarative_user__handle_command_7_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 2);
	MR_tfield(0, MR_tempr1, 0) = MR_r1;
	MR_tfield(0, MR_tempr1, 1) = (MR_Integer) 2;
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r1, 0) = MR_sv(1);
	MR_tfield(1, MR_r1, 1) = MR_tempr1;
	MR_r2 = MR_sv(2);
	MR_decr_sp_and_return(8);
	}
MR_def_label(mdb__declarative_user__handle_command_7_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,7)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i21);
	}
	MR_tag_alloc_heap(MR_r1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_r1, 0) = (MR_Integer) 1;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r4;
	MR_tfield(3, MR_r1, 1) = MR_tfield(0, MR_tempr1, 1);
	MR_r2 = MR_tempr1;
	MR_decr_sp_and_return(8);
	}
MR_def_label(mdb__declarative_user__handle_command_7_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,1)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i23);
	}
	MR_sv(2) = MR_r4;
	MR_sv(5) = MR_r1;
	MR_r1 = MR_r3;
	MR_np_call_localret_ent(fn__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_103_101_116_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_1_0,
		mdb__declarative_user__handle_command_7_0_i24);
MR_def_label(mdb__declarative_user__handle_command_7_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(fn__mdb__declarative_debugger__get_decl_question_node_1_0,
		mdb__declarative_user__handle_command_7_0_i25);
MR_def_label(mdb__declarative_user__handle_command_7_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_r1;
	MR_tfield(0, MR_r2, 1) = (MR_Integer) 1;
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r1, 0) = MR_sv(1);
	MR_tfield(1, MR_r1, 1) = MR_r2;
	MR_r2 = MR_sv(2);
	MR_decr_sp_and_return(8);
MR_def_label(mdb__declarative_user__handle_command_7_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,4)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i28);
	}
	MR_sv(2) = MR_r4;
	MR_sv(5) = MR_r1;
	MR_r1 = MR_r3;
	MR_np_call_localret_ent(fn__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_103_101_116_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_1_0,
		mdb__declarative_user__handle_command_7_0_i29);
MR_def_label(mdb__declarative_user__handle_command_7_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__mdb__declarative_debugger__get_decl_question_node_1_0,
		mdb__declarative_user__handle_command_7_0_i30);
MR_def_label(mdb__declarative_user__handle_command_7_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 3;
	MR_tfield(3, MR_tempr1, 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_sv(2);
	MR_decr_sp_and_return(8);
	}
MR_def_label(mdb__declarative_user__handle_command_7_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,10)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i32);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 1);
	MR_r2 = MR_r4;
	MR_decr_sp_and_return(8);
MR_def_label(mdb__declarative_user__handle_command_7_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,3)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i33);
	}
	MR_sv(2) = MR_r4;
	MR_sv(5) = MR_r1;
	MR_r1 = MR_r3;
	MR_np_call_localret_ent(fn__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_103_101_116_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_1_0,
		mdb__declarative_user__handle_command_7_0_i34);
MR_def_label(mdb__declarative_user__handle_command_7_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(fn__mdb__declarative_debugger__get_decl_question_node_1_0,
		mdb__declarative_user__handle_command_7_0_i35);
MR_def_label(mdb__declarative_user__handle_command_7_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 3, (MR_Integer) 1);
	MR_tfield(3, MR_r2, 0) = MR_r1;
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r1, 0) = MR_sv(1);
	MR_tfield(1, MR_r1, 1) = MR_r2;
	MR_r2 = MR_sv(2);
	MR_decr_sp_and_return(8);
MR_def_label(mdb__declarative_user__handle_command_7_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,6)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i38);
	}
	MR_sv(2) = MR_r4;
	MR_r1 = MR_r3;
	MR_np_call_localret_ent(fn__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_103_101_116_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_1_0,
		mdb__declarative_user__handle_command_7_0_i39);
MR_def_label(mdb__declarative_user__handle_command_7_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 3, (MR_Integer) 2);
	MR_tfield(3, MR_r2, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_r2, 1) = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = MR_sv(2);
	MR_decr_sp_and_return(8);
MR_def_label(mdb__declarative_user__handle_command_7_0,38)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,5)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i41);
	}
	MR_sv(2) = MR_r4;
	MR_r1 = MR_r3;
	MR_np_call_localret_ent(fn__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_103_101_116_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_1_0,
		mdb__declarative_user__handle_command_7_0_i42);
MR_def_label(mdb__declarative_user__handle_command_7_0,42)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 2, (MR_Integer) 1);
	MR_tfield(2, MR_r2, 0) = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = MR_sv(2);
	MR_decr_sp_and_return(8);
MR_def_label(mdb__declarative_user__handle_command_7_0,41)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,8)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i44);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_r2 = MR_r4;
	MR_decr_sp_and_return(8);
MR_def_label(mdb__declarative_user__handle_command_7_0,44)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i45);
	}
	MR_sv(2) = MR_r4;
	MR_sv(5) = MR_r1;
	MR_r1 = MR_r3;
	MR_np_call_localret_ent(fn__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_103_101_116_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_1_0,
		mdb__declarative_user__handle_command_7_0_i46);
MR_def_label(mdb__declarative_user__handle_command_7_0,46)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(fn__mdb__declarative_debugger__get_decl_question_node_1_0,
		mdb__declarative_user__handle_command_7_0_i47);
MR_def_label(mdb__declarative_user__handle_command_7_0,47)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 2);
	MR_tfield(0, MR_r2, 0) = MR_r1;
	MR_tfield(0, MR_r2, 1) = (MR_Integer) 0;
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r1, 0) = MR_sv(1);
	MR_tfield(1, MR_r1, 1) = MR_r2;
	MR_r2 = MR_sv(2);
	MR_decr_sp_and_return(8);
MR_def_label(mdb__declarative_user__handle_command_7_0,45)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,1)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i50);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_sv(1) = MR_tempr1;
	MR_sv(2) = MR_r4;
	MR_sv(3) = MR_tfield(1, MR_r2, 0);
	MR_sv(5) = MR_r1;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_103_101_116_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_1_0,
		mdb__declarative_user__handle_command_7_0_i51);
MR_def_label(mdb__declarative_user__handle_command_7_0,51)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_np_call_localret_ent(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_116_114_97_99_101_95_97_116_111_109_115_95_95_91_49_93_95_48_3_0,
		mdb__declarative_user__handle_command_7_0_i52);
MR_def_label(mdb__declarative_user__handle_command_7_0,52)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(3),0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i54);
	}
	MR_r3 = MR_sv(2);
	MR_np_call_localret_ent(mdb__declarative_user__browse_atom_7_0,
		mdb__declarative_user__handle_command_7_0_i55);
MR_def_label(mdb__declarative_user__handle_command_7_0,55)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i57);
	}
	MR_r1 = MR_sv(5);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_sv(1);
	MR_r3 = MR_tempr1;
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_np_tailcall_ent(mdb__declarative_user__query_user_6_0);
	}
MR_def_label(mdb__declarative_user__handle_command_7_0,57)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r4 = MR_tfield(1, MR_r1, 2);
	if (MR_LTAGS_TESTR(MR_r4,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i60);
	}
	MR_sv(3) = MR_r2;
	MR_r1 = MR_tfield(0, MR_r2, 1);
	MR_r2 = (MR_Word) MR_string_const("Cannot track the entire atom. Please select a subterm to track.\n", 64);
	MR_np_call_localret_ent(io__write_string_4_0,
		mdb__declarative_user__handle_command_7_0_i61);
MR_def_label(mdb__declarative_user__handle_command_7_0,61)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(1);
	MR_r3 = MR_sv(3);
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_np_tailcall_ent(mdb__declarative_user__query_user_6_0);
MR_def_label(mdb__declarative_user__handle_command_7_0,60)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r4;
	MR_sv(1) = MR_tfield(1, MR_tempr1, 1);
	MR_sv(3) = MR_r2;
	MR_sv(6) = MR_tfield(1, MR_r1, 1);
	MR_sv(7) = MR_tfield(1, MR_r1, 0);
	MR_r1 = MR_tfield(1, MR_tempr1, 0);
	}
	MR_np_call_localret_ent(fn__mdb__declarative_user__arg_num_to_arg_pos_1_0,
		mdb__declarative_user__handle_command_7_0_i63);
MR_def_label(mdb__declarative_user__handle_command_7_0,63)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(4);
	MR_np_call_localret_ent(fn__mdb__declarative_debugger__get_decl_question_node_1_0,
		mdb__declarative_user__handle_command_7_0_i64);
MR_def_label(mdb__declarative_user__handle_command_7_0,64)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 5);
	MR_tfield(1, MR_tempr1, 0) = MR_r1;
	MR_tfield(1, MR_tempr1, 1) = MR_sv(2);
	MR_tfield(1, MR_tempr1, 2) = MR_sv(1);
	MR_tfield(1, MR_tempr1, 3) = MR_sv(7);
	MR_tfield(1, MR_tempr1, 4) = MR_sv(6);
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r1, 0) = MR_sv(4);
	MR_tfield(1, MR_r1, 1) = MR_tempr1;
	MR_r2 = MR_sv(3);
	MR_decr_sp_and_return(8);
	}
MR_def_label(mdb__declarative_user__handle_command_7_0,54)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(2);
	MR_sv(2) = MR_tfield(1, MR_sv(3), 0);
	MR_r3 = MR_sv(2);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(mdb__declarative_user__browse_atom_argument_8_0,
		mdb__declarative_user__handle_command_7_0_i67);
MR_def_label(mdb__declarative_user__handle_command_7_0,67)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i69);
	}
MR_def_label(mdb__declarative_user__handle_command_7_0,169)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(5);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_sv(1);
	MR_r3 = MR_tempr1;
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_np_tailcall_ent(mdb__declarative_user__query_user_6_0);
	}
MR_def_label(mdb__declarative_user__handle_command_7_0,69)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_tfield(1, MR_r1, 0);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(2);
	MR_sv(2) = MR_tfield(1, MR_r1, 1);
	MR_sv(3) = MR_tfield(1, MR_r1, 2);
	MR_sv(6) = MR_r2;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__mdb__declarative_user__arg_num_to_arg_pos_1_0,
		mdb__declarative_user__handle_command_7_0_i71);
MR_def_label(mdb__declarative_user__handle_command_7_0,71)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(5);
	MR_sv(5) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_sv(4);
	}
	MR_np_call_localret_ent(fn__mdb__declarative_debugger__get_decl_question_node_1_0,
		mdb__declarative_user__handle_command_7_0_i72);
MR_def_label(mdb__declarative_user__handle_command_7_0,72)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 5);
	MR_tfield(1, MR_tempr1, 0) = MR_r1;
	MR_tfield(1, MR_tempr1, 1) = MR_sv(5);
	MR_tfield(1, MR_tempr1, 2) = MR_sv(3);
	MR_tfield(1, MR_tempr1, 3) = MR_sv(1);
	MR_tfield(1, MR_tempr1, 4) = MR_sv(2);
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r1, 0) = MR_sv(4);
	MR_tfield(1, MR_r1, 1) = MR_tempr1;
	MR_r2 = MR_sv(6);
	MR_decr_sp_and_return(8);
	}
MR_def_label(mdb__declarative_user__handle_command_7_0,50)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,2)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i75);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_sv(1) = MR_tempr1;
	MR_sv(2) = MR_r4;
	MR_sv(3) = MR_tfield(2, MR_r2, 0);
	MR_sv(5) = MR_r1;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_103_101_116_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_1_0,
		mdb__declarative_user__handle_command_7_0_i76);
MR_def_label(mdb__declarative_user__handle_command_7_0,76)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_116_114_97_99_101_95_97_116_111_109_115_95_95_91_49_93_95_48_3_0,
		mdb__declarative_user__handle_command_7_0_i77);
MR_def_label(mdb__declarative_user__handle_command_7_0,77)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(3),0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i79);
	}
	MR_r1 = MR_r2;
	MR_r2 = MR_sv(2);
	MR_np_call_localret_ent(mdb__declarative_user__browse_xml_atom_4_0,
		mdb__declarative_user__handle_command_7_0_i176);
MR_def_label(mdb__declarative_user__handle_command_7_0,79)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_r2 = MR_tfield(1, MR_sv(3), 0);
	MR_r3 = MR_sv(2);
	MR_np_call_localret_ent(mdb__declarative_user__browse_xml_atom_argument_5_0,
		mdb__declarative_user__handle_command_7_0_i176);
MR_def_label(mdb__declarative_user__handle_command_7_0,75)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,0)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i83);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_sv(1) = MR_tempr1;
	MR_sv(2) = MR_r4;
	MR_sv(3) = MR_tfield(3, MR_r2, 1);
	MR_sv(5) = MR_r1;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_103_101_116_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_1_0,
		mdb__declarative_user__handle_command_7_0_i84);
MR_def_label(mdb__declarative_user__handle_command_7_0,84)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_105_111_95_97_99_116_105_111_110_115_95_95_91_49_93_95_48_2_0,
		mdb__declarative_user__handle_command_7_0_i85);
MR_def_label(mdb__declarative_user__handle_command_7_0,85)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_r3 = MR_sv(2);
	MR_np_call_localret_ent(mdb__declarative_user__browse_chosen_io_action_7_0,
		mdb__declarative_user__handle_command_7_0_i169);
MR_def_label(mdb__declarative_user__handle_command_7_0,83)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,4)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i88);
	}
	MR_tag_alloc_heap(MR_r1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_r1, 0) = (MR_Integer) 2;
	MR_tfield(3, MR_r1, 1) = MR_tfield(3, MR_r2, 1);
	MR_r2 = MR_r4;
	MR_decr_sp_and_return(8);
MR_def_label(mdb__declarative_user__handle_command_7_0,88)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,5)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i90);
	}
	MR_r6 = MR_tfield(3, MR_r2, 1);
	if (MR_LTAGS_TESTR(MR_r6,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i92);
	}
	MR_sv(1) = MR_r3;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r4;
	MR_sv(2) = MR_tempr1;
	MR_r2 = (MR_Word) MR_TAG_COMMON(1,11,1);
	MR_sv(5) = MR_r1;
	MR_r1 = MR_tfield(0, MR_tempr1, 4);
	MR_r3 = MR_tfield(0, MR_tempr1, 1);
	}
	MR_np_call_localret_ent(mdb__help__path_6_0,
		mdb__declarative_user__handle_command_7_0_i97);
MR_def_label(mdb__declarative_user__handle_command_7_0,92)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_tfield(1, MR_r6, 0);
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = (MR_Word) MR_string_const("decl", 4);
	MR_tfield(1, MR_r2, 1) = MR_tempr1;
	MR_sv(1) = MR_r3;
	MR_tempr2 = MR_r4;
	MR_sv(2) = MR_tempr2;
	MR_sv(5) = MR_r1;
	MR_r1 = MR_tfield(0, MR_tempr2, 4);
	MR_r3 = MR_tfield(0, MR_tempr2, 1);
	}
	MR_np_call_localret_ent(mdb__help__path_6_0,
		mdb__declarative_user__handle_command_7_0_i97);
MR_def_label(mdb__declarative_user__handle_command_7_0,97)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i99);
	}
MR_def_label(mdb__declarative_user__handle_command_7_0,176)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_r3 = MR_sv(2);
	MR_r1 = MR_sv(5);
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_np_tailcall_ent(mdb__declarative_user__query_user_6_0);
MR_def_label(mdb__declarative_user__handle_command_7_0,99)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_tfield(1, MR_r1, 0);
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_TAG_COMMON(1,11,2);
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(io__write_strings_3_0,
		mdb__declarative_user__handle_command_7_0_i176);
MR_def_label(mdb__declarative_user__handle_command_7_0,90)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,3)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i104);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 7);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_TAG_COMMON(1,12,0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 0;
	MR_tfield(0, MR_tempr1, 3) = (MR_Word) MR_tbmkword(0, 0);
	MR_tempr2 = MR_r4;
	MR_tfield(0, MR_tempr1, 4) = MR_tfield(0, MR_tempr2, 2);
	MR_tfield(0, MR_tempr1, 5) = (MR_Word) MR_tbmkword(0, 0);
	MR_tfield(0, MR_tempr1, 6) = (MR_Word) MR_tbmkword(0, 0);
	MR_sv(1) = MR_r3;
	MR_sv(2) = MR_tempr2;
	MR_sv(5) = MR_r1;
	MR_r1 = (MR_Integer) 0;
	MR_r2 = MR_tfield(3, MR_r2, 1);
	MR_r3 = (MR_Integer) 0;
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(mdb__browser_info__run_param_command_7_0,
		mdb__declarative_user__handle_command_7_0_i107);
MR_def_label(mdb__declarative_user__handle_command_7_0,107)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 6);
	MR_r3 = MR_tempr1;
	MR_tempr2 = MR_sv(2);
	MR_tfield(0, MR_tempr1, 0) = MR_tfield(0, MR_tempr2, 0);
	MR_tfield(0, MR_tempr1, 1) = MR_tfield(0, MR_tempr2, 1);
	MR_tfield(0, MR_tempr1, 2) = MR_tfield(0, MR_r1, 4);
	MR_tfield(0, MR_tempr1, 3) = MR_tfield(0, MR_tempr2, 3);
	MR_tfield(0, MR_tempr1, 4) = MR_tfield(0, MR_tempr2, 4);
	MR_tfield(0, MR_tempr1, 5) = MR_tfield(0, MR_tempr2, 5);
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(1);
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_np_tailcall_ent(mdb__declarative_user__query_user_6_0);
	}
MR_def_label(mdb__declarative_user__handle_command_7_0,104)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r2,3,1)) {
		MR_GOTO_LAB(mdb__declarative_user__handle_command_7_0_i110);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_sv(1) = MR_tempr1;
	MR_sv(2) = MR_r4;
	MR_sv(3) = MR_tfield(3, MR_r2, 1);
	MR_sv(4) = MR_tfield(3, MR_r2, 2);
	MR_sv(5) = MR_r1;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_103_101_116_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_1_0,
		mdb__declarative_user__handle_command_7_0_i111);
MR_def_label(mdb__declarative_user__handle_command_7_0,111)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_116_114_97_99_101_95_97_116_111_109_115_95_95_91_49_93_95_48_3_0,
		mdb__declarative_user__handle_command_7_0_i112);
MR_def_label(mdb__declarative_user__handle_command_7_0,112)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_r2 = MR_sv(3);
	MR_r3 = MR_sv(4);
	MR_r4 = MR_sv(2);
	MR_np_call_localret_ent(mdb__declarative_user__print_atom_arguments_6_0,
		mdb__declarative_user__handle_command_7_0_i117);
MR_def_label(mdb__declarative_user__handle_command_7_0,110)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_sv(1) = MR_tempr1;
	MR_sv(2) = MR_r4;
	MR_sv(3) = MR_tfield(3, MR_r2, 1);
	MR_sv(4) = MR_tfield(3, MR_r2, 2);
	MR_sv(5) = MR_r1;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_103_101_116_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_1_0,
		mdb__declarative_user__handle_command_7_0_i115);
MR_def_label(mdb__declarative_user__handle_command_7_0,115)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_105_111_95_97_99_116_105_111_110_115_95_95_91_49_93_95_48_2_0,
		mdb__declarative_user__handle_command_7_0_i116);
MR_def_label(mdb__declarative_user__handle_command_7_0,116)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_r3 = MR_sv(4);
	MR_r4 = MR_sv(2);
	MR_np_call_localret_ent(mdb__declarative_user__print_chosen_io_actions_6_0,
		mdb__declarative_user__handle_command_7_0_i117);
MR_def_label(mdb__declarative_user__handle_command_7_0,117)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(1);
	MR_r3 = MR_sv(2);
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_np_tailcall_ent(mdb__declarative_user__query_user_6_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module24)
	MR_init_entry1(mdb__declarative_user__browse_decl_bug_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__browse_decl_bug_6_0);
	MR_init_label5(mdb__declarative_user__browse_decl_bug_6_0,5,3,2,8,10)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'browse_decl_bug'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__browse_decl_bug_6_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(1);
	MR_sv(1) = (MR_Word) MR_succip;
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_decl_bug_6_0_i3);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_tfield(0, MR_r1, 0);
	MR_r5 = MR_tempr1;
	if (MR_PTAG_TESTR(MR_tempr1,0)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_decl_bug_6_0_i5);
	}
	MR_tempr2 = MR_tempr1;
	MR_r6 = MR_tempr2;
	MR_r5 = MR_r2;
	MR_r1 = MR_tfield(0, MR_tempr2, 0);
	MR_r2 = MR_tfield(0, MR_tfield(0, MR_tempr2, 1), 0);
	MR_GOTO_LAB(mdb__declarative_user__browse_decl_bug_6_0_i2);
	}
MR_def_label(mdb__declarative_user__browse_decl_bug_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r6 = MR_r5;
	MR_r5 = MR_r2;
	MR_r1 = MR_mask_field(MR_r6, 0);
	MR_r2 = MR_r1;
	MR_GOTO_LAB(mdb__declarative_user__browse_decl_bug_6_0_i2);
MR_def_label(mdb__declarative_user__browse_decl_bug_6_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r5 = MR_r2;
	MR_r1 = MR_tfield(0, MR_tfield(1, MR_r1, 0), 2);
	MR_r2 = MR_r1;
MR_def_label(mdb__declarative_user__browse_decl_bug_6_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r5,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_decl_bug_6_0_i8);
	}
	MR_np_call_localret_ent(mdb__declarative_user__browse_atom_7_0,
		mdb__declarative_user__browse_decl_bug_6_0_i10);
MR_def_label(mdb__declarative_user__browse_decl_bug_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_r3 = MR_tfield(1, MR_r5, 0);
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(mdb__declarative_user__browse_atom_argument_8_0,
		mdb__declarative_user__browse_decl_bug_6_0_i10);
MR_def_label(mdb__declarative_user__browse_decl_bug_6_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_decr_sp_and_return(1);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module25)
	MR_init_entry1(mdb__declarative_user__browse_xml_decl_bug_5_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__browse_xml_decl_bug_5_0);
	MR_init_label10(mdb__declarative_user__browse_xml_decl_bug_5_0,5,3,2,9,10,11,13,14,15,16)
	MR_init_label2(mdb__declarative_user__browse_xml_decl_bug_5_0,17,8)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'browse_xml_decl_bug'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__browse_xml_decl_bug_5_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_xml_decl_bug_5_0_i3);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(0, MR_r1, 0);
	MR_r5 = MR_tempr1;
	if (MR_PTAG_TESTR(MR_tempr1,0)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_xml_decl_bug_5_0_i5);
	}
	MR_r1 = MR_r2;
	MR_sv(1) = MR_r3;
	MR_r2 = MR_tfield(0, MR_tfield(0, MR_tempr1, 1), 0);
	MR_GOTO_LAB(mdb__declarative_user__browse_xml_decl_bug_5_0_i2);
	}
MR_def_label(mdb__declarative_user__browse_xml_decl_bug_5_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_r2;
	MR_sv(1) = MR_r3;
	MR_r2 = MR_mask_field(MR_r5, 0);
	MR_GOTO_LAB(mdb__declarative_user__browse_xml_decl_bug_5_0_i2);
MR_def_label(mdb__declarative_user__browse_xml_decl_bug_5_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_r2;
	MR_sv(1) = MR_r3;
	MR_r2 = MR_tfield(0, MR_tfield(1, MR_tempr1, 0), 2);
	}
MR_def_label(mdb__declarative_user__browse_xml_decl_bug_5_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_xml_decl_bug_5_0_i8);
	}
	MR_sv(2) = MR_tfield(0, MR_r2, 1);
	MR_r1 = MR_tfield(0, MR_r2, 0);
	MR_np_call_localret_ent(fn__mdbcomp__rtti_access__get_proc_label_from_layout_1_0,
		mdb__declarative_user__browse_xml_decl_bug_5_0_i9);
MR_def_label(mdb__declarative_user__browse_xml_decl_bug_5_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_sv(2) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(mdb__declarative_user__get_user_arg_values_2_0,
		mdb__declarative_user__browse_xml_decl_bug_5_0_i10);
MR_def_label(mdb__declarative_user__browse_xml_decl_bug_5_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_sv(2) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(mdb__declarative_execution__get_pred_attributes_5_0,
		mdb__declarative_user__browse_xml_decl_bug_5_0_i11);
MR_def_label(mdb__declarative_user__browse_xml_decl_bug_5_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 5);
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(3,16);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(mdb__declarative_user__IntroducedFrom__pred__browse_xml_atom__714__1_2_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 2;
	MR_tfield(0, MR_tempr1, 3) = MR_r4;
	MR_tfield(0, MR_tempr1, 4) = (MR_Integer) 1;
	MR_sv(3) = MR_r1;
	MR_sv(4) = MR_r2;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__bool__pred_to_bool_1_0,
		mdb__declarative_user__browse_xml_decl_bug_5_0_i13);
MR_def_label(mdb__declarative_user__browse_xml_decl_bug_5_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_sv(3) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(fn__mdbcomp__prim_data__sym_name_to_string_1_0,
		mdb__declarative_user__browse_xml_decl_bug_5_0_i14);
MR_def_label(mdb__declarative_user__browse_xml_decl_bug_5_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(4);
	MR_sv(4) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(".", 1);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		mdb__declarative_user__browse_xml_decl_bug_5_0_i15);
MR_def_label(mdb__declarative_user__browse_xml_decl_bug_5_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		mdb__declarative_user__browse_xml_decl_bug_5_0_i16);
MR_def_label(mdb__declarative_user__browse_xml_decl_bug_5_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(3);
	MR_np_call_localret_ent(fn__mdb__browser_term__synthetic_term_to_browser_term_3_0,
		mdb__declarative_user__browse_xml_decl_bug_5_0_i17);
MR_def_label(mdb__declarative_user__browse_xml_decl_bug_5_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_r2 = MR_tfield(0, MR_tempr1, 1);
	MR_r3 = MR_r2;
	MR_r4 = MR_tfield(0, MR_tempr1, 2);
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(mdb__browse__save_and_browse_browser_term_xml_6_0);
	}
MR_def_label(mdb__declarative_user__browse_xml_decl_bug_5_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = MR_tfield(1, MR_tempr1, 0);
	MR_r3 = MR_sv(1);
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(mdb__declarative_user__browse_xml_atom_argument_5_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(io__write_strings_4_0);

MR_BEGIN_MODULE(mdb__declarative_user_module26)
	MR_init_entry1(mdb__declarative_user__user_confirm_bug_help_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__user_confirm_bug_help_3_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'user_confirm_bug_help'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__user_confirm_bug_help_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_r1, 1);
	MR_r2 = (MR_Word) MR_TAG_COMMON(1,11,9);
	MR_np_tailcall_ent(io__write_strings_4_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_mdb__declarative_debugger__type_ctor_info_final_decl_atom_0;
MR_decl_entry(io__write_list_5_1);
MR_decl_entry(fn__univ__univ_value_1_0);
MR_decl_entry(io__write_5_2);

MR_BEGIN_MODULE(mdb__declarative_user_module27)
	MR_init_entry1(mdb__declarative_user__write_decl_bug_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__write_decl_bug_4_0);
	MR_init_label10(mdb__declarative_user__write_decl_bug_4_0,6,7,9,10,5,13,14,12,16,17)
	MR_init_label9(mdb__declarative_user__write_decl_bug_4_0,18,19,20,21,3,23,24,26,27)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'write_decl_bug'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__write_decl_bug_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(mdb__declarative_user__write_decl_bug_4_0_i3);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(0, MR_r1, 0);
	MR_r4 = MR_tempr1;
	if (MR_PTAG_TESTR(MR_tempr1,0)) {
		MR_GOTO_LAB(mdb__declarative_user__write_decl_bug_4_0_i5);
	}
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_tfield(0, MR_tempr1, 1);
	MR_sv(3) = MR_tfield(0, MR_tempr1, 2);
	MR_r1 = MR_tfield(0, MR_r2, 1);
	MR_r2 = (MR_Word) MR_string_const("Found incorrect contour:\n", 25);
	}
	MR_np_call_localret_ent(io__write_string_4_0,
		mdb__declarative_user__write_decl_bug_4_0_i6);
MR_def_label(mdb__declarative_user__write_decl_bug_4_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__mdb__declarative_user__decl_caller_type_0_0,
		mdb__declarative_user__write_decl_bug_4_0_i7);
MR_def_label(mdb__declarative_user__write_decl_bug_4_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 6);
	MR_r4 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(13,0);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(mdb__declarative_user__write_decl_final_atom_6_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 3;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 4) = (MR_Word) MR_string_const("", 0);
	MR_tfield(0, MR_tempr1, 5) = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdb__declarative_debugger, final_decl_atom);
	MR_r2 = MR_sv(3);
	MR_r3 = (MR_Word) MR_string_const("", 0);
	}
	MR_np_call_localret_ent(io__write_list_5_1,
		mdb__declarative_user__write_decl_bug_4_0_i9);
MR_def_label(mdb__declarative_user__write_decl_bug_4_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__mdb__declarative_user__decl_caller_type_0_0,
		mdb__declarative_user__write_decl_bug_4_0_i10);
MR_def_label(mdb__declarative_user__write_decl_bug_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Word) MR_string_const("", 0);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(2);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(mdb__declarative_user__write_decl_final_atom_6_0);
	}
MR_def_label(mdb__declarative_user__write_decl_bug_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r4,1)) {
		MR_GOTO_LAB(mdb__declarative_user__write_decl_bug_4_0_i12);
	}
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_tfield(1, MR_r4, 0);
	MR_r1 = MR_tfield(0, MR_r2, 1);
	MR_r2 = (MR_Word) MR_string_const("Found partially uncovered atom:\n", 32);
	MR_np_call_localret_ent(io__write_string_4_0,
		mdb__declarative_user__write_decl_bug_4_0_i13);
MR_def_label(mdb__declarative_user__write_decl_bug_4_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__mdb__declarative_user__decl_caller_type_0_0,
		mdb__declarative_user__write_decl_bug_4_0_i14);
MR_def_label(mdb__declarative_user__write_decl_bug_4_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Word) MR_string_const("", 0);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(2);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(mdb__declarative_user__write_decl_init_atom_6_0);
	}
MR_def_label(mdb__declarative_user__write_decl_bug_4_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r4;
	MR_sv(2) = MR_tfield(2, MR_tempr1, 1);
	MR_sv(3) = MR_tfield(2, MR_tempr1, 0);
	MR_r1 = MR_tfield(0, MR_r2, 1);
	MR_r2 = (MR_Word) MR_string_const("Found unhandled or incorrect exception:\n", 40);
	}
	MR_np_call_localret_ent(io__write_string_4_0,
		mdb__declarative_user__write_decl_bug_4_0_i16);
MR_def_label(mdb__declarative_user__write_decl_bug_4_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__mdb__declarative_user__decl_caller_type_0_0,
		mdb__declarative_user__write_decl_bug_4_0_i17);
MR_def_label(mdb__declarative_user__write_decl_bug_4_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Word) MR_string_const("", 0);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(3);
	}
	MR_np_call_localret_ent(mdb__declarative_user__write_decl_init_atom_6_0,
		mdb__declarative_user__write_decl_bug_4_0_i18);
MR_def_label(mdb__declarative_user__write_decl_bug_4_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(mdb__term_rep__rep_to_univ_2_0,
		mdb__declarative_user__write_decl_bug_4_0_i19);
MR_def_label(mdb__declarative_user__write_decl_bug_4_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_tfield(0, MR_sv(1), 1);
	MR_np_call_localret_ent(fn__univ__univ_value_1_0,
		mdb__declarative_user__write_decl_bug_4_0_i20);
MR_def_label(mdb__declarative_user__write_decl_bug_4_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_sv(2);
	MR_r3 = (MR_Integer) 2;
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(io__write_5_2,
		mdb__declarative_user__write_decl_bug_4_0_i21);
MR_def_label(mdb__declarative_user__write_decl_bug_4_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_sv(1), 1);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(io__nl_3_0);
MR_def_label(mdb__declarative_user__write_decl_bug_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r2;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r1, 0);
	MR_sv(2) = MR_tfield(0, MR_tempr1, 0);
	MR_sv(3) = MR_tfield(0, MR_tempr1, 2);
	MR_r1 = MR_tfield(0, MR_r2, 1);
	MR_r2 = (MR_Word) MR_string_const("Found inadmissible call:\n", 25);
	}
	MR_np_call_localret_ent(io__write_string_4_0,
		mdb__declarative_user__write_decl_bug_4_0_i23);
MR_def_label(mdb__declarative_user__write_decl_bug_4_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__mdb__declarative_user__decl_caller_type_0_0,
		mdb__declarative_user__write_decl_bug_4_0_i24);
MR_def_label(mdb__declarative_user__write_decl_bug_4_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r4, 0, (MR_Integer) 1);
	MR_tfield(0, MR_r4, 0) = MR_sv(2);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Word) MR_string_const("Parent ", 7);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(mdb__declarative_user__write_decl_atom_6_0,
		mdb__declarative_user__write_decl_bug_4_0_i26);
MR_def_label(mdb__declarative_user__write_decl_bug_4_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(fn__mdb__declarative_user__decl_caller_type_0_0,
		mdb__declarative_user__write_decl_bug_4_0_i27);
MR_def_label(mdb__declarative_user__write_decl_bug_4_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r4, 0, (MR_Integer) 1);
	MR_tfield(0, MR_r4, 0) = MR_sv(3);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Word) MR_string_const("Call ", 5);
	MR_r3 = MR_tempr1;
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(mdb__declarative_user__write_decl_atom_6_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module28)
	MR_init_entry1(mdb__declarative_user__user_confirm_bug_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__user_confirm_bug_6_0);
	MR_init_label10(mdb__declarative_user__user_confirm_bug_6_0,78,4,5,7,8,30,9,11,10,13)
	MR_init_label5(mdb__declarative_user__user_confirm_bug_6_0,20,22,18,16,25)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'user_confirm_bug'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__mdb__declarative_user__user_confirm_bug_6_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
MR_def_label(mdb__declarative_user__user_confirm_bug_6_0,78)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(0, MR_r2, 5);
	if (MR_INT_NE(MR_tempr1,0)) {
		MR_GOTO_LAB(mdb__declarative_user__user_confirm_bug_6_0_i30);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	}
	MR_np_call_localret_ent(mdb__declarative_user__write_decl_bug_4_0,
		mdb__declarative_user__user_confirm_bug_6_0_i4);
MR_def_label(mdb__declarative_user__user_confirm_bug_6_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("Is this a bug? ", 15);
	MR_r2 = MR_sv(2);
	MR_np_call_localret_ent(mdb__declarative_user__get_command_6_0,
		mdb__declarative_user__user_confirm_bug_6_0_i5);
MR_def_label(mdb__declarative_user__user_confirm_bug_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,1)) {
		MR_GOTO_LAB(mdb__declarative_user__user_confirm_bug_6_0_i7);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(3);
MR_def_label(mdb__declarative_user__user_confirm_bug_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,10)) {
		MR_GOTO_LAB(mdb__declarative_user__user_confirm_bug_6_0_i8);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(3);
MR_def_label(mdb__declarative_user__user_confirm_bug_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__user_confirm_bug_6_0_i9);
	}
MR_def_label(mdb__declarative_user__user_confirm_bug_6_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_and_return(3);
MR_def_label(mdb__declarative_user__user_confirm_bug_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(mdb__declarative_user__user_confirm_bug_6_0_i10);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tfield(1, MR_tempr1, 0);
	MR_r3 = MR_tempr2;
	}
	MR_np_call_localret_ent(mdb__declarative_user__browse_decl_bug_6_0,
		mdb__declarative_user__user_confirm_bug_6_0_i11);
MR_def_label(mdb__declarative_user__user_confirm_bug_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_succip_word = MR_sv(3);
	MR_GOTO_LAB(mdb__declarative_user__user_confirm_bug_6_0_i78);
	}
MR_def_label(mdb__declarative_user__user_confirm_bug_6_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(mdb__declarative_user__user_confirm_bug_6_0_i13);
	}
	MR_sv(2) = MR_r2;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_tfield(2, MR_tempr1, 0);
	MR_r3 = MR_sv(2);
	}
	MR_np_call_localret_ent(mdb__declarative_user__browse_xml_decl_bug_5_0,
		mdb__declarative_user__user_confirm_bug_6_0_i25);
MR_def_label(mdb__declarative_user__user_confirm_bug_6_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_r1,3,0)) {
		MR_GOTO_LAB(mdb__declarative_user__user_confirm_bug_6_0_i16);
	}
	if (MR_PTAG_TESTR(MR_sv(1),0)) {
		MR_GOTO_LAB(mdb__declarative_user__user_confirm_bug_6_0_i18);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_tfield(0, MR_sv(1), 0);
	if (MR_PTAG_TESTR(MR_tempr1,0)) {
		MR_GOTO_LAB(mdb__declarative_user__user_confirm_bug_6_0_i20);
	}
	MR_tempr2 = MR_r2;
	MR_r2 = MR_tfield(3, MR_r1, 1);
	MR_r1 = MR_tfield(0, MR_tfield(0, MR_tempr1, 1), 1);
	MR_r3 = MR_tempr2;
	}
	MR_np_call_localret_ent(mdb__declarative_user__browse_chosen_io_action_7_0,
		mdb__declarative_user__user_confirm_bug_6_0_i22);
MR_def_label(mdb__declarative_user__user_confirm_bug_6_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_tfield(3, MR_r1, 1);
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_r3 = MR_tempr1;
	}
	MR_np_call_localret_ent(mdb__declarative_user__browse_chosen_io_action_7_0,
		mdb__declarative_user__user_confirm_bug_6_0_i22);
MR_def_label(mdb__declarative_user__user_confirm_bug_6_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_succip_word = MR_sv(3);
	MR_GOTO_LAB(mdb__declarative_user__user_confirm_bug_6_0_i78);
MR_def_label(mdb__declarative_user__user_confirm_bug_6_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r2;
	MR_r1 = (MR_Word) MR_string_const("No such IO action.\n", 19);
	MR_np_call_localret_ent(io__write_string_3_0,
		mdb__declarative_user__user_confirm_bug_6_0_i25);
MR_def_label(mdb__declarative_user__user_confirm_bug_6_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r2;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(mdb__declarative_user__user_confirm_bug_help_3_0,
		mdb__declarative_user__user_confirm_bug_6_0_i25);
MR_def_label(mdb__declarative_user__user_confirm_bug_6_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_succip_word = MR_sv(3);
	MR_GOTO_LAB(mdb__declarative_user__user_confirm_bug_6_0_i78);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module29)
	MR_init_entry1(fn__mdb__declarative_user__get_browser_state_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__mdb__declarative_user__get_browser_state_1_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'get_browser_state'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__mdb__declarative_user__get_browser_state_1_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_r1, 2);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module30)
	MR_init_entry1(mdb__declarative_user__set_browser_state_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__set_browser_state_3_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'set_browser_state'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__mdb__declarative_user__set_browser_state_3_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 6);
	MR_tfield(0, MR_tempr1, 0) = MR_tfield(0, MR_r2, 0);
	MR_tfield(0, MR_tempr1, 1) = MR_tfield(0, MR_r2, 1);
	MR_tfield(0, MR_tempr1, 2) = MR_r1;
	MR_tfield(0, MR_tempr1, 3) = MR_tfield(0, MR_r2, 3);
	MR_tfield(0, MR_tempr1, 4) = MR_tfield(0, MR_r2, 4);
	MR_tfield(0, MR_tempr1, 5) = MR_tfield(0, MR_r2, 5);
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module31)
	MR_init_entry1(fn__mdb__declarative_user__get_user_output_stream_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__mdb__declarative_user__get_user_output_stream_1_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'get_user_output_stream'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__mdb__declarative_user__get_user_output_stream_1_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_r1, 1);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module32)
	MR_init_entry1(fn__mdb__declarative_user__get_user_input_stream_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__mdb__declarative_user__get_user_input_stream_1_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'get_user_input_stream'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__mdb__declarative_user__get_user_input_stream_1_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_r1, 0);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module33)
	MR_init_entry1(mdb__declarative_user__set_user_testing_flag_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__set_user_testing_flag_3_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'set_user_testing_flag'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__mdb__declarative_user__set_user_testing_flag_3_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 6);
	MR_tfield(0, MR_tempr1, 0) = MR_tfield(0, MR_r2, 0);
	MR_tfield(0, MR_tempr1, 1) = MR_tfield(0, MR_r2, 1);
	MR_tfield(0, MR_tempr1, 2) = MR_tfield(0, MR_r2, 2);
	MR_tfield(0, MR_tempr1, 3) = MR_tfield(0, MR_r2, 3);
	MR_tfield(0, MR_tempr1, 4) = MR_tfield(0, MR_r2, 4);
	MR_tfield(0, MR_tempr1, 5) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(mdb__declarative_tree__trace_atom_subterm_is_ground_3_0);

MR_BEGIN_MODULE(mdb__declarative_user_module34)
	MR_init_entry1(fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0);
	MR_init_label9(fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0,2,4,5,7,6,12,10,15,14)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'get_subterm_mode_from_atoms'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_np_call_localret_ent(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0,
		fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0_i2);
MR_def_label(fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0_i4);
	}
	MR_r1 = (MR_Integer) 3;
	MR_decr_sp_and_return(5);
MR_def_label(fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(3) = MR_tfield(1, MR_r1, 0);
	MR_sv(4) = MR_tfield(1, MR_r1, 1);
	MR_np_call_localret_ent(fn__mdb__declarative_execution__chosen_head_vars_presentation_0_0,
		fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0_i5);
MR_def_label(fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0_i7);
	}
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 1);
	MR_tfield(1, MR_r2, 0) = MR_sv(3);
	MR_r1 = MR_sv(1);
	MR_r3 = MR_sv(4);
	MR_GOTO_LAB(fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0_i6);
MR_def_label(fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 1);
	MR_tfield(0, MR_r2, 0) = MR_sv(3);
	MR_r1 = MR_sv(1);
	MR_r3 = MR_sv(4);
MR_def_label(fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r3;
	MR_sv(1) = MR_r2;
	MR_np_call_localret_ent(mdb__declarative_tree__trace_atom_subterm_is_ground_3_0,
		fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0_i12);
MR_def_label(fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0_i10);
	}
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_and_return(5);
MR_def_label(fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_sv(4);
	MR_r2 = MR_sv(1);
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(mdb__declarative_tree__trace_atom_subterm_is_ground_3_0,
		fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0_i15);
MR_def_label(fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0_i14);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(5);
MR_def_label(fn__mdb__declarative_user__get_subterm_mode_from_atoms_3_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(5);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module35)
	MR_init_entry1(fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0);
	MR_init_label8(fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0,2,3,5,4,10,8,13,12)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'get_subterm_mode_from_atoms_for_arg'/5 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_sv(3) = MR_tempr1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_r4;
	}
	MR_np_call_localret_ent(mdb__declarative_user__convert_dirs_to_term_path_from_atom_3_0,
		fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0_i2);
MR_def_label(fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r1;
	MR_np_call_localret_ent(fn__mdb__declarative_execution__chosen_head_vars_presentation_0_0,
		fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0_i3);
MR_def_label(fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0_i5);
	}
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 1);
	MR_tfield(1, MR_r2, 0) = MR_sv(1);
	MR_r1 = MR_sv(2);
	MR_r3 = MR_sv(4);
	MR_GOTO_LAB(fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0_i4);
MR_def_label(fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 0, (MR_Integer) 1);
	MR_tfield(0, MR_r2, 0) = MR_sv(1);
	MR_r1 = MR_sv(2);
	MR_r3 = MR_sv(4);
MR_def_label(fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(4) = MR_r3;
	MR_sv(1) = MR_r2;
	MR_np_call_localret_ent(mdb__declarative_tree__trace_atom_subterm_is_ground_3_0,
		fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0_i10);
MR_def_label(fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0_i8);
	}
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_and_return(5);
MR_def_label(fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_sv(4);
	MR_r2 = MR_sv(1);
	MR_r1 = MR_sv(3);
	MR_np_call_localret_ent(mdb__declarative_tree__trace_atom_subterm_is_ground_3_0,
		fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0_i13);
MR_def_label(fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0_i12);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(5);
MR_def_label(fn__mdb__declarative_user__get_subterm_mode_from_atoms_for_arg_4_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(5);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module36)
	MR_init_entry1(mdb__declarative_user__one_word_cmd_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__one_word_cmd_3_0);
	MR_init_label1(mdb__declarative_user__one_word_cmd_3_0,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'one_word_cmd'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__one_word_cmd_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__one_word_cmd_3_0_i1);
	}
	MR_r2 = MR_r1;
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__one_word_cmd_3_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(string__to_int_2_0);

MR_BEGIN_MODULE(mdb__declarative_user_module37)
	MR_init_entry1(mdb__declarative_user__browse_arg_cmd_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__browse_arg_cmd_2_0);
	MR_init_label10(mdb__declarative_user__browse_arg_cmd_2_0,117,9,7,14,6,22,21,27,26,31)
	MR_init_label1(mdb__declarative_user__browse_arg_cmd_2_0,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'browse_arg_cmd'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__browse_arg_cmd_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_arg_cmd_2_0_i117);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(1,14,0);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__browse_arg_cmd_2_0,117)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_r2 = MR_tfield(1, MR_r1, 1);
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_arg_cmd_2_0_i6);
	}
	MR_r2 = MR_tfield(1, MR_r1, 0);
	MR_sv(1) = MR_r2;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(string__to_int_2_0,
		mdb__declarative_user__browse_arg_cmd_2_0_i9);
MR_def_label(mdb__declarative_user__browse_arg_cmd_2_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_arg_cmd_2_0_i7);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 1);
	MR_tfield(1, MR_tempr1, 0) = MR_r2;
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 1);
	MR_tfield(1, MR_r2, 0) = MR_tempr1;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(2);
	}
MR_def_label(mdb__declarative_user__browse_arg_cmd_2_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const("-x", 2)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_arg_cmd_2_0_i14);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(2,14,0);
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(2);
MR_def_label(mdb__declarative_user__browse_arg_cmd_2_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const("--xml", 5)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_arg_cmd_2_0_i1);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(2,14,0);
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(2);
MR_def_label(mdb__declarative_user__browse_arg_cmd_2_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_tfield(1, MR_r2, 1);
	if (MR_LTAGS_TESTR(MR_r3,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_arg_cmd_2_0_i1);
	}
	MR_r3 = MR_tfield(1, MR_r1, 0);
	if ((strcmp((char *) (MR_Word *) MR_r3, MR_string_const("-x", 2)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_arg_cmd_2_0_i21);
	}
	MR_r1 = MR_tfield(1, MR_r2, 0);
	MR_np_call_localret_ent(string__to_int_2_0,
		mdb__declarative_user__browse_arg_cmd_2_0_i22);
MR_def_label(mdb__declarative_user__browse_arg_cmd_2_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_arg_cmd_2_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 1);
	MR_tfield(1, MR_tempr1, 0) = MR_r2;
	MR_tag_alloc_heap(MR_r2, 2, (MR_Integer) 1);
	MR_tfield(2, MR_r2, 0) = MR_tempr1;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(2);
	}
MR_def_label(mdb__declarative_user__browse_arg_cmd_2_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r3, MR_string_const("io", 2)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_arg_cmd_2_0_i26);
	}
	MR_r1 = MR_tfield(1, MR_r2, 0);
	MR_np_call_localret_ent(string__to_int_2_0,
		mdb__declarative_user__browse_arg_cmd_2_0_i27);
MR_def_label(mdb__declarative_user__browse_arg_cmd_2_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_arg_cmd_2_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 2);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 0;
	MR_tfield(3, MR_tempr1, 1) = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(2);
	}
MR_def_label(mdb__declarative_user__browse_arg_cmd_2_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r3, MR_string_const("--xml", 5)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_arg_cmd_2_0_i1);
	}
	MR_r1 = MR_tfield(1, MR_r2, 0);
	MR_np_call_localret_ent(string__to_int_2_0,
		mdb__declarative_user__browse_arg_cmd_2_0_i31);
MR_def_label(mdb__declarative_user__browse_arg_cmd_2_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__browse_arg_cmd_2_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 1);
	MR_tfield(1, MR_tempr1, 0) = MR_r2;
	MR_tag_alloc_heap(MR_r2, 2, (MR_Integer) 1);
	MR_tfield(2, MR_r2, 0) = MR_tempr1;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(2);
	}
MR_def_label(mdb__declarative_user__browse_arg_cmd_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_decr_sp_and_return(2);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_string_0;
MR_decl_entry(__Unify___list__list_1_0);

MR_BEGIN_MODULE(mdb__declarative_user_module38)
	MR_init_entry1(mdb__declarative_user__print_arg_cmd_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__print_arg_cmd_2_0);
	MR_init_label10(mdb__declarative_user__print_arg_cmd_2_0,166,8,6,12,15,17,19,21,5,30)
	MR_init_label7(mdb__declarative_user__print_arg_cmd_2_0,28,34,37,39,41,43,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'print_arg_cmd'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__print_arg_cmd_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__print_arg_cmd_2_0_i166);
	}
	MR_r2 = (MR_Word) MR_tbmkword(0, 9);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__print_arg_cmd_2_0,166)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_r2 = MR_tfield(1, MR_r1, 1);
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__print_arg_cmd_2_0_i5);
	}
	MR_r2 = MR_tfield(1, MR_r1, 0);
	MR_sv(1) = MR_r2;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(string__to_int_2_0,
		mdb__declarative_user__print_arg_cmd_2_0_i8);
MR_def_label(mdb__declarative_user__print_arg_cmd_2_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__print_arg_cmd_2_0_i6);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 3);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 1;
	MR_tfield(3, MR_tempr1, 1) = MR_r2;
	MR_tfield(3, MR_tempr1, 2) = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(3);
	}
MR_def_label(mdb__declarative_user__print_arg_cmd_2_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,5,15);
	MR_np_call_localret_ent(fn__string__words_separator_2_0,
		mdb__declarative_user__print_arg_cmd_2_0_i12);
MR_def_label(mdb__declarative_user__print_arg_cmd_2_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__print_arg_cmd_2_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r1, 1);
	if (MR_LTAGS_TEST(MR_tempr1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__print_arg_cmd_2_0_i1);
	}
	MR_sv(1) = MR_tfield(1, MR_r1, 0);
	MR_sv(2) = MR_tfield(1, MR_tempr1, 0);
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r2 = (MR_Word) MR_tbmkword(0, 0);
	MR_r3 = MR_tfield(1, MR_tempr1, 1);
	}
	MR_np_call_localret_ent(__Unify___list__list_1_0,
		mdb__declarative_user__print_arg_cmd_2_0_i15);
MR_def_label(mdb__declarative_user__print_arg_cmd_2_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__print_arg_cmd_2_0_i1);
	}
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(string__to_int_2_0,
		mdb__declarative_user__print_arg_cmd_2_0_i17);
MR_def_label(mdb__declarative_user__print_arg_cmd_2_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__print_arg_cmd_2_0_i1);
	}
	MR_sv(1) = MR_r2;
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(string__to_int_2_0,
		mdb__declarative_user__print_arg_cmd_2_0_i19);
MR_def_label(mdb__declarative_user__print_arg_cmd_2_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__print_arg_cmd_2_0_i1);
	}
	if (((MR_Integer) MR_sv(1) > (MR_Integer) MR_r2)) {
		MR_GOTO_LAB(mdb__declarative_user__print_arg_cmd_2_0_i21);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 3);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 1;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(1);
	MR_tfield(3, MR_tempr1, 2) = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(3);
	}
MR_def_label(mdb__declarative_user__print_arg_cmd_2_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 3);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 1;
	MR_tfield(3, MR_tempr1, 1) = MR_r2;
	MR_tfield(3, MR_tempr1, 2) = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(3);
	}
MR_def_label(mdb__declarative_user__print_arg_cmd_2_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r1, 0);
	if ((strcmp((char *) (MR_Word *) MR_tempr1, MR_string_const("io", 2)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__print_arg_cmd_2_0_i1);
	}
	MR_tempr1 = MR_tfield(1, MR_r2, 1);
	if (MR_LTAGS_TESTR(MR_tempr1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__print_arg_cmd_2_0_i1);
	}
	MR_r1 = MR_tfield(1, MR_r2, 0);
	MR_sv(1) = MR_r1;
	}
	MR_np_call_localret_ent(string__to_int_2_0,
		mdb__declarative_user__print_arg_cmd_2_0_i30);
MR_def_label(mdb__declarative_user__print_arg_cmd_2_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__print_arg_cmd_2_0_i28);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 3);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 2;
	MR_tfield(3, MR_tempr1, 1) = MR_r2;
	MR_tfield(3, MR_tempr1, 2) = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(3);
	}
MR_def_label(mdb__declarative_user__print_arg_cmd_2_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_TAG_COMMON(0,5,16);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__string__words_separator_2_0,
		mdb__declarative_user__print_arg_cmd_2_0_i34);
MR_def_label(mdb__declarative_user__print_arg_cmd_2_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__print_arg_cmd_2_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r1, 1);
	if (MR_LTAGS_TEST(MR_tempr1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__print_arg_cmd_2_0_i1);
	}
	MR_sv(1) = MR_tfield(1, MR_r1, 0);
	MR_sv(2) = MR_tfield(1, MR_tempr1, 0);
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r2 = (MR_Word) MR_tbmkword(0, 0);
	MR_r3 = MR_tfield(1, MR_tempr1, 1);
	}
	MR_np_call_localret_ent(__Unify___list__list_1_0,
		mdb__declarative_user__print_arg_cmd_2_0_i37);
MR_def_label(mdb__declarative_user__print_arg_cmd_2_0,37)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__print_arg_cmd_2_0_i1);
	}
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(string__to_int_2_0,
		mdb__declarative_user__print_arg_cmd_2_0_i39);
MR_def_label(mdb__declarative_user__print_arg_cmd_2_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__print_arg_cmd_2_0_i1);
	}
	MR_sv(1) = MR_r2;
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(string__to_int_2_0,
		mdb__declarative_user__print_arg_cmd_2_0_i41);
MR_def_label(mdb__declarative_user__print_arg_cmd_2_0,41)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__print_arg_cmd_2_0_i1);
	}
	if (((MR_Integer) MR_sv(1) > (MR_Integer) MR_r2)) {
		MR_GOTO_LAB(mdb__declarative_user__print_arg_cmd_2_0_i43);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 3);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 2;
	MR_tfield(3, MR_tempr1, 1) = MR_sv(1);
	MR_tfield(3, MR_tempr1, 2) = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(3);
	}
MR_def_label(mdb__declarative_user__print_arg_cmd_2_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 3);
	MR_tfield(3, MR_tempr1, 0) = (MR_Integer) 2;
	MR_tfield(3, MR_tempr1, 1) = MR_r2;
	MR_tfield(3, MR_tempr1, 2) = MR_sv(1);
	MR_r2 = MR_tempr1;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(3);
	}
MR_def_label(mdb__declarative_user__print_arg_cmd_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_decr_sp_and_return(3);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(mdb__parse__parse_2_0);

MR_BEGIN_MODULE(mdb__declarative_user_module39)
	MR_init_entry1(mdb__declarative_user__format_arg_cmd_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__format_arg_cmd_2_0);
	MR_init_label2(mdb__declarative_user__format_arg_cmd_2_0,4,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'format_arg_cmd'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__format_arg_cmd_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(1);
	MR_sv(1) = (MR_Word) MR_succip;
	if (MR_LTAGS_TEST(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__format_arg_cmd_2_0_i1);
	}
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = (MR_Word) MR_string_const("format", 6);
	MR_tfield(1, MR_r2, 1) = MR_r1;
	MR_r1 = MR_r2;
	MR_np_call_localret_ent(mdb__parse__parse_2_0,
		mdb__declarative_user__format_arg_cmd_2_0_i4);
MR_def_label(mdb__declarative_user__format_arg_cmd_2_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__format_arg_cmd_2_0_i1);
	}
	if (MR_RTAGS_TESTR(MR_r2,3,3)) {
		MR_GOTO_LAB(mdb__declarative_user__format_arg_cmd_2_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(3, MR_r2, 1);
	if (MR_PTAG_TESTR(MR_tempr1,1)) {
		MR_GOTO_LAB(mdb__declarative_user__format_arg_cmd_2_0_i1);
	}
	MR_tag_alloc_heap(MR_r2, 3, (MR_Integer) 2);
	MR_tfield(3, MR_r2, 0) = (MR_Integer) 3;
	MR_tfield(3, MR_r2, 1) = MR_tempr1;
	MR_succip_word = MR_sv(1);
	MR_decr_sp(1);
	MR_r1 = MR_TRUE;
	MR_proceed();
	}
MR_def_label(mdb__declarative_user__format_arg_cmd_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(1);
	MR_decr_sp(1);
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_mdb__parse__type_ctor_info_setting_option_0;
extern const MR_TypeCtorInfo_Struct mercury_data_getopt__type_ctor_info_option_data_0;
MR_decl_entry(svmap__det_update_4_0);

MR_BEGIN_MODULE(mdb__declarative_user_module40)
	MR_init_entry1(mdb__declarative_user__format_param_arg_cmd_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__format_param_arg_cmd_3_0);
	MR_init_label6(mdb__declarative_user__format_param_arg_cmd_3_0,7,13,15,2,21,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'format_param_arg_cmd'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__format_param_arg_cmd_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	if (MR_LTAGS_TEST(MR_r2,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__format_param_arg_cmd_3_0_i2);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r2, 0);
	if ((strcmp((char *) (MR_Word *) MR_tempr1, MR_string_const("io", 2)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__format_param_arg_cmd_3_0_i2);
	}
	MR_tempr1 = MR_tfield(1, MR_r2, 1);
	if (MR_LTAGS_TEST(MR_tempr1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__format_param_arg_cmd_3_0_i1);
	}
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_r1;
	MR_tfield(1, MR_r2, 1) = MR_tempr1;
	MR_r1 = MR_r2;
	}
	MR_np_call_localret_ent(mdb__parse__parse_2_0,
		mdb__declarative_user__format_param_arg_cmd_3_0_i7);
MR_def_label(mdb__declarative_user__format_param_arg_cmd_3_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__format_param_arg_cmd_3_0_i1);
	}
	if (MR_RTAGS_TESTR(MR_r2,3,3)) {
		MR_GOTO_LAB(mdb__declarative_user__format_param_arg_cmd_3_0_i1);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_tfield(3, MR_r2, 1);
	if (MR_PTAG_TESTR(MR_tempr1,2)) {
		MR_GOTO_LAB(mdb__declarative_user__format_param_arg_cmd_3_0_i1);
	}
	MR_tempr2 = MR_tfield(2, MR_tempr1, 0);
	if (MR_PTAG_TESTR(MR_tempr2,0)) {
		MR_GOTO_LAB(mdb__declarative_user__format_param_arg_cmd_3_0_i1);
	}
	MR_sv(1) = MR_tfield(2, MR_tempr1, 1);
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdb__parse, setting_option);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(getopt, option_data);
	MR_r3 = (MR_Integer) 0;
	MR_r4 = (MR_Word) MR_TAG_COMMON(1,15,0);
	MR_r5 = MR_tfield(0, MR_tempr2, 0);
	}
	MR_np_call_localret_ent(svmap__det_update_4_0,
		mdb__declarative_user__format_param_arg_cmd_3_0_i13);
MR_def_label(mdb__declarative_user__format_param_arg_cmd_3_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdb__parse, setting_option);
	MR_r2 = (MR_Word) MR_CTOR0_ADDR(getopt, option_data);
	MR_r3 = (MR_Integer) 2;
	MR_r4 = (MR_Word) MR_TAG_COMMON(1,15,1);
	MR_r5 = MR_tempr1;
	}
	MR_np_call_localret_ent(svmap__det_update_4_0,
		mdb__declarative_user__format_param_arg_cmd_3_0_i15);
MR_def_label(mdb__declarative_user__format_param_arg_cmd_3_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 1);
	MR_tfield(0, MR_tempr1, 0) = MR_r1;
	MR_tag_alloc_heap(MR_tempr2, 2, (MR_Integer) 2);
	MR_tfield(2, MR_tempr2, 0) = MR_tempr1;
	MR_tfield(2, MR_tempr2, 1) = MR_sv(1);
	MR_tag_alloc_heap(MR_r2, 3, (MR_Integer) 2);
	MR_tfield(3, MR_r2, 0) = (MR_Integer) 3;
	MR_tfield(3, MR_r2, 1) = MR_tempr2;
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_r1 = MR_TRUE;
	MR_proceed();
	}
MR_def_label(mdb__declarative_user__format_param_arg_cmd_3_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_r2,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__format_param_arg_cmd_3_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_tempr1, 0) = MR_r1;
	MR_tfield(1, MR_tempr1, 1) = MR_r2;
	MR_r1 = MR_tempr1;
	}
	MR_np_call_localret_ent(mdb__parse__parse_2_0,
		mdb__declarative_user__format_param_arg_cmd_3_0_i21);
MR_def_label(mdb__declarative_user__format_param_arg_cmd_3_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__format_param_arg_cmd_3_0_i1);
	}
	if (MR_RTAGS_TESTR(MR_r2,3,3)) {
		MR_GOTO_LAB(mdb__declarative_user__format_param_arg_cmd_3_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(3, MR_r2, 1);
	if (MR_PTAG_TESTR(MR_tempr1,2)) {
		MR_GOTO_LAB(mdb__declarative_user__format_param_arg_cmd_3_0_i1);
	}
	MR_tag_alloc_heap(MR_r2, 3, (MR_Integer) 2);
	MR_tfield(3, MR_r2, 0) = (MR_Integer) 3;
	MR_tfield(3, MR_r2, 1) = MR_tempr1;
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_r1 = MR_TRUE;
	MR_proceed();
	}
MR_def_label(mdb__declarative_user__format_param_arg_cmd_3_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module41)
	MR_init_entry1(mdb__declarative_user__num_io_actions_cmd_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__num_io_actions_cmd_2_0);
	MR_init_label2(mdb__declarative_user__num_io_actions_cmd_2_0,4,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'num_io_actions_cmd'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__num_io_actions_cmd_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(1);
	MR_sv(1) = (MR_Word) MR_succip;
	if (MR_LTAGS_TEST(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__num_io_actions_cmd_2_0_i1);
	}
	MR_r2 = MR_tfield(1, MR_r1, 1);
	if (MR_LTAGS_TESTR(MR_r2,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__num_io_actions_cmd_2_0_i1);
	}
	MR_r1 = MR_tfield(1, MR_r1, 0);
	MR_np_call_localret_ent(string__to_int_2_0,
		mdb__declarative_user__num_io_actions_cmd_2_0_i4);
MR_def_label(mdb__declarative_user__num_io_actions_cmd_2_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(mdb__declarative_user__num_io_actions_cmd_2_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 3, (MR_Integer) 1);
	MR_tfield(3, MR_tempr1, 0) = MR_r2;
	MR_tag_alloc_heap(MR_r2, 3, (MR_Integer) 2);
	MR_tfield(3, MR_r2, 0) = (MR_Integer) 3;
	MR_tfield(3, MR_r2, 1) = MR_tempr1;
	MR_succip_word = MR_sv(1);
	MR_decr_sp(1);
	MR_r1 = MR_TRUE;
	MR_proceed();
	}
MR_def_label(mdb__declarative_user__num_io_actions_cmd_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(1);
	MR_decr_sp(1);
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module42)
	MR_init_entry1(mdb__declarative_user__trust_arg_cmd_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__trust_arg_cmd_2_0);
	MR_init_label2(mdb__declarative_user__trust_arg_cmd_2_0,3,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'trust_arg_cmd'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__trust_arg_cmd_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__trust_arg_cmd_2_0_i3);
	}
	MR_r2 = (MR_Word) MR_tbmkword(0, 5);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__trust_arg_cmd_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r1, 0);
	if ((strcmp((char *) (MR_Word *) MR_tempr1, MR_string_const("module", 6)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__trust_arg_cmd_2_0_i1);
	}
	MR_tempr1 = MR_tfield(1, MR_r1, 1);
	if (MR_LTAGS_TESTR(MR_tempr1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__trust_arg_cmd_2_0_i1);
	}
	MR_r2 = (MR_Word) MR_tbmkword(0, 6);
	MR_r1 = MR_TRUE;
	MR_proceed();
	}
MR_def_label(mdb__declarative_user__trust_arg_cmd_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module43)
	MR_init_entry1(mdb__declarative_user__search_mode_cmd_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__search_mode_cmd_2_0);
	MR_init_label10(mdb__declarative_user__search_mode_cmd_2_0,5,7,9,11,13,15,17,19,21,23)
	MR_init_label1(mdb__declarative_user__search_mode_cmd_2_0,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'search_mode_cmd'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__search_mode_cmd_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__search_mode_cmd_2_0_i1);
	}
	MR_r3 = MR_tfield(1, MR_r1, 1);
	if (MR_LTAGS_TESTR(MR_r3,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__search_mode_cmd_2_0_i1);
	}
	MR_r3 = MR_tfield(1, MR_r1, 0);
	if ((strcmp((char *) (MR_Word *) MR_r3, MR_string_const("b", 1)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__search_mode_cmd_2_0_i5);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(3,16,0);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__search_mode_cmd_2_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r3, MR_string_const("dq", 2)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__search_mode_cmd_2_0_i7);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(3,16,1);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__search_mode_cmd_2_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r3, MR_string_const("td", 2)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__search_mode_cmd_2_0_i9);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(3,16,2);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__search_mode_cmd_2_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r3, MR_string_const("sdq", 3)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__search_mode_cmd_2_0_i11);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(3,16,3);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__search_mode_cmd_2_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r3, MR_string_const("binary", 6)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__search_mode_cmd_2_0_i13);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(3,16,0);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__search_mode_cmd_2_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r3, MR_string_const("top-down", 8)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__search_mode_cmd_2_0_i15);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(3,16,2);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__search_mode_cmd_2_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r3, MR_string_const("top_down", 8)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__search_mode_cmd_2_0_i17);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(3,16,2);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__search_mode_cmd_2_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r3, MR_string_const("divide-and-query", 16)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__search_mode_cmd_2_0_i19);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(3,16,1);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__search_mode_cmd_2_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r3, MR_string_const("divide_and_query", 16)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__search_mode_cmd_2_0_i21);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(3,16,1);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__search_mode_cmd_2_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r3, MR_string_const("suspicion-divide-and-query", 26)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__search_mode_cmd_2_0_i23);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(3,16,3);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__search_mode_cmd_2_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r3, MR_string_const("suspicion_divide_and_query", 26)) != 0)) {
		MR_GOTO_LAB(mdb__declarative_user__search_mode_cmd_2_0_i1);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(3,16,3);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__search_mode_cmd_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module44)
	MR_init_entry1(mdb__declarative_user__help_cmd_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__help_cmd_2_0);
	MR_init_label2(mdb__declarative_user__help_cmd_2_0,3,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'help_cmd'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__help_cmd_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_r1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__help_cmd_2_0_i3);
	}
	MR_r2 = (MR_Word) MR_TAG_COMMON(3,9,1);
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(mdb__declarative_user__help_cmd_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r1, 1);
	if (MR_LTAGS_TESTR(MR_tempr1,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__help_cmd_2_0_i1);
	}
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 1);
	MR_tfield(1, MR_tempr1, 0) = MR_tfield(1, MR_r1, 0);
	MR_tag_alloc_heap(MR_r2, 3, (MR_Integer) 2);
	MR_tfield(3, MR_r2, 0) = (MR_Integer) 5;
	MR_tfield(3, MR_r2, 1) = MR_tempr1;
	MR_r1 = MR_TRUE;
	MR_proceed();
	}
MR_def_label(mdb__declarative_user__help_cmd_2_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module45)
	MR_init_entry1(mdb__declarative_user__is_dash_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__is_dash_1_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'is_dash'/1 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__is_dash_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = ((MR_Integer) MR_r1 == (MR_Integer) 45);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module46)
	MR_init_entry1(mdb__declarative_user__trace_atom_arg_to_univ_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__trace_atom_arg_to_univ_2_0);
	MR_init_label1(mdb__declarative_user__trace_atom_arg_to_univ_2_0,3)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'trace_atom_arg_to_univ'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__trace_atom_arg_to_univ_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r3 = MR_tfield(0, MR_r1, 2);
	if (MR_LTAGS_TESTR(MR_r3,0,0)) {
		MR_GOTO_LAB(mdb__declarative_user__trace_atom_arg_to_univ_2_0_i3);
	}
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdb__browse, unbound);
	MR_np_tailcall_ent(fn__univ__univ_1_1);
MR_def_label(mdb__declarative_user__trace_atom_arg_to_univ_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(1, MR_r3, 0);
	MR_np_tailcall_ent(mdb__term_rep__rep_to_univ_2_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_int_0;
MR_decl_entry(__Unify___maybe__maybe_1_0);
MR_decl_entry(__Unify___mdb__browser_info__param_cmd_0_0);

MR_BEGIN_MODULE(mdb__declarative_user_module47)
	MR_init_entry1(__Unify___mdb__declarative_user__user_command_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___mdb__declarative_user__user_command_0_0);
	MR_init_label10(__Unify___mdb__declarative_user__user_command_0_0,5,6,7,8,9,10,11,12,13,14)
	MR_init_label10(__Unify___mdb__declarative_user__user_command_0_0,15,16,17,18,22,26,28,30,34,90)
	MR_init_label2(__Unify___mdb__declarative_user__user_command_0_0,38,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Unify___mdb__declarative_user__user_command_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i90);
	}
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_sv(1) = MR_tempr1;
	MR_sv(2) = MR_r2;
	if (MR_LTAGS_TESTR(MR_tempr1,0,9)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i5);
	}
	MR_r1 = (MR_sv(2) == MR_tempr1);
	MR_decr_sp(3);
	MR_proceed();
	}
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,11)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i6);
	}
	MR_r1 = (MR_sv(2) == MR_sv(1));
	MR_decr_sp_and_return(3);
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,12)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i7);
	}
	MR_r1 = (MR_sv(2) == MR_sv(1));
	MR_decr_sp_and_return(3);
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,2)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i8);
	}
	MR_r1 = (MR_sv(2) == MR_sv(1));
	MR_decr_sp_and_return(3);
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,7)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i9);
	}
	MR_r1 = (MR_sv(2) == MR_sv(1));
	MR_decr_sp_and_return(3);
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,1)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i10);
	}
	MR_r1 = (MR_sv(2) == MR_sv(1));
	MR_decr_sp_and_return(3);
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,4)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i11);
	}
	MR_r1 = (MR_sv(2) == MR_sv(1));
	MR_decr_sp_and_return(3);
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,10)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i12);
	}
	MR_r1 = (MR_sv(2) == MR_sv(1));
	MR_decr_sp_and_return(3);
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,3)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i13);
	}
	MR_r1 = (MR_sv(2) == MR_sv(1));
	MR_decr_sp_and_return(3);
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,6)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i14);
	}
	MR_r1 = (MR_sv(2) == MR_sv(1));
	MR_decr_sp_and_return(3);
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,5)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i15);
	}
	MR_r1 = (MR_sv(2) == MR_sv(1));
	MR_decr_sp_and_return(3);
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,8)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i16);
	}
	MR_r1 = (MR_sv(2) == MR_sv(1));
	MR_decr_sp_and_return(3);
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,0)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i17);
	}
	MR_r1 = (MR_sv(2) == MR_sv(1));
	MR_decr_sp_and_return(3);
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(1),1)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i18);
	}
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i1);
	}
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_tfield(1, MR_sv(1), 0);
	MR_r3 = MR_tfield(1, MR_sv(2), 0);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(__Unify___maybe__maybe_1_0);
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(1),2)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i22);
	}
	if (MR_PTAG_TESTR(MR_sv(2),2)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i1);
	}
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_tfield(2, MR_sv(1), 0);
	MR_r3 = MR_tfield(2, MR_sv(2), 0);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(__Unify___maybe__maybe_1_0);
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(1),3,0)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i26);
	}
	if (MR_RTAGS_TESTR(MR_sv(2),3,0)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i1);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_tfield(3, MR_sv(1), 1);
	MR_tempr2 = MR_tfield(3, MR_sv(2), 1);
	MR_r1 = (MR_tempr1 == MR_tempr2);
	MR_decr_sp_and_return(3);
	}
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(1),3,4)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i28);
	}
	if (MR_RTAGS_TESTR(MR_sv(2),3,4)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i1);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_tfield(3, MR_sv(1), 1);
	MR_tempr2 = MR_tfield(3, MR_sv(2), 1);
	MR_r1 = (MR_tempr1 == MR_tempr2);
	MR_decr_sp_and_return(3);
	}
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(1),3,5)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i30);
	}
	if (MR_RTAGS_TESTR(MR_sv(2),3,5)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i1);
	}
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r2 = MR_tfield(3, MR_sv(1), 1);
	MR_r3 = MR_tfield(3, MR_sv(2), 1);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(__Unify___maybe__maybe_1_0);
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(1),3,3)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i34);
	}
	if (MR_RTAGS_TESTR(MR_sv(2),3,3)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i1);
	}
	MR_r1 = MR_tfield(3, MR_sv(1), 1);
	MR_r2 = MR_tfield(3, MR_sv(2), 1);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(__Unify___mdb__browser_info__param_cmd_0_0);
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(1),3,1)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i38);
	}
	if (MR_RTAGS_TESTR(MR_sv(2),3,1)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i1);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tempr3 = MR_sv(1);
	MR_tempr1 = MR_tfield(3, MR_tempr3, 1);
	MR_tempr4 = MR_sv(2);
	MR_tempr2 = MR_tfield(3, MR_tempr4, 1);
	if ((MR_tempr1 != MR_tempr2)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i1);
	}
	MR_tempr1 = MR_tfield(3, MR_tempr3, 2);
	MR_tempr2 = MR_tfield(3, MR_tempr4, 2);
	MR_r1 = (MR_tempr1 == MR_tempr2);
	MR_decr_sp_and_return(3);
	}
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,90)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,38)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,2)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i1);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tempr3 = MR_sv(1);
	MR_tempr1 = MR_tfield(3, MR_tempr3, 1);
	MR_tempr4 = MR_sv(2);
	MR_tempr2 = MR_tfield(3, MR_tempr4, 1);
	if ((MR_tempr1 != MR_tempr2)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_command_0_0_i1);
	}
	MR_tempr1 = MR_tfield(3, MR_tempr3, 2);
	MR_tempr2 = MR_tfield(3, MR_tempr4, 2);
	MR_r1 = (MR_tempr1 == MR_tempr2);
	MR_decr_sp_and_return(3);
	}
MR_def_label(__Unify___mdb__declarative_user__user_command_0_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_decr_sp_and_return(3);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(__Compare___maybe__maybe_1_0);
MR_decl_entry(private_builtin__builtin_compare_int_3_0);
MR_decl_entry(__Compare___mdb__browser_info__param_cmd_0_0);
MR_decl_entry(private_builtin__compare_error_0_0);

MR_BEGIN_MODULE(mdb__declarative_user_module48)
	MR_init_entry1(__Compare___mdb__declarative_user__user_command_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___mdb__declarative_user__user_command_0_0);
	MR_init_label10(__Compare___mdb__declarative_user__user_command_0_0,5,6,7,8,9,10,11,12,13,14)
	MR_init_label10(__Compare___mdb__declarative_user__user_command_0_0,15,16,17,18,19,20,21,22,23,24)
	MR_init_label10(__Compare___mdb__declarative_user__user_command_0_0,4,26,27,28,29,30,31,32,33,34)
	MR_init_label10(__Compare___mdb__declarative_user__user_command_0_0,35,36,37,38,39,40,41,42,43,44)
	MR_init_label10(__Compare___mdb__declarative_user__user_command_0_0,45,25,46,47,50,51,52,53,54,55)
	MR_init_label10(__Compare___mdb__declarative_user__user_command_0_0,56,57,58,59,60,61,229,62,63,66)
	MR_init_label9(__Compare___mdb__declarative_user__user_command_0_0,69,72,75,78,84,81,91,48,100)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(__Compare___mdb__declarative_user__user_command_0_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i229);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	if (MR_LTAGS_TESTR(MR_sv(1),0,9)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i5);
	}
	MR_r1 = (MR_Integer) 15;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i4);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,11)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i6);
	}
	MR_r1 = (MR_Integer) 19;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i4);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,12)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i7);
	}
	MR_r1 = (MR_Integer) 20;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i4);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i8);
	}
	MR_r1 = (MR_Integer) 2;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i4);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,7)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i9);
	}
	MR_r1 = (MR_Integer) 13;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i4);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i10);
	}
	MR_r1 = (MR_Integer) 1;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i4);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,4)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i11);
	}
	MR_r1 = (MR_Integer) 9;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i4);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,10)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i12);
	}
	MR_r1 = (MR_Integer) 17;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i4);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,3)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i13);
	}
	MR_r1 = (MR_Integer) 3;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i4);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,6)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i14);
	}
	MR_r1 = (MR_Integer) 12;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i4);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,5)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i15);
	}
	MR_r1 = (MR_Integer) 11;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i4);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,8)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i16);
	}
	MR_r1 = (MR_Integer) 14;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i4);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i17);
	}
	MR_r1 = (MR_Integer) 0;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i4);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(1),1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i18);
	}
	MR_r1 = (MR_Integer) 4;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i4);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(1),2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i19);
	}
	MR_r1 = (MR_Integer) 5;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i4);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(1),3,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i20);
	}
	MR_r1 = (MR_Integer) 6;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i4);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(1),3,4)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i21);
	}
	MR_r1 = (MR_Integer) 16;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i4);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(1),3,5)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i22);
	}
	MR_r1 = (MR_Integer) 18;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i4);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(1),3,3)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i23);
	}
	MR_r1 = (MR_Integer) 10;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i4);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(1),3,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i24);
	}
	MR_r1 = (MR_Integer) 7;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i4);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 8;
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,9)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i26);
	}
	MR_r2 = (MR_Integer) 15;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i25);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,11)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i27);
	}
	MR_r2 = (MR_Integer) 19;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i25);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,12)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i28);
	}
	MR_r2 = (MR_Integer) 20;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i25);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i29);
	}
	MR_r2 = (MR_Integer) 2;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i25);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,7)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i30);
	}
	MR_r2 = (MR_Integer) 13;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i25);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i31);
	}
	MR_r2 = (MR_Integer) 1;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i25);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,4)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i32);
	}
	MR_r2 = (MR_Integer) 9;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i25);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,10)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i33);
	}
	MR_r2 = (MR_Integer) 17;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i25);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,3)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i34);
	}
	MR_r2 = (MR_Integer) 3;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i25);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,6)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i35);
	}
	MR_r2 = (MR_Integer) 12;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i25);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,5)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i36);
	}
	MR_r2 = (MR_Integer) 11;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i25);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,8)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i37);
	}
	MR_r2 = (MR_Integer) 14;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i25);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,37)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i38);
	}
	MR_r2 = (MR_Integer) 0;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i25);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,38)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i39);
	}
	MR_r2 = (MR_Integer) 4;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i25);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i40);
	}
	MR_r2 = (MR_Integer) 5;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i25);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i41);
	}
	MR_r2 = (MR_Integer) 6;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i25);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,41)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,4)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i42);
	}
	MR_r2 = (MR_Integer) 16;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i25);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,42)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,5)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i43);
	}
	MR_r2 = (MR_Integer) 18;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i25);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,3)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i44);
	}
	MR_r2 = (MR_Integer) 10;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i25);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,44)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i45);
	}
	MR_r2 = (MR_Integer) 7;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i25);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,45)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Integer) 8;
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (((MR_Integer) MR_r1 >= (MR_Integer) MR_r2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i46);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,46)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (((MR_Integer) MR_r1 <= (MR_Integer) MR_r2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i47);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,47)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,9)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i50);
	}
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,50)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,11)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i51);
	}
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,51)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,12)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i52);
	}
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,52)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i53);
	}
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,53)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,7)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i54);
	}
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,54)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i55);
	}
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,55)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,4)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i56);
	}
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,56)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,10)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i57);
	}
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,57)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,3)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i58);
	}
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,58)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,6)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i59);
	}
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,59)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,5)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i60);
	}
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,60)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,8)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i61);
	}
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,61)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i62);
	}
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,229)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_and_return(3);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,62)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(1),1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i63);
	}
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i48);
	}
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_tfield(1, MR_sv(1), 0);
	MR_r3 = MR_tfield(1, MR_sv(2), 0);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(__Compare___maybe__maybe_1_0);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,63)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(1),2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i66);
	}
	if (MR_PTAG_TESTR(MR_sv(2),2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i48);
	}
	MR_r1 = (MR_Word) MR_INT_CTOR_ADDR;
	MR_r2 = MR_tfield(2, MR_sv(1), 0);
	MR_r3 = MR_tfield(2, MR_sv(2), 0);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(__Compare___maybe__maybe_1_0);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,66)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(1),3,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i69);
	}
	if (MR_RTAGS_TESTR(MR_sv(2),3,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i48);
	}
	MR_r1 = MR_tfield(3, MR_sv(1), 1);
	MR_r2 = MR_tfield(3, MR_sv(2), 1);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(private_builtin__builtin_compare_int_3_0);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,69)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(1),3,4)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i72);
	}
	if (MR_RTAGS_TESTR(MR_sv(2),3,4)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i48);
	}
	MR_r1 = MR_tfield(3, MR_sv(1), 1);
	MR_r2 = MR_tfield(3, MR_sv(2), 1);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(private_builtin__builtin_compare_int_3_0);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,72)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(1),3,5)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i75);
	}
	if (MR_RTAGS_TESTR(MR_sv(2),3,5)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i48);
	}
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	MR_r2 = MR_tfield(3, MR_sv(1), 1);
	MR_r3 = MR_tfield(3, MR_sv(2), 1);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(__Compare___maybe__maybe_1_0);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,75)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(1),3,3)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i78);
	}
	if (MR_RTAGS_TESTR(MR_sv(2),3,3)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i48);
	}
	MR_r1 = MR_tfield(3, MR_sv(1), 1);
	MR_r2 = MR_tfield(3, MR_sv(2), 1);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(__Compare___mdb__browser_info__param_cmd_0_0);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,78)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(1),3,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i81);
	}
	if (MR_RTAGS_TESTR(MR_sv(2),3,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i48);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6;
	MR_tempr5 = MR_sv(2);
	MR_tempr1 = MR_tfield(3, MR_tempr5, 2);
	MR_tempr6 = MR_sv(1);
	MR_tempr2 = MR_tfield(3, MR_tempr6, 2);
	MR_tempr3 = MR_tempr6;
	MR_sv(1) = MR_tempr2;
	MR_tempr4 = MR_tempr5;
	MR_sv(2) = MR_tempr1;
	MR_r1 = MR_tfield(3, MR_tempr3, 1);
	MR_r2 = MR_tfield(3, MR_tempr4, 1);
	}
	MR_np_call_localret_ent(private_builtin__builtin_compare_int_3_0,
		__Compare___mdb__declarative_user__user_command_0_0_i84);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,84)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i100);
	}
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(private_builtin__builtin_compare_int_3_0);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,81)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i48);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6;
	MR_tempr5 = MR_sv(2);
	MR_tempr1 = MR_tfield(3, MR_tempr5, 2);
	MR_tempr6 = MR_sv(1);
	MR_tempr2 = MR_tfield(3, MR_tempr6, 2);
	MR_tempr3 = MR_tempr6;
	MR_sv(1) = MR_tempr2;
	MR_tempr4 = MR_tempr5;
	MR_sv(2) = MR_tempr1;
	MR_r1 = MR_tfield(3, MR_tempr3, 1);
	MR_r2 = MR_tfield(3, MR_tempr4, 1);
	}
	MR_np_call_localret_ent(private_builtin__builtin_compare_int_3_0,
		__Compare___mdb__declarative_user__user_command_0_0_i91);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,91)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_command_0_0_i100);
	}
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(private_builtin__builtin_compare_int_3_0);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,48)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(private_builtin__compare_error_0_0);
MR_def_label(__Compare___mdb__declarative_user__user_command_0_0,100)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(3);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(__Unify___mdb__declarative_debugger__decl_question_1_0);

MR_BEGIN_MODULE(mdb__declarative_user_module49)
	MR_init_entry1(__Unify___mdb__declarative_user__user_question_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___mdb__declarative_user__user_question_1_0);
	MR_init_label4(__Unify___mdb__declarative_user__user_question_1_0,16,5,10,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___mdb__declarative_user__user_question_1_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r2 == MR_r3)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_question_1_0_i16);
	}
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r2;
	MR_sv(1) = MR_tempr1;
	MR_tempr2 = MR_r3;
	MR_sv(2) = MR_tempr2;
	MR_sv(3) = MR_r1;
	if (MR_PTAG_TESTR(MR_tempr1,0)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_question_1_0_i5);
	}
	if (MR_PTAG_TESTR(MR_tempr2,0)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_question_1_0_i1);
	}
	MR_r2 = MR_tfield(0, MR_tempr1, 0);
	MR_r3 = MR_tfield(0, MR_tempr2, 0);
	MR_decr_sp(4);
	MR_np_tailcall_ent(__Unify___mdb__declarative_debugger__decl_question_1_0);
	}
MR_def_label(__Unify___mdb__declarative_user__user_question_1_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(__Unify___mdb__declarative_user__user_question_1_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_question_1_0_i1);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_tfield(1, MR_tempr1, 1);
	MR_tempr2 = MR_sv(2);
	MR_sv(2) = MR_tfield(1, MR_tempr2, 1);
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tfield(1, MR_tempr1, 0);
	MR_r3 = MR_tfield(1, MR_tempr2, 0);
	}
	MR_np_call_localret_ent(__Unify___mdb__declarative_debugger__decl_question_1_0,
		__Unify___mdb__declarative_user__user_question_1_0_i10);
MR_def_label(__Unify___mdb__declarative_user__user_question_1_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_question_1_0_i1);
	}
	MR_r1 = (MR_sv(1) == MR_sv(2));
	MR_decr_sp_and_return(4);
MR_def_label(__Unify___mdb__declarative_user__user_question_1_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_decr_sp_and_return(4);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(__Compare___mdb__declarative_debugger__decl_question_1_0);

MR_BEGIN_MODULE(mdb__declarative_user_module50)
	MR_init_entry1(__Compare___mdb__declarative_user__user_question_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___mdb__declarative_user__user_question_1_0);
	MR_init_label7(__Compare___mdb__declarative_user__user_question_1_0,3,2,7,5,10,12,45)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___mdb__declarative_user__user_question_1_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r2 == MR_r3)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_question_1_0_i3);
	}
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_r1;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_question_1_0_i2);
MR_def_label(__Compare___mdb__declarative_user__user_question_1_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_def_label(__Compare___mdb__declarative_user__user_question_1_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(1),0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_question_1_0_i5);
	}
	if (MR_PTAG_TESTR(MR_sv(2),0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_question_1_0_i7);
	}
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tfield(0, MR_sv(1), 0);
	MR_r3 = MR_tfield(0, MR_sv(2), 0);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(__Compare___mdb__declarative_debugger__decl_question_1_0);
MR_def_label(__Compare___mdb__declarative_user__user_question_1_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_question_1_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_question_1_0_i10);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_question_1_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6;
	MR_tempr5 = MR_sv(1);
	MR_tempr1 = MR_tfield(1, MR_tempr5, 1);
	MR_tempr6 = MR_sv(2);
	MR_tempr2 = MR_tfield(1, MR_tempr6, 1);
	MR_tempr3 = MR_tempr5;
	MR_sv(1) = MR_tempr2;
	MR_tempr4 = MR_tempr6;
	MR_sv(2) = MR_tempr1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tfield(1, MR_tempr3, 0);
	MR_r3 = MR_tfield(1, MR_tempr4, 0);
	}
	MR_np_call_localret_ent(__Compare___mdb__declarative_debugger__decl_question_1_0,
		__Compare___mdb__declarative_user__user_question_1_0_i12);
MR_def_label(__Compare___mdb__declarative_user__user_question_1_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_question_1_0_i45);
	}
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(1);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(private_builtin__builtin_compare_int_3_0);
MR_def_label(__Compare___mdb__declarative_user__user_question_1_0,45)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(4);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(__Unify___mdb__declarative_debugger__decl_answer_1_0);
MR_decl_entry(builtin__unify_2_0);
MR_decl_entry(__Unify___io__output_stream_0_0);

MR_BEGIN_MODULE(mdb__declarative_user_module51)
	MR_init_entry1(__Unify___mdb__declarative_user__user_response_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___mdb__declarative_user__user_response_1_0);
	MR_init_label10(__Unify___mdb__declarative_user__user_response_1_0,5,6,9,7,13,17,19,51,23,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___mdb__declarative_user__user_response_1_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r2 == MR_r3)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_response_1_0_i51);
	}
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_sv(1) = MR_tempr1;
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_r1;
	if (MR_LTAGS_TESTR(MR_tempr1,0,1)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_response_1_0_i5);
	}
	MR_r1 = (MR_sv(2) == MR_tempr1);
	MR_decr_sp(4);
	MR_proceed();
	}
MR_def_label(__Unify___mdb__declarative_user__user_response_1_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,0)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_response_1_0_i6);
	}
	MR_r1 = (MR_sv(2) == MR_sv(1));
	MR_decr_sp_and_return(4);
MR_def_label(__Unify___mdb__declarative_user__user_response_1_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(1),1)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_response_1_0_i7);
	}
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_response_1_0_i1);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_tfield(1, MR_tempr1, 1);
	MR_tempr2 = MR_sv(2);
	MR_sv(2) = MR_tfield(1, MR_tempr2, 1);
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tfield(1, MR_tempr1, 0);
	MR_r3 = MR_tfield(1, MR_tempr2, 0);
	}
	MR_np_call_localret_ent(__Unify___mdb__declarative_debugger__decl_question_1_0,
		__Unify___mdb__declarative_user__user_response_1_0_i9);
MR_def_label(__Unify___mdb__declarative_user__user_response_1_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_response_1_0_i1);
	}
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(1);
	MR_r3 = MR_sv(2);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(__Unify___mdb__declarative_debugger__decl_answer_1_0);
MR_def_label(__Unify___mdb__declarative_user__user_response_1_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(1),2)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_response_1_0_i13);
	}
	if (MR_PTAG_TESTR(MR_sv(2),2)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_response_1_0_i1);
	}
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tfield(2, MR_sv(1), 0);
	MR_r3 = MR_tfield(2, MR_sv(2), 0);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(__Unify___mdb__declarative_debugger__decl_question_1_0);
MR_def_label(__Unify___mdb__declarative_user__user_response_1_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(1),3,2)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_response_1_0_i17);
	}
	if (MR_RTAGS_TESTR(MR_sv(2),3,2)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_response_1_0_i1);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_tfield(3, MR_sv(1), 1);
	MR_tempr2 = MR_tfield(3, MR_sv(2), 1);
	MR_r1 = (MR_tempr1 == MR_tempr2);
	MR_decr_sp_and_return(4);
	}
MR_def_label(__Unify___mdb__declarative_user__user_response_1_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(1),3,3)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_response_1_0_i19);
	}
	if (MR_RTAGS_TESTR(MR_sv(2),3,3)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_response_1_0_i1);
	}
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tfield(3, MR_sv(1), 1);
	MR_r3 = MR_tfield(3, MR_sv(2), 1);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(builtin__unify_2_0);
MR_def_label(__Unify___mdb__declarative_user__user_response_1_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(1),3,1)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_response_1_0_i23);
	}
	if (MR_RTAGS_TESTR(MR_sv(2),3,1)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_response_1_0_i1);
	}
	MR_r1 = MR_tfield(3, MR_sv(1), 1);
	MR_r2 = MR_tfield(3, MR_sv(2), 1);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(__Unify___io__output_stream_0_0);
MR_def_label(__Unify___mdb__declarative_user__user_response_1_0,51)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(__Unify___mdb__declarative_user__user_response_1_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,0)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_response_1_0_i1);
	}
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tfield(3, MR_sv(1), 1);
	MR_r3 = MR_tfield(3, MR_sv(2), 1);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(__Unify___mdb__declarative_debugger__decl_question_1_0);
MR_def_label(__Unify___mdb__declarative_user__user_response_1_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_decr_sp_and_return(4);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(__Compare___mdb__declarative_debugger__decl_answer_1_0);
MR_decl_entry(builtin__compare_3_0);
MR_decl_entry(__Compare___io__output_stream_0_0);

MR_BEGIN_MODULE(mdb__declarative_user_module52)
	MR_init_entry1(__Compare___mdb__declarative_user__user_response_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___mdb__declarative_user__user_response_1_0);
	MR_init_label10(__Compare___mdb__declarative_user__user_response_1_0,7,8,9,10,11,12,5,16,164,17)
	MR_init_label10(__Compare___mdb__declarative_user__user_response_1_0,18,19,20,21,14,25,26,29,27,34)
	MR_init_label10(__Compare___mdb__declarative_user__user_response_1_0,35,36,23,40,41,42,43,45,46,38)
	MR_init_label10(__Compare___mdb__declarative_user__user_response_1_0,50,51,52,53,54,56,48,60,61,62)
	MR_init_label10(__Compare___mdb__declarative_user__user_response_1_0,63,64,65,58,70,71,72,73,74,75)
	MR_init_label10(__Compare___mdb__declarative_user__user_response_1_0,68,79,80,81,149,82,83,84,152,85)
	MR_init_label1(__Compare___mdb__declarative_user__user_response_1_0,87)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___mdb__declarative_user__user_response_1_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	if ((MR_r2 == MR_r3)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i164);
	}
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_r3;
	MR_sv(3) = MR_r1;
	if (MR_LTAGS_TESTR(MR_sv(1),0,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i5);
	}
	if (MR_LTAGS_TESTR(MR_sv(2),0,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i7);
	}
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp(4);
	MR_proceed();
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i8);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i9);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i10);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i11);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,3)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i12);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i149);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(1),0,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i14);
	}
	if (MR_LTAGS_TESTR(MR_sv(2),0,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i16);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i17);
	}
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,164)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i18);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i19);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i20);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,3)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i21);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i149);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(1),1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i23);
	}
	if (MR_LTAGS_TESTR(MR_sv(2),0,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i25);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i26);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i27);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6;
	MR_tempr5 = MR_sv(1);
	MR_tempr1 = MR_tfield(1, MR_tempr5, 1);
	MR_tempr6 = MR_sv(2);
	MR_tempr2 = MR_tfield(1, MR_tempr6, 1);
	MR_tempr3 = MR_tempr5;
	MR_sv(1) = MR_tempr2;
	MR_tempr4 = MR_tempr6;
	MR_sv(2) = MR_tempr1;
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tfield(1, MR_tempr3, 0);
	MR_r3 = MR_tfield(1, MR_tempr4, 0);
	}
	MR_np_call_localret_ent(__Compare___mdb__declarative_debugger__decl_question_1_0,
		__Compare___mdb__declarative_user__user_response_1_0_i29);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i87);
	}
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_sv(1);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(__Compare___mdb__declarative_debugger__decl_answer_1_0);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i34);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i35);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,3)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i36);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i152);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(1),2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i38);
	}
	if (MR_LTAGS_TESTR(MR_sv(2),0,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i40);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i41);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,41)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i42);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,42)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i43);
	}
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tfield(2, MR_sv(1), 0);
	MR_r3 = MR_tfield(2, MR_sv(2), 0);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(__Compare___mdb__declarative_debugger__decl_question_1_0);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i45);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,45)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,3)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i46);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,46)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i152);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,38)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(1),3,2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i48);
	}
	if (MR_LTAGS_TESTR(MR_sv(2),0,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i50);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,50)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i51);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,51)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i52);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,52)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i53);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,53)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i54);
	}
	MR_r1 = MR_tfield(3, MR_sv(1), 1);
	MR_r2 = MR_tfield(3, MR_sv(2), 1);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(private_builtin__builtin_compare_int_3_0);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,54)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,3)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i56);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,56)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i149);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,48)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(1),3,3)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i58);
	}
	if (MR_LTAGS_TESTR(MR_sv(2),0,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i60);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,60)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i61);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,61)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i62);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,62)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i63);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,63)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i64);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,64)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,3)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i65);
	}
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tfield(3, MR_sv(1), 1);
	MR_r3 = MR_tfield(3, MR_sv(2), 1);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(builtin__compare_3_0);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,65)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i149);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,58)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(1),3,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i68);
	}
	if (MR_LTAGS_TESTR(MR_sv(2),0,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i70);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,70)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i71);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,71)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i72);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,72)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i73);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,73)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i74);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,74)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,3)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i75);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,75)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i149);
	}
	MR_r1 = MR_tfield(3, MR_sv(1), 1);
	MR_r2 = MR_tfield(3, MR_sv(2), 1);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(__Compare___io__output_stream_0_0);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,68)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i79);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,79)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TESTR(MR_sv(2),0,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i80);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,80)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i81);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,81)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_sv(2),2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i82);
	}
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,149)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,82)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i83);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,83)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,3)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i84);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,84)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_RTAGS_TESTR(MR_sv(2),3,1)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_response_1_0_i85);
	}
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,152)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_and_return(4);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,85)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_r2 = MR_tfield(3, MR_sv(1), 1);
	MR_r3 = MR_tfield(3, MR_sv(2), 1);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(__Compare___mdb__declarative_debugger__decl_question_1_0);
MR_def_label(__Compare___mdb__declarative_user__user_response_1_0,87)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(4);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module53)
	MR_init_entry1(__Unify___mdb__declarative_user__user_search_mode_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___mdb__declarative_user__user_search_mode_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___mdb__declarative_user__user_search_mode_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_r1 == MR_r2);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module54)
	MR_init_entry1(__Compare___mdb__declarative_user__user_search_mode_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___mdb__declarative_user__user_search_mode_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___mdb__declarative_user__user_search_mode_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(private_builtin__builtin_compare_int_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(__Unify___io__input_stream_0_0);
MR_decl_entry(__Unify___mdb__browser_info__browser_persistent_state_0_0);
extern const MR_TypeCtorInfo_Struct mercury_data_mdb__help__type_ctor_info_system_0;

MR_BEGIN_MODULE(mdb__declarative_user_module55)
	MR_init_entry1(__Unify___mdb__declarative_user__user_state_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___mdb__declarative_user__user_state_0_0);
	MR_init_label6(__Unify___mdb__declarative_user__user_state_0_0,4,6,8,10,12,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___mdb__declarative_user__user_state_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_state_0_0_i12);
	}
	MR_incr_sp(11);
	MR_sv(11) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_tfield(0, MR_tempr1, 1);
	MR_tempr2 = MR_sv(2);
	MR_sv(2) = MR_tfield(0, MR_tempr1, 2);
	MR_sv(3) = MR_tfield(0, MR_tempr1, 3);
	MR_sv(4) = MR_tfield(0, MR_tempr1, 4);
	MR_sv(5) = MR_tfield(0, MR_tempr1, 5);
	MR_sv(6) = MR_tfield(0, MR_tempr2, 1);
	MR_sv(7) = MR_tfield(0, MR_tempr2, 2);
	MR_sv(8) = MR_tfield(0, MR_tempr2, 3);
	MR_sv(9) = MR_tfield(0, MR_tempr2, 4);
	MR_sv(10) = MR_tfield(0, MR_tempr2, 5);
	MR_r1 = MR_tfield(0, MR_tempr1, 0);
	MR_r2 = MR_tfield(0, MR_tempr2, 0);
	}
	MR_np_call_localret_ent(__Unify___io__input_stream_0_0,
		__Unify___mdb__declarative_user__user_state_0_0_i4);
MR_def_label(__Unify___mdb__declarative_user__user_state_0_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_state_0_0_i1);
	}
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(6);
	MR_np_call_localret_ent(__Unify___io__output_stream_0_0,
		__Unify___mdb__declarative_user__user_state_0_0_i6);
MR_def_label(__Unify___mdb__declarative_user__user_state_0_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_state_0_0_i1);
	}
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(7);
	MR_np_call_localret_ent(__Unify___mdb__browser_info__browser_persistent_state_0_0,
		__Unify___mdb__declarative_user__user_state_0_0_i8);
MR_def_label(__Unify___mdb__declarative_user__user_state_0_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_state_0_0_i1);
	}
	if ((MR_sv(3) != MR_sv(8))) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_state_0_0_i1);
	}
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdb__help, system);
	MR_r2 = MR_sv(4);
	MR_r3 = MR_sv(9);
	MR_np_call_localret_ent(builtin__unify_2_0,
		__Unify___mdb__declarative_user__user_state_0_0_i10);
MR_def_label(__Unify___mdb__declarative_user__user_state_0_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(__Unify___mdb__declarative_user__user_state_0_0_i1);
	}
	MR_r1 = (MR_sv(5) == MR_sv(10));
	MR_decr_sp_and_return(11);
MR_def_label(__Unify___mdb__declarative_user__user_state_0_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_TRUE;
	MR_proceed();
MR_def_label(__Unify___mdb__declarative_user__user_state_0_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_decr_sp_and_return(11);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(__Compare___io__input_stream_0_0);
MR_decl_entry(__Compare___mdb__browser_info__browser_persistent_state_0_0);

MR_BEGIN_MODULE(mdb__declarative_user_module56)
	MR_init_entry1(__Compare___mdb__declarative_user__user_state_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___mdb__declarative_user__user_state_0_0);
	MR_init_label8(__Compare___mdb__declarative_user__user_state_0_0,3,2,5,9,13,17,21,53)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___mdb__declarative_user__user_state_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((MR_r1 == MR_r2)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_state_0_0_i3);
	}
	MR_incr_sp(11);
	MR_sv(11) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_GOTO_LAB(__Compare___mdb__declarative_user__user_state_0_0_i2);
MR_def_label(__Compare___mdb__declarative_user__user_state_0_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_def_label(__Compare___mdb__declarative_user__user_state_0_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6;
	MR_tempr5 = MR_sv(2);
	MR_sv(10) = MR_tfield(0, MR_tempr5, 5);
	MR_sv(9) = MR_tfield(0, MR_tempr5, 4);
	MR_sv(8) = MR_tfield(0, MR_tempr5, 3);
	MR_sv(7) = MR_tfield(0, MR_tempr5, 2);
	MR_sv(6) = MR_tfield(0, MR_tempr5, 1);
	MR_tempr6 = MR_sv(1);
	MR_sv(5) = MR_tfield(0, MR_tempr6, 5);
	MR_sv(4) = MR_tfield(0, MR_tempr6, 4);
	MR_sv(3) = MR_tfield(0, MR_tempr6, 3);
	MR_tempr1 = MR_tfield(0, MR_tempr6, 2);
	MR_tempr2 = MR_tfield(0, MR_tempr6, 1);
	MR_tempr3 = MR_tempr6;
	MR_sv(1) = MR_tempr2;
	MR_tempr4 = MR_tempr5;
	MR_sv(2) = MR_tempr1;
	MR_r1 = MR_tfield(0, MR_tempr3, 0);
	MR_r2 = MR_tfield(0, MR_tempr4, 0);
	}
	MR_np_call_localret_ent(__Compare___io__input_stream_0_0,
		__Compare___mdb__declarative_user__user_state_0_0_i5);
MR_def_label(__Compare___mdb__declarative_user__user_state_0_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_state_0_0_i53);
	}
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(6);
	MR_np_call_localret_ent(__Compare___io__output_stream_0_0,
		__Compare___mdb__declarative_user__user_state_0_0_i9);
MR_def_label(__Compare___mdb__declarative_user__user_state_0_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_state_0_0_i53);
	}
	MR_r1 = MR_sv(2);
	MR_r2 = MR_sv(7);
	MR_np_call_localret_ent(__Compare___mdb__browser_info__browser_persistent_state_0_0,
		__Compare___mdb__declarative_user__user_state_0_0_i13);
MR_def_label(__Compare___mdb__declarative_user__user_state_0_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_state_0_0_i53);
	}
	MR_r1 = MR_sv(3);
	MR_r2 = MR_sv(8);
	MR_np_call_localret_ent(private_builtin__builtin_compare_int_3_0,
		__Compare___mdb__declarative_user__user_state_0_0_i17);
MR_def_label(__Compare___mdb__declarative_user__user_state_0_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_state_0_0_i53);
	}
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdb__help, system);
	MR_r2 = MR_sv(4);
	MR_r3 = MR_sv(9);
	MR_np_call_localret_ent(builtin__compare_3_0,
		__Compare___mdb__declarative_user__user_state_0_0_i21);
MR_def_label(__Compare___mdb__declarative_user__user_state_0_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,0)) {
		MR_GOTO_LAB(__Compare___mdb__declarative_user__user_state_0_0_i53);
	}
	MR_r1 = MR_sv(5);
	MR_r2 = MR_sv(10);
	MR_succip_word = MR_sv(11);
	MR_decr_sp(11);
	MR_np_tailcall_ent(private_builtin__builtin_compare_int_3_0);
MR_def_label(__Compare___mdb__declarative_user__user_state_0_0,53)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(11);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module57)
	MR_init_entry1(mdb__declarative_user__IntroducedFrom__pred__browse_atom__695__1_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__IntroducedFrom__pred__browse_atom__695__1_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__browse_atom__695__1'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__IntroducedFrom__pred__browse_atom__695__1_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_r1 == MR_r2);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module58)
	MR_init_entry1(mdb__declarative_user__IntroducedFrom__pred__browse_xml_atom__714__1_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__mdb__declarative_user__IntroducedFrom__pred__browse_xml_atom__714__1_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'IntroducedFrom__pred__browse_xml_atom__714__1'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(mdb__declarative_user__IntroducedFrom__pred__browse_xml_atom__714__1_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_r1 == MR_r2);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module59)
	MR_init_entry1(fn__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_103_101_116_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_103_101_116_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_1_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__func__get_decl_question__[1]_0'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(fn__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_102_117_110_99_95_95_103_101_116_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_1_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_mask_field(MR_r1, 0);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(string__append_3_2);

MR_BEGIN_MODULE(mdb__declarative_user_module60)
	MR_init_entry1(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0);
	MR_init_label10(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0,7,5,8,3,12,10,13,9,15,16)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__user_question_prompt__[1]_0'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,0)) {
		MR_GOTO_LAB(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0_i3);
	}
	MR_r2 = MR_tfield(0, MR_r1, 0);
	if (MR_PTAG_TESTR(MR_r2,1)) {
		MR_GOTO_LAB(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0_i5);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r2, 2);
	if (MR_LTAGS_TESTR(MR_tempr1,0,0)) {
		MR_GOTO_LAB(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0_i7);
	}
	MR_r1 = (MR_Word) MR_string_const("Unsatisfiable? ", 15);
	MR_proceed();
	}
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("Complete? ", 10);
	MR_proceed();
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r2,2)) {
		MR_GOTO_LAB(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0_i8);
	}
	MR_r1 = (MR_Word) MR_string_const("Expected? ", 10);
	MR_proceed();
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const("Valid? ", 7);
	MR_proceed();
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_tfield(1, MR_r1, 0);
	MR_r3 = MR_tempr1;
	if (MR_PTAG_TESTR(MR_tempr1,1)) {
		MR_GOTO_LAB(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0_i10);
	}
	MR_r4 = MR_tfield(1, MR_tempr1, 2);
	if (MR_LTAGS_TESTR(MR_r4,0,0)) {
		MR_GOTO_LAB(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0_i12);
	}
	MR_r2 = MR_tfield(1, MR_r1, 1);
	MR_r1 = (MR_Word) MR_string_const("Unsatisfiable? ", 15);
	MR_GOTO_LAB(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0_i9);
	}
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_tfield(1, MR_r1, 1);
	MR_r1 = (MR_Word) MR_string_const("Complete? ", 10);
	MR_GOTO_LAB(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0_i9);
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r3,2)) {
		MR_GOTO_LAB(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0_i13);
	}
	MR_r2 = MR_tfield(1, MR_r1, 1);
	MR_r1 = (MR_Word) MR_string_const("Expected? ", 10);
	MR_GOTO_LAB(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0_i9);
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_tfield(1, MR_r1, 1);
	MR_r1 = (MR_Word) MR_string_const("Valid? ", 7);
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r2,0)) {
		MR_GOTO_LAB(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0_i15);
	}
	MR_r2 = (MR_Word) MR_string_const("[yes] ", 6);
	MR_np_tailcall_ent(string__append_3_2);
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r2,1)) {
		MR_GOTO_LAB(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0_i16);
	}
	MR_r2 = (MR_Word) MR_string_const("[no] ", 5);
	MR_np_tailcall_ent(string__append_3_2);
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_117_115_101_114_95_113_117_101_115_116_105_111_110_95_112_114_111_109_112_116_95_95_91_49_93_95_48_2_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_string_const("[inadmissible] ", 15);
	MR_np_tailcall_ent(string__append_3_2);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module61)
	MR_init_entry1(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_116_114_97_99_101_95_97_116_111_109_115_95_95_91_49_93_95_48_3_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_116_114_97_99_101_95_97_116_111_109_115_95_95_91_49_93_95_48_3_0);
	MR_init_label2(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_116_114_97_99_101_95_97_116_111_109_115_95_95_91_49_93_95_48_3_0,3,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__edt_node_trace_atoms__[1]_0'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_116_114_97_99_101_95_97_116_111_109_115_95_95_91_49_93_95_48_3_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_116_114_97_99_101_95_97_116_111_109_115_95_95_91_49_93_95_48_3_0_i3);
	}
	MR_r1 = MR_tfield(1, MR_r1, 1);
	MR_r2 = MR_r1;
	MR_proceed();
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_116_114_97_99_101_95_97_116_111_109_115_95_95_91_49_93_95_48_3_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_116_114_97_99_101_95_97_116_111_109_115_95_95_91_49_93_95_48_3_0_i4);
	}
	MR_r1 = MR_tfield(2, MR_r1, 1);
	MR_r2 = MR_r1;
	MR_proceed();
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_116_114_97_99_101_95_97_116_111_109_115_95_95_91_49_93_95_48_3_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_tfield(0, MR_r1, 1);
	MR_r2 = MR_tfield(0, MR_tfield(0, MR_tempr1, 2), 0);
	MR_proceed();
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(mdb__declarative_user_module62)
	MR_init_entry1(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_105_111_95_97_99_116_105_111_110_115_95_95_91_49_93_95_48_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_105_111_95_97_99_116_105_111_110_115_95_95_91_49_93_95_48_2_0);
	MR_init_label2(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_105_111_95_97_99_116_105_111_110_115_95_95_91_49_93_95_48_2_0,3,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__edt_node_io_actions__[1]_0'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_105_111_95_97_99_116_105_111_110_115_95_95_91_49_93_95_48_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_105_111_95_97_99_116_105_111_110_115_95_95_91_49_93_95_48_2_0_i3);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_proceed();
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_105_111_95_97_99_116_105_111_110_115_95_95_91_49_93_95_48_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_105_111_95_97_99_116_105_111_110_115_95_95_91_49_93_95_48_2_0_i4);
	}
	MR_r1 = (MR_Word) MR_tbmkword(0, 0);
	MR_proceed();
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_100_116_95_110_111_100_101_95_105_111_95_97_99_116_105_111_110_115_95_95_91_49_93_95_48_2_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_tfield(0, MR_r1, 2), 1);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

extern const MR_TypeCtorInfo_Struct mercury_data_io__type_ctor_info_state_0;
MR_decl_entry(list__foldl_4_10);

MR_BEGIN_MODULE(mdb__declarative_user_module63)
	MR_init_entry1(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0);
	MR_init_label10(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0,5,8,3,12,13,14,15,16,11,36)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__write_decl_question__[1]_0'/4 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0_i3);
	}
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_tag_alloc_heap(MR_r4, 0, (MR_Integer) 1);
	MR_tfield(0, MR_r4, 0) = MR_tfield(1, MR_r1, 1);
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_tfield(1, MR_r1, 2);
	MR_r1 = MR_r2;
	MR_r2 = (MR_Word) MR_string_const("Call ", 5);
	MR_r3 = (MR_Integer) 0;
	MR_np_call_localret_ent(mdb__declarative_user__write_decl_atom_6_0,
		f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0_i5);
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_sv(2),0,0)) {
		MR_GOTO_LAB(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0_i36);
	}
	MR_r1 = MR_tfield(0, MR_sv(1), 1);
	MR_r2 = (MR_Word) MR_string_const("Solutions:\n", 11);
	MR_np_call_localret_ent(io__write_string_4_0,
		f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0_i8);
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 0, (MR_Integer) 6);
	MR_r3 = MR_tempr1;
	MR_tfield(0, MR_tempr1, 0) = (MR_Word) MR_COMMON(13,1);
	MR_tfield(0, MR_tempr1, 1) = (MR_Word) MR_ENTRY_AP(mdb__declarative_user__write_decl_final_atom_6_0);
	MR_tfield(0, MR_tempr1, 2) = (MR_Integer) 3;
	MR_tfield(0, MR_tempr1, 3) = MR_sv(1);
	MR_tfield(0, MR_tempr1, 4) = (MR_Word) MR_string_const("\t", 1);
	MR_tfield(0, MR_tempr1, 5) = (MR_Integer) 2;
	MR_r1 = (MR_Word) MR_CTOR0_ADDR(mdb__declarative_debugger, final_decl_atom);
	MR_r2 = (MR_Word) MR_IO_CTOR_ADDR;
	MR_r4 = MR_sv(2);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(list__foldl_4_10);
	}
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,2)) {
		MR_GOTO_LAB(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0_i11);
	}
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r2;
	MR_sv(2) = MR_tfield(2, MR_r1, 2);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = (MR_Word) MR_string_const("Call ", 5);
	MR_r3 = (MR_Integer) 0;
	MR_r4 = MR_tfield(2, MR_tempr1, 1);
	}
	MR_np_call_localret_ent(mdb__declarative_user__write_decl_init_atom_6_0,
		f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0_i12);
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_sv(1), 1);
	MR_r2 = (MR_Word) MR_string_const("Throws ", 7);
	MR_np_call_localret_ent(io__write_string_4_0,
		f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0_i13);
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_np_call_localret_ent(mdb__term_rep__rep_to_univ_2_0,
		f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0_i14);
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_tfield(0, MR_sv(1), 1);
	MR_np_call_localret_ent(fn__univ__univ_value_1_0,
		f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0_i15);
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_sv(2);
	MR_r3 = (MR_Integer) 2;
	MR_r4 = MR_tempr1;
	}
	MR_np_call_localret_ent(io__write_5_2,
		f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0_i16);
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_sv(1), 1);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(io__nl_3_0);
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = (MR_Word) MR_string_const("", 0);
	MR_r3 = (MR_Integer) 0;
	MR_r4 = MR_tfield(0, MR_tempr1, 2);
	MR_np_tailcall_ent(mdb__declarative_user__write_decl_final_atom_6_0);
	}
MR_def_label(f_109_100_98_95_95_100_101_99_108_97_114_97_116_105_118_101_95_117_115_101_114_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_119_114_105_116_101_95_100_101_99_108_95_113_117_101_115_116_105_111_110_95_95_91_49_93_95_48_4_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(3);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

static void mercury__mdb__declarative_user_maybe_bunch_0(void)
{
	mdb__declarative_user_module0();
	mdb__declarative_user_module1();
	mdb__declarative_user_module2();
	mdb__declarative_user_module3();
	mdb__declarative_user_module4();
	mdb__declarative_user_module5();
	mdb__declarative_user_module6();
	mdb__declarative_user_module7();
	mdb__declarative_user_module8();
	mdb__declarative_user_module9();
	mdb__declarative_user_module10();
	mdb__declarative_user_module11();
	mdb__declarative_user_module12();
	mdb__declarative_user_module13();
	mdb__declarative_user_module14();
	mdb__declarative_user_module15();
	mdb__declarative_user_module16();
	mdb__declarative_user_module17();
	mdb__declarative_user_module18();
	mdb__declarative_user_module19();
	mdb__declarative_user_module20();
	mdb__declarative_user_module21();
	mdb__declarative_user_module22();
	mdb__declarative_user_module23();
	mdb__declarative_user_module24();
	mdb__declarative_user_module25();
	mdb__declarative_user_module26();
	mdb__declarative_user_module27();
	mdb__declarative_user_module28();
	mdb__declarative_user_module29();
	mdb__declarative_user_module30();
	mdb__declarative_user_module31();
	mdb__declarative_user_module32();
	mdb__declarative_user_module33();
	mdb__declarative_user_module34();
	mdb__declarative_user_module35();
	mdb__declarative_user_module36();
	mdb__declarative_user_module37();
	mdb__declarative_user_module38();
	mdb__declarative_user_module39();
}

static void mercury__mdb__declarative_user_maybe_bunch_1(void)
{
	mdb__declarative_user_module40();
	mdb__declarative_user_module41();
	mdb__declarative_user_module42();
	mdb__declarative_user_module43();
	mdb__declarative_user_module44();
	mdb__declarative_user_module45();
	mdb__declarative_user_module46();
	mdb__declarative_user_module47();
	mdb__declarative_user_module48();
	mdb__declarative_user_module49();
	mdb__declarative_user_module50();
	mdb__declarative_user_module51();
	mdb__declarative_user_module52();
	mdb__declarative_user_module53();
	mdb__declarative_user_module54();
	mdb__declarative_user_module55();
	mdb__declarative_user_module56();
	mdb__declarative_user_module57();
	mdb__declarative_user_module58();
	mdb__declarative_user_module59();
	mdb__declarative_user_module60();
	mdb__declarative_user_module61();
	mdb__declarative_user_module62();
	mdb__declarative_user_module63();
}

/* suppress gcc -Wmissing-decls warnings */
void mercury__mdb__declarative_user__init(void);
void mercury__mdb__declarative_user__init_type_tables(void);
void mercury__mdb__declarative_user__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__mdb__declarative_user__write_out_proc_statics(FILE *deep_fp, FILE *procrep_fp);
#endif
#ifdef MR_RECORD_TERM_SIZES
void mercury__mdb__declarative_user__init_complexity_procs(void);
#endif

void mercury__mdb__declarative_user__init(void)
{
	static MR_bool done = MR_FALSE;
	if (done) {
		return;
	}
	done = MR_TRUE;
	mercury__mdb__declarative_user_maybe_bunch_0();
	mercury__mdb__declarative_user_maybe_bunch_1();
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_mdb__declarative_user__type_ctor_info_user_command_0,
		mdb__declarative_user__user_command_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_mdb__declarative_user__type_ctor_info_user_question_1,
		mdb__declarative_user__user_question_1_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_mdb__declarative_user__type_ctor_info_user_response_1,
		mdb__declarative_user__user_response_1_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_mdb__declarative_user__type_ctor_info_user_search_mode_0,
		mdb__declarative_user__user_search_mode_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_mdb__declarative_user__type_ctor_info_user_state_0,
		mdb__declarative_user__user_state_0_0);
	mercury__mdb__declarative_user__init_debugger();
}

void mercury__mdb__declarative_user__init_type_tables(void)
{
	static MR_bool done = MR_FALSE;
	if (done) {
		return;
	}
	done = MR_TRUE;
	{
		MR_register_type_ctor_info(
		&mercury_data_mdb__declarative_user__type_ctor_info_user_command_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_mdb__declarative_user__type_ctor_info_user_question_1);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_mdb__declarative_user__type_ctor_info_user_response_1);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_mdb__declarative_user__type_ctor_info_user_search_mode_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_mdb__declarative_user__type_ctor_info_user_state_0);
	}
}


void mercury__mdb__declarative_user__init_debugger(void)
{
	static MR_bool done = MR_FALSE;
	if (done) {
		return;
	}
	done = MR_TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__mdb__declarative_user__write_out_proc_statics(FILE *deep_fp, FILE *procrep_fp)
{
	MR_write_out_module_proc_reps_start(procrep_fp, &mercury_data__module_common_layout__mdb__declarative_user);
	MR_write_out_module_proc_reps_end(procrep_fp);
}

#endif

#ifdef MR_RECORD_TERM_SIZES

void mercury__mdb__declarative_user__init_complexity_procs(void)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
