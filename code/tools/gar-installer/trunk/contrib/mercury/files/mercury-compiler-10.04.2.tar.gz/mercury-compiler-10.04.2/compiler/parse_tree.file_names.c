/*
** Automatically generated from `file_names.m'
** by the Mercury compiler,
** version 10.04.2, configured for x86_64-unknown-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
** HIGHLEVEL_CODE=no
**
** END_OF_C_GRADE_INFO
*/

/*
INIT mercury__parse_tree__file_names__init
ENDINIT
*/

#define MR_ALLOW_RESET
#include "mercury_imp.h"
#line 539 "../library/io.int"
#include "io.mh"

#line 28 "parse_tree.file_names.c"
#line 547 "../library/io.int"
#include "string.mh"

#line 32 "parse_tree.file_names.c"
#line 56 "../library/dir.int"
#include "dir.mh"

#line 36 "parse_tree.file_names.c"
#line 29 "../library/bitmap.int2"
#include "bitmap.mh"

#line 40 "parse_tree.file_names.c"
#line 28 "../library/time.int2"
#include "time.mh"

#line 44 "parse_tree.file_names.c"
#line 31 "../library/array.int2"
#include "array.mh"

#line 48 "parse_tree.file_names.c"
#line 33 "../mdbcomp/mdbcomp.rtti_access.int2"
#include "mdbcomp.rtti_access.mh"

#line 52 "parse_tree.file_names.c"
#line 53 "parse_tree.file_names.c"
#include "parse_tree.file_names.mh"

#line 56 "parse_tree.file_names.c"
#line 57 "parse_tree.file_names.c"
#ifndef PARSE_TREE__FILE_NAMES_DECL_GUARD
#define PARSE_TREE__FILE_NAMES_DECL_GUARD

#line 61 "parse_tree.file_names.c"
#line 62 "parse_tree.file_names.c"

#endif
#line 65 "parse_tree.file_names.c"

#ifdef _MSC_VER
#define MR_STATIC_LINKAGE extern
#else
#define MR_STATIC_LINKAGE static
#endif

struct mercury_type_0 {
	MR_String f1;
	MR_Word * f2;
};
MR_STATIC_LINKAGE const struct mercury_type_0 mercury_common_0[];

extern const MR_TypeCtorInfo_Struct
	mercury_data_parse_tree__file_names__type_ctor_info_maybe_create_dirs_0,
	mercury_data_parse_tree__file_names__type_ctor_info_maybe_search_0;
MR_decl_label10(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0, 2,3,4,5,9,10,11,6,15,16)
MR_decl_label10(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0, 20,25,26,27,28,22,30,31,17,18)
MR_decl_label10(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0, 36,40,45,46,44,49,13,56,54,61)
MR_decl_label10(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0, 62,63,64,65,66,67,68,69,70,71)
MR_decl_label10(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0, 72,73,74,75,76,77,78,79,80,81)
MR_decl_label10(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0, 82,83,84,85,86,87,88,89,90,91)
MR_decl_label10(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0, 92,93,94,95,96,97,59,100,99,102)
MR_decl_label10(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0, 51,106,105,104,111,112,113,114,115,116)
MR_decl_label10(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0, 117,118,119,110,109,123,122,128,130,127)
MR_decl_label10(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0, 134,140,139,138,143,145,142,147,153,162)
MR_decl_label1(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0, 166)
MR_decl_label1(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_120_116_114_97_95_108_105_110_107_95_111_98_106_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_8_0, 2)
MR_decl_label1(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_97_99_116_95_116_97_98_108_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_8_0, 2)
MR_decl_label10(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0, 238,5,6,7,8,9,10,11,12,13)
MR_decl_label10(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0, 14,15,16,17,18,19,20,21,22,23)
MR_decl_label10(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0, 24,25,26,27,28,29,30,31,32,33)
MR_decl_label10(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0, 34,35,36,37,38,39,40,3,43,106)
MR_decl_label10(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0, 42,52,54,55,58,60,57,65,63,56)
MR_decl_label9(parse_tree__file_names__get_class_dir_name_2_0, 2,3,6,7,8,9,10,4,12)
MR_decl_label10(parse_tree__file_names__make_file_name_9_0, 2,3,7,12,13,14,15,9,17,18)
MR_decl_label9(parse_tree__file_names__make_file_name_9_0, 4,5,23,27,32,33,31,36,28)
MR_decl_label7(parse_tree__file_names__mercury_std_library_module_name_1_0, 6,7,9,35,20,3,1)
MR_decl_label10(parse_tree__file_names__module_name_to_file_name_7_0, 90,9,8,11,7,14,15,5,21,20)
MR_decl_label10(parse_tree__file_names__module_name_to_file_name_7_0, 24,23,26,19,30,32,28,34,17,37)
MR_decl_label1(parse_tree__file_names__module_name_to_file_name_7_0, 38)
MR_decl_label3(parse_tree__file_names__module_name_to_lib_file_name_8_0, 2,3,4)
MR_decl_label10(parse_tree__file_names__module_name_to_search_file_name_6_0, 90,9,8,11,7,14,15,5,21,20)
MR_decl_label10(parse_tree__file_names__module_name_to_search_file_name_6_0, 24,23,26,19,30,32,28,34,17,37)
MR_decl_label1(parse_tree__file_names__module_name_to_search_file_name_6_0, 38)
MR_decl_label2(fn__parse_tree__file_names__qualify_mercury_std_library_module_name_1_0, 4,2)
MR_def_extern_entry(parse_tree__file_names__module_name_to_file_name_stem_2_0)
MR_def_extern_entry(parse_tree__file_names__mercury_std_library_module_name_1_0)
MR_def_extern_entry(fn__parse_tree__file_names__qualify_mercury_std_library_module_name_1_0)
MR_decl_static(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0)
MR_decl_static(parse_tree__file_names__make_file_name_9_0)
MR_def_extern_entry(parse_tree__file_names__module_name_to_file_name_7_0)
MR_def_extern_entry(parse_tree__file_names__module_name_to_search_file_name_6_0)
MR_def_extern_entry(parse_tree__file_names__module_name_to_lib_file_name_8_0)
MR_def_extern_entry(parse_tree__file_names__extra_link_obj_file_name_8_0)
MR_def_extern_entry(parse_tree__file_names__fact_table_file_name_8_0)
MR_def_extern_entry(parse_tree__file_names__file_name_to_module_name_2_0)
MR_def_extern_entry(parse_tree__file_names__module_name_to_make_var_name_2_0)
MR_def_extern_entry(parse_tree__file_names__get_class_dir_name_2_0)
MR_def_extern_entry(__Unify___parse_tree__file_names__maybe_create_dirs_0_0)
MR_def_extern_entry(__Compare___parse_tree__file_names__maybe_create_dirs_0_0)
MR_def_extern_entry(__Unify___parse_tree__file_names__maybe_search_0_0)
MR_def_extern_entry(__Compare___parse_tree__file_names__maybe_search_0_0)
MR_def_extern_entry(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_97_99_116_95_116_97_98_108_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_8_0)
MR_def_extern_entry(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_120_116_114_97_95_108_105_110_107_95_111_98_106_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_8_0)
MR_decl_static(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0)

static const struct mercury_type_0 mercury_common_0[2] =
{
{
MR_string_const("jmercury", 8),
MR_tbmkword(0, 0)
},
{
MR_string_const("\'", 1),
MR_tbmkword(0, 0)
},
};

static const MR_EnumFunctorDesc mercury_data_parse_tree__file_names__enum_functor_desc_maybe_create_dirs_0_0 = {
	"do_create_dirs",
	0
};

static const MR_EnumFunctorDesc mercury_data_parse_tree__file_names__enum_functor_desc_maybe_create_dirs_0_1 = {
	"do_not_create_dirs",
	1
};

const MR_EnumFunctorDescPtr mercury_data_parse_tree__file_names__enum_value_ordered_maybe_create_dirs_0[] = {
	&mercury_data_parse_tree__file_names__enum_functor_desc_maybe_create_dirs_0_0,
	&mercury_data_parse_tree__file_names__enum_functor_desc_maybe_create_dirs_0_1
};

const MR_EnumFunctorDescPtr mercury_data_parse_tree__file_names__enum_name_ordered_maybe_create_dirs_0[] = {
	&mercury_data_parse_tree__file_names__enum_functor_desc_maybe_create_dirs_0_0,
	&mercury_data_parse_tree__file_names__enum_functor_desc_maybe_create_dirs_0_1
};

const MR_Integer mercury_data_parse_tree__file_names__functor_number_map_maybe_create_dirs_0[] = {
	0,
	1 };
	
const MR_TypeCtorInfo_Struct mercury_data_parse_tree__file_names__type_ctor_info_maybe_create_dirs_0 = {
	0,
	13,
	-1,
	MR_TYPECTOR_REP_ENUM,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___parse_tree__file_names__maybe_create_dirs_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___parse_tree__file_names__maybe_create_dirs_0_0)),
	"parse_tree.file_names",
	"maybe_create_dirs",
	{ (void *)mercury_data_parse_tree__file_names__enum_name_ordered_maybe_create_dirs_0 },
	{ (void *)mercury_data_parse_tree__file_names__enum_value_ordered_maybe_create_dirs_0 },
	2,
	4,
	mercury_data_parse_tree__file_names__functor_number_map_maybe_create_dirs_0
};

static const MR_EnumFunctorDesc mercury_data_parse_tree__file_names__enum_functor_desc_maybe_search_0_0 = {
	"do_search",
	0
};

static const MR_EnumFunctorDesc mercury_data_parse_tree__file_names__enum_functor_desc_maybe_search_0_1 = {
	"do_not_search",
	1
};

const MR_EnumFunctorDescPtr mercury_data_parse_tree__file_names__enum_value_ordered_maybe_search_0[] = {
	&mercury_data_parse_tree__file_names__enum_functor_desc_maybe_search_0_0,
	&mercury_data_parse_tree__file_names__enum_functor_desc_maybe_search_0_1
};

const MR_EnumFunctorDescPtr mercury_data_parse_tree__file_names__enum_name_ordered_maybe_search_0[] = {
	&mercury_data_parse_tree__file_names__enum_functor_desc_maybe_search_0_1,
	&mercury_data_parse_tree__file_names__enum_functor_desc_maybe_search_0_0
};

const MR_Integer mercury_data_parse_tree__file_names__functor_number_map_maybe_search_0[] = {
	1,
	0 };
	
const MR_TypeCtorInfo_Struct mercury_data_parse_tree__file_names__type_ctor_info_maybe_search_0 = {
	0,
	13,
	-1,
	MR_TYPECTOR_REP_ENUM,
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Unify___parse_tree__file_names__maybe_search_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY_AP(__Compare___parse_tree__file_names__maybe_search_0_0)),
	"parse_tree.file_names",
	"maybe_search",
	{ (void *)mercury_data_parse_tree__file_names__enum_name_ordered_maybe_search_0 },
	{ (void *)mercury_data_parse_tree__file_names__enum_value_ordered_maybe_search_0 },
	2,
	4,
	mercury_data_parse_tree__file_names__functor_number_map_maybe_search_0
};



MR_decl_entry(fn__mdbcomp__prim_data__sym_name_to_string_1_0);

MR_BEGIN_MODULE(parse_tree__file_names_module0)
	MR_init_entry1(parse_tree__file_names__module_name_to_file_name_stem_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__parse_tree__file_names__module_name_to_file_name_stem_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'module_name_to_file_name_stem'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__parse_tree__file_names__module_name_to_file_name_stem_2_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(fn__mdbcomp__prim_data__sym_name_to_string_1_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(library__mercury_std_library_module_1_0);
MR_decl_entry(mdbcomp__prim_data__strip_outermost_qualifier_3_0);

MR_BEGIN_MODULE(parse_tree__file_names_module1)
	MR_init_entry1(parse_tree__file_names__mercury_std_library_module_name_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__parse_tree__file_names__mercury_std_library_module_name_1_0);
	MR_init_label7(parse_tree__file_names__mercury_std_library_module_name_1_0,6,7,9,35,20,3,1)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'mercury_std_library_module_name'/1 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__parse_tree__file_names__mercury_std_library_module_name_1_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_PTAG_TESTR(MR_r1,1)) {
		MR_GOTO_LAB(parse_tree__file_names__mercury_std_library_module_name_1_0_i3);
	}
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_np_call_localret_ent(fn__mdbcomp__prim_data__sym_name_to_string_1_0,
		parse_tree__file_names__mercury_std_library_module_name_1_0_i6);
MR_def_label(parse_tree__file_names__mercury_std_library_module_name_1_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(library__mercury_std_library_module_1_0,
		parse_tree__file_names__mercury_std_library_module_name_1_0_i7);
MR_def_label(parse_tree__file_names__mercury_std_library_module_name_1_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO_LAB(parse_tree__file_names__mercury_std_library_module_name_1_0_i20);
	}
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(mdbcomp__prim_data__strip_outermost_qualifier_3_0,
		parse_tree__file_names__mercury_std_library_module_name_1_0_i9);
MR_def_label(parse_tree__file_names__mercury_std_library_module_name_1_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(parse_tree__file_names__mercury_std_library_module_name_1_0_i1);
	}
	if ((strcmp(MR_string_const("mercury", 7), (char *) (MR_Word *) MR_r2) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__mercury_std_library_module_name_1_0_i1);
	}
	MR_r1 = MR_r3;
	MR_np_call_localret_ent(fn__mdbcomp__prim_data__sym_name_to_string_1_0,
		parse_tree__file_names__mercury_std_library_module_name_1_0_i35);
MR_def_label(parse_tree__file_names__mercury_std_library_module_name_1_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(library__mercury_std_library_module_1_0);
MR_def_label(parse_tree__file_names__mercury_std_library_module_name_1_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(2);
MR_def_label(parse_tree__file_names__mercury_std_library_module_name_1_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_tfield(0, MR_r1, 0);
	MR_np_tailcall_ent(library__mercury_std_library_module_1_0);
MR_def_label(parse_tree__file_names__mercury_std_library_module_name_1_0,1)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_FALSE;
	MR_decr_sp_and_return(2);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__mdbcomp__prim_data__add_outermost_qualifier_2_0);

MR_BEGIN_MODULE(parse_tree__file_names_module2)
	MR_init_entry1(fn__parse_tree__file_names__qualify_mercury_std_library_module_name_1_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__fn__parse_tree__file_names__qualify_mercury_std_library_module_name_1_0);
	MR_init_label2(fn__parse_tree__file_names__qualify_mercury_std_library_module_name_1_0,4,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'qualify_mercury_std_library_module_name'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__fn__parse_tree__file_names__qualify_mercury_std_library_module_name_1_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(2);
	MR_sv(2) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_np_call_localret_ent(parse_tree__file_names__mercury_std_library_module_name_1_0,
		fn__parse_tree__file_names__qualify_mercury_std_library_module_name_1_0_i4);
MR_def_label(fn__parse_tree__file_names__qualify_mercury_std_library_module_name_1_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(fn__parse_tree__file_names__qualify_mercury_std_library_module_name_1_0_i2);
	}
	MR_r1 = (MR_Word) MR_string_const("mercury", 7);
	MR_r2 = MR_sv(1);
	MR_succip_word = MR_sv(2);
	MR_decr_sp(2);
	MR_np_tailcall_ent(fn__mdbcomp__prim_data__add_outermost_qualifier_2_0);
MR_def_label(fn__parse_tree__file_names__qualify_mercury_std_library_module_name_1_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_decr_sp_and_return(2);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(string__remove_suffix_3_0);
MR_decl_entry(libs__globals__lookup_string_option_3_0);
MR_decl_entry(fn__f_115_116_114_105_110_103_95_95_43_43_2_0);
MR_declare_entry(MR_do_redo);

MR_BEGIN_MODULE(parse_tree__file_names_module3)
	MR_init_entry1(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__parse_tree__file_names__file_is_arch_or_grade_dependent_2_0);
	MR_init_label10(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,238,5,6,7,8,9,10,11,12,13)
	MR_init_label10(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,14,15,16,17,18,19,20,21,22,23)
	MR_init_label10(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,24,25,26,27,28,29,30,31,32,33)
	MR_init_label10(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,34,35,36,37,38,39,40,3,43,106)
	MR_init_label10(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,42,52,54,55,58,60,57,65,63,56)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'file_is_arch_or_grade_dependent'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(8);
	MR_sv(8) = (MR_Word) MR_succip;
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,238)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".a", 2)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i5);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".c", 2)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i6);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".s", 2)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i7);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".\044A", 3)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i8);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".il", 3)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i9);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".dir", 4)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i10);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".dll", 4)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i11);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".erl", 4)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i12);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".hrl", 4)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i13);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".mih", 4)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i14);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".opt", 4)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i15);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".beam", 5)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i16);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".imdg", 5)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i17);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".init", 5)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i18);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".java", 5)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i19);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".used", 5)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i20);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".beams", 6)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i21);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".class", 6)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i22);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".pic_s", 6)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i23);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".c_date", 7)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i24);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".s_date", 7)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i25);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const("_init.c", 7)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i26);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".il_date", 8)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i27);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".optdate", 8)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i28);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".request", 8)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i29);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,29)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const("_init.\044O", 8)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i30);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".analysis", 9)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i31);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".erl_date", 9)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i32);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const("_init.erl", 9)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i33);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".java_date", 10)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i34);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".trans_opt", 10)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i35);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,35)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const("_init.beam", 10)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i36);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".pic_s_date", 11)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i37);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,37)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".track_flags", 12)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i38);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,38)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".analysis_date", 14)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i39);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,39)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".trans_opt_date", 15)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i40);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r2, MR_string_const(".analysis_status", 16)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i3);
	}
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_r1 = MR_r2;
	MR_r2 = (MR_Word) MR_string_const(".tmp", 4);
	MR_np_call_localret_ent(string__remove_suffix_3_0,
		parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i43);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,43)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i42);
	}
	MR_r1 = MR_sv(1);
	MR_succip_word = MR_sv(8);
	MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i238);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,106)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,42)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Integer) 535;
	MR_np_call_localret_ent(libs__globals__lookup_string_option_3_0,
		parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i52);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,52)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(2), (char *) (MR_Word *) MR_r1) == 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i106);
	}
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Integer) 534;
	MR_np_call_localret_ent(libs__globals__lookup_string_option_3_0,
		parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i54);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,54)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(2), (char *) (MR_Word *) MR_r1) == 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i106);
	}
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Integer) 533;
	MR_np_call_localret_ent(libs__globals__lookup_string_option_3_0,
		parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i55);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,55)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(2), (char *) (MR_Word *) MR_r1) == 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i106);
	}
	MR_sv(3) = (MR_Word) MR_redoip_slot(MR_maxfr);
	MR_sv(4) = (MR_Word) MR_redofr_slot(MR_maxfr);
	MR_save_maxfr(MR_sv(5));
	MR_redofr_slot_word(MR_maxfr) = (MR_Word) MR_curfr;
	MR_redoip_slot_word(MR_maxfr) = (MR_Word) MR_LABEL_AP(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i56);
	MR_sv(6) = (MR_Word) MR_redoip_slot(MR_maxfr);
	MR_sv(7) = (MR_Word) MR_redofr_slot(MR_maxfr);
	MR_redofr_slot_word(MR_maxfr) = (MR_Word) MR_curfr;
	MR_redoip_slot_word(MR_maxfr) = (MR_Word) MR_LABEL_AP(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i58);
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Integer) 475;
	MR_np_call_localret_ent(libs__globals__lookup_string_option_3_0,
		parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i57);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,58)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_redoip_slot_word(MR_maxfr) = (MR_Word) MR_LABEL_AP(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i60);
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Integer) 476;
	MR_np_call_localret_ent(libs__globals__lookup_string_option_3_0,
		parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i57);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,60)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_redoip_slot_word(MR_maxfr) = MR_sv(6);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(7);
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Integer) 477;
	MR_np_call_localret_ent(libs__globals__lookup_string_option_3_0,
		parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i57);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,57)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(2), (char *) (MR_Word *) MR_r1) == 0)) {
		MR_GOTO_LAB(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i63);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("_init", 5);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		parse_tree__file_names__file_is_arch_or_grade_dependent_2_0_i65);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,65)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(2), (char *) (MR_Word *) MR_r1) != 0)) {
		MR_GOTO(MR_ENTRY(MR_do_redo));
	}
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,63)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_restore_maxfr(MR_sv(5));
	MR_redoip_slot_word(MR_maxfr) = MR_sv(3);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(4);
	MR_r1 = MR_TRUE;
	MR_decr_sp_and_return(8);
MR_def_label(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,56)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_redoip_slot_word(MR_maxfr) = MR_sv(3);
	MR_redofr_slot_word(MR_maxfr) = MR_sv(4);
	MR_r1 = MR_FALSE;
	MR_decr_sp_and_return(8);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(libs__globals__lookup_bool_option_3_0);
MR_decl_entry(libs__handle_options__grade_directory_component_2_0);
MR_decl_entry(fn__dir__relative_path_name_from_components_1_0);
MR_decl_entry(dir__make_directory_4_0);
extern const MR_TypeCtorInfo_Struct mercury_data_builtin__type_ctor_info_string_0;
MR_decl_entry(fn__f_108_105_115_116_95_95_43_43_2_0);

MR_BEGIN_MODULE(parse_tree__file_names_module4)
	MR_init_entry1(parse_tree__file_names__make_file_name_9_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__parse_tree__file_names__make_file_name_9_0);
	MR_init_label10(parse_tree__file_names__make_file_name_9_0,2,3,7,12,13,14,15,9,17,18)
	MR_init_label9(parse_tree__file_names__make_file_name_9_0,4,5,23,27,32,33,31,36,28)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'make_file_name'/9 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(parse_tree__file_names__make_file_name_9_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(8);
	MR_sv(8) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_sv(4) = MR_r4;
	MR_sv(5) = MR_r5;
	MR_sv(6) = MR_r6;
	MR_r2 = (MR_Integer) 599;
	MR_np_call_localret_ent(libs__globals__lookup_bool_option_3_0,
		parse_tree__file_names__make_file_name_9_0_i2);
MR_def_label(parse_tree__file_names__make_file_name_9_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Integer) 598;
	MR_np_call_localret_ent(libs__globals__lookup_bool_option_3_0,
		parse_tree__file_names__make_file_name_9_0_i3);
MR_def_label(parse_tree__file_names__make_file_name_9_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(7),1)) {
		MR_GOTO_LAB(parse_tree__file_names__make_file_name_9_0_i5);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(6);
	MR_np_call_localret_ent(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,
		parse_tree__file_names__make_file_name_9_0_i7);
MR_def_label(parse_tree__file_names__make_file_name_9_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(parse_tree__file_names__make_file_name_9_0_i4);
	}
	if (MR_INT_NE(MR_sv(3),0)) {
		MR_GOTO_LAB(parse_tree__file_names__make_file_name_9_0_i9);
	}
	if ((strcmp((char *) (MR_Word *) MR_sv(6), MR_string_const(".opt", 4)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__make_file_name_9_0_i12);
	}
	MR_r1 = MR_sv(1);
	MR_GOTO_LAB(parse_tree__file_names__make_file_name_9_0_i4);
MR_def_label(parse_tree__file_names__make_file_name_9_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(6), MR_string_const(".imdg", 5)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__make_file_name_9_0_i13);
	}
	MR_r1 = MR_sv(1);
	MR_GOTO_LAB(parse_tree__file_names__make_file_name_9_0_i4);
MR_def_label(parse_tree__file_names__make_file_name_9_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(6), MR_string_const(".request", 8)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__make_file_name_9_0_i14);
	}
	MR_r1 = MR_sv(1);
	MR_GOTO_LAB(parse_tree__file_names__make_file_name_9_0_i4);
MR_def_label(parse_tree__file_names__make_file_name_9_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(6), MR_string_const(".analysis", 9)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__make_file_name_9_0_i15);
	}
	MR_r1 = MR_sv(1);
	MR_GOTO_LAB(parse_tree__file_names__make_file_name_9_0_i4);
MR_def_label(parse_tree__file_names__make_file_name_9_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(6), MR_string_const(".trans_opt", 10)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__make_file_name_9_0_i9);
	}
	MR_r1 = MR_sv(1);
	MR_GOTO_LAB(parse_tree__file_names__make_file_name_9_0_i4);
MR_def_label(parse_tree__file_names__make_file_name_9_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(libs__handle_options__grade_directory_component_2_0,
		parse_tree__file_names__make_file_name_9_0_i17);
MR_def_label(parse_tree__file_names__make_file_name_9_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Integer) 613;
	}
	MR_np_call_localret_ent(libs__globals__lookup_string_option_3_0,
		parse_tree__file_names__make_file_name_9_0_i18);
MR_def_label(parse_tree__file_names__make_file_name_9_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_r3 = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = (MR_Word) MR_string_const("Mercury", 7);
	MR_tfield(1, MR_tempr1, 1) = MR_sv(2);
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_r4 = MR_tempr2;
	MR_tfield(1, MR_tempr2, 0) = MR_r1;
	MR_tfield(1, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 2);
	MR_r3 = MR_tempr3;
	MR_tfield(1, MR_tempr3, 0) = MR_sv(1);
	MR_tfield(1, MR_tempr3, 1) = MR_tempr2;
	MR_tag_alloc_heap(MR_tempr4, 1, (MR_Integer) 2);
	MR_sv(1) = MR_tempr4;
	MR_tfield(1, MR_tempr4, 0) = (MR_Word) MR_string_const("Mercury", 7);
	MR_tfield(1, MR_tempr4, 1) = MR_tempr3;
	MR_r1 = MR_sv(5);
	MR_GOTO_LAB(parse_tree__file_names__make_file_name_9_0_i27);
	}
MR_def_label(parse_tree__file_names__make_file_name_9_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(7);
MR_def_label(parse_tree__file_names__make_file_name_9_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,1)) {
		MR_GOTO_LAB(parse_tree__file_names__make_file_name_9_0_i23);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_sv(1) = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = (MR_Word) MR_string_const("Mercury", 7);
	MR_tfield(1, MR_tempr1, 1) = MR_sv(2);
	MR_r1 = MR_sv(5);
	MR_GOTO_LAB(parse_tree__file_names__make_file_name_9_0_i27);
	}
MR_def_label(parse_tree__file_names__make_file_name_9_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(5);
	MR_sv(1) = MR_sv(2);
MR_def_label(parse_tree__file_names__make_file_name_9_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_sv(1),0,0)) {
		MR_GOTO_LAB(parse_tree__file_names__make_file_name_9_0_i28);
	}
	if (MR_INT_NE(MR_sv(4),0)) {
		MR_GOTO_LAB(parse_tree__file_names__make_file_name_9_0_i31);
	}
	MR_sv(5) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(fn__dir__relative_path_name_from_components_1_0,
		parse_tree__file_names__make_file_name_9_0_i32);
MR_def_label(parse_tree__file_names__make_file_name_9_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(dir__make_directory_4_0,
		parse_tree__file_names__make_file_name_9_0_i33);
MR_def_label(parse_tree__file_names__make_file_name_9_0,33)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_r3 = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = MR_sv(5);
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_r2 = MR_sv(1);
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	}
	MR_np_call_localret_ent(fn__f_108_105_115_116_95_95_43_43_2_0,
		parse_tree__file_names__make_file_name_9_0_i36);
MR_def_label(parse_tree__file_names__make_file_name_9_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_r3 = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = MR_r1;
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_r2 = MR_sv(1);
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	}
	MR_np_call_localret_ent(fn__f_108_105_115_116_95_95_43_43_2_0,
		parse_tree__file_names__make_file_name_9_0_i36);
MR_def_label(parse_tree__file_names__make_file_name_9_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(8);
	MR_decr_sp(8);
	MR_np_tailcall_ent(fn__dir__relative_path_name_from_components_1_0);
MR_def_label(parse_tree__file_names__make_file_name_9_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(8);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(parse_tree__source_file_map__lookup_module_source_file_4_0);
MR_decl_entry(string__suffix_2_0);
MR_decl_entry(parse_tree__java_names__mangle_sym_name_for_java_4_0);
MR_decl_entry(fn__mdbcomp__prim_data__sym_name_to_string_sep_2_0);

MR_BEGIN_MODULE(parse_tree__file_names_module5)
	MR_init_entry1(parse_tree__file_names__module_name_to_file_name_7_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__parse_tree__file_names__module_name_to_file_name_7_0);
	MR_init_label10(parse_tree__file_names__module_name_to_file_name_7_0,90,9,8,11,7,14,15,5,21,20)
	MR_init_label10(parse_tree__file_names__module_name_to_file_name_7_0,24,23,26,19,30,32,28,34,17,37)
	MR_init_label1(parse_tree__file_names__module_name_to_file_name_7_0,38)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'module_name_to_file_name'/7 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__parse_tree__file_names__module_name_to_file_name_7_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r3, MR_string_const(".m", 2)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__module_name_to_file_name_7_0_i90);
	}
	MR_r1 = MR_r2;
	MR_np_tailcall_ent(parse_tree__source_file_map__lookup_module_source_file_4_0);
MR_def_label(parse_tree__file_names__module_name_to_file_name_7_0,90)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_sv(3) = MR_tempr1;
	MR_sv(4) = MR_r4;
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Word) MR_string_const(".java", 5);
	}
	MR_np_call_localret_ent(string__suffix_2_0,
		parse_tree__file_names__module_name_to_file_name_7_0_i9);
MR_def_label(parse_tree__file_names__module_name_to_file_name_7_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(parse_tree__file_names__module_name_to_file_name_7_0_i8);
	}
	MR_r1 = MR_sv(2);
	MR_GOTO_LAB(parse_tree__file_names__module_name_to_file_name_7_0_i7);
MR_def_label(parse_tree__file_names__module_name_to_file_name_7_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_string_const(".class", 6);
	MR_np_call_localret_ent(string__suffix_2_0,
		parse_tree__file_names__module_name_to_file_name_7_0_i11);
MR_def_label(parse_tree__file_names__module_name_to_file_name_7_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(parse_tree__file_names__module_name_to_file_name_7_0_i5);
	}
	MR_r1 = MR_sv(2);
MR_def_label(parse_tree__file_names__module_name_to_file_name_7_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = (MR_Word) MR_TAG_COMMON(1,0,0);
	MR_r2 = (MR_Integer) 0;
	MR_r3 = (MR_Word) MR_string_const("__", 2);
	MR_np_call_localret_ent(parse_tree__java_names__mangle_sym_name_for_java_4_0,
		parse_tree__file_names__module_name_to_file_name_7_0_i14);
MR_def_label(parse_tree__file_names__module_name_to_file_name_7_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		parse_tree__file_names__module_name_to_file_name_7_0_i15);
MR_def_label(parse_tree__file_names__module_name_to_file_name_7_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(3);
	MR_r5 = (MR_Integer) 1;
	MR_r6 = MR_sv(4);
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0);
	}
MR_def_label(parse_tree__file_names__module_name_to_file_name_7_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_sv(3);
	MR_tempr2 = MR_sv(4);
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Word) MR_string_const(".erl", 4);
	}
	MR_np_call_localret_ent(string__suffix_2_0,
		parse_tree__file_names__module_name_to_file_name_7_0_i21);
MR_def_label(parse_tree__file_names__module_name_to_file_name_7_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(parse_tree__file_names__module_name_to_file_name_7_0_i20);
	}
	MR_r1 = MR_sv(2);
	MR_GOTO_LAB(parse_tree__file_names__module_name_to_file_name_7_0_i19);
MR_def_label(parse_tree__file_names__module_name_to_file_name_7_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_string_const(".hrl", 4);
	MR_np_call_localret_ent(string__suffix_2_0,
		parse_tree__file_names__module_name_to_file_name_7_0_i24);
MR_def_label(parse_tree__file_names__module_name_to_file_name_7_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(parse_tree__file_names__module_name_to_file_name_7_0_i23);
	}
	MR_r1 = MR_sv(2);
	MR_GOTO_LAB(parse_tree__file_names__module_name_to_file_name_7_0_i19);
MR_def_label(parse_tree__file_names__module_name_to_file_name_7_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_string_const(".beam", 5);
	MR_np_call_localret_ent(string__suffix_2_0,
		parse_tree__file_names__module_name_to_file_name_7_0_i26);
MR_def_label(parse_tree__file_names__module_name_to_file_name_7_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(parse_tree__file_names__module_name_to_file_name_7_0_i17);
	}
	MR_r1 = MR_sv(2);
MR_def_label(parse_tree__file_names__module_name_to_file_name_7_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_np_call_localret_ent(parse_tree__file_names__mercury_std_library_module_name_1_0,
		parse_tree__file_names__module_name_to_file_name_7_0_i30);
MR_def_label(parse_tree__file_names__module_name_to_file_name_7_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(parse_tree__file_names__module_name_to_file_name_7_0_i28);
	}
	MR_r1 = (MR_Word) MR_string_const("mercury", 7);
	MR_r2 = MR_sv(2);
	MR_np_call_localret_ent(fn__mdbcomp__prim_data__add_outermost_qualifier_2_0,
		parse_tree__file_names__module_name_to_file_name_7_0_i32);
MR_def_label(parse_tree__file_names__module_name_to_file_name_7_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_string_const("__", 2);
	MR_np_call_localret_ent(fn__mdbcomp__prim_data__sym_name_to_string_sep_2_0,
		parse_tree__file_names__module_name_to_file_name_7_0_i34);
MR_def_label(parse_tree__file_names__module_name_to_file_name_7_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_r2 = (MR_Word) MR_string_const("__", 2);
	MR_np_call_localret_ent(fn__mdbcomp__prim_data__sym_name_to_string_sep_2_0,
		parse_tree__file_names__module_name_to_file_name_7_0_i34);
MR_def_label(parse_tree__file_names__module_name_to_file_name_7_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		parse_tree__file_names__module_name_to_file_name_7_0_i38);
MR_def_label(parse_tree__file_names__module_name_to_file_name_7_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_sv(3);
	MR_tempr2 = MR_sv(4);
	MR_r1 = MR_r2;
	MR_r2 = (MR_Word) MR_string_const(".", 1);
	}
	MR_np_call_localret_ent(fn__mdbcomp__prim_data__sym_name_to_string_sep_2_0,
		parse_tree__file_names__module_name_to_file_name_7_0_i37);
MR_def_label(parse_tree__file_names__module_name_to_file_name_7_0,37)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		parse_tree__file_names__module_name_to_file_name_7_0_i38);
MR_def_label(parse_tree__file_names__module_name_to_file_name_7_0,38)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Word) MR_tbmkword(0, 0);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(3);
	MR_r5 = (MR_Integer) 1;
	MR_r6 = MR_sv(4);
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(parse_tree__file_names_module6)
	MR_init_entry1(parse_tree__file_names__module_name_to_search_file_name_6_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__parse_tree__file_names__module_name_to_search_file_name_6_0);
	MR_init_label10(parse_tree__file_names__module_name_to_search_file_name_6_0,90,9,8,11,7,14,15,5,21,20)
	MR_init_label10(parse_tree__file_names__module_name_to_search_file_name_6_0,24,23,26,19,30,32,28,34,17,37)
	MR_init_label1(parse_tree__file_names__module_name_to_search_file_name_6_0,38)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'module_name_to_search_file_name'/6 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__parse_tree__file_names__module_name_to_search_file_name_6_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_r3, MR_string_const(".m", 2)) != 0)) {
		MR_GOTO_LAB(parse_tree__file_names__module_name_to_search_file_name_6_0_i90);
	}
	MR_r1 = MR_r2;
	MR_np_tailcall_ent(parse_tree__source_file_map__lookup_module_source_file_4_0);
MR_def_label(parse_tree__file_names__module_name_to_search_file_name_6_0,90)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_sv(3) = MR_tempr1;
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Word) MR_string_const(".java", 5);
	}
	MR_np_call_localret_ent(string__suffix_2_0,
		parse_tree__file_names__module_name_to_search_file_name_6_0_i9);
MR_def_label(parse_tree__file_names__module_name_to_search_file_name_6_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(parse_tree__file_names__module_name_to_search_file_name_6_0_i8);
	}
	MR_r1 = MR_sv(2);
	MR_GOTO_LAB(parse_tree__file_names__module_name_to_search_file_name_6_0_i7);
MR_def_label(parse_tree__file_names__module_name_to_search_file_name_6_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_string_const(".class", 6);
	MR_np_call_localret_ent(string__suffix_2_0,
		parse_tree__file_names__module_name_to_search_file_name_6_0_i11);
MR_def_label(parse_tree__file_names__module_name_to_search_file_name_6_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(parse_tree__file_names__module_name_to_search_file_name_6_0_i5);
	}
	MR_r1 = MR_sv(2);
MR_def_label(parse_tree__file_names__module_name_to_search_file_name_6_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = (MR_Word) MR_TAG_COMMON(1,0,0);
	MR_r2 = (MR_Integer) 0;
	MR_r3 = (MR_Word) MR_string_const("__", 2);
	MR_np_call_localret_ent(parse_tree__java_names__mangle_sym_name_for_java_4_0,
		parse_tree__file_names__module_name_to_search_file_name_6_0_i14);
MR_def_label(parse_tree__file_names__module_name_to_search_file_name_6_0,14)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		parse_tree__file_names__module_name_to_search_file_name_6_0_i15);
MR_def_label(parse_tree__file_names__module_name_to_search_file_name_6_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(3);
	MR_r5 = (MR_Integer) 0;
	MR_r6 = (MR_Integer) 1;
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0);
	}
MR_def_label(parse_tree__file_names__module_name_to_search_file_name_6_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(3);
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Word) MR_string_const(".erl", 4);
	}
	MR_np_call_localret_ent(string__suffix_2_0,
		parse_tree__file_names__module_name_to_search_file_name_6_0_i21);
MR_def_label(parse_tree__file_names__module_name_to_search_file_name_6_0,21)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(parse_tree__file_names__module_name_to_search_file_name_6_0_i20);
	}
	MR_r1 = MR_sv(2);
	MR_GOTO_LAB(parse_tree__file_names__module_name_to_search_file_name_6_0_i19);
MR_def_label(parse_tree__file_names__module_name_to_search_file_name_6_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_string_const(".hrl", 4);
	MR_np_call_localret_ent(string__suffix_2_0,
		parse_tree__file_names__module_name_to_search_file_name_6_0_i24);
MR_def_label(parse_tree__file_names__module_name_to_search_file_name_6_0,24)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(parse_tree__file_names__module_name_to_search_file_name_6_0_i23);
	}
	MR_r1 = MR_sv(2);
	MR_GOTO_LAB(parse_tree__file_names__module_name_to_search_file_name_6_0_i19);
MR_def_label(parse_tree__file_names__module_name_to_search_file_name_6_0,23)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_r2 = (MR_Word) MR_string_const(".beam", 5);
	MR_np_call_localret_ent(string__suffix_2_0,
		parse_tree__file_names__module_name_to_search_file_name_6_0_i26);
MR_def_label(parse_tree__file_names__module_name_to_search_file_name_6_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(parse_tree__file_names__module_name_to_search_file_name_6_0_i17);
	}
	MR_r1 = MR_sv(2);
MR_def_label(parse_tree__file_names__module_name_to_search_file_name_6_0,19)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_np_call_localret_ent(parse_tree__file_names__mercury_std_library_module_name_1_0,
		parse_tree__file_names__module_name_to_search_file_name_6_0_i30);
MR_def_label(parse_tree__file_names__module_name_to_search_file_name_6_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(parse_tree__file_names__module_name_to_search_file_name_6_0_i28);
	}
	MR_r1 = (MR_Word) MR_string_const("mercury", 7);
	MR_r2 = MR_sv(2);
	MR_np_call_localret_ent(fn__mdbcomp__prim_data__add_outermost_qualifier_2_0,
		parse_tree__file_names__module_name_to_search_file_name_6_0_i32);
MR_def_label(parse_tree__file_names__module_name_to_search_file_name_6_0,32)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_string_const("__", 2);
	MR_np_call_localret_ent(fn__mdbcomp__prim_data__sym_name_to_string_sep_2_0,
		parse_tree__file_names__module_name_to_search_file_name_6_0_i34);
MR_def_label(parse_tree__file_names__module_name_to_search_file_name_6_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(2);
	MR_r2 = (MR_Word) MR_string_const("__", 2);
	MR_np_call_localret_ent(fn__mdbcomp__prim_data__sym_name_to_string_sep_2_0,
		parse_tree__file_names__module_name_to_search_file_name_6_0_i34);
MR_def_label(parse_tree__file_names__module_name_to_search_file_name_6_0,34)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		parse_tree__file_names__module_name_to_search_file_name_6_0_i38);
MR_def_label(parse_tree__file_names__module_name_to_search_file_name_6_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(2);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(3);
	MR_r1 = MR_r2;
	MR_r2 = (MR_Word) MR_string_const(".", 1);
	}
	MR_np_call_localret_ent(fn__mdbcomp__prim_data__sym_name_to_string_sep_2_0,
		parse_tree__file_names__module_name_to_search_file_name_6_0_i37);
MR_def_label(parse_tree__file_names__module_name_to_search_file_name_6_0,37)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		parse_tree__file_names__module_name_to_search_file_name_6_0_i38);
MR_def_label(parse_tree__file_names__module_name_to_search_file_name_6_0,38)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Word) MR_tbmkword(0, 0);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(3);
	MR_r5 = (MR_Integer) 0;
	MR_r6 = (MR_Integer) 1;
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(parse_tree__file_names_module7)
	MR_init_entry1(parse_tree__file_names__module_name_to_lib_file_name_8_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__parse_tree__file_names__module_name_to_lib_file_name_8_0);
	MR_init_label3(parse_tree__file_names__module_name_to_lib_file_name_8_0,2,3,4)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'module_name_to_lib_file_name'/8 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__parse_tree__file_names__module_name_to_lib_file_name_8_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(5);
	MR_sv(5) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r4;
	MR_sv(4) = MR_r5;
	MR_r1 = MR_r3;
	MR_np_call_localret_ent(fn__mdbcomp__prim_data__sym_name_to_string_1_0,
		parse_tree__file_names__module_name_to_lib_file_name_8_0_i2);
MR_def_label(parse_tree__file_names__module_name_to_lib_file_name_8_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(3);
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		parse_tree__file_names__module_name_to_lib_file_name_8_0_i3);
MR_def_label(parse_tree__file_names__module_name_to_lib_file_name_8_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(2);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		parse_tree__file_names__module_name_to_lib_file_name_8_0_i4);
MR_def_label(parse_tree__file_names__module_name_to_lib_file_name_8_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Word) MR_tbmkword(0, 0);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(3);
	MR_r5 = (MR_Integer) 1;
	MR_r6 = MR_sv(4);
	MR_succip_word = MR_sv(5);
	MR_decr_sp(5);
	MR_np_tailcall_ent(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(parse_tree__file_names_module8)
	MR_init_entry1(parse_tree__file_names__extra_link_obj_file_name_8_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__parse_tree__file_names__extra_link_obj_file_name_8_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'extra_link_obj_file_name'/8 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__parse_tree__file_names__extra_link_obj_file_name_8_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_r3;
	MR_r3 = MR_r4;
	MR_r4 = MR_r5;
	MR_np_tailcall_ent(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_120_116_114_97_95_108_105_110_107_95_111_98_106_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_8_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(parse_tree__file_names_module9)
	MR_init_entry1(parse_tree__file_names__fact_table_file_name_8_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__parse_tree__file_names__fact_table_file_name_8_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'fact_table_file_name'/8 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__parse_tree__file_names__fact_table_file_name_8_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_r3;
	MR_r3 = MR_r4;
	MR_r4 = MR_r5;
	MR_np_tailcall_ent(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_97_99_116_95_116_97_98_108_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_8_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__mdbcomp__prim_data__string_to_sym_name_1_0);

MR_BEGIN_MODULE(parse_tree__file_names_module10)
	MR_init_entry1(parse_tree__file_names__file_name_to_module_name_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__parse_tree__file_names__file_name_to_module_name_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'file_name_to_module_name'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__parse_tree__file_names__file_name_to_module_name_2_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(fn__mdbcomp__prim_data__string_to_sym_name_1_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(parse_tree__file_names_module11)
	MR_init_entry1(parse_tree__file_names__module_name_to_make_var_name_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__parse_tree__file_names__module_name_to_make_var_name_2_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'module_name_to_make_var_name'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__parse_tree__file_names__module_name_to_make_var_name_2_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(fn__mdbcomp__prim_data__sym_name_to_string_1_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(fn__f_100_105_114_95_95_47_2_0);

MR_BEGIN_MODULE(parse_tree__file_names_module12)
	MR_init_entry1(parse_tree__file_names__get_class_dir_name_2_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__parse_tree__file_names__get_class_dir_name_2_0);
	MR_init_label9(parse_tree__file_names__get_class_dir_name_2_0,2,3,6,7,8,9,10,4,12)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'get_class_dir_name'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__parse_tree__file_names__get_class_dir_name_2_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(3);
	MR_sv(3) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_r2 = (MR_Integer) 599;
	MR_np_call_localret_ent(libs__globals__lookup_bool_option_3_0,
		parse_tree__file_names__get_class_dir_name_2_0_i2);
MR_def_label(parse_tree__file_names__get_class_dir_name_2_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(2) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Integer) 598;
	MR_np_call_localret_ent(libs__globals__lookup_bool_option_3_0,
		parse_tree__file_names__get_class_dir_name_2_0_i3);
MR_def_label(parse_tree__file_names__get_class_dir_name_2_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(2),1)) {
		MR_GOTO_LAB(parse_tree__file_names__get_class_dir_name_2_0_i4);
	}
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(libs__handle_options__grade_directory_component_2_0,
		parse_tree__file_names__get_class_dir_name_2_0_i6);
MR_def_label(parse_tree__file_names__get_class_dir_name_2_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Integer) 613;
	}
	MR_np_call_localret_ent(libs__globals__lookup_string_option_3_0,
		parse_tree__file_names__get_class_dir_name_2_0_i7);
MR_def_label(parse_tree__file_names__get_class_dir_name_2_0,7)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("Mercury", 7);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_100_105_114_95_95_47_2_0,
		parse_tree__file_names__get_class_dir_name_2_0_i8);
MR_def_label(parse_tree__file_names__get_class_dir_name_2_0,8)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = MR_sv(1);
	MR_np_call_localret_ent(fn__f_100_105_114_95_95_47_2_0,
		parse_tree__file_names__get_class_dir_name_2_0_i9);
MR_def_label(parse_tree__file_names__get_class_dir_name_2_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_string_const("Mercury", 7);
	MR_np_call_localret_ent(fn__f_100_105_114_95_95_47_2_0,
		parse_tree__file_names__get_class_dir_name_2_0_i10);
MR_def_label(parse_tree__file_names__get_class_dir_name_2_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r2 = (MR_Word) MR_string_const("classs", 6);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(fn__f_100_105_114_95_95_47_2_0);
MR_def_label(parse_tree__file_names__get_class_dir_name_2_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,1)) {
		MR_GOTO_LAB(parse_tree__file_names__get_class_dir_name_2_0_i12);
	}
	MR_r1 = (MR_Word) MR_string_const("Mercury", 7);
	MR_r2 = (MR_Word) MR_string_const("classs", 6);
	MR_succip_word = MR_sv(3);
	MR_decr_sp(3);
	MR_np_tailcall_ent(fn__f_100_105_114_95_95_47_2_0);
MR_def_label(parse_tree__file_names__get_class_dir_name_2_0,12)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(".", 1);
	MR_decr_sp_and_return(3);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(parse_tree__file_names_module13)
	MR_init_entry1(__Unify___parse_tree__file_names__maybe_create_dirs_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___parse_tree__file_names__maybe_create_dirs_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___parse_tree__file_names__maybe_create_dirs_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_r1 == MR_r2);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(private_builtin__builtin_compare_int_3_0);

MR_BEGIN_MODULE(parse_tree__file_names_module14)
	MR_init_entry1(__Compare___parse_tree__file_names__maybe_create_dirs_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___parse_tree__file_names__maybe_create_dirs_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___parse_tree__file_names__maybe_create_dirs_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(private_builtin__builtin_compare_int_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(parse_tree__file_names_module15)
	MR_init_entry1(__Unify___parse_tree__file_names__maybe_search_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Unify___parse_tree__file_names__maybe_search_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Unify__'/2 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Unify___parse_tree__file_names__maybe_search_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_r1 == MR_r2);
	MR_proceed();
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(parse_tree__file_names_module16)
	MR_init_entry1(__Compare___parse_tree__file_names__maybe_search_0_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury____Compare___parse_tree__file_names__maybe_search_0_0);
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for '__Compare__'/3 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury____Compare___parse_tree__file_names__maybe_search_0_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_tailcall_ent(private_builtin__builtin_compare_int_3_0);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(parse_tree__file_names_module17)
	MR_init_entry1(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_97_99_116_95_116_97_98_108_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_8_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_97_99_116_95_116_97_98_108_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_8_0);
	MR_init_label1(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_97_99_116_95_116_97_98_108_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_8_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__fact_table_file_name__[2]_0'/8 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_97_99_116_95_116_97_98_108_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_8_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_sv(2) = MR_tempr1;
	MR_sv(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_97_99_116_95_116_97_98_108_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_8_0_i2);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_102_97_99_116_95_116_97_98_108_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_8_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Word) MR_tbmkword(0, 0);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(2);
	MR_r5 = (MR_Integer) 1;
	MR_r6 = MR_sv(3);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE


MR_BEGIN_MODULE(parse_tree__file_names_module18)
	MR_init_entry1(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_120_116_114_97_95_108_105_110_107_95_111_98_106_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_8_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_120_116_114_97_95_108_105_110_107_95_111_98_106_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_8_0);
	MR_init_label1(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_120_116_114_97_95_108_105_110_107_95_111_98_106_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_8_0,2)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__extra_link_obj_file_name__[2]_0'/8 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_define_entry(mercury__f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_120_116_114_97_95_108_105_110_107_95_111_98_106_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_8_0);
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(4);
	MR_sv(4) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r3;
	MR_sv(2) = MR_tempr1;
	MR_sv(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(fn__f_115_116_114_105_110_103_95_95_43_43_2_0,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_120_116_114_97_95_108_105_110_107_95_111_98_106_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_8_0_i2);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_101_120_116_114_97_95_108_105_110_107_95_111_98_106_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_8_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Word) MR_tbmkword(0, 0);
	MR_r3 = MR_tempr1;
	MR_r4 = MR_sv(2);
	MR_r5 = (MR_Integer) 1;
	MR_r6 = MR_sv(3);
	MR_succip_word = MR_sv(4);
	MR_decr_sp(4);
	MR_np_tailcall_ent(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0);
	}
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

MR_decl_entry(string__prefix_2_0);
MR_decl_entry(string__append_3_1);
MR_decl_entry(string__append_3_2);
MR_decl_entry(string__append_list_2_0);
MR_decl_entry(libs__compiler_util__unexpected_2_0);

MR_BEGIN_MODULE(parse_tree__file_names_module19)
	MR_init_entry1(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0);
	MR_INIT_PROC_LAYOUT_ADDR(mercury__f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0);
	MR_init_label10(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,2,3,4,5,9,10,11,6,15,16)
	MR_init_label10(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,20,25,26,27,28,22,30,31,17,18)
	MR_init_label10(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,36,40,45,46,44,49,13,56,54,61)
	MR_init_label10(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,62,63,64,65,66,67,68,69,70,71)
	MR_init_label10(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,72,73,74,75,76,77,78,79,80,81)
	MR_init_label10(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,82,83,84,85,86,87,88,89,90,91)
	MR_init_label10(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,92,93,94,95,96,97,59,100,99,102)
	MR_init_label10(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,51,106,105,104,111,112,113,114,115,116)
	MR_init_label10(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,117,118,119,110,109,123,122,128,130,127)
	MR_init_label10(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,134,140,139,138,143,145,142,147,153,162)
	MR_init_label1(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,166)
MR_BEGIN_CODE

/*-------------------------------------------------------------------------*/
/* code for 'UnusedArgs__pred__choose_file_name__[2]_0'/10 mode 0 */
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_local_thread_engine_base
#endif
MR_def_static(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_incr_sp(10);
	MR_sv(10) = (MR_Word) MR_succip;
	MR_sv(1) = MR_r1;
	MR_sv(2) = MR_r2;
	MR_sv(3) = MR_r3;
	MR_sv(4) = MR_r4;
	MR_sv(5) = MR_r5;
	MR_sv(6) = MR_r6;
	MR_r2 = (MR_Integer) 598;
	MR_np_call_localret_ent(libs__globals__lookup_bool_option_3_0,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i2);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,2)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Integer) 599;
	MR_np_call_localret_ent(libs__globals__lookup_bool_option_3_0,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i3);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,3)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(8) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Integer) 534;
	MR_np_call_localret_ent(libs__globals__lookup_string_option_3_0,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i4);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,4)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(9) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Integer) 533;
	MR_np_call_localret_ent(libs__globals__lookup_string_option_3_0,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i5);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,5)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(5),0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i6);
	}
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".hrl", 4)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i9);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_tempr2 = MR_tempr1;
	MR_decr_sp_and_return(10);
	}
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,9)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".mih", 4)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i10);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_tempr2 = MR_tempr1;
	MR_decr_sp_and_return(10);
	}
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,10)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".hrl.tmp", 8)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i11);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_tempr2 = MR_tempr1;
	MR_decr_sp_and_return(10);
	}
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,11)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".mih.tmp", 8)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i6);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_sv(3);
	MR_tempr2 = MR_tempr1;
	MR_decr_sp_and_return(10);
	}
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,6)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(7),0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i13);
	}
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Integer) 599;
	MR_np_call_localret_ent(libs__globals__lookup_bool_option_3_0,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i15);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,15)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = (MR_Integer) 598;
	MR_np_call_localret_ent(libs__globals__lookup_bool_option_3_0,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i16);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,16)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(7),1)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i18);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(4);
	MR_np_call_localret_ent(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i20);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,20)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i17);
	}
	if (MR_INT_NE(MR_sv(5),0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i22);
	}
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".opt", 4)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i25);
	}
	MR_r1 = MR_sv(1);
	MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i17);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,25)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".imdg", 5)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i26);
	}
	MR_r1 = MR_sv(1);
	MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i17);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,26)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".request", 8)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i27);
	}
	MR_r1 = MR_sv(1);
	MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i17);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,27)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".analysis", 9)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i28);
	}
	MR_r1 = MR_sv(1);
	MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i17);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,28)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".trans_opt", 10)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i22);
	}
	MR_r1 = MR_sv(1);
	MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i17);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,22)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(libs__handle_options__grade_directory_component_2_0,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i30);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,30)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_sv(1);
	MR_sv(1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Integer) 613;
	}
	MR_np_call_localret_ent(libs__globals__lookup_string_option_3_0,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i31);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,31)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_r3 = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = (MR_Word) MR_string_const("Mercury", 7);
	MR_tfield(1, MR_tempr1, 1) = MR_sv(2);
	MR_tag_alloc_heap(MR_tempr2, 1, (MR_Integer) 2);
	MR_r4 = MR_tempr2;
	MR_tfield(1, MR_tempr2, 0) = MR_r1;
	MR_tfield(1, MR_tempr2, 1) = MR_tempr1;
	MR_tag_alloc_heap(MR_tempr3, 1, (MR_Integer) 2);
	MR_r3 = MR_tempr3;
	MR_tfield(1, MR_tempr3, 0) = MR_sv(1);
	MR_tfield(1, MR_tempr3, 1) = MR_tempr2;
	MR_tag_alloc_heap(MR_tempr4, 1, (MR_Integer) 2);
	MR_sv(1) = MR_tempr4;
	MR_tfield(1, MR_tempr4, 0) = (MR_Word) MR_string_const("Mercury", 7);
	MR_tfield(1, MR_tempr4, 1) = MR_tempr3;
	MR_r1 = MR_sv(3);
	MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i40);
	}
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,17)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(7);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,18)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_r1,1)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i36);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_sv(1) = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = (MR_Word) MR_string_const("Mercury", 7);
	MR_tfield(1, MR_tempr1, 1) = MR_sv(2);
	MR_r1 = MR_sv(3);
	MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i40);
	}
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,36)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(3);
	MR_sv(1) = MR_sv(2);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,40)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_LTAGS_TEST(MR_sv(1),0,0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i166);
	}
	if (MR_INT_NE(MR_sv(6),0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i44);
	}
	MR_sv(3) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_np_call_localret_ent(fn__dir__relative_path_name_from_components_1_0,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i45);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,45)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_np_call_localret_ent(dir__make_directory_4_0,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i46);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,46)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_r3 = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = MR_sv(3);
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_r2 = MR_sv(1);
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	}
	MR_np_call_localret_ent(fn__f_108_105_115_116_95_95_43_43_2_0,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i49);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,44)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tag_alloc_heap(MR_tempr1, 1, (MR_Integer) 2);
	MR_r3 = MR_tempr1;
	MR_tfield(1, MR_tempr1, 0) = MR_r1;
	MR_tfield(1, MR_tempr1, 1) = (MR_Word) MR_tbmkword(0, 0);
	MR_r2 = MR_sv(1);
	MR_r1 = (MR_Word) MR_STRING_CTOR_ADDR;
	}
	MR_np_call_localret_ent(fn__f_108_105_115_116_95_95_43_43_2_0,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i49);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,49)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(10);
	MR_decr_sp(10);
	MR_np_tailcall_ent(fn__dir__relative_path_name_from_components_1_0);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,13)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_INT_NE(MR_sv(8),1)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i54);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r2 = MR_sv(4);
	MR_np_call_localret_ent(parse_tree__file_names__file_is_arch_or_grade_dependent_2_0,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i56);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,56)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (MR_r1) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i51);
	}
	MR_r1 = MR_sv(7);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,54)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const("", 0)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i61);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,61)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".a", 2)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i62);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,62)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".\044A", 3)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i63);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,63)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".mh", 3)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i64);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,64)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".so", 3)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i65);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,65)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".ss", 3)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i66);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,66)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".dll", 4)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i67);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,67)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".err", 4)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i68);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,68)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".exe", 4)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i69);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,69)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".ils", 4)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i70);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,70)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".jar", 4)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i71);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,71)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".erls", 5)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i72);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,72)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".init", 5)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i73);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,73)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".ints", 5)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i74);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,74)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".opts", 5)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i75);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,75)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".ugly", 5)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i76);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,76)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".beams", 6)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i77);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,77)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".check", 6)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i78);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,78)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".clean", 6)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i79);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,79)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".dylib", 6)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i80);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,80)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".int3s", 6)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i81);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,81)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".javas", 6)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i82);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,82)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".order", 6)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i83);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,83)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".depend", 7)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i84);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,84)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".mh.tmp", 7)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i85);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,85)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".pic_ss", 7)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i86);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,86)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".classes", 8)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i87);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,87)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".init.tmp", 9)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i88);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,88)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".hlds_dump", 10)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i89);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,89)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".mlds_dump", 10)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i90);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,90)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".realclean", 10)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i91);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,91)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".trans_opts", 11)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i92);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,92)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".install_hdrs", 13)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i93);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,93)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".install_ints", 13)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i94);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,94)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".install_opts", 13)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i95);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,95)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".dependency_graph", 17)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i96);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,96)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".install_grade_hdrs", 19)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i97);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,97)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".\044(EXT_FOR_SHARED_LIB)", 22)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i59);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,59)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(4);
	MR_r2 = (MR_Word) MR_string_const(".mih_dump", 9);
	MR_np_call_localret_ent(string__prefix_2_0,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i100);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,100)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i99);
	}
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,99)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(4);
	MR_r2 = (MR_Word) MR_string_const(".c_dump", 7);
	MR_np_call_localret_ent(string__prefix_2_0,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i102);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,102)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i51);
	}
	MR_r1 = MR_sv(3);
	MR_decr_sp_and_return(10);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,51)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = MR_sv(7);
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".dir/*.o", 8)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i106);
	}
	MR_r1 = MR_sv(1);
	MR_r5 = MR_sv(3);
	MR_r6 = MR_sv(4);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(6);
	MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i105);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,106)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".dir/*.\044O", 9)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i104);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r5 = MR_sv(3);
	MR_r6 = MR_sv(4);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(6);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,105)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = (MR_Word) MR_string_const("dirs", 4);
	MR_tfield(1, MR_r2, 1) = MR_sv(2);
	MR_succip_word = MR_sv(10);
	MR_decr_sp(10);
	MR_np_tailcall_ent(parse_tree__file_names__make_file_name_9_0);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,104)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".o", 2)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i111);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r5 = MR_sv(3);
	MR_r6 = MR_sv(4);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(6);
	MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i110);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,111)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".\044O", 3)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i112);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r5 = MR_sv(3);
	MR_r6 = MR_sv(4);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(6);
	MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i110);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,112)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".pic_o", 6)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i113);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r5 = MR_sv(3);
	MR_r6 = MR_sv(4);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(6);
	MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i110);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,113)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".lpic_o", 7)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i114);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r5 = MR_sv(3);
	MR_r6 = MR_sv(4);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(6);
	MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i110);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,114)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const("_init.o", 7)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i115);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r5 = MR_sv(3);
	MR_r6 = MR_sv(4);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(6);
	MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i110);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,115)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const("_init.\044O", 8)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i116);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r5 = MR_sv(3);
	MR_r6 = MR_sv(4);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(6);
	MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i110);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,116)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const("_init.pic_o", 11)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i117);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r5 = MR_sv(3);
	MR_r6 = MR_sv(4);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(6);
	MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i110);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,117)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const("_init.lpic_o", 12)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i118);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r5 = MR_sv(3);
	MR_r6 = MR_sv(4);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(6);
	MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i110);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,118)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const("\044(EXT_FOR_PIC_OBJECTS)", 22)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i119);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r5 = MR_sv(3);
	MR_r6 = MR_sv(4);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(6);
	MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i110);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,119)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const("_init.\044(EXT_FOR_PIC_OBJECTS)", 28)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i109);
	}
	MR_sv(7) = MR_r1;
	MR_r1 = MR_sv(1);
	MR_r5 = MR_sv(3);
	MR_r6 = MR_sv(4);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(6);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,110)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = (MR_Word) MR_string_const("os", 2);
	MR_tfield(1, MR_r2, 1) = MR_sv(2);
	MR_succip_word = MR_sv(10);
	MR_decr_sp(10);
	MR_np_tailcall_ent(parse_tree__file_names__make_file_name_9_0);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,109)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_sv(7) = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("_init.", 6);
	MR_r2 = MR_sv(4);
	MR_np_call_localret_ent(string__append_3_1,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i123);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,123)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i122);
	}
	MR_r1 = MR_r2;
	MR_r2 = (MR_Word) MR_string_const("s", 1);
	MR_np_call_localret_ent(string__append_3_2,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i145);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,122)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(".", 1);
	MR_r2 = MR_sv(4);
	MR_np_call_localret_ent(string__append_3_1,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i128);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,128)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i127);
	}
	MR_r1 = MR_r2;
	MR_r2 = (MR_Word) MR_string_const(".tmp", 4);
	MR_np_call_localret_ent(string__remove_suffix_3_0,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i130);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,130)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i127);
	}
	MR_r1 = MR_r2;
	MR_r2 = (MR_Word) MR_string_const("s", 1);
	MR_np_call_localret_ent(string__append_3_2,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i145);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,127)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const(".dv", 3)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i134);
	}
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = (MR_Word) MR_string_const("deps", 4);
	MR_tfield(1, MR_r2, 1) = MR_sv(2);
	MR_r1 = MR_sv(1);
	MR_r5 = MR_sv(3);
	MR_r6 = MR_sv(4);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(6);
	MR_succip_word = MR_sv(10);
	MR_decr_sp(10);
	MR_np_tailcall_ent(parse_tree__file_names__make_file_name_9_0);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,134)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), (char *) (MR_Word *) MR_sv(9)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i140);
	}
	MR_r1 = MR_sv(1);
	MR_r5 = MR_sv(3);
	MR_r6 = MR_sv(4);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(6);
	MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i139);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,140)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), (char *) (MR_Word *) MR_sv(7)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i138);
	}
	MR_r1 = MR_sv(1);
	MR_r5 = MR_sv(3);
	MR_r6 = MR_sv(4);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(6);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,139)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = (MR_Word) MR_string_const("lib", 3);
	MR_tfield(1, MR_r2, 1) = MR_sv(2);
	MR_succip_word = MR_sv(10);
	MR_decr_sp(10);
	MR_np_tailcall_ent(parse_tree__file_names__make_file_name_9_0);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,138)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_r1 = (MR_Word) MR_string_const(".", 1);
	MR_r2 = MR_sv(4);
	MR_np_call_localret_ent(string__append_3_1,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i143);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,143)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if (!(MR_r1)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i142);
	}
	MR_r1 = MR_r2;
	MR_r2 = (MR_Word) MR_string_const("s", 1);
	MR_np_call_localret_ent(string__append_3_2,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i145);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,145)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_r1;
	MR_tfield(1, MR_r2, 1) = MR_sv(2);
	MR_r1 = MR_sv(1);
	MR_r5 = MR_sv(3);
	MR_r6 = MR_sv(4);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(6);
	MR_succip_word = MR_sv(10);
	MR_decr_sp(10);
	MR_np_tailcall_ent(parse_tree__file_names__make_file_name_9_0);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,142)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	if ((strcmp((char *) (MR_Word *) MR_sv(4), MR_string_const("", 0)) != 0)) {
		MR_GOTO_LAB(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i147);
	}
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = (MR_Word) MR_string_const("bin", 3);
	MR_tfield(1, MR_r2, 1) = MR_sv(2);
	MR_r1 = MR_sv(1);
	MR_r5 = MR_sv(3);
	MR_r6 = MR_sv(4);
	MR_r3 = MR_sv(5);
	MR_r4 = MR_sv(6);
	MR_succip_word = MR_sv(10);
	MR_decr_sp(10);
	MR_np_tailcall_ent(parse_tree__file_names__make_file_name_9_0);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,147)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_tag_alloc_heap(MR_r2, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r2, 0) = MR_sv(4);
	MR_tfield(1, MR_r2, 1) = (MR_Word) MR_TAG_COMMON(1,0,1);
	MR_tag_alloc_heap(MR_r1, 1, (MR_Integer) 2);
	MR_tfield(1, MR_r1, 0) = (MR_Word) MR_string_const("unknown extension \140", 19);
	MR_tfield(1, MR_r1, 1) = MR_r2;
	MR_np_call_localret_ent(string__append_list_2_0,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i153);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,153)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("file_names.m", 12);
	MR_r2 = MR_tempr1;
	}
	MR_np_call_localret_ent(libs__compiler_util__unexpected_2_0,
		f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0_i162);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,162)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_succip_word = MR_sv(10);
	MR_decr_sp(10);
	MR_np_tailcall_ent(parse_tree__file_names__make_file_name_9_0);
MR_def_label(f_112_97_114_115_101_95_116_114_101_101_95_95_102_105_108_101_95_110_97_109_101_115_95_95_85_110_117_115_101_100_65_114_103_115_95_95_112_114_101_100_95_95_99_104_111_111_115_101_95_102_105_108_101_95_110_97_109_101_95_95_91_50_93_95_48_10_0,166)
	MR_MAYBE_INIT_LOCAL_THREAD_ENGINE_BASE
	MR_decr_sp_and_return(10);
#ifdef MR_maybe_local_thread_engine_base
	#undef MR_maybe_local_thread_engine_base
	#define MR_maybe_local_thread_engine_base MR_thread_engine_base
#endif
MR_END_MODULE

static void mercury__parse_tree__file_names_maybe_bunch_0(void)
{
	parse_tree__file_names_module0();
	parse_tree__file_names_module1();
	parse_tree__file_names_module2();
	parse_tree__file_names_module3();
	parse_tree__file_names_module4();
	parse_tree__file_names_module5();
	parse_tree__file_names_module6();
	parse_tree__file_names_module7();
	parse_tree__file_names_module8();
	parse_tree__file_names_module9();
	parse_tree__file_names_module10();
	parse_tree__file_names_module11();
	parse_tree__file_names_module12();
	parse_tree__file_names_module13();
	parse_tree__file_names_module14();
	parse_tree__file_names_module15();
	parse_tree__file_names_module16();
	parse_tree__file_names_module17();
	parse_tree__file_names_module18();
	parse_tree__file_names_module19();
}

/* suppress gcc -Wmissing-decls warnings */
void mercury__parse_tree__file_names__init(void);
void mercury__parse_tree__file_names__init_type_tables(void);
void mercury__parse_tree__file_names__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__parse_tree__file_names__write_out_proc_statics(FILE *deep_fp, FILE *procrep_fp);
#endif
#ifdef MR_RECORD_TERM_SIZES
void mercury__parse_tree__file_names__init_complexity_procs(void);
#endif

void mercury__parse_tree__file_names__init(void)
{
	static MR_bool done = MR_FALSE;
	if (done) {
		return;
	}
	done = MR_TRUE;
	mercury__parse_tree__file_names_maybe_bunch_0();
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_parse_tree__file_names__type_ctor_info_maybe_create_dirs_0,
		parse_tree__file_names__maybe_create_dirs_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_parse_tree__file_names__type_ctor_info_maybe_search_0,
		parse_tree__file_names__maybe_search_0_0);
	mercury__parse_tree__file_names__init_debugger();
}

void mercury__parse_tree__file_names__init_type_tables(void)
{
	static MR_bool done = MR_FALSE;
	if (done) {
		return;
	}
	done = MR_TRUE;
	{
		MR_register_type_ctor_info(
		&mercury_data_parse_tree__file_names__type_ctor_info_maybe_create_dirs_0);
	}
	{
		MR_register_type_ctor_info(
		&mercury_data_parse_tree__file_names__type_ctor_info_maybe_search_0);
	}
}


void mercury__parse_tree__file_names__init_debugger(void)
{
	static MR_bool done = MR_FALSE;
	if (done) {
		return;
	}
	done = MR_TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__parse_tree__file_names__write_out_proc_statics(FILE *deep_fp, FILE *procrep_fp)
{
	MR_write_out_module_proc_reps_start(procrep_fp, &mercury_data__module_common_layout__parse_tree__file_names);
	MR_write_out_module_proc_reps_end(procrep_fp);
}

#endif

#ifdef MR_RECORD_TERM_SIZES

void mercury__parse_tree__file_names__init_complexity_procs(void)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
