INTRODUCTION
============

This is a modified version Katana Native Interface (KNI, http://www.neuronics.ch)
used by Golem toolkit.	
	
The modification enables a reactive trajectory-based control of the Katana robotic
manipulator in place of a standard point-to-point paradigm. The modified KNI
also requires a custom Katana firmware which is attached to the package.

Because the newest KNI software has already built-in required firmware commands,
the modified KNI will not be required by Golem in future.


REQUIREMENTS
============

KNI has been design to work on Windows-based and Linux-based platforms,
and it has been tested on:

- Windows XP SP3 x86
- Windows 7 x64 SP1
- Ubuntu 10.04 32 bit

KNI requires Visual C++ 2008 on Windows platforms, or GNU C++ compiler
with cmake makefile tool on Linux platforms.


WINDOWS INSTALLATION
====================

KNI is distributed as a compressed file archive,
and it can be extracted in any convenient directory - for example in

	C:\Users\{user_name}\Documents\Projects

The VC++ project creates a static library, but it can can be easily reconfigured
for other build targets as well.


LINUX INSTALLATION
==================

There are loads of distributions of Linux around. This example shows how to
install KNI on Ubuntu 10.04.


1. Installation of GNU C++ compiler and cmake

Make sure that GNU C++ compiler and cmake are already installed on the system -
if not, they can be installed using Synaptic Package Manager. Packages names are:

	g++
	cmake
	cmake-curses-gui


2. Installation of KNI.

- extract the KNI file archive in any convenient directory - for example in
	
	/home/{user_name}/Documents/Projects

- create a temporary build directory e.g. "BUILD" in the cmake directory:
	
	mkdir /home/{user_name}/Documents/Projects/KNI/compiler/cmake/default/BUILD

- enter the build directory directory and run cmake in wizard mode:
	
	cd /home/{user_name}/Documents/Projects/KNI/compiler/cmake/default/BUILD
	ccmake -i ..

- press [c] to configure cmake and then edit cmake variables if necessary:
	
	CMAKE_INSTALL_PREFIX - the default installation directory for libraries and header files
	LIBRARY_OUTPUT_PATH - the default output directory for building libraries
	EXECUTABLE_OUTPUT_PATH - the default output directory for building executables

- press again [c] and then [g] to generate makefiles and exit cmake

- run make and make install to build and install KNI

	make
	make install
	
  To install files administrator priviliges may be required, so:
  
	make
	sudo make install


FIRMWARE INSTALLATION
=====================

Firmware upload is optional and required only when working with a real
(not virtual) Katana arm. The firmware can be found in

	C:\Users\{user_name}\Documents\Projects\KNI\resources\firmware\{firmware_version}\

All Katana joint motors require the same firmware image

	normalmotor-v2.1.hex

Firmware can be uploaded using Firmware Loader from Neuronics.
For details please refer to the Firmware Loader documentation.

